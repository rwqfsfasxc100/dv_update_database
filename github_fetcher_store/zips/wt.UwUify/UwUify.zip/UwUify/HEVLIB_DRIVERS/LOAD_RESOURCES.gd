extends Node

const LOAD_RESOURCES = {
	"menu/Language.gd": {"load_type": "script"}
}
