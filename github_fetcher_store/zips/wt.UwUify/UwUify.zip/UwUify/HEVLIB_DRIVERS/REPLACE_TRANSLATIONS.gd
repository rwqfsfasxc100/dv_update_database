# File-based translations using HevLib Driver system (1.11.3+)
# Config-locked: each category only loads if its config option is enabled

const TRANSLATIONS = {
	"file": {
		# Always load config translations
		"res://UwUify/i18n/config.txt": "|",
		
		# Dialogue
		"res://UwUify/i18n/dialogue.txt": {
			"string": "|",
			"mod": "UwUify",
			"section": "UwUify_CONFIG_OPTIONS",
			"setting": "EnableDialogue"
		},
		
		# Equipment
		"res://UwUify/i18n/equipment_descriptions.txt": {
			"string": "|",
			"mod": "UwUify",
			"section": "UwUify_CONFIG_OPTIONS",
			"setting": "EnableEquipment"
		},
		"res://UwUify/i18n/equipment_manuals.txt": {
			"string": "|",
			"mod": "UwUify",
			"section": "UwUify_CONFIG_OPTIONS",
			"setting": "EnableEquipment"
		},
		"res://UwUify/i18n/equipment_names.txt": {
			"string": "|",
			"mod": "UwUify",
			"section": "UwUify_CONFIG_OPTIONS",
			"setting": "EnableEquipment"
		},
		"res://UwUify/i18n/equipment_specs.txt": {
			"string": "|",
			"mod": "UwUify",
			"section": "UwUify_CONFIG_OPTIONS",
			"setting": "EnableEquipment"
		},
		
		# UI
		"res://UwUify/i18n/hud.txt": {
			"string": "|",
			"mod": "UwUify",
			"section": "UwUify_CONFIG_OPTIONS",
			"setting": "EnableUI"
		},
		"res://UwUify/i18n/ui.txt": {
			"string": "|",
			"mod": "UwUify",
			"section": "UwUify_CONFIG_OPTIONS",
			"setting": "EnableUI"
		},
		
		# Tooltips
		"res://UwUify/i18n/tooltips.txt": {
			"string": "|",
			"mod": "UwUify",
			"section": "UwUify_CONFIG_OPTIONS",
			"setting": "EnableTooltips"
		},
		
		# World
		"res://UwUify/i18n/misc.txt": {
			"string": "|",
			"mod": "UwUify",
			"section": "UwUify_CONFIG_OPTIONS",
			"setting": "EnableWorld"
		},
		"res://UwUify/i18n/oddities.txt": {
			"string": "|",
			"mod": "UwUify",
			"section": "UwUify_CONFIG_OPTIONS",
			"setting": "EnableWorld"
		},
		"res://UwUify/i18n/poi.txt": {
			"string": "|",
			"mod": "UwUify",
			"section": "UwUify_CONFIG_OPTIONS",
			"setting": "EnableWorld"
		},
		"res://UwUify/i18n/services.txt": {
			"string": "|",
			"mod": "UwUify",
			"section": "UwUify_CONFIG_OPTIONS",
			"setting": "EnableWorld"
		},
		
		# Tips
		"res://UwUify/i18n/tips.txt": {
			"string": "|",
			"mod": "UwUify",
			"section": "UwUify_CONFIG_OPTIONS",
			"setting": "EnableTips"
		},
		
		# Tunes
		"res://UwUify/i18n/tunes.txt": {
			"string": "|",
			"mod": "UwUify",
			"section": "UwUify_CONFIG_OPTIONS",
			"setting": "EnableTunes"
		},
		
		# Ships
		"res://UwUify/i18n/ship_descriptions.txt": {
			"string": "|",
			"mod": "UwUify",
			"section": "UwUify_CONFIG_OPTIONS",
			"setting": "EnableShips"
		},
		"res://UwUify/i18n/ship_names.txt": {
			"string": "|",
			"mod": "UwUify",
			"section": "UwUify_CONFIG_OPTIONS",
			"setting": "EnableShips"
		},
		"res://UwUify/i18n/ship_specs.txt": {
			"string": "|",
			"mod": "UwUify",
			"section": "UwUify_CONFIG_OPTIONS",
			"setting": "EnableShips"
		}
	}
}

