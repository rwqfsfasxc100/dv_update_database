extends Node

# Set mod priority if you want it to load before/after other mods
# Mods are loaded from lowest to highest priority, default is 0
const MOD_PRIORITY = -1
# Name of the mod, used for writing to the logs
const MOD_NAME = "Velocity Plus"
const MOD_VERSION_MAJOR = 1
const MOD_VERSION_MINOR = 5
const MOD_VERSION_BUGFIX = 9
const MOD_VERSION_METADATA = ""
const MOD_IS_LIBRARY = false
var modPath:String = get_script().resource_path.get_base_dir() + "/"
var _savedObjects := []
var ADD_EQUIPMENT_ITEMS = []
var check
var config = {}
var d = Directory.new()
var correct = d.file_exists("res://HevLib/pointers.gd")
var pointers = null
func _init(modLoader = ModLoader):
	if correct:
		pointers = load("res://HevLib/pointers.gd").new()
		l("Initializing DLC")
		loadDLC()
		
		var mp = self.get_script().get_path()
		var md = mp.split(mp.split("/")[mp.split("/").size() - 1])[0]
		var mc = load(md + "mod_checker_script.tscn").instance()
		add_child(mc)
		
		config = pointers.ConfigDriver.__get_config("VelocityPlus")
		
		installScriptExtension("MicrowavesMeltOre/emp.gd")
		installScriptExtension("MVFSShaderStyles/SimulationLayer.gd")
		installScriptExtension("VariatedBroadcasts/ConversationPlayer.gd")
		installScriptExtension("CrewHider/CrewFaceOnEnceladus.gd")
		installScriptExtension("CrewHider/RestricedCrewList.gd")
		installScriptExtension("RemoveRingLimits/Escape Veloity.gd")
		installScriptExtension("RemoveRingLimits/Leaving Rings.gd")
		installScriptExtension("RemoveRingLimits/ship-ctrl.gd")
		installScriptExtension("TurretOverrides/PDT.gd")
		installScriptExtension("RemoveWeaponGimbals/PDT.gd")
		replaceScene("ShowMarketValue/MineralMarket.tscn","res://enceladus/MineralMarket.tscn") # Fixes issue #5033 ; https://git.kodera.pl/games/delta-v/-/issues/5033
		replaceScene("ScoopExtraReturnDialogue/DIALOG_SCOOP_RETURNING_1.tscn","res://comms/conversation/subtrees/DIALOG_SCOOP_RETURNING_1.tscn")
		installScriptExtension("HideUndamagedEquipment/SystemShipRepairUI.gd")
		installScriptExtension("BetterTooltips/DoTradeIn.gd")
		replaceScene("BetterTooltips/SystemShipRepairUI.tscn","res://enceladus/SystemShipRepairUI.tscn")
		installScriptExtension("AchievementEnabler/AchievementAbstract.gd")
		installScriptExtension("ExtendedCrewIdentificationLimits/AutopilotOverlay.gd")
		installScriptExtension("ArmTargetToAutopilot/DockingArm.gd")
		installScriptExtension("DisplayNegativeDepth/ship-ctrl.gd")
		installScriptExtension("ExtraOMSDisplays/OMS.gd")
		installScriptExtension("ExtraOMSDisplays/CurrentGame.gd")
		installScriptExtension("ExtraOMSDisplays/ship-ctrl.gd")
		installScriptExtension("ShowEquipmentReliability/Upgrades.gd")
		installScriptExtension("PilotsReduceAstrogationCalcTime/ship-ctrl.gd")
		installScriptExtension("ScoopAutoReturnProtocol/ship-ctrl.gd")
		installScriptExtension("DisablePilotAutoAdrenaline/ship-ctrl.gd")
		installScriptExtension("ToggleSystemsAtEnceladus/SystemList.gd")
		installScriptExtension("ToggleSystemsAtEnceladus/Tuning.gd")
		installScriptExtension("ToggleSystemsAtEnceladus/ship-ctrl.gd")
		installScriptExtension("MaxAstrogatorTrackingTime/CurrentGame.gd")
		installScriptExtension("DisableMaintDroneSanBUS/drone-plant.gd")
		installScriptExtension("TemperatureBasedThrust/thruster.gd")
		installScriptExtension("NaturalTimeSkip/CurrentGame.gd")
		installScriptExtension("AutoRepairs/Repairs.gd")
		if config.get("VP_SHIPS",{}).get("fix_voyager_MPU_in_OCP",true):
			replaceScene("OCPVoyagerFix/ocp-209.tscn","res://ships/ocp-209.tscn")
		installScriptExtension("StationTransferSpeed/TradingHub.gd")


var cradle_left = {
	"system":"SYSTEM_CRADLE-L",
	"name_override":"SYSTEM_CRADLE",
	"manual":"SYSTEM_CRADLE_MANUAL",
	"specs":"SYSTEM_CRADLE_SPECS",
	"price":2500,
	"alignment":"ALIGNMENT_LEFT",
	"test_protocol":"detach",
	"equipment_type":"EQUIPMENT_CARGO_CONTAINER",
	"slot_type":"HARDPOINT"
}
var cradle_right = {
	"system":"SYSTEM_CRADLE-R",
	"name_override":"SYSTEM_CRADLE",
	"manual":"SYSTEM_CRADLE_MANUAL",
	"specs":"SYSTEM_CRADLE_SPECS",
	"price":2500,
	"alignment":"ALIGNMENT_RIGHT",
	"test_protocol":"detach",
	"equipment_type":"EQUIPMENT_CARGO_CONTAINER", 
	"slot_type":"HARDPOINT"
}

func _ready():
	l("Readying")
	
	if d.file_exists("res://HevLib/ModMain.gd"):
		if config.get("VP_ENCELADUS",{}).get("add_empty_cradle_equipment",true): # Implementation for issue #5133 ; https://git.kodera.pl/games/delta-v/-/issues/5133
			addEquipmentItem(cradle_left)
			addEquipmentItem(cradle_right)
#		var WebTranslate = load("res://HevLib/pointers/WebTranslate.gd")
#		var fallback = [
#			modPath + "i18n/en_ends.txt",
#			modPath + "i18n/en_60.txt",
#			modPath + "i18n/en_45.txt",
#			modPath + "i18n/en_30.txt",
#			modPath + "i18n/en_1.txt",
#			modPath + "i18n/en.txt",
#		]
#		WebTranslate.__webtranslate("https://github.com/rwqfsfasxc100/VelocityPlus",fallback, "res://VelocityPlus/ModMain.gd")
#	else:
	
	
	l("Ready")


func updateTL(path:String, delim:String = ",", useRelativePath:bool = true, fullLogging:bool = true):
	if useRelativePath:
		path = str(modPath + path)
	l("Adding translations from: %s" % path)
	var tlFile:File = File.new()
	var err = tlFile.open(path, File.READ)
	
	if err != OK:
		return
	
	var translations := []
	
	var translationCount = 0
	var csvLine := tlFile.get_line().split(delim)
	
	if fullLogging:
		l("Adding translations as: %s" % csvLine)
	for i in range(1, csvLine.size()):
		var translationObject := Translation.new()
		translationObject.locale = csvLine[i]
		translations.append(translationObject)
	
	while not tlFile.eof_reached():
		var line = tlFile.get_line()
		if line.begins_with("#"):
			continue
		csvLine = line.split(delim)
		var size = csvLine.size()
		if size > 1:
			if size > 2:
				var i = 0
				while i < size:
					if csvLine[i].ends_with("\\") and i < size:
						csvLine[i] = csvLine[i].rstrip("\\") + delim + csvLine[i + 1]
						csvLine.remove(i + 1)
						size -= 1
					i += 1
			var translationID := csvLine[0]
			for i in range(1, size):
				translations[i - 1].add_message(translationID, csvLine[i].c_unescape())
			if fullLogging:
				l("Added translation: %s" % csvLine)
			translationCount += 1
	
	tlFile.close()
	
	for translationObject in translations:
		TranslationServer.add_translation(translationObject)
	l("%s Translations Updated" % translationCount)

func installScriptExtension(path:String):
	var childPath:String = str(modPath + path)
	var childScript:Script = load(childPath)

	childScript.new()

	var parentScript:Script = childScript.get_base_script()
	var parentPath:String = parentScript.resource_path

	l("Installing script extension: %s <- %s" % [parentPath, childPath])

	childScript.take_over_path(parentPath)

func replaceScene(newPath:String, oldPath:String = ""):
	l("Updating scene: %s" % newPath)

	if oldPath.empty():
		oldPath = str("res://" + newPath)

	newPath = str(modPath + newPath)

	var scene := load(newPath)
	scene.take_over_path(oldPath)
	_savedObjects.append(scene)
	l("Finished updating: %s" % oldPath)

func loadDLC():
	l("Preloading DLC as workaround")
	var DLCLoader:Settings = preload("res://Settings.gd").new()
	DLCLoader.loadDLC()
	DLCLoader.queue_free()
	l("Finished loading DLC")

func l(msg:String, title:String = MOD_NAME, version:String = str(MOD_VERSION_MAJOR) + "." + str(MOD_VERSION_MINOR) + "." + str(MOD_VERSION_BUGFIX)):
	if not MOD_VERSION_METADATA == "":
		version = version + "-" + MOD_VERSION_METADATA
	Debug.l("[%s V%s]: %s" % [title, version, msg])

# Helper function that formats and appends the data provided to the variant
func addEquipmentItem(item_data: Dictionary):
	var Equipment = load("res://HevLib/pointers/Equipment.gd")
#	var equipment = Equipment.__make_equipment(item_data)
	ADD_EQUIPMENT_ITEMS.append(item_data)
