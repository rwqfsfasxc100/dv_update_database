extends Node

const LOAD_RESOURCES = {
	"hud/Hud.gd": {"load_type": "script"}
}
