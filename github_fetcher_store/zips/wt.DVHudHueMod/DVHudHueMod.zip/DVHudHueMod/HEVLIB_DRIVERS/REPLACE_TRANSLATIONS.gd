# This translation file is generated automatically
# Do not modify anything directly, as this can break things for those working on them
# Please use Translation Tracker to modify these yourself, and contact the mod author to implement them
# https://github.com/rwqfsfasxc100/TranslationTracker/releases/latest

# [license]
# 3-Clause BSD NON-AI License
# 
# Copyright 2026 WT (Oleksandr Hladyr)
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, the training of, or improvment of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form in an AI-training dataset is considered a breach of this License.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

const TRANSLATIONS = {
	"master_locale": "en",
	"en": {
		"DVHUDHUEMOD_MOD_DESCRIPTION": {
			"string": "Grants the option to independently modify each three LCh parameters of the three R.G.B. channels in the in-ring HUD/UI.",
			"version_hash": 2353744967
		},
		"DVHUDHUEMOD_MOD_BRIEF": {
			"string": "Per-channel LCh HUD Recolor Mod",
			"version_hash": 2314930112
		},
		"DVHUDHUE_OPTIONS": {
			"string": "DVHudHueMod Settings",
			"version_hash": 843070931
		},
		"DVHUDHUE_COLOR_SPACE_NAME": {
			"string": "Color Space",
			"version_hash": 3229501264
		},
		"DVHUDHUE_COLOR_SPACE_DESC": {
			"string": "Select color space algorithm",
			"version_hash": 855771991
		},
		"DVHUDHUE_OVERLAP_NAME": {
			"string": "Overlap",
			"version_hash": 3751615902
		},
		"DVHUDHUE_OVERLAP_DESC": {
			"string": "Color range overlap bleeding percentage (0 to 100)",
			"version_hash": 2885609303
		},
		"DVHUDHUE_LIGHTNESS_MODE_NAME": {
			"string": "Lightness Mode",
			"version_hash": 3428530139
		},
		"DVHUDHUE_LIGHTNESS_MODE_DESC": {
			"string": "HDR preserves neon glows. Clamp strictly blends towards pure white/black (GIMP).",
			"version_hash": 177636296
		},
		"DVHUDHUE_MASTER_LIGHTNESS_NAME": {
			"string": "Master Channel - Lightness",
			"version_hash": 2753517032
		},
		"DVHUDHUE_MASTER_LIGHTNESS_DESC": {
			"string": "Lightness multiplier for Master channel (0.0 to 2.0)",
			"version_hash": 140443547
		},
		"DVHUDHUE_MASTER_CHROMA_NAME": {
			"string": "Master Channel - Chroma / Saturation",
			"version_hash": 1583722698
		},
		"DVHUDHUE_MASTER_CHROMA_DESC": {
			"string": "Chroma multiplier for Master channel (0.0 to 2.0)",
			"version_hash": 1278449092
		},
		"DVHUDHUE_MASTER_HUE_NAME": {
			"string": "Master Channel - Hue Shift",
			"version_hash": 2701345303
		},
		"DVHUDHUE_MASTER_HUE_DESC": {
			"string": "Hue rotation for Master channel in degrees (-180 to 180)",
			"version_hash": 3148300876
		},
		"DVHUDHUE_R_LIGHTNESS_NAME": {
			"string": "Red Channel - Lightness",
			"version_hash": 701288439
		},
		"DVHUDHUE_R_LIGHTNESS_DESC": {
			"string": "Lightness multiplier for Red channel (0.0 to 2.0)",
			"version_hash": 3135391722
		},
		"DVHUDHUE_R_CHROMA_NAME": {
			"string": "Red Channel - Chroma / Saturation",
			"version_hash": 2669824409
		},
		"DVHUDHUE_R_CHROMA_DESC": {
			"string": "Chroma multiplier for Red channel (0.0 to 2.0)",
			"version_hash": 2595579571
		},
		"DVHUDHUE_R_HUE_NAME": {
			"string": "Red Channel - Hue Shift",
			"version_hash": 649116710
		},
		"DVHUDHUE_R_HUE_DESC": {
			"string": "Hue rotation for Red channel in degrees (-180 to 180)",
			"version_hash": 2216456027
		},
		"DVHUDHUE_Y_LIGHTNESS_NAME": {
			"string": "Yellow Channel - Lightness",
			"version_hash": 2953682968
		},
		"DVHUDHUE_Y_LIGHTNESS_DESC": {
			"string": "Lightness multiplier for Yellow channel (0.0 to 2.0)",
			"version_hash": 2450952139
		},
		"DVHUDHUE_Y_CHROMA_NAME": {
			"string": "Yellow Channel - Chroma / Saturation",
			"version_hash": 2040166138
		},
		"DVHUDHUE_Y_CHROMA_DESC": {
			"string": "Chroma multiplier for Yellow channel (0.0 to 2.0)",
			"version_hash": 3588957684
		},
		"DVHUDHUE_Y_HUE_NAME": {
			"string": "Yellow Channel - Hue Shift",
			"version_hash": 2901511239
		},
		"DVHUDHUE_Y_HUE_DESC": {
			"string": "Hue rotation for Yellow channel in degrees (-180 to 180)",
			"version_hash": 3876100732
		},
		"DVHUDHUE_G_LIGHTNESS_NAME": {
			"string": "Green Channel - Lightness",
			"version_hash": 2718876685
		},
		"DVHUDHUE_G_LIGHTNESS_DESC": {
			"string": "Lightness multiplier for Green channel (0.0 to 2.0)",
			"version_hash": 182368896
		},
		"DVHUDHUE_G_CHROMA_NAME": {
			"string": "Green Channel - Chroma / Saturation",
			"version_hash": 4015837487
		},
		"DVHUDHUE_G_CHROMA_DESC": {
			"string": "Chroma multiplier for Green channel (0.0 to 2.0)",
			"version_hash": 737456009
		},
		"DVHUDHUE_G_HUE_NAME": {
			"string": "Green Channel - Hue Shift",
			"version_hash": 2666704956
		},
		"DVHUDHUE_G_HUE_DESC": {
			"string": "Hue rotation for Green channel in degrees (-180 to 180)",
			"version_hash": 2502300017
		},
		"DVHUDHUE_C_LIGHTNESS_NAME": {
			"string": "Cyan Channel - Lightness",
			"version_hash": 1524344679
		},
		"DVHUDHUE_C_LIGHTNESS_DESC": {
			"string": "Lightness multiplier for Cyan channel (0.0 to 2.0)",
			"version_hash": 3618245946
		},
		"DVHUDHUE_C_CHROMA_NAME": {
			"string": "Cyan Channel - Chroma / Saturation",
			"version_hash": 779693321
		},
		"DVHUDHUE_C_CHROMA_DESC": {
			"string": "Chroma multiplier for Cyan channel (0.0 to 2.0)",
			"version_hash": 2984314147
		},
		"DVHUDHUE_C_HUE_NAME": {
			"string": "Cyan Channel - Hue Shift",
			"version_hash": 1472172950
		},
		"DVHUDHUE_C_HUE_DESC": {
			"string": "Hue rotation for Cyan channel in degrees (-180 to 180)",
			"version_hash": 2071873515
		},
		"DVHUDHUE_B_LIGHTNESS_NAME": {
			"string": "Blue Channel - Lightness",
			"version_hash": 2100963012
		},
		"DVHUDHUE_B_LIGHTNESS_DESC": {
			"string": "Lightness multiplier for Blue channel (0.0 to 2.0)",
			"version_hash": 1171814455
		},
		"DVHUDHUE_B_CHROMA_NAME": {
			"string": "Blue Channel - Chroma / Saturation",
			"version_hash": 3471852710
		},
		"DVHUDHUE_B_CHROMA_DESC": {
			"string": "Chroma multiplier for Blue channel (0.0 to 2.0)",
			"version_hash": 537882656
		},
		"DVHUDHUE_B_HUE_NAME": {
			"string": "Blue Channel - Hue Shift",
			"version_hash": 2048791283
		},
		"DVHUDHUE_B_HUE_DESC": {
			"string": "Hue rotation for Blue channel in degrees (-180 to 180)",
			"version_hash": 1770526312
		},
		"DVHUDHUE_M_LIGHTNESS_NAME": {
			"string": "Magenta Channel - Lightness",
			"version_hash": 2478961081
		},
		"DVHUDHUE_M_LIGHTNESS_DESC": {
			"string": "Lightness multiplier for Magenta channel (0.0 to 2.0)",
			"version_hash": 3512830316
		},
		"DVHUDHUE_M_CHROMA_NAME": {
			"string": "Magenta Channel - Chroma / Saturation",
			"version_hash": 3270903259
		},
		"DVHUDHUE_M_CHROMA_DESC": {
			"string": "Chroma multiplier for Magenta channel (0.0 to 2.0)",
			"version_hash": 2412307637
		},
		"DVHUDHUE_M_HUE_NAME": {
			"string": "Magenta Channel - Hue Shift",
			"version_hash": 2426789352
		},
		"DVHUDHUE_M_HUE_DESC": {
			"string": "Hue rotation for Magenta channel in degrees (-180 to 180)",
			"version_hash": 976150749
		}
	}
}
