# This translation file is generated automatically
# Do not modify anything directly, as this can break things for those working on them
# Please use Translation Tracker to modify these yourself, and contact the mod author to implement them
# https://github.com/rwqfsfasxc100/TranslationTracker/releases/latest

const TRANSLATIONS = {
	"master_locale": "en",
	"en": {
		"DVHUDHUEMOD_MOD_DESCRIPTION": {
			"string": "Grants the option to independently modify each three LCh parameters of the three R.G.B. channels in the in-ring HUD/UI.",
			"version_hash": 2353744967
		},
		"DVHUDHUEMOD_MOD_BRIEF": {
			"string": "Per-channel LCh HUD Recolor Mod",
			"version_hash": 2314930112
		},
		"DVHUDHUE_OPTIONS": {
			"string": "DVHudHueMod Settings",
			"version_hash": 843070931
		},
		"DVHUDHUE_COLOR_SPACE_NAME": {
			"string": "Color Space Mode",
			"version_hash": 445548565
		},
		"DVHUDHUE_COLOR_SPACE_DESC": {
			"string": "Select color space algorithm (HSV vs OKLCH perceptually uniform)",
			"version_hash": 3797318061
		},
		"DVHUDHUE_R_LIGHTNESS_NAME": {
			"string": "Red Channel - Lightness",
			"version_hash": 701288439
		},
		"DVHUDHUE_R_LIGHTNESS_DESC": {
			"string": "Lightness multiplier for Red channel (0.0 to 2.0)",
			"version_hash": 3135391722
		},
		"DVHUDHUE_R_CHROMA_NAME": {
			"string": "Red Channel - Chroma / Saturation",
			"version_hash": 2669824409
		},
		"DVHUDHUE_R_CHROMA_DESC": {
			"string": "Chroma multiplier for Red channel (0.0 to 2.0)",
			"version_hash": 2595579571
		},
		"DVHUDHUE_R_HUE_NAME": {
			"string": "Red Channel - Hue Shift",
			"version_hash": 649116710
		},
		"DVHUDHUE_R_HUE_DESC": {
			"string": "Hue rotation for Red channel in degrees (-180 to 180)",
			"version_hash": 2216456027
		},
		"DVHUDHUE_G_LIGHTNESS_NAME": {
			"string": "Green Channel - Lightness",
			"version_hash": 2718876685
		},
		"DVHUDHUE_G_LIGHTNESS_DESC": {
			"string": "Lightness multiplier for Green channel (0.0 to 2.0)",
			"version_hash": 182368896
		},
		"DVHUDHUE_G_CHROMA_NAME": {
			"string": "Green Channel - Chroma / Saturation",
			"version_hash": 4015837487
		},
		"DVHUDHUE_G_CHROMA_DESC": {
			"string": "Chroma multiplier for Green channel (0.0 to 2.0)",
			"version_hash": 737456009
		},
		"DVHUDHUE_G_HUE_NAME": {
			"string": "Green Channel - Hue Shift",
			"version_hash": 2666704956
		},
		"DVHUDHUE_G_HUE_DESC": {
			"string": "Hue rotation for Green channel in degrees (-180 to 180)",
			"version_hash": 2502300017
		},
		"DVHUDHUE_B_LIGHTNESS_NAME": {
			"string": "Blue Channel - Lightness",
			"version_hash": 2100963012
		},
		"DVHUDHUE_B_LIGHTNESS_DESC": {
			"string": "Lightness multiplier for Blue channel (0.0 to 2.0)",
			"version_hash": 1171814455
		},
		"DVHUDHUE_B_CHROMA_NAME": {
			"string": "Blue Channel - Chroma / Saturation",
			"version_hash": 3471852710
		},
		"DVHUDHUE_B_CHROMA_DESC": {
			"string": "Chroma multiplier for Blue channel (0.0 to 2.0)",
			"version_hash": 537882656
		},
		"DVHUDHUE_B_HUE_NAME": {
			"string": "Blue Channel - Hue Shift",
			"version_hash": 2048791283
		},
		"DVHUDHUE_B_HUE_DESC": {
			"string": "Hue rotation for Blue channel in degrees (-180 to 180)",
			"version_hash": 1770526312
		}
	}
}
