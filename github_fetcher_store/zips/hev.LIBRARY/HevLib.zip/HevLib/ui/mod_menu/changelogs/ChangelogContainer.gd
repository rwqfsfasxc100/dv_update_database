# [license]
# 3-Clause BSD NON-AI License
# 
# Copyright 2026 __hev (Benjamin Buckhurst)
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

extends VBoxContainer

var clearing = false

func parse(path:String,current_page:int,page_size:int,LEFT:Button,RIGHT:Button,refs:Array):
	var pointers:HevLibPointers = ModLoader._savedObjects[0]
	var header_label = load("res://HevLib/ui/mod_menu/changelogs/labels/version_label.tscn")
	var entry_label = load("res://HevLib/ui/mod_menu/changelogs/labels/changelog_entry.tscn")
	
	var data:Dictionary = pointers.ManifestV2.__parse_changelogs(path)
	
	var size = data.size()
	var offset = (current_page * page_size)
	var max_pages = int(ceil(float(size)/float(page_size))) - 1
	var keys = data.keys()
	LEFT.disabled = current_page < 1
	RIGHT.disabled = current_page > max_pages - 1
	for iv in clamp(size - offset,0,page_size):
		var config = keys[iv + offset]
		var lines = data[config]
		var header = header_label.instance()
		header.text = config
		if not clearing:
			refs.append(header)
			add_child(header)
		for l in lines:
			var label = entry_label.instance()
			var tex = TranslationServer.translate(l)
			label.text = tex
			if not clearing:
				refs.append(label)
				add_child(label)
			yield(CurrentGame.get_tree(),"idle_frame")
		yield(CurrentGame.get_tree(),"idle_frame")
