# [license]
# 3-Clause BSD NON-AI License
# 
# Copyright 2026 __hev (Benjamin Buckhurst)
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

const Tsukuyomi_Decom = {
	"name":"Tsukuyomi-Decom",
	"alias":"TSUKUYOMI",
	"specific_derelict_name":"IOER_DerelictTsukuyomi",
	"path":"res://IndustriesOfEnceladusRewrite/ships/Tsukuyomi-Decom.tscn",
	"config":{"config": {
		"ammo":{
			"capacity":100000.0, 
			"initial":100000.0, 
		}, 
		"autopilot":{
			"type":"SYSTEM_AUTOPILOT_MK3"
		}, 
		"capacitor":{
				"capacity":1500.0,
				"initial":1500.0
		}, 
		"cargo":{
			"equipment":"SYSTEM_CARGO_MPU",
			"aux":"SYSTEM_NONE",
			"modifierDivided":"SYSTEM_CARGO_MOD_2K"
		},
		"drones":{
			"initial":100000.0, 
			"capacity":100000.0, 
		}, 
		"fuel":{
			"capacity":500000.0, 
			"initial":500000.0
		}, 
		"propulsion":{
			"mainLarge":"SYSTEM_MAIN_ENGINE_ZURBIN", 
			"rcsLarge":"SYSTEM_MAIN_ENGINE_NDNTR",
		}, 
		"reactor":{"power":40.0}, 
		"shielding":{"emp":0.0}, 
		"turbine":{
			"capacity":500.0, 
			"power":500.0
		}, 
		"weaponSlot":{
			"left":{"type":"SYSTEM_NONE"}, 
			"right":{"type":"SYSTEM_NONE"}, 
			"middleLeft":{"type":"SYSTEM_NONE"}, 
			"middleRight":{"type":"SYSTEM_NONE"}, 
			"turretFrontLeft":{"type":"SYSTEM_NONE"}, 
			"turretFrontRight":{"type":"SYSTEM_NONE"},
			"leftBay2":{"type":"SYSTEM_NONE"}, 
			"rightBay2":{"type":"SYSTEM_NONE"},
			"leftBay3":{"type":"SYSTEM_NONE"}, 
			"rightBay3":{"type":"SYSTEM_NONE"},
		},
	}},
	"dealer":{
		"age":200,
		"weight":1,
	},
	"derelict":{
		"chance":0.1,
		"minimum_chance":0.1,
		"money":2000000,
		"stock_chance":0.2,
		"allow_damage":true,
		"cause_extra_damage":true,
		"rock_cluster_chance":0.3,
		"rock_cluster_count":33,
		"clump":false,
		"clump_velocity":25,
		"ring_storm_chance":0.3,
		"pirate_chance":0.3,
		"rescue":false,
		"chaos":0.65
	},
}

const AT225_STUB = {
	"name":"AT225-STUB",
	"alias":"AT225",
	"specific_derelict_name":"IOER_DerelictTitanStub",
	"path":"res://IndustriesOfEnceladusRewrite/ships/ATK225-Stub.tscn",
	"config":{"config": {
		"ammo": {
			"capacity": 1000.0,
			"initial": 1000.0
		},
		"autopilot": {"type":"SYSTEM_AUTOPILOT_MK2"},
		"capacitor":{"capacity":500.0}, 
		"cargo":{
			"equipment":"SYSTEM_CARGO_MPUFSO"
		}, 
		"fuel": {
			"capacity": 80000.0,
			"initial": 80000.0
		},
		"hud":{"type":"SYSTEM_HUD_AT225"}, 
		"propulsion":{
			"main":"SYSTEM_MAIN_ENGINE_BWMT535", 
			"rcs":"SYSTEM_THRUSTER_K37"
		}, 
		"reactor":{"power":16.0},
		"turbine":{"power":500.0},
		"weaponSlot":{
			"middleLeft":{"type":"SYSTEM_NONE"}, 
			"middleRight":{"type":"SYSTEM_EMD14"}, 
			"leftDrone":{"type":"SYSTEM_NONE"},
			"rightDrone":{"type":"SYSTEM_NONE"},
			"leftBay1":{"type":"SYSTEM_EXSTORAGE-L"}, 
			"leftBay3":{"type":"SYSTEM_EXSTORAGE-L"}, 
			"rightBay1":{"type":"SYSTEM_EXSTORAGE-R"}, 
			"rightBay3":{"type":"SYSTEM_EXSTORAGE-R"}, 
		}, 
	}},
	"dealer":{
		"age":60,
		"weight":2,
	},
	"derelict":{
		"chance":0.3,
		"minimum_chance":0.1,
		"money":2000000,
		"stock_chance":0.2,
		"allow_damage":true,
		"cause_extra_damage":true,
		"rock_cluster_chance":0.3,
		"rock_cluster_count":33,
		"clump":false,
		"clump_velocity":25,
		"ring_storm_chance":0.3,
		"pirate_chance":0.3,
		"rescue":false,
		"chaos":0.5
	},
	"miner":{
		"chaos":0.25
	},
}

const AT225_EIME = {
	"name":"IOE-AT225-EIME",
	"alias":"AT225",
	"specific_derelict_name":"IOER_DerelictTitanEIME",
	"path":"res://IndustriesOfEnceladusRewrite/ships/ATK225-EIME.tscn",
	"config":{"config": {
		"ammo": {
			"capacity": 1000.0,
			"initial": 1000.0
		},
		"autopilot": {"type":"SYSTEM_AUTOPILOT_MK2"},
		"capacitor":{"capacity":500.0}, 
		"cargo":{
			"equipment":"SYSTEM_CARGO_MPUFSO"
		}, 
		"fuel": {
			"capacity": 80000.0,
			"initial": 80000.0
		},
		"hud":{"type":"SYSTEM_HUD_AT225"}, 
		"propulsion":{
			"main":"SYSTEM_MAIN_ENGINE_BWMT535", 
			"rcs":"SYSTEM_THRUSTER_K37"
		}, 
		"reactor":{"power":16.0},
		"turbine":{"power":500.0},
		"weaponSlot":{
			"middleLeft":{"type":"SYSTEM_NONE"}, 
			"middleRight":{"type":"SYSTEM_EMD14"}, 
			"leftDrone":{"type":"SYSTEM_NONE"},
			"rightDrone":{"type":"SYSTEM_NONE"},
			"leftBay3":{"type":"SYSTEM_EXSTORAGE-L"}, 
			"rightBay3":{"type":"SYSTEM_EXSTORAGE-R"}, 
		}, 
	}},
	"dealer":{
		"age":60,
		"weight":1,
	},
	"derelict":{
		"chance":0.3,
		"minimum_chance":0.1,
		"money":2000000,
		"stock_chance":0.2,
		"allow_damage":true,
		"cause_extra_damage":true,
		"rock_cluster_chance":0.3,
		"rock_cluster_count":33,
		"clump":false,
		"clump_velocity":25,
		"ring_storm_chance":0.3,
		"pirate_chance":0.3,
		"rescue":false,
		"chaos":0.5
	},
	"miner":{
		"chaos":0.25
	},
}

const ATLAS_WASP = {
	"name":"ATLAS-WASP",
	"specific_derelict_name":"IOER_DerelictWasp",
	"path":"res://IndustriesOfEnceladusRewrite/ships/ATLAS-Wasp.tscn",
	"alias":"WASP",
	"config":{"config": {
		"ammo":{
			"capacity": 1000.0,
			"initial": 1000.0
		},
		"autopilot":{"type":"SYSTEM_AUTOPILOT_MK2"}, 
		"capacitor":{"capacity": 1500.0}, 
		"cargo":{
			"equipment":"SYSTEM_CARGO_STANDARD",
		},
		"fuel":{
			"capacity": 15000.0, 
			"initial": 15000.0, 
		}, 
		"propulsion":{
			"rcs":"SYSTEM_THRUSTER_GHET"
		}, 
		"reactor":{"power": 4.0},
		"shielding":{"emp": 320},  
		"turbine":{"power": 500.0},
		"weaponSlot":{
			"middleLeft":{"type":"SYSTEM_RAILTOR"}, 
			"middleRight":{"type":"SYSTEM_RAILTOR"}
		}, 
	}},
	"dealer":{
		"age":50,
		"weight":1,
	},
	"derelict":{
		"chance":0.4,
		"minimum_chance":0.1,
		"money":3000000,
		"stock_chance":0.2,
		"allow_damage":true,
		"cause_extra_damage":true,
		"rock_cluster_chance":0.3,
		"rock_cluster_count":33,
		"clump":false,
		"clump_velocity":25,
		"ring_storm_chance":0.3,
		"pirate_chance":0.3,
		"rescue":false,
		"chaos":0.4
	},
	"miner":{
		"chaos":0.25
	},
}

const COTHON_LUX = {
	"name":"COTHON-LUX",
	"specific_derelict_name":"IOER_DerelictCothonLux",
	"path":"res://IndustriesOfEnceladusRewrite/ships/Cothon-Lux.tscn",
	"alias":"COTHON",
	"config":{"config": {
		"ammo":{
			"capacity": 1000.0, 
			"initial": 1000.0, 
		}, 
		"autopilot":{"type":"SYSTEM_AUTOPILOT_MK2"}, 
		"capacitor":{"capacity": 500.0}, 
		"cargo":{
			"equipment":"SYSTEM_CARGO_STANDARD",
			"modifierDivided":"SYSTEM_CARGO_MOD_2K"
		},
		"fuel":{
			"capacity": 80000.0, 
			"initial": 80000.0, 
		}, 
		"propulsion":{
			"main":"SYSTEM_MAIN_ENGINE_PNTR", 
			"rcs":"SYSTEM_THRUSTER_NDSTR"
		}, 
		"reactor":{"power": 8.0},
		"shielding":{"emp": 100},  
		"turbine":{"power": 200.0}, 
		"weaponSlot":{
			"right":{"type":"SYSTEM_EMD14"}, 
			"left":{"type":"SYSTEM_NONE"}
		}, 
	}},
	"dealer":{
		"age":200,
		"weight":1,
	},
	"derelict":{
		"chance":0.4,
		"minimum_chance":0.1,
		"money":10000000,
		"stock_chance":0.2,
		"allow_damage":true,
		"cause_extra_damage":true,
		"rock_cluster_chance":0.3,
		"rock_cluster_count":33,
		"clump":false,
		"clump_velocity":25,
		"ring_storm_chance":0.3,
		"pirate_chance":0.3,
		"rescue":false,
		"chaos":0.3
	},
	"miner":{
		"chaos":0.0
	},
}

const PIGEON_PROSPECTOR = {
	"name":"PIGEON-PROSPECTOR",
	"specific_derelict_name":"IOER_DerelictPigeon",
	"path":"res://IndustriesOfEnceladusRewrite/ships/Eagle-Prospector-Pigeon.tscn",
	"alias":"PROSPECTOR",
	"config":{"config":{
		"ammo":{
			"capacity": 1000.0, 
			"initial": 1000.0, 
		}, 
		"autopilot":{"type":"SYSTEM_AUTOPILOT_MK2"}, 
		"fuel":{
			"capacity": 50000.0, 
			"initial": 50000.0, 
		}, 
		"propulsion":{
			"main":"SYSTEM_MAIN_ENGINE_K37", 
			"rcs":"SYSTEM_THRUSTER_K37"
		}, 
		"reactor":{	"power": 16.0},
		"turbine":{"power": 200.0}, 
		"weaponSlot":{
			"main": {"type":"SYSTEM_NONE"},
			"right":{"type":"SYSTEM_EMD14"}, 
			"left":{"type":"SYSTEM_EMD14"}
		}, 
	}},
	"dealer":{
		"age":80,
		"weight":1,
	},
	"derelict":{
		"chance":0.5,
		"minimum_chance":0.1,
		"money":10000000,
		"stock_chance":0.2,
		"allow_damage":true,
		"cause_extra_damage":true,
		"rock_cluster_chance":0.3,
		"rock_cluster_count":33,
		"clump":false,
		"clump_velocity":25,
		"ring_storm_chance":0.3,
		"pirate_chance":0.3,
		"rescue":false,
		"chaos":0.4
	},
	"miner":{
		"chaos":0.25
	},
}

const MAD_CERF_CIV = {
	"name":"MAD-CERF-CIV",
	"specific_derelict_name":"IOER_DerelictCERF",
	"path":"res://IndustriesOfEnceladusRewrite/ships/MAD-CERF-Civ.tscn",
	"alias":"MADCERF",
	"config":{"config": {
		"ammo":{
			"capacity":1000.0, 
			"initial":1000.0, 
		}, 
		"autopilot":{
			"type":"SYSTEM_AUTOPILOT_MK1"
		},
		"cargo":{
			"equipment":"SYSTEM_CARGO_STANDARD",
			"modifierDivided":"SYSTEM_NONE",
		},
		"capacitor":{"capacity":1000.0}, 
		"fuel":{
			"capacity":80000.0, 
			"initial":80000.0, 
		}, 
		"hud":{
			"type":"SYSTEM_HUD_CERF"
		}, 
		"propulsion":{
			"main":"SYSTEM_MAIN_ENGINE_CHEVAL", 
			"rcs":"SYSTEM_THRUSTER_MADTX4"
		}, 
		"aux":{
			"power":"SYSTEM_AUX_SMES_MK2"
		},
		"reactor":{	"power": 16.0},
		"turbine":{"power":200.0}, 
		"weaponSlot":{
			"middleLeft":{"type":"SYSTEM_EMD14"}, 
			"middleRight":{"type":"SYSTEM_EMD14"}, 
			"main":{"type":"SYSTEM_SALVAGE_ARM"}
		}, 
	}},
	"dealer":{
		"age":150,
		"weight":1,
	},
	"derelict":{
		"chance":0.4,
		"minimum_chance":0.1,
		"money":4000000,
		"stock_chance":0.2,
		"allow_damage":true,
		"cause_extra_damage":true,
		"rock_cluster_chance":0.3,
		"rock_cluster_count":33,
		"clump":false,
		"clump_velocity":25,
		"ring_storm_chance":0.3,
		"pirate_chance":0.3,
		"rescue":false,
		"chaos":0.4
	},
	"miner":{
		"chaos":0.4
	},
}

const MAD_CERF_CIV_INVERSE = {
	"name":"MAD-CERF-CIV-INVERSE",
	"specific_derelict_name":"IOER_DerelictCERFInverse",
	"path":"res://IndustriesOfEnceladusRewrite/ships/MAD-CERF-Civ-Inverse.tscn",
	"alias":"MADCERF",
	"config":{"config": {
		"ammo":{
			"capacity":1000.0, 
			"initial":1000.0, 
		}, 
		"autopilot":{
			"type":"SYSTEM_AUTOPILOT_MK1"
		},
		"cargo":{
			"equipment":"SYSTEM_CARGO_STANDARD",
			"modifierDivided":"SYSTEM_NONE",
		},
		"capacitor":{"capacity":1000.0}, 
		"fuel":{
			"capacity":80000.0, 
			"initial":80000.0, 
		}, 
		"hud":{
			"type":"SYSTEM_HUD_CERF"
		}, 
		"propulsion":{
			"main":"SYSTEM_MAIN_ENGINE_CHEVAL", 
			"rcs":"SYSTEM_THRUSTER_MADTX4"
		}, 
		"aux":{
			"power":"SYSTEM_AUX_SMES_MK2"
		},
		"reactor":{	"power": 16.0},
		"turbine":{"power":200.0}, 
		"weaponSlot":{
			"middleLeft":{"type":"SYSTEM_EMD14"}, 
			"middleRight":{"type":"SYSTEM_EMD14"}, 
			"main":{"type":"SYSTEM_SALVAGE_ARM"}
		}, 
	}},
	"dealer":{
		"age":130,
		"weight":1,
	},
	"derelict":{
		"chance":0.4,
		"minimum_chance":0.1,
		"money":4000000,
		"stock_chance":0.2,
		"allow_damage":true,
		"cause_extra_damage":true,
		"rock_cluster_chance":0.3,
		"rock_cluster_count":33,
		"clump":false,
		"clump_velocity":25,
		"ring_storm_chance":0.3,
		"pirate_chance":0.3,
		"rescue":false,
		"chaos":0.4
	},
	"miner":{
		"chaos":0.4
	},
}

const OBERON = {
	"name":"OBERON",
	"specific_derelict_name":"IOER_DerelictOberon",
	"path":"res://IndustriesOfEnceladusRewrite/ships/Oberon.tscn",
	"config":{"config": {
		"ammo":{
			"capacity":0.0, 
			"initial":0.0, 
		}, 
		"autopilot":{
			"type":"SYSTEM_AUTOPILOT_MK2"
		},  
		"capacitor":{
				"capacity":1500.0
		}, 
		"cargo":{
			"equipment":"SYSTEM_NONE",
			"modifierAmorphic":"SYSTEM_NONE"
		},
		"drones":{
			"initial":0.0, 
			"capacity":0.0, 
		}, 
		"fuel":{
			"capacity": 15000.0, 
			"initial": 15000.0, 
		}, 
		"propulsion":{
			"main":"SYSTEM_MAIN_ENGINE_K44", 
			"rcs":"SYSTEM_THRUSTER_K69V"
		}, 
		"reactor":{	"power": 30.0},
		"turbine":{
			"capacity":320.0, 
			"power":320.0
		}, 
		"weaponSlot": {
			"mainLeft":{"type":"SYSTEM_SALVAGE_ARM"},
			"mainRight":{"type":"SYSTEM_SALVAGE_ARM"},
		},
	}},
	"dealer":{
		"age":35,
		"weight":1,
	},
	"derelict":{
		"chance":0.2,
		"minimum_chance":0.1,
		"money":3000000,
		"stock_chance":0.2,
		"allow_damage":true,
		"cause_extra_damage":true,
		"rock_cluster_chance":0.3,
		"rock_cluster_count":33,
		"clump":false,
		"clump_velocity":25,
		"ring_storm_chance":0.3,
		"pirate_chance":0.3,
		"rescue":false,
		"chaos":0.6
	},
	"miner":{
		"chaos":0.4
	},
}

const OCP_DD = {
	"name":"OCP209-DD",
	"specific_derelict_name":"IOER_DerelictOCPDeepDish",
	"path":"res://IndustriesOfEnceladusRewrite/ships/OCP-209-DD.tscn",
	"alias":"OCP209",
	"config":{"config": {
		"ammo":{
			"capacity":0.0, 
			"initial":0.0, 
		}, 
		"autopilot":{
			"type":"SYSTEM_AUTOPILOT_MK1"
		},  
		"capacitor":{
				"capacity":1000.0
		}, 
		"cargo":{
			"equipment":"SYSTEM_CARGO_MPU",
			"aux":"SYSTEM_NONE",
			"modifierAmorphic":"SYSTEM_CARGO_MOD_2K"
		},
		"drones":{
			"initial":0.0, 
			"capacity":0.0, 
		}, 
		"fuel":{
			"capacity": 80000.0, 
			"initial": 80000.0, 
		}, 
		"propulsion":{
			"main":"SYSTEM_MAIN_ENGINE_K44", 
			"rcs":"SYSTEM_THRUSTER_MA150HO"
		}, 
		"reactor":{	"power": 16.0},
		"turbine":{
			"capacity":200.0, 
			"power":200.0
		}, 
		"weaponSlot": {
			"mainLeft":{"type":"SYSTEM_SALVAGE_ARM"},
			"mainRight":{"type":"SYSTEM_SALVAGE_ARM"},
			"middleLeft":{"type":"SYSTEM_PDMWG-L"},
			"middleRight":{"type":"SYSTEM_PDMWG-R"},
		},
	}},
	"dealer":{
		"age":75,
		"weight":1,
	},
	"derelict":{
		"chance":0.2,
		"minimum_chance":0.1,
		"money":2000000,
		"stock_chance":0.2,
		"allow_damage":true,
		"cause_extra_damage":true,
		"rock_cluster_chance":0.3,
		"rock_cluster_count":33,
		"clump":false,
		"clump_velocity":25,
		"ring_storm_chance":0.3,
		"pirate_chance":0.3,
		"rescue":false,
		"chaos":0.5
	},
	"miner":{
		"chaos":0.25
	},
}

const OCP_TWIN = {
	"name":"OCP213-TWIN",
	"specific_derelict_name":"IOER_DerelictOCPTwin",
	"path":"res://IndustriesOfEnceladusRewrite/ships/OCP-213-TWIN.tscn",
	"alias":"OCP209",
	"config":{"config": {
		"ammo":{
			"capacity":0.0, 
			"initial":0.0, 
		}, 
		"autopilot":{
			"type":"SYSTEM_AUTOPILOT_MK1"
		},  
		"capacitor":{
				"capacity":1000.0
		}, 
		"cargo":{
			"equipment":"SYSTEM_CARGO_MPU",
			"aux":"SYSTEM_NONE",
			"modifierAmorphic":"SYSTEM_CARGO_MOD_2K"
		},
		"drones":{
			"initial":0.0, 
			"capacity":0.0, 
		}, 
		"fuel":{
			"capacity": 80000.0, 
			"initial": 80000.0, 
		}, 
		"propulsion":{
			"main":"SYSTEM_MAIN_ENGINE_K44", 
			"rcs":"SYSTEM_THRUSTER_MA150HO"
		}, 
		"reactor":{	"power": 16.0},
		"turbine":{
			"capacity":200.0, 
			"power":200.0
		}, 
		"weaponSlot": {
			"mainLeft":{"type":"SYSTEM_SALVAGE_ARM"},
			"mainRight":{"type":"SYSTEM_SALVAGE_ARM"},
			"middleLeft":{"type":"SYSTEM_PDMWG"},
			"middleRight":{"type":"SYSTEM_PDMWG"},
		},
	}},
	"dealer":{
		"age":100,
		"weight":2
	},
	"derelict":{
		"chance":0.2,
		"minimum_chance":0.1,
		"money":2000000,
		"stock_chance":0.2,
		"allow_damage":true,
		"cause_extra_damage":true,
		"rock_cluster_chance":0.3,
		"rock_cluster_count":33,
		"clump":false,
		"clump_velocity":25,
		"ring_storm_chance":0.3,
		"pirate_chance":0.3,
		"rescue":false,
		"chaos":0.5
	},
	"miner":{
		"chaos":0.25
	},
}

const OCP_SNAP = {
	"name":"OCP209-SNAP",
	"specific_derelict_name":"IOER_DerelictOCPSnap",
	"path":"res://IndustriesOfEnceladusRewrite/ships/OCP-209-Snap.tscn",
	"alias":"OCP209",
	"config":{"config": {
		"ammo":{
			"capacity":0.0, 
			"initial":0.0, 
		}, 
		"autopilot":{
			"type":"SYSTEM_AUTOPILOT_MK1"
		},  
		"capacitor":{
				"capacity":1000.0
		}, 
		"cargo":{
			"equipment":"SYSTEM_CARGO_MPU",
			"modifierAmorphic":"SYSTEM_CARGO_MOD_2K"
		},
		"drones":{
			"initial":0.0, 
			"capacity":0.0, 
		}, 
		"fuel":{
			"capacity": 80000.0, 
			"initial": 80000.0, 
		}, 
		"propulsion":{
			"main":"SYSTEM_MAIN_ENGINE_K44", 
			"rcs":"SYSTEM_THRUSTER_MA150HO"
		}, 
		"reactor":{	"power": 16.0},
		"turbine":{
			"capacity":200.0, 
			"power":200.0
		}, 
		"weaponSlot": {
			"mainLeft":{"type":"SYSTEM_SALVAGE_ARM"},
			"mainRight":{"type":"SYSTEM_SALVAGE_ARM"},
			"middleLeft":{"type":"SYSTEM_PDMWG-L"},
			"middleRight":{"type":"SYSTEM_PDMWG-R"},
		},
	}},
	"dealer":{
		"age":100,
		"weight":1,
	},
	"derelict":{
		"chance":0.2,
		"minimum_chance":0.1,
		"money":2000000,
		"stock_chance":0.2,
		"allow_damage":true,
		"cause_extra_damage":true,
		"rock_cluster_chance":0.3,
		"rock_cluster_count":33,
		"clump":false,
		"clump_velocity":25,
		"ring_storm_chance":0.3,
		"pirate_chance":0.3,
		"rescue":false,
		"chaos":0.5
	},
	"miner":{
		"chaos":0.25
	},
}

const TRTL_OCP = {
	"name":"TRTL-OCP",
	"specific_derelict_name":"IOER_DerelictOK720",
	"path":"res://IndustriesOfEnceladusRewrite/ships/RA-TRTL-OCP.tscn",
	"alias":"TRTL",
	"config":{"config": {
		"ammo":{
			"capacity": 1000.0, 
			"initial": 1000.0, 
		}, 
		"autopilot":{"type":"SYSTEM_AUTOPILOT_MK1"}, 
		"capacitor":{"capacity": 500.0}, 
		"cargo":{
			"equipment":"SYSTEM_CARGO_STANDARD",
			"modifierDivided":"SYSTEM_CARGO_MOD_2K"
		},
		"fuel":{
			"capacity": 30000.0, 
			"initial": 30000.0, 
		}, 
		"propulsion":{
			"main":"SYSTEM_MAIN_ENGINE_K37", 
			"rcs":"SYSTEM_THRUSTER_K37"
		}, 
		"reactor":{	"power": 8.0},
		"turbine":{"power": 100.0}, 
		"weaponSlot":{
			"left": {"type":"SYSTEM_EMD14"},
			"right": {"type":"SYSTEM_EMD14"},
			"leftBack": {"type":"SYSTEM_NONE"},
			"rightBack": {"type":"SYSTEM_NONE"},
		}, 
	}},
	"dealer":{
		"age":60,
		"weight":1,
	},
	"derelict":{
		"chance":0.4,
		"minimum_chance":0.1,
		"money":5000000,
		"stock_chance":0.2,
		"allow_damage":true,
		"cause_extra_damage":true,
		"rock_cluster_chance":0.3,
		"rock_cluster_count":33,
		"clump":false,
		"clump_velocity":25,
		"ring_storm_chance":0.3,
		"pirate_chance":0.3,
		"rescue":false,
		"chaos":0.2
	},
	"miner":{
		"chaos":0.0
	},
}

const TRTL_PEEPER = {
	"name":"TRTL-PEEPER",
	"specific_derelict_name":"IOER_DerelictPeeper",
	"path":"res://IndustriesOfEnceladusRewrite/ships/RA-TRTL-PEEPER.tscn",
	"alias":"TRTL",
	"config":{"config": {
		"ammo":{
			"capacity": 1000.0, 
			"initial": 1000.0, 
		}, 
		"autopilot":{"type":"SYSTEM_AUTOPILOT_MK1"}, 
		"capacitor":{"capacity": 500.0}, 
		"cargo":{
			"equipment":"SYSTEM_CARGO_STANDARD",
			"modifierDivided":"SYSTEM_CARGO_MOD_2K"
		},
		"fuel":{
			"capacity": 30000.0, 
			"initial": 30000.0, 
		}, 
		"propulsion":{
			"main":"SYSTEM_MAIN_ENGINE_K37", 
			"rcs":"SYSTEM_THRUSTER_K37"
		}, 
		"reactor":{	"power": 8.0},
		"turbine":{"power": 100.0}, 
		"weaponSlot":{
			"left": {"type":"SYSTEM_EMD14"},
			"right": {"type":"SYSTEM_EMD14"},
			"leftBack": {"type":"SYSTEM_NONE"},
			"rightBack": {"type":"SYSTEM_NONE"},
		}, 
	}},
	"dealer":{
		"age":45,
		"weight":1,
	},
	"derelict":{
		"chance":0.4,
		"minimum_chance":0.1,
		"money":5000000,
		"stock_chance":0.2,
		"allow_damage":true,
		"cause_extra_damage":true,
		"rock_cluster_chance":0.3,
		"rock_cluster_count":33,
		"clump":false,
		"clump_velocity":25,
		"ring_storm_chance":0.3,
		"pirate_chance":0.3,
		"rescue":false,
		"chaos":0.2
	},
	"miner":{
		"chaos":0.0
	},
}

const TRTL_RAM = {
	"name":"TRTL-RAM",
	"specific_derelict_name":"IOER_DerelictTRTLRam",
	"path":"res://IndustriesOfEnceladusRewrite/ships/RA-TRTL-Ram.tscn",
	"alias":"TRTL",
	"config":{"config": {
		"ammo":{
			"capacity": 1000.0, 
			"initial": 1000.0, 
		}, 
		"autopilot":{"type":"SYSTEM_AUTOPILOT_MK2"}, 
		"capacitor":{"capacity": 500.0}, 
		"cargo":{
			"equipment":"SYSTEM_CARGO_STANDARD",
			"modifierDivided":"SYSTEM_CARGO_MOD_2K"
		},
		"fuel":{
			"capacity": 30000.0, 
			"initial": 30000.0, 
		}, 
		"propulsion":{
			"main":"SYSTEM_MAIN_ENGINE_PNTR", 
			"rcs":"SYSTEM_THRUSTER_NDSTR"
		}, 
		"reactor":{	"power": 8.0},
		"shielding":{"emp": 100},  
		"turbine":{"power": 200.0}, 
		"weaponSlot":{
			"main": {"type":"SYSTEM_NONE"},
			"right":{"type":"SYSTEM_EMD14"}, 
			"left":{"type":"SYSTEM_EMD14"}
		}, 
	}},
	"dealer":{
		"age":75,
		"weight":1,
	},
	"derelict":{
		"chance":0.2,
		"minimum_chance":0.1,
		"money":5000000,
		"stock_chance":0.2,
		"allow_damage":true,
		"cause_extra_damage":true,
		"rock_cluster_chance":0.3,
		"rock_cluster_count":33,
		"clump":false,
		"clump_velocity":25,
		"ring_storm_chance":0.3,
		"pirate_chance":0.3,
		"rescue":false,
		"chaos":0.2
	},
	"miner":{
		"chaos":0.0
	},
}

const CK65 = {
	"name":"CK65",
	"specific_derelict_name":"IOER_DerelictCK65",
	"path":"res://IndustriesOfEnceladusRewrite/ships/CK65.tscn",
	"alias":"PROSPECTOR",
	"config":{"config": {
		"ammo":{
			"capacity": 1000.0, 
			"initial": 1000.0, 
		}, 
		"autopilot":{"type":"SYSTEM_AUTOPILOT_MK2"}, 
		"capacitor":{"capacity": 500.0}, 
		"cargo":{
			"equipment":"SYSTEM_CARGO_STANDARD",
			"modifierDivided":"SYSTEM_CARGO_MOD_2K"
		},
		"fuel":{
			"capacity": 80000.0, 
			"initial": 80000.0, 
		}, 
		"propulsion":{
			"main":"SYSTEM_MAIN_ENGINE_PNTR", 
			"rcs":"SYSTEM_THRUSTER_NDSTR"
		}, 
		"reactor":{	"power": 8.0},
		"shielding":{"emp": 100},  
		"turbine":{"power": 200.0}, 
		"weaponSlot":{
			"right":{"type":"SYSTEM_EMD14"}, 
			"left":{"type":"SYSTEM_NONE"}
		}, 
	}},
	"dealer":{
		"age":20,
		"weight":1,
	},
	"derelict":{
		"chance":0.5,
		"minimum_chance":0.1,
		"money":5000000,
		"stock_chance":0.2,
		"allow_damage":true,
		"cause_extra_damage":true,
		"rock_cluster_chance":0.3,
		"rock_cluster_count":33,
		"clump":false,
		"clump_velocity":25,
		"ring_storm_chance":0.3,
		"pirate_chance":0.3,
		"rescue":false,
		"chaos":0.4
	},
	"miner":{
		"chaos":0.25
	},
}

const CK69 = {
	"name":"CK69",
	"specific_derelict_name":"IOER_DerelictCK69",
	"path":"res://IndustriesOfEnceladusRewrite/ships/CK69.tscn",
	"alias":"PROSPECTOR",
	"config":{"config": {
		"ammo":{
			"capacity": 1000.0, 
			"initial": 1000.0, 
		}, 
		"autopilot":{"type":"SYSTEM_AUTOPILOT_MK2"}, 
		"capacitor":{"capacity": 500.0}, 
		"cargo":{
			"equipment":"SYSTEM_CARGO_STANDARD",
			"modifierDivided":"SYSTEM_CARGO_MOD_2K"
		},
		"fuel":{
			"capacity": 80000.0, 
			"initial": 80000.0, 
		}, 
		"propulsion":{
			"main":"SYSTEM_MAIN_ENGINE_PNTR", 
			"rcs":"SYSTEM_THRUSTER_NDSTR"
		}, 
		"reactor":{	"power": 8.0},
		"shielding":{"emp": 100},  
		"turbine":{"power": 200.0}, 
		"weaponSlot":{
			"right":{"type":"SYSTEM_EMD14"}, 
			"left":{"type":"SYSTEM_NONE"}
		}, 
	}},
	"dealer":{
		"age":20,
		"weight":1,
	},
	"derelict":{
		"chance":0.5,
		"minimum_chance":0.1,
		"money":5000000,
		"stock_chance":0.2,
		"allow_damage":true,
		"cause_extra_damage":true,
		"rock_cluster_chance":0.3,
		"rock_cluster_count":33,
		"clump":false,
		"clump_velocity":25,
		"ring_storm_chance":0.3,
		"pirate_chance":0.3,
		"rescue":false,
		"chaos":0.4
	},
	"miner":{
		"chaos":0.25
	},
}

const YME = {
	"name":"YME",
	"specific_derelict_name":"IOER_DerelictYME",
	"path":"res://IndustriesOfEnceladusRewrite/ships/YME.tscn",
	"alias":"EIME",
	"config":{
		"config":{
			"fuel":{
				"capacity":30000.0, 
				"initial":30000.0, 
			}, 
			"propulsion":{
				"main":"SYSTEM_MAIN_ENGINE_EIZAP", 
				"rcs":"SYSTEM_THRUSTER_AGILE"
			}, 
			"weaponSlot":{
				"main":{
					"type":"SYSTEM_NONE"
				}, 
				"left":{
					"type":"SYSTEM_NONE"
				}, 
				"right":{
					"type":"SYSTEM_NONE"
				}, 
			}, 
			"ammo":{
				"capacity":0.0, 
				"initial":0.0
			}, 
			"autopilot":{
				"type":"SYSTEM_AUTOPILOT_MK4"
			}, 
			"capacitor":{
				"capacity":1000.0
			}, 
			"turbine":{
				"power":500.0
			},
			"reactor":{
				"power": 30.0
			},
		}
	},
	"dealer":{
		"age":1,
		"weight":1,
	},
	"derelict":{
		"chance":0.3,
		"minimum_chance":0.1,
		"money":2000000,
		"stock_chance":0.2,
		"allow_damage":true,
		"cause_extra_damage":true,
		"rock_cluster_chance":0.3,
		"rock_cluster_count":33,
		"clump":false,
		"clump_velocity":25,
		"ring_storm_chance":0.3,
		"pirate_chance":0.3,
		"rescue":false,
		"chaos":0.5
	},
	"miner":{
		"chaos":0.25
	},
}
const EIME_B = {
	"name":"EIME-B",
	"specific_derelict_name":"IOER_DerelictEIME_B",
	"path":"res://IndustriesOfEnceladusRewrite/ships/EIME-B.tscn",
	"alias":"EIME",
	"config":{
		"config":{
			"fuel":{
				"capacity":30000.0, 
				"initial":30000.0, 
			}, 
			"propulsion":{
				"main":"SYSTEM_MAIN_ENGINE_EIZAP", 
				"rcs":"SYSTEM_THRUSTER_AGILE"
			}, 
			"weaponSlot":{
				"main":{
					"type":"SYSTEM_NONE"
				}, 
				"left":{
					"type":"SYSTEM_NONE"
				}, 
				"right":{
					"type":"SYSTEM_NONE"
				}, 
			}, 
			"ammo":{
				"capacity":0.0, 
				"initial":0.0
			}, 
			"autopilot":{
				"type":"SYSTEM_AUTOPILOT_MK4"
			}, 
			"capacitor":{
				"capacity":1000.0
			}, 
			"turbine":{
				"power":500.0
			},
			"reactor":{
				"power": 30.0
			},
		}
	},
	"dealer":{
		"age":1,
		"weight":1,
	},
	"derelict":{
		"chance":0.3,
		"minimum_chance":0.1,
		"money":2000000,
		"stock_chance":0.2,
		"allow_damage":true,
		"cause_extra_damage":true,
		"rock_cluster_chance":0.3,
		"rock_cluster_count":33,
		"clump":false,
		"clump_velocity":25,
		"ring_storm_chance":0.3,
		"pirate_chance":0.3,
		"rescue":false,
		"chaos":0.5
	},
	"miner":{
		"chaos":0.25
	},
}

const OCP_SALVAGE = {
	"name":"OCP-SALVAGE",
	"specific_derelict_name":"IOER_DerelictOCPSalvage",
	"path":"res://IndustriesOfEnceladusRewrite/ships/ocp-209-salvage.tscn",
	"alias":"OCP209",
	"config":{
		"config":{
			"hud":{
				"type":"SYSTEM_HUD_OCP209"
			}, 
			"aux":{
				"power":"SYSTEM_AUX_SMES_MK2"
			},
			"weaponSlot":{
				"mainLeft":{
					"type":"SYSTEM_SALVAGE_ARM"
				}, 
				"mainRight":{
					"type":"SYSTEM_SALVAGE_ARM"
				}, 
			}, 
			"reactor":{
				"power":16.0
			}, 
			"ammo":{
				"capacity":0.0, 
				"initial":0.0, 
			}, 
			"fuel":{
				"capacity":80000.0, 
				"initial":80000.0, 
			}, 
			"capacitor":{
				"capacity":1000.0, 
			}, 
			"turbine":{
				"power":200.0, 
			}, 
			"shielding":{
				"emp":0, 
			}, 
			"autopilot":{
				"type":"SYSTEM_AUTOPILOT_MK2"
			}, 
			"propulsion":{
				"main":"SYSTEM_MAIN_ENGINE_DFMPD2205", 
				"rcs":"SYSTEM_THRUSTER_GHET"
			}, 
		}
	},
	"dealer":{
		"age":50,
		"weight":1,
	},
	"derelict":{
		"chance":0.2,
		"minimum_chance":0.2,
		"money":2000000,
		"stock_chance":0.2,
		"allow_damage":true,
		"cause_extra_damage":true,
		"rock_cluster_chance":0.3,
		"rock_cluster_count":33,
		"clump":false,
		"clump_velocity":25,
		"ring_storm_chance":0.3,
		"pirate_chance":0.3,
		"rescue":false,
		"chaos":0.5
	},
	"miner":{
		"chaos":0.25
	},
}
