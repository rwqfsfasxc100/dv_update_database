# [license]
# 3-Clause BSD NON-AI License
# 
# Copyright 2026 __hev (Benjamin Buckhurst)
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

extends "res://IndustriesOfEnceladusRewrite/ships/modules/CargoAuxBase.gd"

export  var ventTime = 0.5
export  var massDamageScale = 20.0
export (float, 0, 1000, 0.5) var self_kgps = 100.0
export  var powerDrawPerKg = 100
export (int, 50, 150) var modify_mineralEfficiency = 100
export (float, 0, 1, 0.05) var self_remassEfficiency = 0.5
export (int) var modify_kgps_add = 0
export  (int, 10, 1000, 1) var modify_kgps_percent_multi = 100

export (float) var tuneable_speed_min = 0.5
export (float) var tuneable_speed_max = 1.5

export (float,0.1,1.0,0.05) var minimum_filler_content = 0.30

export (int,-50,50,1) var tunable_mpu_min = -15
export (int,-50,50,1) var tunable_mpu_max = 15

export (int, 5, 75, 1) var max_ores_processing = 10
export (float, 0,20,0.05) var ore_swapover_time = 5.0
export (float) var ore_swapover_fade_time = 0.33
export (float) var swapover_color_fade_scale = 3.0

export  var enabled = true


var power = 0.0

func getStatus():
	return 100
func getPower():
	if bayCount:
		var pv = clamp(power / min(bayCount,max_ores_processing), 0, 1)
		var sv = swapover_fade * swapover_color_fade_scale
		return clamp(pv - (sv * pv),0,1)
	return 0.0

func get_minimum_filler_content():
	var base = minimum_filler_content
	var dynamicKgps = get_preprocessor_kgps()
	var ratio = dynamicKgps / self_kgps
	base = pow(base,2.0 - ratio)
	var b2 = base / 1.5
	return clamp(b2,0.05,1.0)



func get_preprocessor_kgps() -> float:
	return ship.getTunedValue(slotName, "IOE_TUNE_PREPROC_RECLAIM", self_kgps)

func get_preprocessor_efficiency() -> float:
	var tuned = ship.getTunedValue(slotName, "IOE_TUNE_PREPROC_RECLAIM", self_kgps)
	var val = pow(self_remassEfficiency,tuned / self_kgps)
	return val

func powerFromRatio(x: float) -> float:
	return ((1.0 / (x * (2.0 - x)) - 1) * 1.8 + 1)

func get_power():
	var dynamicKgps = get_preprocessor_kgps()
	var ratio = dynamicKgps / self_kgps
	var pv = powerFromRatio(ratio) * dynamicKgps
	var powerDrawKw = (powerDrawPerKg * pv)/self_kgps
	return powerDrawKw

func getParameters():
	if self_kgps == 0 or powerDrawPerKg == 0:
		return {}
	
	var out = {}
	if self_remassEfficiency > 0.0 or self_kgps > 0.0:
		var powerDrawKw = get_power()
		var powerDrawHuman = ["%s" % [CurrentGame.formatThousands(powerDrawKw / 1000)], "MW"] if powerDrawKw > 1000 else ["%s" % [CurrentGame.formatThousands(powerDrawKw)], "kW"]
		out.merge({"IOE_TUNE_PARAMETER_PREPROC_MELT_REMASS_EFFICIENCY": ["%.1f" % [(get_preprocessor_efficiency() * 100.0)], "%"]})
		out.merge({"IOE_TUNE_PARAMETER_PREPROC_MELT_POWER_DRAW": powerDrawHuman})
		if minimum_filler_content < 1.0:
			
			out.merge({"IOE_TUNE_PARAMETER_PREPROC_CHUNK_WATER_MASS_CEILING": ["%.1f" % (get_minimum_filler_content() * 100), "%"]})
		
	return out

func getTuneables():
	if self_kgps <= 0.0 or powerDrawPerKg <= 0.0:
		return {}
	var out = {}
	if self_remassEfficiency > 0.0:
		out.merge({"IOE_TUNE_PREPROC_RECLAIM": {
			"type": "float", 
			"min": ceil(float(self_kgps) * tuneable_speed_min), 
			"max": ceil(float(self_kgps) * tuneable_speed_max), 
			"step": ceil(float(self_kgps) / 100), 
			"default": self_kgps, 
			"current": get_preprocessor_kgps(), 
			"unit": "kg/s", 
			"testProtocol": "cargo"
		}})
	return out

var processor = null

func _ready():
	if not ship.setup:
		yield(ship,"setup")
	var shipSystems = ship.getSystems()
	var current_mpu = ship.getConfig("cargo.equipment")
	for sys in shipSystems:
		var node = shipSystems[sys]
		if node.name == current_mpu:
			processor = node.ref
	if processor:
		baseMineralEfficiency = processor.mineralEfficiency
		basekgps = processor.kgps
		basePowerDrawPerKg = processor.powerDrawPerKg
		modifyProcessor()

onready var ventRemass = $VentRemass
onready var ventMineral = $VentMineral
onready var processingA = $Processing
onready var proStart = $ProStart
onready var proStop = $ProStop
onready var swap = $Swap

var ventingMineral = 0.0

var baseMineralEfficiency = 0
var basekgps = 0
var basePowerDrawPerKg = 0

var swapover_fade = 0.0
var swapover_direction = false
var swapover_time = 0.0

var conserved_isproc = false

func _physics_process(delta):
	ventingMineral = max(0, ventingMineral - delta)

	var venting = false
	var isproc = false
	
	if enabled:
		if (self_remassEfficiency > 0.0 or self_kgps > 0.0):
			var current_kgps = get_preprocessor_kgps()
			var current_powerdraw = get_power()
			var current_remassefficiency = get_preprocessor_efficiency()
			var forProcessing = get_processable_object(delta)
			var minFillContent = get_minimum_filler_content()
			if not swapover_time > 0.0:
				var pvCache = 0.0
				for p in forProcessing:
					if Tool.claim(p):
						if "fillerContent" in p:
							if p.fillerContent > minFillContent:
								var fillerMass = p.fillerContent * p.mass
								var mineralMass = p.mineralContent * p.mass
								var procDelta = min(fillerMass, delta * current_kgps / 1000)
								var requiredPower = procDelta * current_powerdraw * 100
								var gotPower = ship.drawEnergy(requiredPower)
								if gotPower / requiredPower > 0.9:
									var nm = max(mineralMass, p.mass - procDelta)
									
									if nm > 0:
										p.mass = nm
										p.mineralContent = mineralMass / nm
									
									p.fillerContent = 1 - p.mineralContent
									if p.fillerContent <= minFillContent:
										ventingMineral = ventTime
									var newMass = max(mineralMass, p.mass - procDelta)
									var massChange = p.mass - newMass
									var shipRemass = ship.reactiveMass
									var procRemass = massChange * 1000 * current_remassefficiency
									var newRemass = clamp(shipRemass + procRemass, 0, ship.reactiveMassMax)
									ship.reactiveMass = newRemass
									isproc = true
									pvCache += 1.0
									venting = (newRemass - shipRemass < procRemass / 2)
									ship.cargoMass = max(ship.cargoMass - massChange * 1000, 0)
						else :
							if p.has_method("getScan") and p.getScan() == "H2O" and p.has_method("applyEnergyDamage"):
								var mad = max(1, p.mass / massDamageScale)
								var proc = min(p.mass, delta * current_kgps / 1000) * mad
								var requiredPower = proc * current_powerdraw * 1000 * delta * 60
								var gotPower = ship.drawEnergy(requiredPower)
								var prm = ship.reactiveMass
								if gotPower / requiredPower > 0.9:
									p.applyEnergyDamage(gotPower, p.global_position, delta)
									var st = current_remassefficiency * proc * 1000
									var nrm = clamp(prm + st, 0, ship.reactiveMassMax)
									ship.reactiveMass = nrm
									isproc = true
									pvCache += 1.0
									venting = (nrm - prm < st / 2)
					Tool.release(p)
				conserved_isproc = isproc
				power = pvCache
	else: power = 0.0
	
	ventRemass.emitting = venting and not Settings.particlesForbidden
	ventMineral.emitting = ventingMineral > 0 and not Settings.particlesForbidden
	
	if swapover_direction:
		if swapover_fade < ore_swapover_fade_time:
			swapover_fade += delta
		else:
			swapover_direction = false
	else:
		if swapover_fade > 0.0:
			swapover_fade -= delta
	if swapover_time > 0.0:
		swapover_time -= delta
	elif ship.isPlayerControlled():
		if conserved_isproc:
			if not processingA.playing:
				processingA.play()
				proStart.play()
		else :
			if processingA.playing:
				processingA.stop()
				proStop.play()


func modifyProcessor():
	var newMinEff:float = clamp(baseMineralEfficiency * (modify_mineralEfficiency/100.0), 0.05, 0.995) if baseMineralEfficiency > 0.0 else 0.0
	var cc:float = clamp(modify_kgps_percent_multi,10,1000)/100.0
	var newKGPS:int = int(round(max((basekgps * cc) + modify_kgps_add,5)))
	
	var rt:float = (baseMineralEfficiency/newMinEff) if newMinEff > 0.0 else 1.0
	var newPower:float = pow(basePowerDrawPerKg / 10.0,2.0 - rt) * 10.0 * cc
	
	if modify_mineralEfficiency != 100:
		processor.setEfficiency(newMinEff)
	if modify_kgps_percent_multi != 100 or modify_kgps_add != 0:
		processor.setKgps(newKGPS)
	if rt != 1:
		processor.setPower(newPower)

var counter:float = 0.0
var bayCount:int = 0
var current_indexes:Array = []
func get_processable_object(delta):
	var cargo:Array = ship.cargo
	var s:int = cargo.size()
	if s:
		if s > max_ores_processing:
			var lucky:Array = []
			if s == bayCount:
				counter += delta
				if counter > (ore_swapover_time + ore_swapover_fade_time):
					counter = 0.0
					swapover_fade = delta
					swapover_time = ore_swapover_fade_time
					swapover_direction = true
					current_indexes.shuffle()
					if conserved_isproc:
						swap.play()
			else:
				current_indexes = range(s)
				current_indexes.shuffle()
				bayCount = s
				counter = 0.0
				swapover_fade = delta
				swapover_time = ore_swapover_fade_time
				swapover_direction = true
				if conserved_isproc:
					swap.play()
			for i in max_ores_processing:
				lucky.append(cargo[i])
			return lucky
		else:
			counter = 0.0
			swapover_fade = 0.0
			swapover_time = 0.0
			swapover_direction = false
			current_indexes = cargo
			return cargo
	bayCount = 0
	return []
	
	

