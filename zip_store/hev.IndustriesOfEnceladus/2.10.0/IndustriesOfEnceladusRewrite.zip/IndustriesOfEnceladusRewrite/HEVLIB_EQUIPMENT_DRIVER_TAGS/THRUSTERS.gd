# [license]
# 3-Clause BSD NON-AI License
# 
# Copyright 2026 __hev (Benjamin Buckhurst)
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

const SYSTEM_THRUSTER_PIN150 = {
	"slots":["propulsion.rcs"],
	"type":"RCS",
	"system":"SYSTEM_THRUSTER_PIN150",
	"price":31500,
	"repair_time":2,
	"fix_price":8000,
	"fix_time":4,
	"acceleration_fail_limit":250,
	"acceleration_fail_scale":100,
	"start_jolt":4000,
	"thrust":1500,
	"randomness":0.01,
	"min_power":0.05,
	"damage_wear_capacity":6000,
	"damage_bent_capacity":5000,
	"damage_bent_threshold":330,
	"damage_choke_capacity":10000,
	"damage_choke_threshold":720,
	"specific_impulse":90,
	"thermal_factor":1,
	"power_draw":90000,
	"gimbal_power_draw":15000,
	"gimbal":rad2deg(0.628),
	"gimbal_accuracy":0.85,
	"gimbal_per_second":rad2deg(25.133),
	"gimbal_vectored_thrust":true,
	"pulse_engine":false,
	"external_power":true,
	"tune_thrust_max":1,
	"mass":185,
	"min_choke":0.05,
	"plume_texture":"res://sfx/thrusters-fusion.png",
	"plume_offset":[-32,0],
	"flare_override_color":"bb7eff",
	"flare_energy":4,
	"position":[0,22.5],
	"scale":[0.25,0.6],
}
const SYSTEM_THRUSTER_PNTRM = {
	"slots":["propulsion.rcs"],
	"type":"RCS",
	"system":"SYSTEM_THRUSTER_PNTRM",
	"price":22750,
	"fix_price":500,
	"thrust":4500,
	"randomness":0.25,
	"specific_impulse":5,
	"power_draw":40000,
	"gimbal":rad2deg(1.047),
	"gimbal_vectored_thrust":true,
	"mass":25,
	"position":[0,4],
	"nozzle":{
		"position":[0,-45],
		"scale":[2.439,1.944],
	},
}
const SYSTEM_THRUSTER_BLAST = {
	"slots":["propulsion.rcs"],
	"type":"RCS",
	"system":"SYSTEM_THRUSTER_BLAST",
	"price":15500,
	"fix_price":2500,
	"thrust":4500,
	"randomness":0.3,
	"min_power":0.05,
	"damage_wear_capacity":6000,
	"damage_bent_capacity":3200,
	"damage_choke_capacity":4800,
	"specific_impulse":22,
	"power_draw":72000,
	"thermal_hit_factor":2,
	"pulse_engine":false,
	"mass":145,
	"scale":[0.25,0.4],
	"nozzle":{
		"texture":"res://weapons/weapons-c.png",
		"normal":"res://weapons/weapons-n.png",
		"heat":"res://weapons/weapons-c.png",
		"region_enabled":true,
		"region_rect":[617,180,46,82],
		"position":[0,42.5],
		"rotation":180,
		"scale":[1.8,0.9],
		"heat_region_enabled":true,
		"heat_region_rect":[361,180,46,82],
		"heat_position":[0,0],
	},
	"flare_texture_scale":5,
	"flare_position":[0.001,60],
	"flare_rotation":0,
	"flare_override_color":"ffc683",
	"extra_nodes":["res://IndustriesOfEnceladusRewrite/sfx/thruster_bits/blast_head.tscn"]
}

const SYSTEM_MAIN_ENGINE_NANI = {
	"slots":["propulsion.main"],
	"type":"TORCH",
	"system":"SYSTEM_MAIN_ENGINE_NANI",
	"path":"res://IndustriesOfEnceladusRewrite/sfx/SYSTEM_MAIN_ENGINE_NANI.tscn"
}
const SYSTEM_MAIN_ENGINE_GEMINI = {
	"slots":["propulsion.main"],
	"type":"TORCH",
	"system":"SYSTEM_MAIN_ENGINE_GEMINI",
	"price":345000,
	"fix_price":12000,
	"exhaust_emit_offset":-16,
	"distance_scale":8,
	"thrust":12000,
	"specific_impulse":28,
	"power_draw":250000,
	"gimbal":rad2deg(1.047),
	"gimbal_per_second":0.35,
	"gimbal_vectored_thrust":true,
	"pulse_engine":false,
	"mass":4350,
	"max_volume":-15,
	"position":[0,40],
	"scale":[1.6,1],
	"nozzle":{
		"position":[-9.25,-70],
		"scale":[0.5,1.4],
	},
	"extra_nozzles":[
		{
			"position":[9.25,-70],
			"scale":[0.5,1.4],
		}
	]
}
const SYSTEM_MAIN_ENGINE_SOYUZ = {
	"slots":["propulsion.main"],
	"type":"TORCH",
	"system":"SYSTEM_MAIN_ENGINE_SOYUZ",
	"price":35000,
	"fix_price":4000,
	"distance_scale":4,
	"thrust":16000,
	"damage_wear_capacity":2400,
	"power_draw":60000,
	"mass":650,
	"position":[0,10],
	"scale":[1,0.4],
	"nozzle":{
		"position":[0,-70],
		"scale":[0.7,1.2],
	},
	"extra_nozzles":[
		{
			"position":[-10,-70],
			"scale":[0.7,1.2],
			"order":"before"
		},
		{
			"position":[10,-70],
			"scale":[0.7,1.2],
			"order":"before"
		},
	],
	"extra_nodes":[
		"res://IndustriesOfEnceladusRewrite/sfx/thruster_bits/soyuz_support.tscn"
	]
}
const SYSTEM_MAIN_ENGINE_THUNDER = {
	"slots":["propulsion.main"],
	"type":"TORCH",
	"system":"SYSTEM_MAIN_ENGINE_THUNDER",
	"priority_offset":1,
	"price":102000,
	"fix_price":7500,
	"fix_time":8,
	"distance_scale":4,
	"acceleration_fail_limit":800,
	"acceleration_fail_scale":400,
	"thrust":16000,
	"fade_seconds":0.1,
	"min_power":0.25,
	"damage_bent_threshold":50,
	"max_misalignment":0.262,
	"specific_impulse":12,
	"thermal_factor":60,
	"gimbal_power_draw":5000,
	"gimbal":rad2deg(0.436),
	"gimbal_per_second":rad2deg(6.282),
	"pulse_per_second":30,
	"tune_thrust_min":0.75,
	"tune_thrust_max":2,
	"mass":950,
	"max_volume":-15,
	"position":[0,10],
	"scale":[0.75,0.75],
	"nozzle":{
		"position":[0,-29.333],
		"scale":[0.4,0.45],
	},
	"extra_nozzles":[
		{
			"position":[13,-29.333],
			"scale":[0.4,0.45],
			"order":"before"
		},
		{
			"position":[-13,-29.333],
			"scale":[0.4,0.45],
			"order":"before"
		},
	],
	"extra_nodes":[
		"res://IndustriesOfEnceladusRewrite/sfx/thruster_bits/thunder_support.tscn"
	]
}
const SYSTEM_MAIN_ENGINE_PIN1200 = {
	"slots":["propulsion.main"],
	"type":"TORCH",
	"system":"SYSTEM_MAIN_ENGINE_PIN1200",
	"price":1180000,
	"repair_time":4,
	"fix_price":92000,
	"fix_time":8,
	"exhaust_emit_offset":16,
	"acceleration_fail_limit":300,
	"acceleration_fail_scale":150,
	"start_jolt":85000,
	"thrust":12000,
	"randomness":0.01,
	"min_power":0.1,
	"damage_wear_capacity":3000,
	"damage_bent_capacity":2500,
	"damage_bent_threshold":165,
	"damage_choke_capacity":5000,
	"damage_choke_threshold":320,
	"special_fuel_limit":5400,
	"specific_impulse":105,
	"thermal_factor":1,
	"power_draw":550000,
	"gimbal_power_draw":30000,
	"gimbal":rad2deg(0.7),
	"gimbal_accuracy":0.85,
	"gimbal_per_second":rad2deg(31),
	"gimbal_vectored_thrust":true,
	"pulse_engine":false,
	"external_power":true,
	"tune_thrust_max":1.25,
	"mass":11350,
	"min_choke":0.5,
	"position":[0,0.156],
	"scale":[0.6,1],
	"nozzle":{
		"texture":"res://ships/modules/magnozzle-cd.png",
		"normal":"res://ships/modules/magnozzle-n.png",
		"heat":"res://ships/modules/magnozzle-cl.png",
	}
}

const SYSTEM_MAIN_ENGINE_CRACK = {
	"slots":["propulsion.main"],
	"type":"TORCH",
	"system":"SYSTEM_MAIN_ENGINE_CRACK",
	"main_bright_ratio":2,
	"price":1575000,
	"repair_time":48,
	"fix_price":50000,
	"fix_time":24,
	"distance_scale":300,
	"acceleration_fail_limit":600,
	"acceleration_fail_scale":400,
	"thrust":18000,
	"command":"m",
	"particle_chance":1,
	"fade_seconds":0.1,
	"wind_up_seconds":0.1,
	"particle_scale":16,
	"randomness":0.2,
	"min_power":0,
	"damage_wear_capacity":12800,
	"damage_bent_capacity":12800,
	"damage_bent_threshold":1280,
	"damage_choke_capacity":128000,
	"damage_choke_threshold":96000,
	"special_fuel_limit":1800,
	"heat_cone":0.1,
	"heat_fire_threshold":2000,
	"max_misalignment":0.02,
	"specific_impulse":1850,
	"thermal_factor":0.00001,
	"power_draw":445000,
	"gimbal_power_draw":400,
	"ignitions_per_second":8,
	"gimbal_per_second":0.496,
	"pulse_per_second":8,
	"exhaust_type":"fusion",
	"external_power":true,
	"tune_thrust_max":1,
	"tune_thrust_min":1,
	"mass":4650,
	"max_volume":-15,
	"min_choke":0.01,
	"offset":[-32,0],
	"position":[0,-8],
	"plume_offset":[-32, 0],
	"plume_has_material":false,
	"scale":[0.6,1],
	"self_modulate":"ff0089",
	"flare_texture_scale":8,
	"flare_color":"ff97ec",
	"flare_energy":24,
	"flare_position":[0.003,86],
	"flare_rotation":0,
	"flare_scale":[6,4],
	"flare_range_height":5,
	"nozzle":{
		"texture":"res://ships/modules/magnozzle-cd.png",
		"normal":"res://ships/modules/magnozzle-n.png",
		"heat":"res://ships/modules/magnozzle-cl.png",
		"position":[0,2],
		"rotation":0,
		"scale":[2,0.6],
	},
	"extra_nodes":["res://IndustriesOfEnceladusRewrite/sfx/thruster_bits/crack_cage.tscn"]
}
