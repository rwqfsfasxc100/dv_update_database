# [license]
# 3-Clause BSD NON-AI License
# 
# Copyright 2026 __hev (Benjamin Buckhurst)
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

const MODIFY_INTERNALS = [
	{
		"system":"SYSTEM_CARGO_AUX_STORPROC_8K",
		"storage_flat":8000
	},
	{
		"system":"SYSTEM_CARGO_AUX_STORAGE_4K",
		"storage_flat":4000,
		"storage_ammo":3000,
		"storage_nanodrones":3000,
		"storage_propellant":5000
	},
	{
		"system":"SYSTEM_CARGO_MPU_BULK",
		"storage_flat":10000
	},
	{
		"system":"SYSTEM_CARGO_AUX_FAB",
		"storage_flat":2000,
		"storage_propellant":6000
	},
	{
		"system":"SYSTEM_CARGO_AUX_BIGFAB",
		"storage_ammo":5000,
		"storage_nanodrones":5000
	},
	{
		"system":"SYSTEM_CARGO_MOD_2K",
		"storage_flat":2000,
		"mass":1600,
		"display_system":{
			"name":"SYSTEM_CARGO_MOD_2K"
		},
	
	},
	{
		"system":"SYSTEM_CARGO_MOD_4K",
		"storage_flat":4000,
		"mass":3300,
		"display_system":{
			"name":"SYSTEM_CARGO_MOD_4K"
		},
	
	},
	{
		"system":"SYSTEM_CARGO_MOD_6K",
		"storage_flat":6000,
		"mass":5500,
		"display_system":{
			"name":"SYSTEM_CARGO_MOD_6K"
		},
	
	},
	{
		"system":"SYSTEM_CARGO_MOD_BOLTS",
		"force_type":"divided",
		"mass":-2650,
		"display_system":{
			"name":"SYSTEM_CARGO_MOD_BOLTS"
		},
	
	},
	{
		"system":"SYSTEM_CARGO_MOD_AMORPH4",
		"storage_multi_upper":1,
		"storage_multi_lower":2,
		"force_type":"amorphic",
		"mass_per_tonne_storage_added":-20,
		"mass":1500,
		"display_system":{
			"name":"SYSTEM_CARGO_MOD_AMORPH4"
		},
	
	},
	{
		"system":"SYSTEM_CARGO_MOD_AMORPH5",
		"storage_multi_upper":2,
		"storage_multi_lower":3,
		"force_type":"amorphic",
		"mass_per_tonne_storage_added":-75,
		"mass":2500,
		"display_system":{
			"name":"SYSTEM_CARGO_MOD_AMORPH5"
		},
	
	},
	{
		"system":"SYSTEM_CARGO_MOD_AMORPH6",
		"storage_multi_upper":5,
		"storage_multi_lower":6,
		"force_type":"amorphic",
		"mass_per_tonne_storage_added":-165,
		"mass":3750,
		"display_system":{
			"name":"SYSTEM_CARGO_MOD_AMORPH6"
		},
	
	},
	{
		"system":"SYSTEM_CREW_ADD_BUNK",
		"crew_count":1,
		"crew_morale":-0.3,
		"mass":250,
		"mass_per_crew_member":15,
		"display_system":{
			"name":"SYSTEM_CREW_ADD_BUNK"
		},
	
	},
	{
		"system":"SYSTEM_CREW_ADD_BUNK2",
		"crew_count":2,
		"crew_morale":-0.4,
		"mass":500,
		"mass_per_crew_member":35,
		"display_system":{
			"name":"SYSTEM_CREW_ADD_BUNK2"
		},
	
	},
	{
		"system":"SYSTEM_CREW_ADD_CAPSULE",
		"crew_count":2,
		"crew_morale":-0.25,
		"mass":1000,
		"mass_per_crew_member":60,
		"display_system":{
			"name":"SYSTEM_CREW_ADD_CAPSULE"
		},
	
	},
	{
		"system":"SYSTEM_CREW_MOD_HOME",
		"crew_count":0,
		"crew_morale":0.1,
		"mass":200,
		"mass_per_crew_member":75,
		"display_system":{
			"name":"SYSTEM_CREW_MOD_HOME"
		},
	
	},
	{
		"system":"SYSTEM_CREW_MOD_KMX",
		"crew_count":-1,
		"crew_morale":0.2,
		"mass":500,
		"mass_per_crew_member":150,
		"display_system":{
			"name":"SYSTEM_CREW_MOD_KMX"
		},
	
	},
	{
		"system":"SYSTEM_CREW_MOD_OCM",
		"crew_count":-2,
		"crew_morale":0.5,
		"mass":700,
		"mass_per_crew_member":200,
		"display_system":{
			"name":"SYSTEM_CREW_MOD_OCM"
		},
	
	},
	{
		"system":"SYSTEM_HULLVAT_AMMO_1",
		"storage_ammo":6000,
		"crew_morale":-0.05,
		"nano_multi_upper":3,
		"nano_multi_lower":4,
		"minimum_nano_utilization_for_reduction":0.33,
		"mass":3000,
		"display_system":{
			"name":"SYSTEM_HULLVAT_AMMO_1"
		},
	
	},
	{
		"system":"SYSTEM_HULLVAT_AMMO_2",
		"storage_ammo":15000,
		"crew_morale":-0.1,
		"nano_multi_upper":1,
		"nano_multi_lower":2,
		"minimum_nano_utilization_for_reduction":0.33,
		"mass":10000,
		"display_system":{
			"name":"SYSTEM_HULLVAT_AMMO_2"
		},
	
	},
	{
		"system":"SYSTEM_HULLVAT_AMMO_EXTEND_1",
		"ammo_multi_upper":4,
		"ammo_multi_lower":3,
		"storage_ammo":1000,
		"storage_multi_upper":9,
		"storage_multi_lower":10,
		"mass":9000,
		"display_system":{
			"name":"SYSTEM_HULLVAT_AMMO_EXTEND_1"
		},
	
	},
	{
		"system":"SYSTEM_HULLVAT_AMMO_EXTEND_2",
		"ammo_multi_upper":5,
		"ammo_multi_lower":3,
		"storage_ammo":2000,
		"storage_multi_upper":4,
		"storage_multi_lower":5,
		"mass":20000,
		"display_system":{
			"name":"SYSTEM_HULLVAT_AMMO_EXTEND_2"
		},
	
	},
	{
		"system":"SYSTEM_HULLVAT_AMMO_EXTEND_3",
		"ammo_multi_upper":2,
		"ammo_multi_lower":1,
		"storage_ammo":1000,
		"propellant_multi_upper":2,
		"propellant_multi_lower":3,
		"minimum_propellant_utilization_for_reduction":0.33,
		"mass":35000,
		"display_system":{
			"name":"SYSTEM_HULLVAT_AMMO_EXTEND_3"
		},
	
	},
	{
		"system":"SYSTEM_HULLVAT_NANO_1",
		"storage_nano":6000,
		"crew_morale":-0.05,
		"ammo_multi_upper":3,
		"ammo_multi_lower":4,
		"minimum_ammo_utilization_for_reduction":0.33,
		"mass":4500,
		"display_system":{
			"name":"SYSTEM_HULLVAT_NANO_1"
		},
	
	},
	{
		"system":"SYSTEM_HULLVAT_NANO_2",
		"storage_nano":15000,
		"crew_morale":-0.1,
		"ammo_multi_upper":1,
		"ammo_multi_lower":2,
		"minimum_ammo_utilization_for_reduction":0.33,
		"mass":12000,
		"display_system":{
			"name":"SYSTEM_HULLVAT_NANO_2"
		},
	
	},
	{
		"system":"SYSTEM_HULLVAT_NANO_EXTEND_1",
		"nano_multi_upper":4,
		"nano_multi_lower":3,
		"storage_nano":1000,
		"storage_multi_upper":9,
		"storage_multi_lower":10,
		"mass":10500,
		"display_system":{
			"name":"SYSTEM_HULLVAT_NANO_EXTEND_1"
		},
	
	},
	{
		"system":"SYSTEM_HULLVAT_NANO_EXTEND_2",
		"nano_multi_upper":5,
		"nano_multi_lower":3,
		"storage_nano":2000,
		"storage_multi_upper":4,
		"storage_multi_lower":5,
		"mass":25000,
		"display_system":{
			"name":"SYSTEM_HULLVAT_NANO_EXTEND_2"
		},
	
	},
	{
		"system":"SYSTEM_HULLVAT_NANO_EXTEND_3",
		"nano_multi_upper":2,
		"nano_multi_lower":1,
		"storage_nano":1000,
		"propellant_multi_upper":2,
		"propellant_multi_lower":3,
		"minimum_propellant_utilization_for_reduction":0.33,
		"mass":40000,
		"display_system":{
			"name":"SYSTEM_HULLVAT_NANO_EXTEND_3"
		},
	
	},
	{
		"system":"SYSTEM_HULLVAT_PROP_1",
		"storage_propellant":10000,
		"storage_multi_upper":9,
		"storage_multi_lower":10,
		"mass":1500,
		"display_system":{
			"name":"SYSTEM_HULLVAT_PROP_1"
		},
	
	},
	{
		"system":"SYSTEM_HULLVAT_PROP_2",
		"storage_propellant":25000,
		"storage_multi_upper":31,
		"storage_multi_lower":40,
		"mass":7000,
		"display_system":{
			"name":"SYSTEM_HULLVAT_PROP_2"
		},
	
	},
	{
		"system":"SYSTEM_HULLVAT_PROP_EXTEND_1",
		"propellant_multi_upper":5,
		"propellant_multi_lower":4,
		"nano_multi_upper":7,
		"nano_multi_lower":8,
		"ammo_multi_upper":7,
		"ammo_multi_lower":8,
		"minimum_ammo_utilization_for_reduction":0.33,
		"minimum_nano_utilization_for_reduction":0.33,
		"mass":3000,
		"display_system":{
			"name":"SYSTEM_HULLVAT_PROP_EXTEND_1"
		},
	
	},
	{
		"system":"SYSTEM_HULLVAT_PROP_EXTEND_2",
		"propellant_multi_upper":3,
		"propellant_multi_lower":2,
		"nano_multi_upper":6,
		"nano_multi_lower":8,
		"ammo_multi_upper":6,
		"ammo_multi_lower":8,
		"minimum_ammo_utilization_for_reduction":0.33,
		"minimum_nano_utilization_for_reduction":0.33,
		"mass":8000,
		"display_system":{
			"name":"SYSTEM_HULLVAT_PROP_EXTEND_2"
		},
	
	},
	{
		"system":"SYSTEM_HULLVAT_PROP_EXTEND_3",
		"propellant_multi_upper":7,
		"propellant_multi_lower":4,
		"nano_multi_upper":5,
		"nano_multi_lower":8,
		"ammo_multi_upper":5,
		"ammo_multi_lower":8,
		"minimum_ammo_utilization_for_reduction":0.33,
		"minimum_nano_utilization_for_reduction":0.33,
		"mass":15000,
		"display_system":{
			"name":"SYSTEM_HULLVAT_PROP_EXTEND_3"
		},
	
	},
	{
		"system":"SYSTEM_HULLVAT_CONSUMABLESPEED_1",
		"ammo_speed_multi_upper":7,
		"ammo_speed_multi_lower":4,
		"nano_speed_multi_upper":7,
		"nano_speed_multi_lower":4,
		"mass":3800,
		"display_system":{
			"name":"SYSTEM_HULLVAT_CONSUMABLESPEED_1"
		},
	
	},
	{
		"system":"SYSTEM_HULLVAT_CONSUMABLESPEED_2",
		"ammo_speed_multi_upper":5,
		"ammo_speed_multi_lower":2,
		"nano_speed_multi_upper":5,
		"nano_speed_multi_lower":2,
		"crew_morale":-0.1,
		"mass":9000,
		"display_system":{
			"name":"SYSTEM_HULLVAT_CONSUMABLESPEED_2"
		},
	
	},
]
