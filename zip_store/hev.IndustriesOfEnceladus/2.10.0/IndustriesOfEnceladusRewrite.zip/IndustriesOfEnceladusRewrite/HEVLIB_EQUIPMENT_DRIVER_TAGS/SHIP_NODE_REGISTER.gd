# [license]
# 3-Clause BSD NON-AI License
# 
# Copyright 2026 __hev (Benjamin Buckhurst)
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

const SHIP_TRTL = {
	"ship_name":"SHIP_TRTL",
	"node_definitions":{
		"IOE_PREPROC_0x30":{
			"position_data":{
				"position":[-32,-75],
				"scale":[0.8]
			},
		},
		"IOE_PREPROC_20x10":{
			"position_data":{
				"position":[-32,-75],
				"scale":[0.8]
			},
		},
		"IOE_PREPROC_40x20":{
			"position_data":{
				"position":[-28,-75],
				"scale":[0.8]
			},
		},
		"IOE_STORAGE_4K":{
			"position_data":{
				"position":[-32,-75],
				"scale":[0.8]
			},
		},
		"IOE_STORAGE_8K":{
			"position_data":{
				"position":[-32,-75],
				"scale":[0.8]
			},
		},
		"IOE_FABAUX_FAB":{
			"position_data":{
				"position":[-32,-75],
				"scale":[0.8]
			},
		},
		"IOE_FABAUX_BIGFAB":{
			"position_data":{
				"position":[-32,-75],
				"scale":[0.8]
			},
		},
		"IOE_ICEBREAKER_M35":{
			"position_data":{
				"position":[-32,-75],
				"scale":[0.8]
			},
		},
		"IOE_ICEBREAKER_M85":{
			"position_data":{
				"position":[-32,-75],
				"scale":[0.8]
			},
		},
		"IOE_ICEBREAKER_P15":{
			"position_data":{
				"position":[-32,-75],
				"scale":[0.8]
			},
		},
		"IOE_BAY_AUX_PERSIST":{},
		"IOE_MPU_BULKER":{
			"properties":{
				"polygon":{
					"value":[2, -32, 0, -24, -18, -24, -24, -18, -24, -6, -18, 0, 6, 0, 18, -4, 24, -16, 32, -56, 32, -8, 32, 20, 20, 48, 0, 48, -20, 48, -32, 20, -32, -24, -32, -56, -18, -38],
					"method":"arr2vec2arr",
					"defer":true
				}
			},
		},
		"IOE_MPU_FURNACE":{
			"properties":{
				"polygon":{
					"value":[-32, -74, -24, -50, -12, -42, -26, -36, -26, 12, -16, 40, 16, 40, 26, 12, 26, -34, 12, -42, 24, -50, 32, -74, 32, -34, 32, 14, 20, 42, -20, 42, -32, 14, -32, -36],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[16, 40, 26, 12, 26, -42, -26, -42, -26, 12, -14, 40],
					"method":"arr2vec2arr",
					"defer":true
				},
			},
		},
	},
}

const SHIP_TRTL_LCB = {
	"ship_name":"SHIP_TRTL_LCB",
	"node_definitions":{
		"IOE_BAY_AUX_PERSIST":{},
		"IOE_MPU_BULKER":{
			"position_data":{
				"position":[0,3],
			},
		},
		"IOE_MPU_FURNACE":{
			"position_data":{
				"position":[0,9],
			},
		},
	}
}

const SHIP_TRTL_R = {
	"ship_name":"SHIP_TRTL_R",
	"node_definitions":{
		"IOE_MPU_BULKER":{
			"position_data":{
				"position":[0,-9],
			},
		},
		"IOE_MPU_FURNACE":{},
	}
}

const SHIP_TRTL_T = {
	"ship_name":"SHIP_TRTL_T",
	"node_definitions":{
		"IOE_MPU_BULKER":{
			"position_data":{
				"position":[0,-13],
			},
		},
		"IOE_MPU_FURNACE":{},
	}
}

const SHIP_PROSPECTOR_BALD = {
	"ship_name":"SHIP_PROSPECTOR_BALD",
	"node_definitions":{
		"IOE_MPU_BULKER":{
			"position_data":{
				"position":[0, -110],
			},
			"properties":{
				"polygon":{
					"value":[0, -24, -16, -24, -22, -18, -22, -6, -16, 0, 16, 0, 22, -8, 22, -24, 16, -34, 24, -34, 24, 34, -24, 34, -24, -34, -16, -34, -4, -30],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[-22, 27, 22, 27, 22, 9, -22, 3],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
		"IOE_MPU_FURNACE":{
			"position_data":{
				"position":[0, -148],
			},
			"properties":{
				"polygon":{
					"value":[-20, 68, -12, 70, 12, 70, 20, 68, 20, 10, 12, 8, 16, 4, 24, 4, 24, 72, -24, 72, -24, 4, -16, 4, -12, 8, -20, 10],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[-20, 70, 20, 70, 20, 8, -20, 8],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
	}
}

const SHIP_TRTL_K44 = {
	"ship_name":"SHIP_TRTL_K44",
	"node_definitions":{
		"IOE_BAY_AUX_PERSIST":{},
		"IOE_MPU_BULKER":{
			"position_data":{
				"position":[0,23],
			},
		},
		"IOE_MPU_FURNACE":{
			"position_data":{
				"position":[0,29],
			},
		},
	}
}

const SHIP_PROSPECTOR_LUX = {
	"ship_name":"SHIP_PROSPECTOR_LUX",
	"node_definitions":{
		"IOE_BAY_AUX_PERSIST":{},
	}
}

const SHIP_COTHON_V = {
	"ship_name":"SHIP_COTHON_V",
	"node_definitions":{
		"IOE_BAY_AUX_PERSIST":{},
	}
}

const SHIP_COTHON_LND = {
	"ship_name":"SHIP_COTHON_LND",
	"node_definitions":{
		"IOE_BAY_AUX_PERSIST":{},
	}
}

const SHIP_COTHON_CHK = {
	"ship_name":"SHIP_COTHON_CHK",
	"node_definitions":{
		"IOE_BAY_AUX_PERSIST":{},
	}
}

const SHIP_OCP209_DD = {
	"ship_name":"SHIP_OCP209_DD",
	"node_definitions":{
		"IOE_BAY_AUX_PERSIST":{},
		"IOE_OCP_DOCKING_BAY_UPPER":{},
		"IOE_OCP_DOCKING_BAY_LOWER":{},
		"IOE_OCP_DRONE_BAY_UPPER":{},
		"IOE_OCP_DRONE_BAY_LOWER":{},
		"IOE_MPU_BULKER":{
			"position_data":{
				"position":[0,-200],
				"rotation":180,
			},
			"properties":{
				"polygon":{
					"value":[2, -32, 0, -24, -18, -24, -24, -18, -24, -6, -18, 0, 6, 0, 18, -4, 24, -16, 24, -64, 32, -41, 32, 0, 32, 24, 24, 44, 0, 52, -24, 44, -32, 24, -32, 0, -32, -24, -36, -47, -32, -56, -24, -40, -14, -34],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
		"IOE_MPU_FURNACE":{
			"position_data":{
				"position":[0,-180],
				"rotation":180,
			},
			"properties":{
				"polygon":{
					"value":[-24, -48, -12, -40, -24, -32, -24, 44, -12, 64, 12, 64, 24, 44, 24, -32, 12, -40, 24, -48, 51, -57, 32, -24, 32, 46, 24, 64, 0, 72, -24, 64, -32, 46, -32, -24],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
	}
}

const SHIP_OCP213_TWIN = {
	"ship_name":"SHIP_OCP213_TWIN",
	"node_definitions":{
		"IOE_OCP_DOCKING_BAY_UPPER":{},
		"IOE_OCP_DOCKING_BAY_LOWER":{},
		"IOE_OCP_TURRET_BAY_UPPER":{},
		"IOE_OCP_TURRET_BAY_LOWER":{},
	}
}

const SHIP_OCP209_SNAP = {
	"ship_name":"SHIP_OCP209_SNAP",
	"node_definitions":{
		"IOE_OCP_DOCKING_BAY_UPPER":{},
		"IOE_OCP_DOCKING_BAY_LOWER":{},
		"IOE_OCP_DRONE_BAY_UPPER":{},
		"IOE_OCP_DRONE_BAY_LOWER":{},
		"IOE_MPU_BULKER":{
			"position_data":{
				"position":[-110,0],
			},
			"properties":{
				"polygon":{
					"value":[4, -24, -18, -24, -24, -18, -24, -6, -18, 0, 18, 0, 26, -10, 26, -38, 32, -26, 32, 0, 32, 40, -14, 72, -30, 22, -32, -2, -32, -22, -22, -58, 4, -92],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[-24, 27, 28, 27, 28, 11, -24, 3],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
		"IOE_MPU_FURNACE":{
			"position_data":{
				"position":[-97,0],
				"rotation":90,
			},
			"properties":{
				"polygon":{
					"value":[-106, -15, -84, 7, -46, 27, 0, 37, 46, 27, 84, 7, 106, -15, 116, -33, 110, -45, 30, -33, 16, -25, 22, -41, 136, -61, 122, -25, 100, 3, 72, 23, 36, 39, 0, 45, -36, 39, -70, 25, -100, 3, -122, -27, -136, -61, -22, -41, -16, -25, -30, -33, -110, -45, -116, -33],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[0, 43, 76, 19, 118, -29, 110, -45, 0, -33, -110, -47, -118, -29, -76, 19],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
	}
}

const SHIP_OCP_SALVAGE = {
	"ship_name":"SHIP_OCP-SALVAGE",
	"node_definitions":{
		"IOE_OCP_TURRET_BAY_UPPER":{
			"properties":{
				"toggleCommand":{
					"value":"ship_slot_5"
				}
			}
		},
		"IOE_OCP_TURRET_BAY_LOWER":{
			"properties":{
				"toggleCommand":{
					"value":"ship_slot_6"
				}
			}
		},
		"IOE_OCP_DRONE_BAY_UPPER":{},
		"IOE_OCP_DRONE_BAY_LOWER":{},
		"IOE_MPU_BULKER":{
			"position_data":{
				"position":[0,192],
			},
		},
		"IOE_MPU_FURNACE":{
			"position_data":{
				"position":[0,192],
			},
		},
	}
}

const SHIP_MADCERF_CIV = {
	"ship_name":"SHIP_MADCERF_CIV",
	"node_definitions":{
		"IOE_PREPROC_0x30":{
			"position_data":{
				"position":[-240,-25],
				"scale":[2]
			},
		},
		"IOE_PREPROC_20x10":{
			"position_data":{
				"position":[-240,-25],
				"scale":[2]
			},
		},
		"IOE_PREPROC_40x20":{
			"position_data":{
				"position":[-240,-25],
				"scale":[2]
			},
		},
		"IOE_STORAGE_4K":{
			"position_data":{
				"position":[-240,-25],
				"scale":[2]
			},
		},
		"IOE_STORAGE_8K":{
			"position_data":{
				"position":[-240,-25],
				"scale":[2]
			},
		},
		"IOE_FABAUX_FAB":{
			"position_data":{
				"position":[-240,-25],
				"scale":[2]
			},
		},
		"IOE_FABAUX_BIGFAB":{
			"position_data":{
				"position":[-240,-25],
				"scale":[2]
			},
		},
		"IOE_ICEBREAKER_M35":{
			"position_data":{
				"position":[-240,-25],
				"scale":[2]
			},
		},
		"IOE_ICEBREAKER_M85":{
			"position_data":{
				"position":[-240,-25],
				"scale":[2]
			},
		},
		"IOE_ICEBREAKER_P15":{
			"position_data":{
				"position":[-240,-25],
				"scale":[2]
			},
		},
		"IOE_BAY_AUX_PERSIST":{},
		"IOE_MPU_BULKER":{
			"position_data":{
				"position":[184, -118],
				"rotation":270,
			},
			"properties":{
				"polygon":{
					"value":[2, -32, 0, -24, -18, -24, -24, -18, -24, -6, -18, 0, 6, 0, 18, -4, 24, -16, 32, -56, 32, 56, -77, 56, -32, -56, -24, -40, -14, -34],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
		"IOE_MPU_FURNACE":{
			"position_data":{
				"position":[0, -220],
				"rotation":180,
			},
			"properties":{
				"polygon":{
					"value":[-32, -60, -40, -68, -96, -68, -96, -84, -40, -160, -18, -154, -14, -146, -34, -146, -80, -84, -70, -72, -38, -72, -28, -62, 28, -62, 38, -72, 70, -72, 80, -84, 34, -146, 14, -146, 18, -154, 40, -160, 94, -84, 94, -68, 40, -68, 32, -60],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[34, -68, 90, -74, 32, -148, -32, -148, -90, -74, -34, -68, -29, -62, 28, -62],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
	}
}

const SHIP_MADCERF_CIV_INVERSE = {
	"ship_name":"SHIP_MADCERF_CIV_INVERSE",
	"node_definitions":{
		"IOE_PREPROC_0x30":{
			"position_data":{
				"position":[240,25],
				"scale":[2],
				"rotation":180
			},
		},
		"IOE_PREPROC_20x10":{
			"position_data":{
				"position":[240,25],
				"scale":[2],
				"rotation":180
			},
		},
		"IOE_PREPROC_40x20":{
			"position_data":{
				"position":[240,25],
				"scale":[2],
				"rotation":180
			},
		},
		"IOE_STORAGE_4K":{
			"position_data":{
				"position":[240,25],
				"scale":[2],
				"rotation":180
			},
		},
		"IOE_STORAGE_8K":{
			"position_data":{
				"position":[240,25],
				"scale":[2],
				"rotation":180
			},
		},
		"IOE_FABAUX_FAB":{
			"position_data":{
				"position":[240,25],
				"scale":[2],
				"rotation":180
			},
		},
		"IOE_FABAUX_BIGFAB":{
			"position_data":{
				"position":[240,25],
				"scale":[2],
				"rotation":180
			},
		},
		"IOE_ICEBREAKER_M35":{
			"position_data":{
				"position":[240,25],
				"scale":[2],
				"rotation":180
			},
		},
		"IOE_ICEBREAKER_M85":{
			"position_data":{
				"position":[240,25],
				"scale":[2],
				"rotation":180
			},
		},
		"IOE_ICEBREAKER_P15":{
			"position_data":{
				"position":[240,25],
				"scale":[2],
				"rotation":180
			},
		},
		"IOE_BAY_AUX_PERSIST":{},
		"IOE_MPU_BULKER":{
			"position_data":{
				"position":[-184, 118],
				"rotation":90,
			},
			"properties":{
				"polygon":{
					"value":[2, -32, 0, -24, -18, -24, -24, -18, -24, -6, -18, 0, 6, 0, 18, -4, 24, -16, 32, -56, 32, 56, -77, 56, -32, -56, -24, -40, -14, -34],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
		"IOE_MPU_FURNACE":{
			"position_data":{
				"position":[0, 220],
			},
			"properties":{
				"polygon":{
					"value":[-32, -60, -40, -68, -96, -68, -96, -84, -40, -160, -18, -154, -14, -146, -34, -146, -80, -84, -70, -72, -38, -72, -28, -62, 28, -62, 38, -72, 70, -72, 80, -84, 34, -146, 14, -146, 18, -154, 40, -160, 94, -84, 94, -68, 40, -68, 32, -60],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[34, -68, 90, -74, 32, -148, -32, -148, -90, -74, -34, -68, -29, -62, 28, -62],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
	}
}

const SHIP_AT225_STUB = {
	"ship_name":"SHIP_AT225_STUB",
	"node_definitions":{
		"IOE_BAY_AUX_PERSIST":{},
		"IOE_MPU_BULKER":{
			"position_data":{
				"position":[0,12],
			},
			"properties":{
				"polygon":{
					"value":[2, -32, 0, -24, -18, -24, -24, -18, -24, -6, -18, 0, 6, 0, 18, -4, 24, -16, 36, -59, 36, 9, 24, 50, -24, 50, -36, 9, -36, -60, -18, -38],
					"method":"arr2vec2arr",
					"defer":true
				}
			},
		},
		"IOE_MPU_FURNACE":{
			"position_data":{
				"position":[0,18],
			},
			"properties":{
				"polygon":{
					"value":[-36, -80, -24, -50, -12, -42, -26, -36, -26, 12, -16, 40, 16, 40, 26, 12, 26, -34, 12, -42, 24, -50, 36, -79, 36, 3, 24, 44, -24, 44, -36, 3],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[16, 40, 26, 12, 26, -42, -26, -42, -26, 12, -14, 40],
					"method":"arr2vec2arr",
					"defer":true
				},
			},
		},
	}
}

const SHIP_COTHON_LUX = {
	"ship_name":"SHIP_COTHON_LUX",
	"node_definitions":{
		"IOE_BAY_AUX_PERSIST":{},
	}
}

const SHIP_TRTL_RAM = {
	"ship_name":"SHIP_TRTL_RAM",
	"node_definitions":{
		"IOE_BAY_AUX_PERSIST":{},
		"IOE_MPU_BULKER":{
			"position_data":{
				"position":[0,3],
			},
		},
		"IOE_MPU_FURNACE":{
			"position_data":{
				"position":[0,9],
			},
		},
	}
}

const SHIP_PROSPECTOR = {
	"ship_name":"SHIP_PROSPECTOR",
	"node_definitions":{
		"IOE_PREPROC_0x30":{
			"position_data":{
				"position":[-27,-192],
				"scale":[0.8]
			},
		},
		"IOE_PREPROC_20x10":{
			"position_data":{
				"position":[-27,-192],
				"scale":[0.8]
			},
		},
		"IOE_PREPROC_40x20":{
			"position_data":{
				"position":[-23,-192],
				"scale":[0.8]
			},
		},
		"IOE_STORAGE_4K":{
			"position_data":{
				"position":[-27,-192],
				"scale":[0.8]
			},
		},
		"IOE_STORAGE_8K":{
			"position_data":{
				"position":[-27,-192],
				"scale":[0.8]
			},
		},
		"IOE_FABAUX_FAB":{
			"position_data":{
				"position":[-27,-192],
				"scale":[0.8]
			},
		},
		"IOE_FABAUX_BIGFAB":{
			"position_data":{
				"position":[-27,-192],
				"scale":[0.8]
			},
		},
		"IOE_ICEBREAKER_M35":{
			"position_data":{
				"position":[-27,-192],
				"scale":[0.8]
			},
		},
		"IOE_ICEBREAKER_M85":{
			"position_data":{
				"position":[-27,-192],
				"scale":[0.8]
			},
		},
		"IOE_ICEBREAKER_P15":{
			"position_data":{
				"position":[-27,-192],
				"scale":[0.8]
			},
		},
		"IOE_BAY_AUX_PERSIST":{},
		"IOE_MPU_BULKER":{
			"position_data":{
				"position":[0,-32],
			},
			"properties":{
				"polygon":{
					"value":[2, -32, 0, -24, -16, -24, -22, -18, -22, -6, -16, 0, 18, 0, 24, -16, 24, 6, 24, 56, -24, 56, -24, 6, -24, -30, -24, -56, -20, -42, -10, -34],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[-22, 27, 18, 27, 24, 11, -22, 3],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
		"IOE_MPU_FURNACE":{
			"position_data":{
				"position":[0, -42],
			},
			"properties":{
				"polygon":{
					"value":[-24, -78, -12, -54, -20, -46, -20, 44, -12, 64, 12, 64, 20, 44, 20, -46, 12, -54, 24, -78, 24, 66, -24, 66],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[-20, 64, 20, 64, 20, -54, -20, -54],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
	},
}

const SHIP_PROSPECTOR_VP = {
	"ship_name":"SHIP_PROSPECTOR_VP",
	"node_definitions":{
		"IOE_PREPROC_0x30":{
			"position_data":{
				"position":[-27,-130],
				"scale":[0.8]
			},
		},
		"IOE_PREPROC_20x10":{
			"position_data":{
				"position":[-27,-130],
				"scale":[0.8]
			},
		},
		"IOE_PREPROC_40x20":{
			"position_data":{
				"position":[-23,-130],
				"scale":[0.8]
			},
		},
		"IOE_STORAGE_4K":{
			"position_data":{
				"position":[-27,-130],
				"scale":[0.8]
			},
		},
		"IOE_STORAGE_8K":{
			"position_data":{
				"position":[-27,-130],
				"scale":[0.8]
			},
		},
		"IOE_FABAUX_FAB":{
			"position_data":{
				"position":[-27,-130],
				"scale":[0.8]
			},
		},
		"IOE_FABAUX_BIGFAB":{
			"position_data":{
				"position":[-27,-130],
				"scale":[0.8]
			},
		},
		"IOE_ICEBREAKER_M35":{
			"position_data":{
				"position":[-27,-130],
				"scale":[0.8]
			},
		},
		"IOE_ICEBREAKER_M85":{
			"position_data":{
				"position":[-27,-130],
				"scale":[0.8]
			},
		},
		"IOE_ICEBREAKER_P15":{
			"position_data":{
				"position":[-27,-130],
				"scale":[0.8]
			},
		},
		"IOE_BAY_AUX_PERSIST":{},
		"IOE_MPU_BULKER":{
			"position_data":{
				"position":[0,-32],
			},
			"properties":{
				"polygon":{
					"value":[2, -32, 0, -24, -16, -24, -22, -18, -22, -6, -16, 0, 18, 0, 24, -16, 24, 6, 24, 56, -24, 56, -24, 6, -24, -30, -24, -56, -20, -42, -10, -34],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[-22, 27, 18, 27, 24, 11, -22, 3],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
		"IOE_MPU_FURNACE":{
			"position_data":{
				"position":[0, -42],
			},
			"properties":{
				"polygon":{
					"value":[-24, -30, -12, -22, -20, -14, -20, 44, -12, 64, 12, 64, 20, 44, 20, -14, 12, -22, 24, -30, 24, 66, -24, 66],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[-20, 64, 20, 64, 20, -54, -20, -54],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
	},
}

const SHIP_AT225 = {
	"ship_name":"SHIP_AT225",
	"node_definitions":{
		"IOE_PREPROC_0x30":{
			"position_data":{
				"position":[-32,-210]
			},
		},
		"IOE_PREPROC_20x10":{
			"position_data":{
				"position":[-32,-210]
			},
		},
		"IOE_PREPROC_40x20":{
			"position_data":{
				"position":[-28,-210]
			},
		},
		"IOE_STORAGE_4K":{
			"position_data":{
				"position":[-32,-210]
			},
		},
		"IOE_STORAGE_8K":{
			"position_data":{
				"position":[-32,-210]
			},
		},
		"IOE_FABAUX_FAB":{
			"position_data":{
				"position":[-32,-160]
			},
		},
		"IOE_FABAUX_BIGFAB":{
			"position_data":{
				"position":[-32,-160]
			},
		},
		"IOE_ICEBREAKER_M35":{
			"position_data":{
				"position":[-32,-210]
			},
		},
		"IOE_ICEBREAKER_M85":{
			"position_data":{
				"position":[-32,-210]
			},
		},
		"IOE_ICEBREAKER_P15":{
			"position_data":{
				"position":[-32,-210]
			},
		},
		"IOE_BAY_AUX_PERSIST":{},
		"IOE_MPU_BULKER":{
			"position_data":{
				"position":[0,126],
			},
			"properties":{
				"polygon":{
					"value":[2, -32, 0, -24, -18, -24, -24, -18, -24, -6, -18, 0, 18, 0, 24, -8, 32, -56, 32, 0, 32, 24, 20, 64, -20, 64, -32, 24, -32, 0, -32, -24, -32, -56, -24, -40, -14, -34],
					"method":"arr2vec2arr",
					"defer":true
				}
			},
		},
		"IOE_MPU_FURNACE":{
			"position_data":{
				"position":[0,104],
			},
			"properties":{
				"polygon":{
					"value":[-32, -72, -24, -48, -12, -40, -24, -32, -24, 44, -12, 82, 12, 82, 24, 44, 24, -32, 12, -40, 24, -48, 32, -72, 32, -24, 32, 46, 20, 86, -20, 86, -32, 46, -32, -24],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[-24, 44, -12, 82, 12, 82, 24, 44, 24, -40, -24, -40],
					"method":"arr2vec2arr",
					"defer":true
				},
			},
		},
	},
}

const SHIP_AT225B = {
	"ship_name":"SHIP_AT225B",
	"node_definitions":{
		"IOE_PREPROC_0x30":{
			"position_data":{
				"position":[-50,-201],
				"scale":[1.85]
			},
		},
		"IOE_PREPROC_20x10":{
			"position_data":{
				"position":[-50,-201],
				"scale":[1.45]
			},
		},
		"IOE_PREPROC_40x20":{
			"position_data":{
				"position":[-46,-201],
				"scale":[1.5]
			},
			"properties":{
				"polygon":{
					"value":[0,-32,10,-28,8,-12,2,-8,8,-6,10,0,8,6,2,8,8,12,10,28,8,32,-4,32,-23.3,19.3,-4,19.3,-4,-23.3,-14,-42.6],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
		"IOE_STORAGE_4K":{
			"position_data":{
				"position":[-50,-201],
				"scale":[1.2]
			},
		},
		"IOE_STORAGE_8K":{
			"position_data":{
				"position":[-50,-201],
				"scale":[1.4]
			},
			"properties":{
				"polygon":{
					"value":[0,32,-12.1,20.7,0,8,0,-22.1,-5.71,-32.1,10,-32,20,-28,20,4,10,8,10,20],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
		"IOE_FABAUX_FAB":{
			"position_data":{
				"position":[-50,-201]
			},
			"properties":{
				"polygon":{
					"value":[-4,-48,28,-12,32,-4,32,30,18,30,10,40,10,52,0,64,-51,29,0,29],
					"method":"arr2vec2arr",
					"defer":true
				}
			}
		},
		"IOE_FABAUX_BIGFAB":{
			"position_data":{
				"position":[-50,-201]
			},
			"properties":{
				"polygon":{
					"value":[-4,-35,16,-34,32,-28,32,38,24,40,18,40,16,46,10,48,10,60,0,72,-61,70,-78,28,-1,26],
					"method":"arr2vec2arr",
					"defer":true
				}
			}
		},
		"IOE_ICEBREAKER_M35":{
			"position_data":{
				"position":[-50,-201],
				"scale":[2.5]
			},
		},
		"IOE_ICEBREAKER_M85":{
			"position_data":{
				"position":[-50,-201],
				"scale":[3]
			},
			"properties":{
				"polygon":{
					"value":[0,19,-26,9.66,0,9.66,0,-10.3,5,1,6,13],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
		"IOE_ICEBREAKER_P15":{
			"position_data":{
				"position":[-50,-201],
				"scale":[3]
			},
		},
		"IOE_BAY_AUX_PERSIST":{},
	},
}

const SHIP_AT225R = {
	"ship_name":"SHIP_AT225R",
	"node_definitions":{
		"IOE_BAY_AUX_PERSIST":{},
	}
}

const SHIP_PROSPECTOR_FAT = {
	"ship_name":"SHIP_PROSPECTOR_FAT",
	"node_definitions":{
		"IOE_PREPROC_0x30":{
			"position_data":{
				"position":[-40,-230],
				"scale":[0.8]
			},
		},
		"IOE_PREPROC_20x10":{
			"position_data":{
				"position":[-40,-230],
				"scale":[0.8]
			},
		},
		"IOE_PREPROC_40x20":{
			"position_data":{
				"position":[-36,-230],
				"scale":[0.8]
			},
		},
		"IOE_STORAGE_4K":{
			"position_data":{
				"position":[-40,-230],
				"scale":[0.8]
			},
		},
		"IOE_STORAGE_8K":{
			"position_data":{
				"position":[-40,-230],
				"scale":[0.8]
			},
		},
		"IOE_FABAUX_FAB":{
			"position_data":{
				"position":[-40,-230],
				"scale":[0.8]
			},
		},
		"IOE_FABAUX_BIGFAB":{
			"position_data":{
				"position":[-40,-230],
				"scale":[0.8]
			},
		},
		"IOE_ICEBREAKER_M35":{
			"position_data":{
				"position":[-40,-230],
				"scale":[0.8]
			},
		},
		"IOE_ICEBREAKER_M85":{
			"position_data":{
				"position":[-40,-230],
				"scale":[0.8]
			},
		},
		"IOE_ICEBREAKER_P15":{
			"position_data":{
				"position":[-40,-230],
				"scale":[0.8]
			},
		},
		"IOE_BAY_AUX_PERSIST":{},
		"IOE_MPU_BULKER":{
			"position_data":{
				"position":[0,-32],
			},
			"properties":{
				"polygon":{
					"value":[6, -32, 2, -24, -18, -24, -24, -18, -24, -6, -18, 0, 18, 0, 24, -8, 40, -56, 40, -8, 40, 16, 40, 56, -40, 56, -40, 16, -40, -6, -40, -18, -40, -56, -26, -40, -14, -34],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[-24, 27, 22, 27, 28, 11, 2, 3, -24, 3],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
		"IOE_MPU_FURNACE":{
			"position_data":{
				"position":[0, -48],
			},
			"properties":{
				"polygon":{
					"value":[-40, -68, -30, -54, -14, -48, -32, -40, -32, 44, -24, 64, 24, 64, 32, 44, 32, -40, 14, -48, 30, -54, 40, -68, 40, -40, 40, 44, 40, 72, 24, 72, -24, 72, -40, 72, -40, 44, -40, -40],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[-32, 44, -24, 64, 24, 64, 32, 44, 32, -48, -32, -48],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
	},
}

const SHIP_OCP209 = {
	"ship_name":"SHIP_OCP209",
	"node_definitions":{
		"IOE_PREPROC_0x30":{
			"position_data":{
				"position":[-140,0],
				"scale":[1.75],
			},
			"properties":{
				"mirrorVertical":{
					"value":true
				},
				"polygon":{
					"value":[0,25,0,-25,16,-12,12,-4,12,4,16,12]
				},
				"set_rot":{
					"value":45
				}
			}
		},
		"IOE_PREPROC_20x10":{
			"position_data":{
				"position":[-140,0],
				"scale":[1.75],
			},
			"properties":{
				"mirrorVertical":{
					"value":true
				},
				"set_rot":{
					"value":45
				}
			}
		},
		"IOE_PREPROC_40x20":{
			"position_data":{
				"position":[-136,0],
				"scale":[1.5]
			},
			"properties":{
				"mirrorVertical":{
					"value":true
				},
				"set_rot":{
					"value":45
				}
			}
		},
		"IOE_STORAGE_4K":{
			"position_data":{
				"position":[-140,0],
				"scale":[1.75],
			},
			"properties":{
				"mirrorVertical":{
					"value":true
				},
				"set_rot":{
					"value":45
				}
			}
		},
		"IOE_STORAGE_8K":{
			"position_data":{
				"position":[-140,0],
				"scale":[1.75],
			},
			"properties":{
				"mirrorVertical":{
					"value":true
				},
				"set_rot":{
					"value":25
				}
			}
		},
		"IOE_FABAUX_FAB":{
			"position_data":{
				"position":[-140,0],
				"scale":[0.8],
			},
			"properties":{
				"set_rot":{
					"value":45
				}
			}
		},
		"IOE_FABAUX_BIGFAB":{
			"position_data":{
				"position":[-140,0],
				"scale":[0.8],
			},
			"properties":{
				"set_rot":{
					"value":45
				}
			}
		},
		"IOE_ICEBREAKER_M35":{
			"position_data":{
				"position":[-140,0],
				"scale":[1],
			},
			"properties":{
				"mirrorVertical":{
					"value":true
				},
				"set_rot":{
					"value":45
				}
			}
		},
		"IOE_ICEBREAKER_M85":{
			"position_data":{
				"position":[-140,0],
				"scale":[2],
			},
			"properties":{
				"mirrorVertical":{
					"value":true
				},
				"polygon":{
					"value":[0,50,0,-24,15,3,16,41,22,53,17,58],
					"method":"arr2vec2arr",
					"defer":true
				},
				"set_rot":{
					"value":45
				}
			}
		},
		"IOE_ICEBREAKER_P15":{
			"position_data":{
				"position":[-140,0],
				"scale":[2],
			},
			"properties":{
				"mirrorVertical":{
					"value":true
				},
				"set_rot":{
					"value":45
				}
			}
		},
		"IOE_OCP_DOCKING_BAY_UPPER":{},
		"IOE_OCP_DOCKING_BAY_LOWER":{},
		"IOE_OCP_TURRET_BAY_UPPER":{},
		"IOE_OCP_TURRET_BAY_LOWER":{},
		"IOE_MPU_BULKER":{
			"position_data":{
				"position":[0,110],
				"rotation":-90,
			},
			"properties":{
				"polygon":{
					"value":[4, -24, -18, -24, -24, -18, -24, -6, -18, 0, 18, 0, 26, -10, 26, -38, 32, -26, 32, 0, 32, 40, -14, 72, -30, 22, -32, -2, -32, -22, -22, -58, 4, -92],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[-24, 27, 28, 27, 28, 11, -24, 3],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
		"IOE_MPU_FURNACE":{
			"position_data":{
				"position":[-97,0],
				"rotation":90,
			},
			"properties":{
				"polygon":{
					"value":[-106, -15, -84, 7, -46, 27, 0, 37, 46, 27, 84, 7, 106, -15, 116, -33, 110, -45, 30, -33, 16, -25, 22, -41, 136, -61, 122, -25, 100, 3, 72, 23, 36, 39, 0, 45, -36, 39, -70, 25, -100, 3, -122, -27, -136, -61, -22, -41, -16, -25, -30, -33, -110, -45, -116, -33],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[0, 43, 76, 19, 118, -29, 110, -45, 0, -33, -110, -47, -118, -29, -76, 19],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
	},
}

const SHIP_COTHON = {
	"ship_name":"SHIP_COTHON",
	"node_definitions":{
		"IOE_PREPROC_0x30":{
			"position_data":{
				"position":[-43,-188]
			},
		},
		"IOE_PREPROC_20x10":{
			"position_data":{
				"position":[-43,-188]
			},
		},
		"IOE_PREPROC_40x20":{
			"position_data":{
				"position":[-39,-188]
			},
		},
		"IOE_STORAGE_4K":{
			"position_data":{
				"position":[-43,-188]
			},
		},
		"IOE_STORAGE_8K":{
			"position_data":{
				"position":[-43,-188]
			},
		},
		"IOE_FABAUX_FAB":{
			"position_data":{
				"position":[-43,-188]
			},
		},
		"IOE_FABAUX_BIGFAB":{
			"position_data":{
				"position":[-43,-188]
			},
		},
		"IOE_ICEBREAKER_M35":{
			"position_data":{
				"position":[-43,-188]
			},
		},
		"IOE_ICEBREAKER_M85":{
			"position_data":{
				"position":[-43,-188]
			},
		},
		"IOE_ICEBREAKER_P15":{
			"position_data":{
				"position":[-43,-188]
			},
		},
		"IOE_BAY_AUX_PERSIST":{},
		"IOE_MPU_BULKER":{
			"position_data":{
				"position":[0, -8],
			},
			"properties":{
				"polygon":{
					"value":[8, -32, 4, -24, -18, -24, -24, -18, -24, -6, -18, 0, 21, 0, 27, -8, 47, -64, 47, -23, 40, 18, 24, 52, -20, 52, -37, 18, -43, -24, -44, -40, -43, -64, -28, -42, -12, -34],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[-24, 27, 22, 27, 28, 11, -24, 3],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
		"IOE_MPU_FURNACE":{
			"position_data":{
				"position":[0, -28],
			},
			"properties":{
				"polygon":{
					"value":[-44, -100, -36, -84, -26, -76, -12, -72, -12, -68, -34, -62, -34, -6, -20, 66, 20, 66, 37, -6, 37, -62, 15, -68, 15, -72, 29, -76, 39, -84, 47, -100, 47, -3, 40, 38, 28, 72, 22, 72, -22, 72, -28, 72, -37, 38, -44, -4, -44, -68, -44, -78],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[-34, -6, -20, 66, 20, 66, 37, -6, 37, -62, 1, -72, -34, -62],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
	},
}

const SHIP_TRTL_OCP = {
	"ship_name":"SHIP_TRTL_OCP",
	"fallback_to_base_ship":false,
	"fallback_override":"SHIP_TRTL",
	"node_definitions":{
		"IOE_PREPROC_0x30":{
			"position_data":{
				"position":[-140,0],
				"scale":[1.75],
			},
			"properties":{
				"mirrorVertical":{
					"value":true
				},
				"polygon":{
					"value":[0,25,0,-25,16,-12,12,-4,12,4,16,12],
					"method":"arr2vec2arr",
					"defer":true
				},
				
				"set_rot":{
					"value":45
				}
			}
		},
		"IOE_PREPROC_20x10":{
			"position_data":{
				"position":[-140,0],
				"scale":[1.75],
			},
			"properties":{
				"mirrorVertical":{
					"value":true
				},
				
				"set_rot":{
					"value":45
				}
			}
		},
		"IOE_PREPROC_40x20":{
			"position_data":{
				"position":[-136,0],
				"scale":[1.5]
			},
			"properties":{
				"mirrorVertical":{
					"value":true
				},
				
				"set_rot":{
					"value":45
				}
			}
		},
		"IOE_STORAGE_4K":{
			"position_data":{
				"position":[-140,0],
				"scale":[1.75],
			},
			"properties":{
				"mirrorVertical":{
					"value":true
				},
				"set_rot":{
					"value":45
				}
			}
		},
		"IOE_STORAGE_8K":{
			"position_data":{
				"position":[-140,0],
				"scale":[1.75],
			},
			"properties":{
				"mirrorVertical":{
					"value":true
				},
				
				"set_rot":{
					"value":45
				}
			}
		},
		"IOE_FABAUX_FAB":{
			"position_data":{
				"position":[-140,0],
				"scale":[0.8],
			},
			"properties":{
				"set_rot":{
					"value":45
				}
			}
		},
		"IOE_FABAUX_BIGFAB":{
			"position_data":{
				"position":[-140,0],
				"scale":[0.8],
			},
			"properties":{
				"set_rot":{
					"value":45
				}
			}
		},
		"IOE_ICEBREAKER_M35":{
			"position_data":{
				"position":[-140,0],
				"scale":[1],
			},
			"properties":{
				"mirrorVertical":{
					"value":true
				},
				
				"set_rot":{
					"value":45
				}
			}
		},
		"IOE_ICEBREAKER_M85":{
			"position_data":{
				"position":[-140,0],
				"scale":[2],
			},
			"properties":{
				"mirrorVertical":{
					"value":true
				},
			
				"set_rot":{
					"value":45
				}
			}
		},
		"IOE_ICEBREAKER_P15":{
			"position_data":{
				"position":[-140,0],
				"scale":[2],
			},
			"properties":{
				"mirrorVertical":{
					"value":true
				},
				
				"set_rot":{
					"value":45
				}
			}
		},
		"IOE_BAY_AUX_PERSIST":{},
		"IOE_MPU_BULKER":{
			"position_data":{
				"position":[0,110],
				"rotation":-90,
			},
			"properties":{
				"polygon":{
					"value":[4, -24, -18, -24, -24, -18, -24, -6, -18, 0, 18, 0, 26, -10, 26, -38, 32, -26, 32, 0, 32, 40, -14, 72, -30, 22, -32, -2, -32, -22, -22, -58, 4, -92],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
		"IOE_MPU_FURNACE":{
			"position_data":{
				"position":[0,96],
			},
			"properties":{
				"polygon":{
					"value":[-106, -15, -84, 7, -46, 27, 0, 37, 46, 27, 84, 7, 106, -15, 116, -33, 110, -45, 30, -33, 16, -25, 22, -41, 138, -62, 122, -24, 100, 4, 72, 26, 38, 40, 0, 46, -38, 40, -72, 26, -100, 4, -120, -20, -136, -56, -22, -41, -16, -25, -30, -33, -110, -45, -116, -33],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[46, 27, 84, 7, 106, -15, 116, -33, 110, -45, 26, -33, -26, -33, -110, -45, -116, -33, -106, -15, -84, 7, -46, 27, 0, 37],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
	},
}

const SHIP_TRTL_PEEPER = {
	"ship_name":"SHIP_TRTL_PEEPER",
	"fallback_to_base_ship":false,
	"fallback_override":"SHIP_TRTL",
	"node_definitions":{
		"IOE_PREPROC_0x30":{
			"position_data":{
				"position":[-140,0],
				"scale":[1.75],
			},
			"properties":{
				"mirrorVertical":{
					"value":true
				},
				"polygon":{
					"value":[0,25,0,-25,16,-12,12,-4,12,4,16,12],
					"method":"arr2vec2arr",
					"defer":true
				},
				
				"set_rot":{
					"value":45
				}
			}
		},
		"IOE_PREPROC_20x10":{
			"position_data":{
				"position":[-140,0],
				"scale":[1.75],
			},
			"properties":{
				"mirrorVertical":{
					"value":true
				},
			
				"set_rot":{
					"value":45
				}
			}
		},
		"IOE_PREPROC_40x20":{
			"position_data":{
				"position":[-136,0],
				"scale":[1.5]
			},
			"properties":{
				"mirrorVertical":{
					"value":true
				},
		
				"set_rot":{
					"value":45
				}
			}
		},
		"IOE_STORAGE_4K":{
			"position_data":{
				"position":[-140,0],
				"scale":[1.75],
			},
			"properties":{
				"mirrorVertical":{
					"value":true
				},
				"set_rot":{
					"value":45
				}
			}
		},
		"IOE_STORAGE_8K":{
			"position_data":{
				"position":[-140,0],
				"scale":[1.75],
			},
			"properties":{
				"mirrorVertical":{
					"value":true
				},
			
				"set_rot":{
					"value":45
				}
			}
		},
		"IOE_FABAUX_FAB":{
			"position_data":{
				"position":[-140,0],
				"scale":[0.8],
			},
			"properties":{
				"set_rot":{
					"value":45
				}
			}
		},
		"IOE_FABAUX_BIGFAB":{
			"position_data":{
				"position":[-140,0],
				"scale":[0.8],
			},
			"properties":{
				"set_rot":{
					"value":45
				}
			}
		},
		"IOE_ICEBREAKER_M35":{
			"position_data":{
				"position":[-140,0],
				"scale":[1],
			},
			"properties":{
				"mirrorVertical":{
					"value":true
				},
			
				"set_rot":{
					"value":45
				}
			}
		},
		"IOE_ICEBREAKER_M85":{
			"position_data":{
				"position":[-140,0],
				"scale":[2],
			},
			"properties":{
				"mirrorVertical":{
					"value":true
				},
			
				"set_rot":{
					"value":45
				}
			}
		},
		"IOE_ICEBREAKER_P15":{
			"position_data":{
				"position":[-140,0],
				"scale":[2],
			},
			"properties":{
				"mirrorVertical":{
					"value":true
				},
			
				"set_rot":{
					"value":45
				}
			}
		},
		"IOE_BAY_AUX_PERSIST":{},
		"IOE_MPU_BULKER":{
			"position_data":{
				"position":[0,85],
				"rotation":-90,
			},
			"properties":{
				"polygon":{
					"value":[4, -29, -23, -29, -29, -23, -29, -11, -23, 0, 23, 0, 31, -15, 31, -43, 37, -31, 37, 1.4, 37, 40, -30, 72, -40, 22, -42, -2, -42, -22, -32, -70, 0, -110],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
		"IOE_MPU_FURNACE":{
			"position_data":{
				"position":[0,85],
			},
			"properties":{
				"polygon":{
					"value":[-106, -10, -84, 7, -46, 27, 46, 27, 84, 7, 106, -10, 116, -28, 110, -40, 30, -28, 16, -20, 22, -36, 138, -57, 137, -43, 126, -14, 107, 8, 88, 24, 60, 37, 0, 46, -60, 37, -86, 27, -107, 6, -125, -18, -139, -52, -22, -36, -16, -20, -30, -28, -110, -40, -116, -28],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[46, 27, 84, 7, 106, -15, 116, -33, 110, -45, 26, -33, -26, -33, -110, -45, -116, -33, -106, -15, -84, 7, -46, 27, 0, 37],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
	},
}

const SHIP_TSUKUYOMI_IOT = {
	"ship_name":"SHIP_TSUKUYOMI_IOT",
	"fallback_to_base_ship":false,
	"fallback_override":"SHIP_TSUKUYOMI_IOT",
	"node_definitions":{
		"IOE_PREPROC_0x30":{
			"position_data":{
				"position":[-117,-1125],
				"scale":[2]
			},
		
		},
		"IOE_PREPROC_20x10":{
			"position_data":{
				"position":[-117,-1125],
				"scale":[2]
			},
		
		},
		"IOE_PREPROC_40x20":{
			"position_data":{
				"position":[-113,-1125],
				"scale":[2]
			},
	
		},
		"IOE_STORAGE_4K":{
			"position_data":{
				"position":[-117,-1125],
				"scale":[2]
			},
		},
		"IOE_STORAGE_8K":{
			"position_data":{
				"position":[-117,-1125],
				"scale":[2]
			},
	
		},
		"IOE_FABAUX_FAB":{
			"position_data":{
				"position":[-117,-1125],
				"scale":[2]
			},
		},
		"IOE_FABAUX_BIGFAB":{
			"position_data":{
				"position":[-117,-1125],
				"scale":[2]
			},
		},
		"IOE_ICEBREAKER_M35":{
			"position_data":{
				"position":[-117,-1125],
				"scale":[2]
			},
	
		},
		"IOE_ICEBREAKER_M85":{
			"position_data":{
				"position":[-117,-1125],
				"scale":[2]
			},
	
		},
		"IOE_ICEBREAKER_P15":{
			"position_data":{
				"position":[-117,-1125],
				"scale":[2]
			},
		
		},
		"IOE_BAY_AUX_PERSIST":{},
		"IOE_MPU_BULKER":{
			"position_data":{
				"position":[0,-498],
			},
			"properties":{
				"polygon":{
					"value":[4, -32, 2, -24, -18, -24, -24, -18, -24, -6, -18, 0, 18, 0, 24, -8, 40, -70, 40, -10, 40, 26, 40, 56, -40, 56, -40, 26, -40, -10, -40, -38, -40, -70, -30, -46, -16, -34],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
		"IOE_MPU_FURNACE":{
			"position_data":{
				"position":[0,-470],
			},
			"properties":{
				"polygon":{
					"value":[-40, -186, -34, -164, -24, -152, -14, -146, -30, -138, -30, 14, -14, 20, 14, 20, 30, 14, 30, -138, 14, -146, 24, -152, 34, -164, 40, -186, 40, -144, 40, 28, 16, 28, -16, 28, -40, 28, -40, -144],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[-30, 20, 30, 20, 30, -146, -30, -146],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
	},
}

const SHIP_PROSPECTOR_PIGEON = {
	"ship_name":"SHIP_PROSPECTOR_PIGEON",
	"fallback_to_base_ship":true,
	"fallback_override":"SHIP_PROSPECTOR",
	"node_definitions":{
		"IOE_PREPROC_0x30":{
			"position_data":{
				"position":[-40,-165],
				"scale":[0.8]
			},
		},
		"IOE_PREPROC_20x10":{
			"position_data":{
				"position":[-40,-165],
				"scale":[0.8]
			},
		
		},
		"IOE_PREPROC_40x20":{
			"position_data":{
				"position":[-36,-165],
				"scale":[0.8]
			},
		},
		"IOE_STORAGE_4K":{
			"position_data":{
				"position":[-40,-165],
				"scale":[0.8]
			},
		},
		"IOE_STORAGE_8K":{
			"position_data":{
				"position":[-40,-165],
				"scale":[0.8]
			},
		},
		"IOE_FABAUX_FAB":{
			"position_data":{
				"position":[-40,-165],
				"scale":[0.8]
			},
		},
		"IOE_FABAUX_BIGFAB":{
			"position_data":{
				"position":[-40,-165],
				"scale":[0.8]
			},
		},
		"IOE_ICEBREAKER_M35":{
			"position_data":{
				"position":[-40,-165],
				"scale":[0.8]
			},
		},
		"IOE_ICEBREAKER_M85":{
			"position_data":{
				"position":[-40,-165],
				"scale":[0.8]
			},
		},
		"IOE_ICEBREAKER_P15":{
			"position_data":{
				"position":[-40,-165],
				"scale":[0.8]
			},
		},
		"IOE_BAY_AUX_PERSIST":{},
		"IOE_MPU_BULKER":{
			"position_data":{
				"position":[0,-32],
			},
			"properties":{
				"polygon":{
					"value":[6, -32, 2, -24, -18, -24, -24, -18, -24, -6, -18, 0, 18, 0, 24, -8, 40, -56, 40, -8, 40, 16, 40, 56, -40, 56, -40, 16, -40, -6, -40, -18, -40, -56, -26, -40, -14, -34],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[-24, 27, 22, 27, 28, 11, 2, 3, -24, 3],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
		"IOE_MPU_FURNACE":{
			"position_data":{
				"position":[0, -48],
			},
			"properties":{
				"polygon":{
					"value":[-40, -68, -30, -54, -14, -48, -32, -40, -32, 44, -24, 64, 24, 64, 32, 44, 32, -40, 14, -48, 30, -54, 40, -68, 40, -40, 40, 44, 40, 72, 24, 72, -24, 72, -40, 72, -40, 44, -40, -40],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[-32, 44, -24, 64, 24, 64, 32, 44, 32, -48, -32, -48],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
	},
}

const SHIP_KITSUNE = {
	"ship_name":"SHIP_KITSUNE",
	"node_definitions":{
		"IOE_MPU_BULKER":{
			"properties":{
				"polygon":{
					"value":[0, -32, 0, -24, -18, -24, -24, -18, -24, -6, -18, 0, 18, 0, 24, -8, 24, -38, 30, -38, 30, 2, 24, 32, -24, 32, -30, 2, -30, -22, -30, -38, -24, -38, -14, -34],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
		"IOE_MPU_FURNACE":{
			"properties":{
				"polygon":{
					"value":[-24, -38, -12, -34, -22, -26, -22, 16, -14, 28, 14, 28, 22, 16, 22, -26, 12, -34, 24, -38, 30, -24, 30, 24, 16, 38, -16, 38, -30, 24, -30, -24],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[-22, 16, -14, 28, 14, 28, 22, 16, 22, -34, -22, -34],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
	}
}

const SHIP_OBERON = {
	"ship_name":"SHIP_OBERON",
	"node_definitions":{
		"IOE_MPU_BULKER":{
			"position_data":{
				"position":[0, -146],
			},
			"properties":{
				"polygon":{
					"value":[-2, -36, -16, -36, -20, -30, -20, -18, -16, -12, 16, -12, 20, -18, 20, -44, 24, -36, 24, -18, 24, 2, 24, 30, -24, 30, -24, 2, -24, -18, -24, -36, -20, -44, -18, -48, -2, -40],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[-20, 15, 20, 15, 20, -9, -20, -9],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
		"IOE_MPU_FURNACE":{
			"position_data":{
				"position":[0, -114],
			},
			"properties":{
				"polygon":{
					"value":[-18, -92, -12, -78, -20, -68, -20, -16, -12, -6, 10, -6, 20, -16, 20, -68, 12, -78, 18, -92, 18, -80, 24, -68, 24, -2, -24, -2, -24, -68, -18, -80],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[-20, -6, 20, -6, 20, -68, 12, -78, -12, -78, -20, -68],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
	}
}

const SHIP_EIME = {
	"ship_name":"SHIP_EIME",
	"node_definitions":{
		"IOE_MPU_BULKER":{
			"parent_node_path":"Beak/Claw Right",
			"position_data":{
				"position":[10, 3],
				"rotation":180
			},
			"properties":{
				"polygon":{
					"value":[27, -22, 21, -22, -23, -38, -29, -36, -33, -22, -29, -14, 19, 4, 19, 38, 5, 52, -19, 52, -33, -8, -37, -22, -41, -36, -43, -52, -23, -44],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[-35, 11, 19, 31, 25, 5, -29, -13],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
		"IOE_MPU_FURNACE":{
			"parent_node_path":"Beak/Claw Right",
			"position_data":{
				"position":[0, -29],
				"rotation":180
			},
			"properties":{
				"polygon":{
					"value":[-53, -84, -25, -72, 3, -60, 17, -54, 9, -50, 3, -54, -27, -54, -35, -42, -17, 48, -9, 56, 3, 56, 9, 48, 9, -14, 3, -18, 9, -24, 17, -18, 17, 56, 7, 68, 7, 78, -15, 62, -21, 58, -43, -42],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[-15, 56, 9, 56, 9, -54, -39, -54],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
	}
}

const SHIP_CK69 = {
	"ship_name":"SHIP_CK69",
	"node_definitions":{
		"IOE_MPU_BULKER":{
			"position_data":{
				"position":[0, -172],
			},
			"properties":{
				"polygon":{
					"value":[0, -24, -16, -24, -22, -18, -22, -6, -16, 0, 16, 0, 22, -8, 22, -24, 16, -34, 24, -34, 24, 34, -24, 34, -24, -34, -16, -34, -4, -30],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[-22, 27, 22, 27, 22, 9, -22, 3],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
		"IOE_MPU_FURNACE":{
			"position_data":{
				"position":[0, -241],
			},
			"properties":{
				"polygon":{
					"value":[-20, 68, -12, 70, 12, 70, 20, 68, 20, 10, 12, 8, 16, 4, 24, 4, 24, 72, -24, 72, -24, 4, -16, 4, -12, 8, -20, 10],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[-20, 70, 20, 70, 20, 8, -20, 8],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
	}
}

const SHIP_CK65 = {
	"ship_name":"SHIP_CK65",
	"node_definitions":{
		"IOE_MPU_BULKER":{
			"position_data":{
				"position":[0, -172],
			},
			"properties":{
				"polygon":{
					"value":[0, -24, -16, -24, -22, -18, -22, -6, -16, 0, 16, 0, 22, -8, 22, -24, 16, -34, 24, -34, 24, 34, -24, 34, -24, -34, -16, -34, -4, -30],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[-22, 27, 22, 27, 22, 9, -22, 3],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
		"IOE_MPU_FURNACE":{
			"position_data":{
				"position":[0, -241],
			},
			"properties":{
				"polygon":{
					"value":[-20, 68, -12, 70, 12, 70, 20, 68, 20, 10, 12, 8, 16, 4, 24, 4, 24, 72, -24, 72, -24, 4, -16, 4, -12, 8, -20, 10],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[-20, 70, 20, 70, 20, 8, -20, 8],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
	}
}

const SHIP_ATLAS_WASP = {
	"ship_name":"SHIP_ATLAS_WASP",
	"node_definitions":{
		"IOE_MPU_BULKER":{
			"position_data":{
				"position":[0, -142],
			},
			"properties":{
				"polygon":{
					"value":[0, -28, 0, -24, -16, -24, -20, -18, -20, -6, -16, 0, 16, 0, 24, -12, 24, 8, 24, 46, -24, 46, -24, 8, -24, -6, -24, -18, -24, -42, -14, -32],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[-24, 27, 24, 27, 24, 11, -16, 3, -24, 3],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
		"IOE_MPU_FURNACE":{
			"position_data":{
				"position":[0, -168],
			},
			"properties":{
				"polygon":{
					"value":[-24, -16, -12, -8, -12, -4, -18, 0, -18, 54, -12, 66, 12, 66, 18, 54, 18, 0, 12, -4, 12, -8, 24, -16, 24, 0, 24, 54, 24, 72, -24, 72, -24, 54, -24, 0],
					"method":"arr2vec2arr",
					"defer":true
				},
				"MineralProcessingUnit/CollisionPolygon2D/polygon":{
					"value":[-18, 54, -12, 66, 12, 66, 18, 54, 18, -6, -18, -6],
					"method":"arr2vec2arr",
					"defer":true
				},
			}
		},
	}
}

const SHIP_AT225_CK = {
	"ship_name":"SHIP_AT225_CB",
	"node_definitions":{
		"IOE_MPU_BULKER":{
			"position_data":{
				"position":[0, 136],
			},
			"mod_requirements":[["wt.funnel_titan"]]
		},
		"IOE_MPU_FURNACE":{
			"position_data":{
				"position":[0, 126],
			},
			"mod_requirements":[["wt.funnel_titan"]]
		},
		
		"IOE_PREPROC_0x30":{
			"position_data":{
				"position":[-32,-150],
			},
			"mod_requirements":[["wt.funnel_titan"]]
		},
		"IOE_PREPROC_20x10":{
			"position_data":{
				"position":[-32,-150],
			},
			"mod_requirements":[["wt.funnel_titan"]]
		
		},
		"IOE_PREPROC_40x20":{
			"position_data":{
				"position":[-32,-150],
			},
			"mod_requirements":[["wt.funnel_titan"]]
		},
		"IOE_STORAGE_4K":{
			"position_data":{
				"position":[-32,-150],
			},
			"mod_requirements":[["wt.funnel_titan"]]
		},
		"IOE_STORAGE_8K":{
			"position_data":{
				"position":[-32,-150],
				"scale":[0.9]
			},
			"mod_requirements":[["wt.funnel_titan"]]
		},
		"IOE_FABAUX_FAB":{
			"position_data":{
				"position":[-32,-150],
			},
			"mod_requirements":[["wt.funnel_titan"]]
		},
		"IOE_FABAUX_BIGFAB":{
			"position_data":{
				"position":[-32,-150],
			},
			"mod_requirements":[["wt.funnel_titan"]]
		},
		"IOE_ICEBREAKER_M35":{
			"position_data":{
				"position":[-32,-150],
			},
			"mod_requirements":[["wt.funnel_titan"]]
		},
		"IOE_ICEBREAKER_M85":{
			"position_data":{
				"position":[-32,-150],
			},
			"mod_requirements":[["wt.funnel_titan"]]
		},
		"IOE_ICEBREAKER_P15":{
			"position_data":{
				"position":[-32,-150],
			},
			"mod_requirements":[["wt.funnel_titan"]]
		},
		"IOE_BAY_AUX_PERSIST":{
			"mod_requirements":[["wt.funnel_titan"]]
		},
	}
}
