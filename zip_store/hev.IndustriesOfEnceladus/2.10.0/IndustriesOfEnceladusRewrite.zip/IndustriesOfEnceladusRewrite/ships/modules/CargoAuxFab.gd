# [license]
# 3-Clause BSD NON-AI License
# 
# Copyright 2026 __hev (Benjamin Buckhurst)
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

extends "res://IndustriesOfEnceladusRewrite/ships/modules/CargoAuxBase.gd"

export  var dronePrintTime = 0.0
export  var bulletPrintTime = 0.0
export  var powerDrawPrint = 70000.0
export (bool) var enabled = true
export  var modify_kgps_add = 0
export  (int, 10, 1000, 1) var modify_kgps_percent_multi = 100

const droneUnit = 0.1
const droneCostPerKg = {
	"Fe":0.8, 
	"Pt":0.2
}

const massDriverUnit = 10.0
const massDriverCostPerKg = {
	"Fe":0.9, 
	"V":0.1
}

var massDriverCostCache = {}
var droneCostCache = {}

onready var printA = $PrintAudio

onready var dronePrintCtr = dronePrintTime
onready var bulletPrintCtr = bulletPrintTime

var power = 0

func getStatus():
	return 100
func getPower():
	return clamp(power, 0, 1)

func tryToDraw(cost:Dictionary, unit:float)->bool:
	var have = true
	for m in cost:
		var how = cost[m] * unit
		if ship.getProcessedCargo(m) < how:
			have = false
	if not have:
		return false
		
	for m in cost:
		var how = cost[m] * unit
		ship.removeProcessedCargo(m, how)
	return true

var made_adjustment = false

var has_modified = false

var current_model = ""

var baseMineralEfficiency = 0
var basekgps = 0
var basePowerDrawPerKg = 0

var fabricationRate = 100.0
export var tuneable_speed_min = 0.75
export var tuneable_speed_max = 2.5

export var material_low = 0.5
export var material_high = 3.0
export var max_efficiency_reduction = 100

func get_fabrication_rate() -> float:
	return ship.getTunedValue(slotName, "IOE_TUNE_FAB_SPEED", fabricationRate)

func powerFromRatio(x: float) -> float:
	return (( 1.0 / ( x * ( 3.0 - x )) - 1 ) * 1.8 + 2 )

func get_power():
	var dynamicKgps = get_fabrication_rate()
	var ratio = dynamicKgps / fabricationRate
	var powerDrawKw = powerDrawPrint * ratio
	return powerDrawKw

func material_efficiency():
	var dynamicKgps = get_fabrication_rate()
	var ratio = dynamicKgps / fabricationRate
	var lv = range_lerp(ratio,material_low,material_high,0,1)
	return lv * max_efficiency_reduction

func getTuneables():
	var out = {}
	out.merge({"IOE_TUNE_FAB_SPEED": {
		"type": "float", 
		"min": ceil(fabricationRate * tuneable_speed_min), 
		"max": ceil(fabricationRate * tuneable_speed_max), 
		"step": 5, 
		"default": fabricationRate, 
		"current": get_fabrication_rate(), 
		"unit": "%", 
		"testProtocol": "cargo"
	}})
	return out

func getParameters():
	var out = {}
	var powerDrawKw = get_power()
	var powerDrawHuman = ["%s" % [CurrentGame.formatThousands(powerDrawKw / 1000)], "MW"] if powerDrawKw > 1000 else ["%s" % [CurrentGame.formatThousands(powerDrawKw)], "kW"]
	var speedRatio = float(fabricationRate / get_fabrication_rate())
	var bpt = (bulletPrintTime*speedRatio)
	var dpt = (dronePrintTime*speedRatio)
	var ammoSpeed = (1/bpt) * massDriverUnit
	var droneSpeed = (1/dpt) * droneUnit
	out.merge({"IOE_TUNE_PARAMETER_PRINT_AMMO_SPEED":["%.1f" % ammoSpeed, "kg/s"]})
	out.merge({"IOE_TUNE_PARAMETER_PRINT_DND_SPEED":["%.1f" % droneSpeed, "kg/s"]})
	out.merge({"IOE_TUNE_PARAMETER_PRINT_POWER_DRAW": powerDrawHuman})
	out.merge({"IOE_TUNE_PARAMETER_PRINT_MATERIAL_EFFICIENCY":["%.1f" % material_efficiency(), "%"]})
	return out 


func calculate_costs():
	var modify = (float(material_efficiency()) / 100)
	for m in droneCostPerKg:
		droneCostCache[m] = float(droneCostPerKg[m]) * (1 + modify)
	for m in massDriverCostPerKg:
		massDriverCostCache[m] = float(massDriverCostPerKg[m]) * (1 + modify)

func getAmmoCost():
	if massDriverCostCache:
		return massDriverCostCache
	return massDriverCostPerKg

func getDroneCost():
	if droneCostCache:
		return droneCostCache
	return droneCostPerKg


func _ready():
	var ship = getShip()
	if not ship.setup:
		yield(ship,"setup")
	var processor
	var reinstance = false
	var current_aux = ship.getConfig("cargo.aux")
	var current_mpu = ship.getConfig("cargo.equipment")
	calculate_costs()
	if current_aux == systemName:
		if current_model != current_mpu:
			reinstance = true
			current_model = current_mpu
		var self_aux = systemName
		for node in ship.get_children():
			if "systemName" in node:
				var nname = node.name
				if node.systemName == current_mpu:
					processor = node
		if processor:
			if not has_modified:
				baseMineralEfficiency = processor.mineralEfficiency
				basekgps = processor.kgps
				basePowerDrawPerKg = processor.powerDrawPerKg
				modifyProcessor(processor,basekgps,basePowerDrawPerKg)
				has_modified = true
			else:
				modifyProcessor(processor,basekgps,basePowerDrawPerKg)
			
#				breakpoint
	

func _physics_process(delta):
	
	if enabled:
		if Tool.claim(ship):
			var pwr = get_power()
			var speedRatio = float(fabricationRate / get_fabrication_rate())
			var newBulletPrintTime = (bulletPrintTime*speedRatio)
			var newDronePrintTime = (dronePrintTime*speedRatio)
			
			var scaledBulletUnit = massDriverUnit
			var scaledDroneUnit = droneUnit
			
			if newBulletPrintTime < delta:
				scaledBulletUnit *= (delta/newBulletPrintTime)
			if newDronePrintTime < delta:
				scaledDroneUnit *= (delta/newDronePrintTime)
			
			
			if ship.droneParts + scaledDroneUnit <= ship.dronePartsMax and pwr > 0:
				if dronePrintCtr < newDronePrintTime:
					var p = pwr * delta
					if ship.drawEnergy(p) >= p * 0.9:
						dronePrintCtr += delta
						
			if ship.massDriverAmmo + scaledBulletUnit <= ship.massDriverAmmoMax and pwr > 0:
				if bulletPrintCtr < newBulletPrintTime:
					var p = pwr * delta
					if ship.drawEnergy(p) >= p * 0.9:
						bulletPrintCtr += delta
					
			if newBulletPrintTime > 0 and bulletPrintCtr >= newBulletPrintTime:
				if tryToDraw(getAmmoCost(), scaledBulletUnit):
					ship.addAmmo(scaledBulletUnit)
					bulletPrintCtr -= newBulletPrintTime
					if newBulletPrintTime > 1:
						if ship.isPlayerControlled() and printA:
							printA.play()
							
			if newDronePrintTime > 0 and dronePrintCtr >= newDronePrintTime:
				if tryToDraw(getDroneCost(), scaledDroneUnit):
					ship.addDrones(scaledDroneUnit)
					dronePrintCtr -= newDronePrintTime
					if newDronePrintTime > 1:
						if ship.isPlayerControlled() and printA:
							printA.play()
							
			Tool.release(ship)


func modifyProcessor(processor,nodeKGPS,nodePower):
	
	var clp = clamp(modify_kgps_percent_multi,10,1000)
	var cc = clp/100.0
	var pl = nodeKGPS * cc
	var om = pl + modify_kgps_add
	var newKGPS = int(pl)
	
	var powerFactor = float((float(newKGPS)/float(nodeKGPS)))
	var newPower = int(nodePower * powerFactor)
	
	if newKGPS != 100.0 or modify_kgps_add != 0.0:
		processor.set("powerDrawPerKg",newPower)
		processor.set("kgps",newKGPS)
