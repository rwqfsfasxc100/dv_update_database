extends "res://IndustriesOfEnceladusRewrite/ships/modules/CargoAuxBase.gd"

export  var ventTime = 0.5
export  var massDamageScale = 20.0
export (float, 0, 1000, 0.5) var self_kgps = 100.0
export  var powerDrawPerKg = 100
export (int, 50, 150) var modify_mineralEfficiency = 100
export (float, 0, 1, 0.05) var self_remassEfficiency = 0.5
export (int) var modify_kgps_add = 0
export  (int, 10, 1000, 1) var modify_kgps_percent_multi = 100

export (float) var tuneable_speed_min = 0.5
export (float) var tuneable_speed_max = 1.5

export (float,0.1,1.0,0.05) var minimum_filler_content = 0.30

export (int,-50,50,1) var tunable_mpu_min = -15
export (int,-50,50,1) var tunable_mpu_max = 15

export (int, 5, 75, 1) var max_ores_processing = 10
export (float, 0,20,0.05) var ore_swapover_time = 5.0
export (float) var ore_swapover_fade_time = 0.33
export (float) var swapover_color_fade_scale = 3.0

export  var enabled = true


var power = 0.0

func getStatus():
	return 100
func getPower():
	if bayCount:
		var pv = clamp(power / min(bayCount,max_ores_processing), 0, 1)
		var sv = swapover_fade * swapover_color_fade_scale
		return clamp(pv - (sv * pv),0,1)
	return 0.0

func get_minimum_filler_content():
	var base = minimum_filler_content
	var dynamicKgps = get_preprocessor_kgps()
	var ratio = dynamicKgps / self_kgps
	base = pow(base,2.0 - ratio)
	var b2 = base / 1.5
	return clamp(b2,0.05,1.0)



func get_preprocessor_kgps() -> float:
	return ship.getTunedValue(slotName, "IOE_TUNE_PREPROC_RECLAIM", self_kgps)

func get_preprocessor_efficiency() -> float:
	var tuned = ship.getTunedValue(slotName, "IOE_TUNE_PREPROC_RECLAIM", self_kgps)
	var val = pow(self_remassEfficiency,tuned / self_kgps)
	return val

func powerFromRatio(x: float) -> float:
	return ((1.0 / (x * (2.0 - x)) - 1) * 1.8 + 1)

func get_power():
	var dynamicKgps = get_preprocessor_kgps()
	var ratio = dynamicKgps / self_kgps
	var pv = powerFromRatio(ratio) * dynamicKgps
	var powerDrawKw = (powerDrawPerKg * pv)/self_kgps
	return powerDrawKw

func getParameters():
	if self_kgps == 0 or powerDrawPerKg == 0:
		return {}
	
	var out = {}
	if self_remassEfficiency > 0.0 or self_kgps > 0.0:
		var powerDrawKw = get_power()
		var powerDrawHuman = ["%s" % [CurrentGame.formatThousands(powerDrawKw / 1000)], "MW"] if powerDrawKw > 1000 else ["%s" % [CurrentGame.formatThousands(powerDrawKw)], "kW"]
		out.merge({"IOE_TUNE_PARAMETER_PREPROC_MELT_REMASS_EFFICIENCY": ["%.1f" % [(get_preprocessor_efficiency() * 100.0)], "%"]})
		out.merge({"IOE_TUNE_PARAMETER_PREPROC_MELT_POWER_DRAW": powerDrawHuman})
		if minimum_filler_content < 1.0:
			
			out.merge({"IOE_TUNE_PARAMETER_PREPROC_CHUNK_WATER_MASS_CEILING": ["%.1f" % (get_minimum_filler_content() * 100), "%"]})
		
	return out

func getTuneables():
	if self_kgps <= 0.0 or powerDrawPerKg <= 0.0:
		return {}
	var out = {}
	if self_remassEfficiency > 0.0:
		out.merge({"IOE_TUNE_PREPROC_RECLAIM": {
			"type": "float", 
			"min": ceil(float(self_kgps) * tuneable_speed_min), 
			"max": ceil(float(self_kgps) * tuneable_speed_max), 
			"step": ceil(float(self_kgps) / 100), 
			"default": self_kgps, 
			"current": get_preprocessor_kgps(), 
			"unit": "kg/s", 
			"testProtocol": "cargo"
		}})
	return out

var processor = null

func _ready():
	ship = getShip()
	if not ship.setup:
		yield(ship,"setup")
	var current_aux = ship.getConfig("cargo.aux")
	var current_mpu = ship.getConfig("cargo.equipment")
	if current_aux == systemName:
		var self_aux = systemName
		var shipSystems = ship.getSystems()
		for sys in shipSystems:
			var node = shipSystems[sys]
			if node.name == current_mpu:
				processor = node.ref
		if processor:
			baseMineralEfficiency = processor.mineralEfficiency
			basekgps = processor.kgps
			basePowerDrawPerKg = processor.powerDrawPerKg
			modifyProcessor()

onready var ventRemass = $VentRemass
onready var ventMineral = $VentMineral
onready var processingA = $Processing
onready var proStart = $ProStart
onready var proStop = $ProStop
onready var swap = $Swap

var ventingMineral = 0.0

var baseMineralEfficiency = 0
var basekgps = 0
var basePowerDrawPerKg = 0

var swapover_fade = 0.0
var swapover_direction = false
var swapover_time = 0.0

var conserved_isproc = false

func _physics_process(delta):
	ventingMineral = max(0, ventingMineral - delta)

	var venting = false
	var isproc = false
	
	if enabled:
		if (self_remassEfficiency > 0.0 or self_kgps > 0.0):
			var current_kgps = get_preprocessor_kgps()
			var current_powerdraw = get_power()
			var current_remassefficiency = get_preprocessor_efficiency()
			var forProcessing = get_processable_object(delta)
			var minFillContent = get_minimum_filler_content()
			if not swapover_time > 0.0:
				var pvCache = 0.0
				for p in forProcessing:
					if Tool.claim(p):
						if "fillerContent" in p:
							if p.fillerContent > minFillContent:
								var fillerMass = p.fillerContent * p.mass
								var mineralMass = p.mineralContent * p.mass
								var procDelta = min(fillerMass, delta * current_kgps / 1000)
								var requiredPower = procDelta * current_powerdraw * 100
								var gotPower = ship.drawEnergy(requiredPower)
								if gotPower / requiredPower > 0.9:
									var nm = max(mineralMass, p.mass - procDelta)
									
									if nm > 0:
										p.mass = nm
										p.mineralContent = mineralMass / nm
									
									p.fillerContent = 1 - p.mineralContent
									if p.fillerContent <= minFillContent:
										ventingMineral = ventTime
									var newMass = max(mineralMass, p.mass - procDelta)
									var massChange = p.mass - newMass
									var shipRemass = ship.reactiveMass
									var procRemass = massChange * 1000 * current_remassefficiency
									var newRemass = clamp(shipRemass + procRemass, 0, ship.reactiveMassMax)
									ship.reactiveMass = newRemass
									isproc = true
									pvCache += 1.0
									venting = (newRemass - shipRemass < procRemass / 2)
									ship.cargoMass = max(ship.cargoMass - massChange * 1000, 0)
						else :
							if p.has_method("getScan") and p.getScan() == "H2O" and p.has_method("applyEnergyDamage"):
								var mad = max(1, p.mass / massDamageScale)
								var proc = min(p.mass, delta * current_kgps / 1000) * mad
								var requiredPower = proc * current_powerdraw * 1000 * delta * 60
								var gotPower = ship.drawEnergy(requiredPower)
								var prm = ship.reactiveMass
								if gotPower / requiredPower > 0.9:
									p.applyEnergyDamage(gotPower, p.global_position, delta)
									var st = current_remassefficiency * proc * 1000
									var nrm = clamp(prm + st, 0, ship.reactiveMassMax)
									ship.reactiveMass = nrm
									isproc = true
									pvCache += 1.0
									venting = (nrm - prm < st / 2)
					Tool.release(p)
				conserved_isproc = isproc
				power = pvCache
	else: power = 0.0
	
	ventRemass.emitting = venting and not Settings.particlesForbidden
	ventMineral.emitting = ventingMineral > 0 and not Settings.particlesForbidden
	
	if swapover_direction:
		if swapover_fade < ore_swapover_fade_time:
			swapover_fade += delta
		else:
			swapover_direction = false
	else:
		if swapover_fade > 0.0:
			swapover_fade -= delta
	if swapover_time > 0.0:
		swapover_time -= delta
	elif ship.isPlayerControlled():
		if conserved_isproc:
			if not processingA.playing:
				processingA.play()
				proStart.play()
		else :
			if processingA.playing:
				processingA.stop()
				proStop.play()


func modifyProcessor():
	var current_efficiency_multi = modify_mineralEfficiency
	var newMinEff = clamp(baseMineralEfficiency * (float(current_efficiency_multi)/100), 0.05, 0.995) if baseMineralEfficiency > 0.0 else 0.0
	
	var current_speed_multi = modify_kgps_percent_multi
	var clp = clamp(current_speed_multi,10,1000)
	var cc = clp/100.0
	var pl = basekgps * cc
	var om = pl + modify_kgps_add
	var newKGPS = int(max(om,5))
	
	var rt = (float(baseMineralEfficiency)/float(newMinEff)) if newMinEff > 0.0 else 1.0
	var newPower = pow(basePowerDrawPerKg / 10,2.0 - rt) * 10 * cc
	
	if modify_mineralEfficiency != 100:
		processor.setEfficiency(newMinEff)
	if modify_kgps_percent_multi != 100 or modify_kgps_add != 0:
		processor.setKgps(newKGPS)
	if rt != 1:
		processor.setPower(newPower)

var counter = 0.0
var bayCount = 0
var current_indexes = []
func get_processable_object(delta):
	var cargo = ship.cargo
	var s = cargo.size()
	if s:
		if s > max_ores_processing:
			var lucky = []
			if s == bayCount:
				counter += delta
				if counter > (ore_swapover_time + ore_swapover_fade_time):
					counter = 0.0
					swapover_fade = delta
					swapover_time = ore_swapover_fade_time
					swapover_direction = true
					current_indexes.shuffle()
					if conserved_isproc:
						swap.play()
			else:
				current_indexes = range(s)
				current_indexes.shuffle()
				bayCount = s
				counter = 0.0
				swapover_fade = delta
				swapover_time = ore_swapover_fade_time
				swapover_direction = true
				if conserved_isproc:
					swap.play()
			for i in range(max_ores_processing):
				lucky.append(cargo[current_indexes[i]])
			return lucky
		else:
			counter = 0.0
			swapover_fade = 0.0
			swapover_time = 0.0
			swapover_direction = false
			current_indexes = cargo
			return cargo
	bayCount = 0
	return []
	
	

