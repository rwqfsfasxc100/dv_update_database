# [license]
# SPDX-License-Identifier: LicenseRef-Proprietary
# Copyright © 2026 __hev (Benjamin Buckhurst). All Rights Reserved.
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that all following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

extends VBoxContainer

var path = ""

var rich_entry_label:PackedScene = load("res://HevLib/ui/mod_menu/changelogs/labels/rich_changelog_entry.tscn")

var changelog_container:PackedScene = load("res://HevLib/ui/mod_menu/changelogs/ChangelogContainer.tscn")

var pointers :HevLibPointers= ModLoader._savedObjects[0]
export (String,"singular","dynamic") var operation = "singular"

onready var LEFT = $PAGES/LEFT
onready var RIGHT = $PAGES/RIGHT

onready var pageBox = $PAGES

onready var scroll_box = $ScrollContainer
onready var add_container = $ScrollContainer/VBoxContainer

func _ready():
	LEFT.connect("pressed",self,"_left_pressed")
	RIGHT.connect("pressed",self,"_right_pressed")
	if path and operation == "singular":
		rect_size = get_parent().rect_size

var refs = []
var panelRefs = []
var antispam = true
func _left_pressed():
	if antispam and current_page > 0:
		antispam = false
		current_page -= 1
		clear()
		if clearing:
			yield(self,"cleared")
		parse()
		yield(pointers,"process_tick")
		yield(pointers,"process_tick")
		yield(pointers,"process_tick")
		antispam = true

func _right_pressed():
	if antispam:
		antispam = false
		current_page += 1
		clear()
		if clearing:
			yield(self,"cleared")
		parse()
		yield(pointers,"process_tick")
		yield(pointers,"process_tick")
		yield(pointers,"process_tick")
		antispam = true

var clearing = false

export var page_size = 15
var current_page = 0
func parse():
	if path:
		var panel = changelog_container.instance()
		panelRefs.append(panel)
		panel.rect_min_size = rect_size - Vector2(12,6)
		add_container.add_child(panel)
		yield(pointers,"process_tick")
		panel.parse(path,current_page,page_size,LEFT,RIGHT,refs)

func _visibility_changed():
	yield(pointers,"process_tick")
	if is_visible_in_tree():
		rect_size = get_parent().rect_size

signal cleared()
func clear_and_update(new):
	clear()
	if clearing:
		yield(self,"cleared")
	path = new
	parse()

func clear():
	clearing = true
	for i in panelRefs:
		i.clearing = true
		i.set_physics_process(false)
		i.set_process(false)
		i.get_parent().remove_child(i)
		Tool.remove(i)
	for i in refs:
		i.visible = false
		Tool.remove(i)
	yield(pointers,"process_tick")
	refs.clear()
	panelRefs.clear()
	clearing = false
	emit_signal("cleared")
