# [license]
# SPDX-License-Identifier: LicenseRef-Proprietary
# Copyright © 2026 __hev (Benjamin Buckhurst). All Rights Reserved.
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that all following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

extends CheckButton

var pointers:HevLibPointers = ModLoader._savedObjects[0]

var current_modlet = null
var current_modlet_path : String = ""

var can_toggle = false

var file:File = File.new()

func _toggled(button_pressed):
	if can_toggle:
		var all_modlets = pointers.ManifestV2.__get_all_modlets(false)
		all_modlets[current_modlet_path] = button_pressed
		var restarting:Array = pointers.modlet_toggle_restart_requests
		if not current_modlet_path in restarting:
			restarting.append(current_modlet_path)
		current_modlet.needs_restart_from_toggling = true
		
		pointers.has_updated = true
		pointers.ConfigDriver.__store_value("HevLib","modlets","seen_modlets",all_modlets)
		yield(pointers,"process_tick")
		current_modlet.update()

func change_modlet_to(modlet,modlet_path:String):
	can_toggle = false
	current_modlet = modlet
	current_modlet_path = modlet_path
	if modlet and modlet_path:
		if modlet_path == "res://ModMenu2/Mod.manifest":
			disabled = true
			hint_tooltip = "HEVLIB_MODMENU_MODLET_TOGGLE_MM2FALLBACK"
		else:
			disabled = false
			hint_tooltip = "HEVLIB_MODMENU_MODLET_TOGGLE_TOOLTIP"
		var all_modlets = pointers.ManifestV2.__get_all_modlets(false)
		var enabled = all_modlets[modlet_path]
		pressed = enabled
		yield(pointers,"physics_process_tick")
		can_toggle = true
