# [license]
# SPDX-License-Identifier: LicenseRef-Proprietary
# Copyright © 2026 __hev (Benjamin Buckhurst). All Rights Reserved.
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that all following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

extends Button

var pointers:HevLibPointers = ModLoader._savedObjects[0]
var file = File.new()

func _ready():
	check()
	pointers.connect("updates_fetched",self,"check")
	visible = false
var visibility:bool = false

func check():
	var update_data:Dictionary = pointers.needs_updates
	var height = 50
	if update_data:
		visibility = true
		height += 50
		$NotificationBox/VBoxContainer/Updates.visible = true
		$NotificationBox/VBoxContainer/Updates/Label.text = TranslationServer.translate("HEVLIB_UPDATE_COUNT") % update_data.size()
	else:
		$NotificationBox/VBoxContainer/Updates.visible = false
	
	if pointers.conflicts_keys.empty():
		$NotificationBox/VBoxContainer/Conflicts.visible = false
	else:
		visibility = true
		height += 50
		$NotificationBox/VBoxContainer/Conflicts.visible = true
		$NotificationBox/VBoxContainer/Conflicts/Label.text = TranslationServer.translate("HEVLIB_CONFLICT_COUNT") % pointers.conflicts_keys.size()
	if pointers.dependancies_keys.empty():
		$NotificationBox/VBoxContainer/Dependancies.visible = false
	else:
		visibility = true
		height += 50
		$NotificationBox/VBoxContainer/Dependancies.visible = true
		$NotificationBox/VBoxContainer/Dependancies/Label.text = TranslationServer.translate("HEVLIB_DEPENDANCY_COUNT") % pointers.dependancies_keys.size()
	$NotificationBox.rect_size.y = height
	$NotificationBox.rect_position.y = -height

func _process(delta):
#	if mouse_focus:
#		focused = true
#	elif key_focus:
#		focused = true
#	else:
#		focused = false
#	if focused:
#		$NotificationBox.visible = true
	if mouse_focus or key_focus:
		$NotificationBox.visible = true
	else:
		$NotificationBox.visible = false
	visible = visibility

func _timeout():
	check()
var focused = false
var key_focus = false
var mouse_focus = false


func _focus_entered():
	key_focus = true


func _focus_exited():
	key_focus = false


func _mouse_entered():
	mouse_focus = true


func _mouse_exited():
	mouse_focus = false
