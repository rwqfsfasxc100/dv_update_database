# [license]
# SPDX-License-Identifier: LicenseRef-Proprietary
# Copyright © 2026 __hev (Benjamin Buckhurst). All Rights Reserved.
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that all following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

extends Tabs

var section_info = {}

var section_values = {}

var mod = ""

func _draw():
	$MarginContainer.rect_size = rect_size
	$MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer.rect_min_size = $MarginContainer.rect_size
	get_tree().call_group("hevlib_settings_tab","recheck_availability")

func _ready():
	var close_button = $MarginContainer/VBoxContainer/HBoxContainer/CloseButton
	var ordered_section_info:Dictionary = {}
	var orderof = {}
	var reorder = []
	for entry in section_info:
		var secentry = section_info[entry]
		if "display_order_position" in secentry:
			var pos = secentry.display_order_position
			while pos in orderof:
				pos += 1
			orderof[pos] = [entry,secentry]
		else:
			reorder.append([entry,secentry])
	var ctr = 0
	for i in orderof:
		if i > ctr:
			ctr = i
	for i in reorder:
		ctr += 1
		orderof[ctr] = i
	var orderKeys = orderof.keys()
	orderKeys.sort()
	for r in orderKeys:
		var i = orderof[r]
		ordered_section_info[i[0]] = i[1]
	for entry in ordered_section_info:
		var entry_info = ordered_section_info[entry]
		var type = entry_info["type"].to_lower()
		var wait = true
		match type:
			"bool","boolean":
				var input = BOOL.instance()
				input.name = entry
				input.CONFIG_DATA = entry_info
				input.CONFIG_ENTRY = entry
				input.CONFIG_SECTION = name
				input.CONFIG_MOD = mod
				$MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer.add_child(input)
			"color","colour":
				var input = COLOR.instance()
				input.name = entry
				input.CONFIG_DATA = entry_info
				input.CONFIG_ENTRY = entry
				input.CONFIG_SECTION = name
				input.CONFIG_MOD = mod
				$MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer.add_child(input)
			"float","int","integer","real":
				var input = INT_FLOAT.instance()
				input.name = entry
				input.CONFIG_DATA = entry_info
				input.CONFIG_ENTRY = entry
				input.CONFIG_SECTION = name
				input.CONFIG_MOD = mod
				match type:
					"int","integer":
						input.val_type = "int"
					"float","real":
						input.val_type = "float"
				$MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer.add_child(input)
			"string","str":
				var input = STRING.instance()
				input.name = entry
				input.CONFIG_DATA = entry_info
				input.CONFIG_ENTRY = entry
				input.CONFIG_SECTION = name
				input.CONFIG_MOD = mod
				$MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer.add_child(input)
			"option","optionbutton","option_button":
				var input = OPTION.instance()
				input.name = entry
				input.CONFIG_DATA = entry_info
				input.CONFIG_ENTRY = entry
				input.CONFIG_SECTION = name
				input.CONFIG_MOD = mod
				$MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer.add_child(input)
			"input":
				var input = INPUT.instance()
				input.name = entry
				input.CONFIG_DATA = entry_info
				input.CONFIG_ENTRY = entry
				input.CONFIG_SECTION = name
				input.CONFIG_MOD = mod
				$MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer.add_child(input)
			"action":
				var input = ACTION.instance()
				input.name = entry
				input.CONFIG_DATA = entry_info
				input.CONFIG_ENTRY = entry
				input.CONFIG_SECTION = name
				input.CONFIG_MOD = mod
				$MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer.add_child(input)
			"display":
				var input = DISPLAY.instance()
				input.name = entry
				input.CONFIG_DATA = entry_info
				input.CONFIG_ENTRY = entry
				input.CONFIG_SECTION = name
				input.CONFIG_MOD = mod
				wait = false
				$MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer.add_child(input)
		if wait:
			yield(ModLoader._savedObjects[0],"process_tick")
	var hb = HBoxContainer.new()
	hb.name = "BottomSeparatorForToolTipsPlsIgnore"
	hb.set_script(load("res://HevLib/ui/mod_menu/mod_list/BottomSeparator.gd"))
	hb.close_button = close_button
	hb.connect("visibility_changed",hb,"_visibility_changed")
	$MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer.add_child(hb)
#	breakpoint



var BOOL = load("res://HevLib/ui/mod_menu/settings_menus/entry_inputs/bool.tscn")
var INT_FLOAT = load("res://HevLib/ui/mod_menu/settings_menus/entry_inputs/int-float.tscn")
var STRING = load("res://HevLib/ui/mod_menu/settings_menus/entry_inputs/string.tscn")
var OPTION = load("res://HevLib/ui/mod_menu/settings_menus/entry_inputs/option_button.tscn")
var INPUT = load("res://HevLib/ui/mod_menu/settings_menus/entry_inputs/input.tscn")
var ACTION = load("res://HevLib/ui/mod_menu/settings_menus/entry_inputs/action.tscn")
var COLOR = load("res://HevLib/ui/mod_menu/settings_menus/entry_inputs/color.tscn")
var DISPLAY = load("res://HevLib/ui/mod_menu/settings_menus/entry_inputs/display.tscn")

func cancel():
	get_parent().get_parent().get_parent().get_parent().get_parent().get_parent().cancel()
