# [license]
# SPDX-License-Identifier: LicenseRef-Proprietary
# Copyright © 2026 __hev (Benjamin Buckhurst). All Rights Reserved.
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that all following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

extends Reference

var pointers:HevLibPointers

func _init(p):
	pointers = p


var control_vars = Dictionary()
# General variables
var file:File = File.new()
const vanilla = "user://cache/Keybinds/vanilla_binds.json"

# Code prefabs
var script_header = "extends Reference\n\nfunc handle_input(bits, event):\n\tpass"

var bit_size_check = "(bits.size() == %s) and "


# Order specific checkers
var orderspecific_checker_entry = "\n\tif event.is_action_pressed(\"%s\", true):"
var orderspecific_checker_end = "\n\telif %s:\n\t\tInput.action_release(\"%s\")"
var orderspecific_checker_expression = "not (%s)"
var orderspecific_checker_expression_part = "(%s in bits)"

var orderspecific_other_buttons_pressed = "\n\t\tif not %s:\n\t\t\tCurrentGame.get_tree().set_input_as_handled()\n\t\t\tInput.action_release(\"%s\")\n\t\telse:\n\t\t\tpass"

var orderspecific_part_def = "\n\t\tvar p%d = bits.find(%s)"
var orderspecific_expr_part = "(%d if p%d > -1 else %d)"

# Order nonspecific checkers
var ordernonspecific_part_def = "\n\t\tvar p%d = %s in bits"
var ordernonspecific_expr_part = "p%d"

# Exclusive handlers

var exclusives_check_for_input = "event.is_action_pressed(\"%s\", true)"
var exclusives_variable_statement = "\n\tvar charset_%s = true"
var exclusives_variable_obj = "charset_%s"
var exclusives_variable_falsify = "\n\t\t\t\tcharset_%s = false"
var exclusives_expression_check = "if not %s:\n\t\t\t\t"
var exclusives_exit_this_expression = "if not %s:\n\t\t\t\t\tCurrentGame.get_tree().set_input_as_handled()\n\t\t\t\t\tInput.action_release(\"%s\")\n\t\t\telse:%s"
var exclusives_exit_this_expression_noexbr = "CurrentGame.get_tree().set_input_as_handled()\n\t\t\t\tInput.action_release(\"%s\")\n\t\t\telse:%s"
var exclusives_exit_from_no_keys = "\n\t\telse:\n\t\t\tCurrentGame.get_tree().set_input_as_handled()\n\t\t\tInput.action_release(\"%s\")"
var exclusives_checker_expression_part = "%s in bits"

func compile_keymap():
	var p = Dictionary()
	var h:Dictionary = pointers.Keymapping.__get_formatted_vanilla_binds()
	control_vars.clear()
	for action in h:
		var d = h[action]
		if not action in p:
			p[action] = Dictionary()
		var g = p[action]
		if not "controls" in g:
			g["controls"] = Array()
		var c = g["controls"]
		for j in d["inputs"]:
			if not j in c:
				c.append(j)
		if not "opts" in g:
			g["opts"] = d.get("opts",{"allow_extra_keys":true,"order_sensitive":true,"exclusive":false})
		
	
	var apg:Dictionary = pointers.defined_control_configs
	for action in apg.keys():
		var d = apg[action]
		if action in p:
			for ac in d["controls"]:
				var add = true
				for vb in p[action]["controls"]:
					if hash(vb) == hash(ac):
						add = false
				if add:
					p[action]["controls"].append(ac)
		else:
			p[action] = Dictionary()
			p[action]["controls"] = d["controls"]
			p[action]["opts"] = d["opts"]
	var scripting = script_header
	
	var exclusives = Dictionary()
	
	for action in p:
		var data = p[action]
		if data["opts"]["exclusive"]:
			exclusives[action] = data
		else:
			scripting += handle_regular_controls(data,action)
	
	if exclusives:
		var exclSize = exclusives.size()
		if exclSize > 1:
			var ordered = Dictionary()
			var disordered = Dictionary()
			var cKeys = Dictionary()
			for e in exclusives:
				var x = exclusives[e]
				var o = x["opts"]
				var k = x["controls"]
				for f in k:
					for f1 in f:
						if not f1 in cKeys:
							cKeys[f1] = Array()
						if not e in cKeys[f1]:
							cKeys[f1].append(e)
				if o["order_sensitive"]:
					ordered[e] = x
				else:
					disordered[e] = x
			
			for k in cKeys:
				var d = cKeys[k].size()
				if d < 2:
					cKeys.erase(k)
			var checker_vars = PoolStringArray()
			for i in ordered:
				var data = ordered[i]
				var controls = data["controls"]
				var opts = data["opts"]
				for stack in controls:
					
					var single = true
					for a in stack:
						if a in cKeys:
							single = false
					if not single:
						var this_checker = ""
						var checkArr = Array()
						for a in stack:
							if this_checker:
								this_checker += "_" + a
							else:
								this_checker = a
							if not this_checker in checkArr:
								checkArr.append(this_checker)
						for r in checkArr:
							if not r in checker_vars:
								checker_vars.append(r)
						control_vars[i] = checkArr
					else:
						pass
			for i in disordered:
				var data = disordered[i]
				var controls = data["controls"]
				var opts = data["opts"]
				for stack in controls:
					var single = true
					for a in stack:
						if a in cKeys:
							single = false
					if not single:
						var checkArr = Array()
						for a in stack:
							if not a in checkArr:
								checkArr.append(a)
						for r in checkArr:
							if not r in checker_vars:
								checker_vars.append(r)
						control_vars[i] = checkArr
					else:
						pass
			var var_statement_list = ""
			for control in checker_vars:
				var_statement_list += exclusives_variable_statement % control
			scripting += var_statement_list
			var ordered_control_list = control_vars.keys()
			ordered_control_list.sort_custom(self,"sort_this_dict")
			
			for ct in ordered_control_list:
				var opts = exclusives[ct]["opts"]
				var extxpr = ""
				var krxpr = exclusives[ct]["controls"]
				for key in krxpr:
					var keysXpr = ""
					for kv in key:
						var sc = pointers.Keymapping.__string_to_scancode(kv)
						if keysXpr:
							keysXpr += " and " + exclusives_checker_expression_part % str(sc)
						else:
							keysXpr = "(" + exclusives_checker_expression_part % str(sc)
					keysXpr += ")"
					if extxpr:
						extxpr += " or " + keysXpr
					else:
						extxpr = "(" + keysXpr
				extxpr = orderspecific_checker_expression % [extxpr + ")"]
				var statement_list = control_vars[ct]
				var handler = "\n\tif " + exclusives_check_for_input % (ct) + ":"
				var expression = ""
				var key = statement_list[-1].split("_")
				if key.size() > 1:
					if opts["order_sensitive"]:
						var map = Dictionary()
						var mx = 214748364
						var cb = 1
						for kv in key:
							var sc = pointers.Keymapping.__string_to_scancode(kv)
							map[cb] = sc
							handler += orderspecific_part_def % [cb,sc]
							
							if not expression:
								var v = "(" + orderspecific_expr_part % [cb,cb,mx-cb]
								expression += v
							else:
								var v = " < " + orderspecific_expr_part % [cb,cb,mx-cb]
								expression += v
							cb += 1
						expression += ")"
					else:
						var map = Dictionary()
						var mx = 214748364
						var cb = 1
						for kv in key:
							var sc = pointers.Keymapping.__string_to_scancode(kv)
							map[cb] = sc
							handler += ordernonspecific_part_def % [cb,sc]
							
							if not expression:
								var v = "(" + ordernonspecific_expr_part % cb
								expression += v
							else:
								var v = " and " + ordernonspecific_expr_part % cb
								expression += v
							cb += 1
						expression += ")"
				else:
					var sc = pointers.Keymapping.__string_to_scancode(key[0])
					expression = orderspecific_checker_expression_part % sc
				if not opts["allow_extra_keys"]:
					expression = bit_size_check % key.size() + expression
				var state = handler
				var state_checker = ""
				for i in statement_list:
					if state_checker:
						state_checker += " or " + exclusives_variable_obj % i
					else:
						state_checker = "if " + exclusives_variable_obj % i
				
				
				state += "\n\t\t" + state_checker + ":\n\t\t\t"
				var falsifiers = ""
				for k in statement_list:
					falsifiers += exclusives_variable_falsify % k
				var other_bind_check_expression = ""
				var unexited_keys = Array()
				var used_keys = Array()
				for c in checker_vars:
					for a in c.split("_"):
						if not a in used_keys:
							used_keys.append(a)
				for bindgroup in krxpr:
					for kcheck in bindgroup:
						if not kcheck in used_keys:
							unexited_keys.append(kcheck)
				
				# Use the unexited_keys array to prevent scancodes inside it from triggering any
				# bind cancelling
				
				var exbr = ""
				
				if unexited_keys:
					for kv in unexited_keys:
						var sc = pointers.Keymapping.__string_to_scancode(kv)
						if other_bind_check_expression:
							other_bind_check_expression += " or " + exclusives_checker_expression_part % str(sc)
						else:
							other_bind_check_expression = exclusives_checker_expression_part % str(sc)
				
				
				if other_bind_check_expression:
					exbr = exclusives_exit_this_expression % [other_bind_check_expression,ct,falsifiers]
				else:
					exbr = exclusives_exit_this_expression_noexbr % [ct,falsifiers]
#					exbr = exclusives_exit_this_expression % ["false",ct,falsifiers]
				state += exclusives_expression_check % expression + exbr + exclusives_exit_from_no_keys % ct + orderspecific_checker_end % [extxpr,ct]
				scripting += state
				
		else:
			var action = exclusives.keys()[0]
			scripting += handle_regular_controls(exclusives[action],action)
			breakpoint
		
	
	return scripting

func handle_regular_controls(data:Dictionary,action: String):
	var scripting = ""
	var keys = data["controls"]
	var opts = data["opts"]
	var extxpr = ""
	for key in keys:
		var keysXpr = ""
		for kv in key:
			var sc = pointers.Keymapping.__string_to_scancode(kv)
			if keysXpr:
				keysXpr += " and " + exclusives_checker_expression_part % str(sc)
			else:
				keysXpr = "(" + exclusives_checker_expression_part % str(sc)
		keysXpr += ")"
		if extxpr:
			extxpr += " or " + keysXpr
		else:
			extxpr = "(" + keysXpr
	extxpr = orderspecific_checker_expression % [extxpr + ")"]
	
	for key in keys:
		if key.size() > 1:
			if opts["order_sensitive"]:
				var handler = orderspecific_checker_entry % action
				var expression = ""
				var map = Dictionary()
				var mx = 214748364
				var cb = 1
				for kv in key:
					var sc = pointers.Keymapping.__string_to_scancode(kv)
					map[cb] = sc
					handler += orderspecific_part_def % [cb,sc]
					
					if not expression:
						var v = "(" + orderspecific_expr_part % [cb,cb,mx-cb]
						expression += v
					else:
						var v = " < " + orderspecific_expr_part % [cb,cb,mx-cb]
						expression += v
					cb += 1
				expression += ")"
				
				if not opts["allow_extra_keys"]:
					expression = bit_size_check % key.size() + expression
				
				handler += orderspecific_other_buttons_pressed % [expression,action]
				handler += orderspecific_checker_end % [extxpr,action]
				scripting += handler
			else:
				var handler = orderspecific_checker_entry % action
				var expression = ""
				var map = Dictionary()
				var mx = 214748364
				var cb = 1
				for kv in key:
					var sc = pointers.Keymapping.__string_to_scancode(kv)
					map[cb] = sc
					handler += ordernonspecific_part_def % [cb,sc]
					
					if not expression:
						var v = "(" + ordernonspecific_expr_part % cb
						expression += v
					else:
						var v = " and " + ordernonspecific_expr_part % cb
						expression += v
					cb += 1
				expression += ")"
				
				if not opts["allow_extra_keys"]:
					expression = bit_size_check % key.size() + expression
				
				handler += orderspecific_other_buttons_pressed % [expression,action]
				handler += orderspecific_checker_end % [extxpr,action]
				scripting += handler
	return scripting

func sort_this_dict(a,b) -> bool:
	var aData = control_vars[a]
	var bData = control_vars[b]
	if bData.size() > aData.size():
		return false
	return true
