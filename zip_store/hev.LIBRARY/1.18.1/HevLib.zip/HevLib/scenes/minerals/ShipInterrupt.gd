# [license]
# SPDX-License-Identifier: LicenseRef-Proprietary
# Copyright © 2026 __hev (Benjamin Buckhurst). All Rights Reserved.
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that all following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

extends Node

var ship

var pointers:HevLibPointers._ConfigDriver

func _init(p):
	pointers = p
	pointers.__establish_connection("hl_shipinterruptupdate",self)
	hl_shipinterruptupdate()

func hl_shipinterruptupdate():
	if pointers:
		cargo_limit = pointers.__get_value("HevLib","HEVLIB_CONFIG_SECTION_EQUIPMENT","processed_mineral_max_display_limit",12)

var cargo_limit:int = 15

var page:int = 0


var counter:int = 0
func handle_list(ores,oresize) -> Array:
	if oresize > cargo_limit:
		var out:Array = Array()
		counter += 1
		var offset:int = page * cargo_limit
		var thisSize:int = min(cargo_limit,oresize - offset)
		var pages:int = int(ceil(float(oresize) / float(cargo_limit)))
		for i in thisSize:
			out.append(ores[offset + i])
		if counter > 49:
			counter = 0
			if page > pages: page = 0
			else: page += 1
		return out
	else:
		counter = 0
		page = 0
		return ores









func getProcessedCargoTypes(how):
	var out = ship.getProcessedCargoTypes(how)
	if out:
		return handle_list(out,out.size())
	return out


func getProcessedCargo(which,how):
	var out = ship.getProcessedCargo(which,how)
	
	return out


func getProcessedCargoCapacity(how):
	var out = ship.getProcessedCargoCapacity(how)
	
	return out

func soundAlert():
	ship.soundAlert()

