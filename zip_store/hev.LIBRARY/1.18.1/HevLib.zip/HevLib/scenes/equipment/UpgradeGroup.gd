# [license]
# SPDX-License-Identifier: LicenseRef-Proprietary
# Copyright © 2026 __hev (Benjamin Buckhurst). All Rights Reserved.
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that all following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

extends "res://enceladus/UpgradeGroup.gd"

# Ship limiting code was ported from IoE
# Thanks Space! The modding community misses you!

export (Array) var limit_ships = Array()
export (Array) var prevent_ships = Array()


export (String) var restrict_hold_type = ""

export (String) var config_id = ""
export (String) var config_section = ""
export (String) var config_setting = ""
export (bool) var invert_config = false

export (String) var storyFlag = ""
export (int) var storyFlagMin = - 1
export (int) var storyFlagMax = - 1

onready var pointers:HevLibPointers._ConfigDriver = ModLoader._savedObjects[0].ConfigDriver
var cv = null
var hl_eqdrupggrp_uinit : bool = false
func _ready():
	if hl_eqdrupggrp_uinit:
		pointers.log_double_load_error(get_script().resource_path)
	hl_eqdrupggrp_uinit = true
	connect("visibility_changed",self,"hl_ug_recheck_this_visibility")

func hl_ug_recheck_this_visibility():
	if pointers and config_id and config_section and config_setting:
		cv = pointers.__get_value(config_id,config_section,config_setting,null)

func reexamine():
	.reexamine()
	if storyFlag and storyFlag != "":
		var story:int = CurrentGame.getStory(storyFlag)
		if storyFlagMax != - 1 and story > storyFlagMax:
			visible = false
			return
		if storyFlagMin != - 1 and story < storyFlagMin:
			visible = false
			return
	var ship:Node = CurrentGame.getPlayerShip()
	var shipname:String = ship.shipName
	if limit_ships and not (shipname in limit_ships):
		visible = false
		return
	if prevent_ships and (shipname in prevent_ships):
		visible = false
		return
	if visible and cv is bool:
		if invert_config:
			cv = !cv
		visible = cv
	if visible and restrict_hold_type:
		visible = (restrict_hold_type.to_upper() == ship.base_storage_type.to_upper())
