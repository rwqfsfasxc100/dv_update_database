# [license]
# SPDX-License-Identifier: LicenseRef-Proprietary
# Copyright © 2026 __hev (Benjamin Buckhurst). All Rights Reserved.
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that all following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

extends OptionButton

onready var ring:Node = get_node("/root/Game/TheRing")

var eventNames:Dictionary = {0:"none"}
var justEvents:Array = Array()
var cnode:String = ""

var defaultOdditiesEvery:float = 450
var defaultTestSpecificStoryElement:String = ""

var busy:bool = false

var focusObject

var use_legacy:bool = false
var use_inject:bool = false

var clear_related_poi:bool = true
var clear_in_cargo:bool = false

func _on_SpawnNow_pressed():
	var ev:String = cnode
	Debug.l("EventDriver: forcing spawn of %s; parameters: legacy [%s]" % [ev,"true" if use_legacy else "false"])
	if ev == "none" or ev == "":
		ev = justEvents[randi() % justEvents.size()]
		Debug.l("EventDriver: random event, selecting %s" % ev)
	var params:Dictionary = Dictionary()
	if use_legacy:
		params["legacy"] = true
	if use_inject:
		params["spawn_now"] = true
	pointers.Events.__spawn_event(ev,ring,params)

var spawnDirectionScale:float = 0.75
var odditySpawnRadiusMin:float = 24000
var odditySpawnRadiusMinCutscene:float = 6000
var odditySpawnRadiusMax:float = 38000
var odditySpawnRadiusSafemax:float = 80000
var odditySpawnFailures:float = 0
var odditySpawnRadiusSafemaxSteps:float = 40

func getPos():
	if Tool.claim(focusObject):
		var cutscene:bool = ("cutscene" in focusObject and focusObject.cutscene) and ("fastTravelDirection" in focusObject and focusObject.fastTravelDirection < 0)
		var focusPoint:Vector2 = focusObject.global_position
		var randomVector:Vector2 = Vector2(rand_range( - 1, 1), rand_range( - 1, 1)).normalized()
		var directionVector:Vector2 = focusObject.linear_velocity.normalized() * spawnDirectionScale
		var dirvec:Vector2 = (randomVector + directionVector).normalized()
		if dirvec.length() < 0.9:
			dirvec = randomVector
		var oddityFocusOffset:Vector2 = dirvec * rand_range(odditySpawnRadiusMin if not cutscene else odditySpawnRadiusMinCutscene, lerp(odditySpawnRadiusMax, odditySpawnRadiusSafemax, clamp(float(odditySpawnFailures) / float(odditySpawnRadiusSafemaxSteps), 0, 1)))
		
		Tool.release(focusObject)
		return CurrentGame.globalCoords(focusPoint + oddityFocusOffset)
		

func _ready():
	focusObject = CurrentGame.getPlayerShip()
	if ring:
		var ts = ring.testSpecificStoryElement
		if ts and ts is String:
			defaultTestSpecificStoryElement = ts
		defaultOdditiesEvery = ring.odditiesEvery
		var value:float = defaultOdditiesEvery
		
		get_parent().get_node("HBoxContainer/Timer").text = "%s s" % value
		get_parent().get_node("HSlider").value = value
		
		addEvents()
var event_objects:Dictionary = Dictionary()
func addEvents():
	
	var events:Array = ring.get_children()
	for indx in events.size():
		var evnt:Object = events[indx]
		var ename:String = evnt.name
		eventNames[indx + 1] = ename
		event_objects[ename] = evnt
		justEvents.append(ename)
	for event in eventNames:
		add_item(eventNames[event])
	
	


func _on_HSlider_value_changed(value):
	defaultOdditiesEvery = value
	ring.odditiesEvery = value
	get_parent().get_node("HBoxContainer/Timer").text = "%s s" % value


func _on_Events_item_selected(index):
	for event in eventNames:
		if event == index:
			cnode = eventNames[index]
	
	
func startEventTimerNode():
	busy = true
	$Timer.start()
	

func _timer_complete():
	
	ring.testSpecificStoryElement = defaultTestSpecificStoryElement
	ring.odditiesEvery = defaultOdditiesEvery
	busy = false
var pointers:HevLibPointers = ModLoader._savedObjects[0]


func _on_ClearEvent_pressed():
	
	pointers.Events.__clear_event(cnode,ring,clear_related_poi,clear_in_cargo)

onready var legacy_button:Control = get_node_or_null(NodePath("../Toggles/Legacy"))
onready var inject_button:Control = get_node_or_null(NodePath("../Toggles/Inject"))
func _toggle_legacy(how):
	use_legacy = how
	if how:
		inject_button.pressed = false
		use_inject = false


func _on_Inject_toggled(how):
	use_inject = how
	if how:
		legacy_button.pressed = false
		use_legacy = false


func _on_ClearPOI_toggled(how):
	clear_related_poi = how


func _on_ClearInCargo_toggled(how):
	clear_in_cargo = how
