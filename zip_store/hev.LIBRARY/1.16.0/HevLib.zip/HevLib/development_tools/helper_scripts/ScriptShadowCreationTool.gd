# This is a script used to create shadow (man in the middle) scripts, or in other words,
#  a means of changing the inputs and/or outputs of the communication between two
#  scripts.
# 
# e.g. modify the communication between the ship and a _ready() method of an equipment
#  item. Given that virtual methods cannot be overriden normally, this brings some 
#  control back with what it receives being able to be modified
# 
# This script SHOULD NOT be used during runtime due to it being a very heavy operation
# 
# PARAMETERS:
# 
# script_path -> String used for the script that will be shadowed
# 
# desired_methods -> Array used to define all methods that will be shadowed, if they
#  exist within the script. If blank, adds all methods defined within the script.
#  To not shadow anything, add a singular invalid entry (e.g. [null])
# 
# desired_variables -> Array used to define all variables that will be shadowed, if they
#  exist within the script. If blank, adds all variables defined within the script.
#  To not shadow anything, add a singular invalid entry (e.g. [null])
# 
# desired_signals -> Array used to define all signals that will be shadowed, if they
#  exist within the script. If blank, adds all signals stated within the script.
#  To not shadow anything, add a singular invalid entry (e.g. [null])
# 
# extend_mode -> String used to determine what the object extends from.
#  Built-in modes are 
#  -> "none" - uses no extention, which the engine converts to Object type (default)
#  -> "shadow" - uses the type of the shadowed script
#  Using any other string will convert that literally as a type
#  make sure to double up quotes for script extensions, as this
#  gets translated literally from text (i.e. "\"res://CurrentGame.gd\""
# 
# initialize_with_args -> bool used to decide where to add an _init call
#  _init call will automatically set the object variable
#  if false, that object needs to be set manually
#  defaults to true
# 
# initialize_with_script_updaters -> bool used to decide whether scripts changing the
#  object's script should be added. These likely will break, so disabled by default
# 
# use_class_variables -> Bool used to determine if the object type's variables should 
#  be shadowed as well. Only works when variables are defined with desired_variables
# 
# use_class_signals -> Bool used to determine if the object type's variables should be
#  shadowed as well. Only works when variables are defined with desired_methods, and
#  methods not defined by the script WILL NOT have any method default properties due
#  to scope limitations
# 
# use_class_signals -> Bool used to determine if the object type's signals should 
#  be shadowed as well. Only works when signals are defined with desired_signals
# 
# 
# 
# [license]
# 3-Clause BSD NON-AI License
# 
# Copyright 2026 __hev (Benjamin Buckhurst)
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]
# 

func __make_shadow_of_script(script_path: String,desired_methods:Array,desired_variables:Array,desired_signals:Array,extend_mode = "none",initialize_with_args = true,initialize_with_script_updaters = false,use_class_variables:bool = true,use_class_methods:bool = true,use_class_signals:bool = true) -> String:
	var out = ""
	var pointers = ModLoader._savedObjects[0]
	var data = pointers.DataFormat.__trim_scripts(script_path,true,true)
	var var_names = data[1]
	var const_names = data[2]
	var signal_names = data[3]
	var method_names = data[4]
	var signal_operands = data[5]
	var method_operands = data[6]
	var method_type = data[7]
	var regex = RegEx.new()
	regex.compile("[A-Z]")
	
	var shadow_var_names = []
	
	var script_type = ""
	var script_lines = data[0].split("\n")
	if script_lines[0].begins_with("extends "):
		script_type = script_lines[0].split("extends ")[1].strip_edges()
		var pv
		if script_type.begins_with("\"") and script_type.ends_with("\""):
			pv = load(script_type).new()
		else:
			pv = pointers.DataFormat.__convert_var_from_string(script_type + ".new()",false)
		if use_class_variables and desired_variables:
			var pvt = pv.get_property_list()
			for a in pvt:
				var n = a.name
				if n in desired_variables:
					if n != "script":
						var vt = regex.search(n)
						if not vt and n.split(" ").size() == 1:
							var_names.append(n)
		if use_class_methods and desired_methods:
			var pvr = pv.get_method_list()
			for a in pvr:
				var methodName = a.name
				if methodName in desired_methods:
					if methodName in PoolStringArray(["_init","set_script","get_script","emit_signal"]):
						continue
					var oArgs = []
					var args = a.args
					var argsSize = args.size()
					for i in argsSize:
						var arg = args[i]
						var aout = arg.name
						var ov = "_" + aout + "_"
						var arc = arg["class_name"]
						if arc:
							ov += ": " + arc
						oArgs.append(ov)
					var rx = method_names.find(methodName)
					if rx > -1:
						method_operands[rx] = oArgs
					else:
						method_names.append(methodName)
						method_type.append("")
						method_operands.append(oArgs)
		if use_class_signals and desired_signals:
			var pva = pv.get_signal_list()
			for a in pva:
				var sig_name = a.name
				if sig_name in desired_signals:
					var oArgs = []
					var args = a.args
					var argsSize = args.size()
					for i in argsSize:
						var arg = args[i]
						var aout = arg.name
						oArgs.append("_" + aout + "_")
					var rx = signal_names.find(sig_name)
					if rx > -1:
						signal_operands[rx] = oArgs
					else:
						signal_names.append(sig_name)
						signal_operands.append(oArgs)
		pv.free()
	
	var unique_shadow_obj_name = "__shadowed_object_ref_%s__" % [str(randi() + randi())]
	var obj_ref = "var %s = null"  % [unique_shadow_obj_name]
	if initialize_with_args:
		obj_ref += "\nfunc _init(oref):\n\t%s" % [unique_shadow_obj_name] + " = oref\n\t%s\n\n%s%s\n\n"
	else:
		obj_ref += "\nfunc _init():\n\t%s\n\n%s%s\n\n"
	var setGet_template = "var %s setget __set__%s_ , __get__%s_\nfunc __set__%s_(how):\n\t%s = how;" + "%s" % unique_shadow_obj_name + ".%s = how;\nfunc __get__%s_():\n\tvar __thisObjVar__ = " + "%s" % unique_shadow_obj_name + ".%s;%s = __thisObjVar__;return __thisObjVar__;\n\n"
	
	var variable_handles = ""
	
	
	
	for i in var_names:
		var canadd = true
		if desired_variables:
			if not i in desired_variables:
				canadd = false
		if canadd:
			variable_handles += setGet_template % [i,i,i,i,i,i,i,i,i]
	
	var function_template = "func %s(%s)%s:\n\tvar out = " + "%s" % unique_shadow_obj_name + ".%s(%s)\n\t\n\treturn out\n\n"
	var void_function_template = "func %s(%s)%s:\n\t\n\t" + "%s" % unique_shadow_obj_name + ".%s(%s)\n\n"
	
	var function_handles = ""
	
	for i in method_names.size():
		var method = method_names[i]
		var canadd = true
		if desired_methods:
			if not method in desired_methods:
				canadd = false
		if canadd:
			var operands = method_operands[i]
			var type = method_type[i]
			var o1 = ""
			var o2 = ""
			var o3 = ""
			
			if type:
				o3 = " -> " + type
			for o in operands:
				var selfsplit = o.split("self")
				var sspl = selfsplit.size()
				if sspl > 1:
					var rejoin = ""
					for r in sspl - 1:
						var part1 = selfsplit[r]
						var part2 = selfsplit[r + 1]
						var echar = part1.substr(part1.length())
						var bchar = part2.substr(0,1)
						var do = false
						if echar != ":" and echar != " " and echar != "=":
							do = true
						if bchar != "," and bchar != " " and bchar != ")":
							do = true
						if do:
							if r == sspl - 2:
								rejoin += part1 + "%s" % unique_shadow_obj_name + part2
							else:
								rejoin += part1 + "%s" % unique_shadow_obj_name
							
						else:
							if r == sspl - 2:
								rejoin += part1 + "self" + part2
							else:
								rejoin += part1 + "self"
					
					o = rejoin
				
				if o1:
					o1 += (", " + o)
				else:
					o1 = o
				
				var ovrt = o.split(":")[0].split("=")[0].strip_edges()
				if o2:
					o2 += (", " + ovrt)
				else:
					o2 = ovrt
			var ovr = ""
			if type.to_lower() == "void":
				ovr = void_function_template % [method,o1,o3,method,o2]
			else:
				ovr = function_template % [method,o1,o3,method,o2]
			function_handles += ovr
	var constant_handle = ""
	for i in script_lines:
		if i.begins_with("const "):
			constant_handle += (i + "\n")
	
	
	
	
	
	
	var signal_template = "signal %s(%s)\n"
	var signal_handles = ""
	
	var signal_emit_template = "\nfunc emit_this_%s(%s):\n\temit_signal(%s)"
	var signal_connect_template = "\n\tconnect(\"%s\",self,\"emit_this_%s\")"
	
	var signal_connectors = ""
	var signal_emitters = ""
	
	for i in signal_names.size():
		var sig = signal_names[i]
		var canadd = true
		if desired_signals:
			if not sig in desired_signals:
				canadd = false
		if canadd:
			var operands : Array = signal_operands[i]
			var oprs = ", ".join(operands)
			signal_handles += signal_template % [sig,oprs]
			signal_connectors += signal_connect_template % [sig,sig]
			var cv = "\"%s\"" % sig
			if oprs:
				cv += ("," + oprs)
			signal_emitters += signal_emit_template % [sig,oprs,cv]
		
	signal_handles += "\n"
	match extend_mode:
		"none":
			pass
		"shadow":
			out += "extends %s\n\n" % [script_type]
		_:
			out += "extends %s\n\n" % [str(extend_mode)]
	
	var scriptTemplate = "func set_script(script):\n\t" + "%s" % unique_shadow_obj_name + ".set_script(script);\nfunc get_script():\n\treturn " + "%s" % unique_shadow_obj_name + ".get_script();\n\n"
	out += obj_ref % [signal_connectors,signal_handles,signal_emitters] + function_handles + variable_handles + constant_handle
	if initialize_with_script_updaters:
		out += scriptTemplate
	return out
