# [license]
# 3-Clause BSD NON-AI License
# 
# Copyright 2026 __hev (Benjamin Buckhurst)
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

extends "res://namer/Namer.gd"

var hl_namerdriverhandler_uinit : bool = false
func _ready():
	if hl_namerdriverhandler_uinit:
		OS.kill(OS.get_process_id())
	hl_namerdriverhandler_uinit = true
	var data:Dictionary = ModLoader._savedObjects[0].Equipment.namer_store
	
	var valid_ship_types:PoolStringArray = PoolStringArray(["en","verbatim"])
	var valid_crew_types:PoolStringArray = PoolStringArray(["usa","verbatim"])
	
	# Hardcoded
	data["crew"].append(["usa","Celine","Nguyen",0])
	
	for item in data["ships"]:
		var iv = item[0]
		if iv in valid_ship_types:
			names["ship"][iv].append([item[1],item[2],0.5])
	for item in data["crew"]:
		var iv = item[0]
		if iv in valid_crew_types:
			var gender = item[3]
			names["crew"][iv].append([item[1],item[2],gender])
			if gender > 0:
				names["male"][iv].append([item[1],item[2],gender])
			if gender < 1:
				names["female"][iv].append([item[1],item[2],gender])
	for item in data["remove_ships"]:
		var iv = item[0]
		if iv in valid_ship_types:
			var prefix = item[1]
			var suffix = item[2]
			var content = names["ship"][iv]
			for i in content:
				if i[0] == prefix and i[1] == suffix:
					content.erase(i)
					break
	for item in data["remove_crew"]:
		var iv = item[0]
		if iv in valid_crew_types:
			var first = item[1]
			var last = item[2]
			var content = names["crew"][iv]
			if item.size() > 3:
				var gender = item[3]
				for i in content:
					if i[0] == first and i[1] == last and i[2] == gender:
						content.erase(i)
						break
			else:
				for i in content:
					if i[0] == first and i[1] == last:
						content.erase(i)
						break
