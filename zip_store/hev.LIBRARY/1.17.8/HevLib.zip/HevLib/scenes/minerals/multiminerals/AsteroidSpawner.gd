# [license]
# 3-Clause BSD NON-AI License
# 
# Copyright 2026 __hev (Benjamin Buckhurst)
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

extends "res://AsteroidSpawner.gd"

var multiminerals:bool = false

var HevLib_pointers:HevLibPointers

func _enter_tree():
	HevLib_pointers = ModLoader._savedObjects[0]
	HevLib_pointers.ConfigDriver.__establish_connection("hl_multiminerals_UV",self)
	hl_multiminerals_UV()

func hl_multiminerals_UV():
	if HevLib_pointers:
		multiminerals = HevLib_pointers.ConfigDriver.__get_value("HevLib","HEVLIB_CONFIG_SECTION_DRIVERS","multiple_minerals_per_chunk")

func spawnAsteroidByClass(oc, spot, chaos, spawnPointRandomness = 0.0, initialLinearVelocity = Vector2(0, 0), initialAngularVelocity = 0.0, tries = 1, spawned = true):
	#Generate the asteroid normally
	var i = .spawnAsteroidByClass(oc, spot, chaos, spawnPointRandomness, initialLinearVelocity, initialAngularVelocity, tries, spawned)
	if not multiminerals:
		return i
	
	#If it's a class 5 roid, it's a mineral chunk
	if oc == 5 and i:
		var pure : float = 0.0
		var impure : float = 0.0

		#How many minerals are possible
		var sm : int = randi() % 3

		#If there are sub-minerals possible
		if sm > 0:
			#How much of the mineral should remain its base type
			pure = i.composition[i.mineral] * range_lerp(i.purity, 0.0, 1.0, 0.5, 0.9) #maps the purity to between 0.5 and 0.9
			#How much of the mineral should become a different mineral
			impure = i.composition[i.mineral] - pure
			#Set the mineral to its new quantity
			i.composition[i.mineral] = pure

		#While we have uncalculated sub-minerals AND 1kg of impurity remaining
		while sm > 0 and impure > 0.001:
			#Remove 1 sub-mineral from the count
			sm -= 1
			#Get mineral vein
			var m : String = getVeinAt(CurrentGame.globalCoords(spot))

			#Quantity of mineral
			var q : float = 0.0
			#While there is more than one sub-mineral remaining
			if sm > 0:
				#Choose how much of the impurity should be the new mineral
				q = rand_range(0, impure)
				#Reduce the impurity left by that amount
				impure -= q
			#If this is the last sub-mineral
			else:
				#The remaining quantity should be this mineral
				q = impure
				impure = 0.0
			
			# Checks for the mineral in an array of mineral entries
			# Fix for one bug in the preexisting mod
			var doesContainMineral:bool = false
			for t in i.composition.keys():
				if t == m:
					doesContainMineral = true
			if not m == null:
				#If the roid already has that mineral
				if doesContainMineral:
					#Add it to the existing amount
					i.composition[m] += q
				#If the roid does not have that mineral
				else:
					#Add it to the roid
					i.composition[m] = q
		if i.has_method("hl_multiminerals_update_mass"):
			i.hl_multiminerals_update_mass()
		else:
			printerr("Mineral [%s] lacks hl_multiminerals_update_mass() method" % i)
			i = hl_multiminerals_update_mass(i)
		
	return i
#Update the roid's mass incase something went fucky
func hl_multiminerals_update_mass(i):
	i.mass = hl_multiminerals_calc_comp(i)
	return i

func hl_multiminerals_calc_comp(i) -> float:
#	print(composition)
	var comp_val:float = 0.0
	#For every material in the roid
	for type in i.composition:
		#If that material actually exists 
		if i.composition[type] >= 0.001:
			#Add it to our sum
			comp_val += i.composition[type]
		#If the material does not exist
		else:
			#Remove the stray atoms
			i.composition.erase(type)
	return comp_val
