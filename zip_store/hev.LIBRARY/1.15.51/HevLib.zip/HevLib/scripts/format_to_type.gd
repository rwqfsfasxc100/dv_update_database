# [license]
# 3-Clause BSD NON-AI License
# 
# Copyright 2026 __hev (Benjamin Buckhurst)
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

static func format_to_type(data, type : int = TYPE_ARRAY):
	var mtype = typeof(data)
	if mtype == type:
		return data
	match type:
		TYPE_AABB:
			match mtype:
				TYPE_ARRAY, TYPE_INT_ARRAY, TYPE_REAL_ARRAY,TYPE_RAW_ARRAY:
					if data.size() >= 6:
						var a = float(data[0])
						var b = float(data[1])
						var c = float(data[2])
						var d = float(data[3])
						var e = float(data[4])
						var f = float(data[5])
						if a and b and c and d and e and f:
							return AABB(Vector3(a,b,c),Vector3(d,e,f))
				TYPE_VECTOR2_ARRAY:
					if data.size() >= 3:
						var a = float(data[0][0])
						var b = float(data[0][1])
						var c = float(data[1][0])
						var d = float(data[1][1])
						var e = float(data[2][0])
						var f = float(data[2][1])
						if a and b and c and d and e and f:
							return AABB(Vector3(a,b,c),Vector3(d,e,f))
				TYPE_VECTOR3_ARRAY:
					if data.size() >= 2:
						var a = data[0]
						var b = data[1]
						if a and b:
							return AABB(a,b)
		TYPE_ARRAY:
			match mtype:
				TYPE_ARRAY,TYPE_COLOR_ARRAY,TYPE_INT_ARRAY,TYPE_RAW_ARRAY,TYPE_REAL_ARRAY,TYPE_STRING_ARRAY,TYPE_VECTOR2_ARRAY,TYPE_VECTOR3_ARRAY:
					return data
				TYPE_DICTIONARY:
					return data.keys()
				_:
					return [data]
					
		TYPE_BASIS:
			match mtype:
				TYPE_ARRAY, TYPE_INT_ARRAY, TYPE_REAL_ARRAY,TYPE_RAW_ARRAY:
					if data.size() >= 9:
						var a = float(data[0])
						var b = float(data[1])
						var c = float(data[2])
						var d = float(data[3])
						var e = float(data[4])
						var f = float(data[5])
						var g = float(data[6])
						var h = float(data[7])
						var i = float(data[8])
						if a and b and c and d and e and f and g and h and i:
							return Basis(Vector3(a,b,c),Vector3(d,e,f),Vector3(g,h,i))
				TYPE_VECTOR2_ARRAY:
					if data.size() >= 5:
						var a = float(data[0][0])
						var b = float(data[0][1])
						var c = float(data[1][0])
						var d = float(data[1][1])
						var e = float(data[2][0])
						var f = float(data[2][1])
						var g = float(data[3][0])
						var h = float(data[3][1])
						var i = float(data[4][0])
						if a and b and c and d and e and f and g and h and i:
							return Basis(Vector3(a,b,c),Vector3(d,e,f),Vector3(g,h,i))
				TYPE_VECTOR3_ARRAY:
					if data.size() >= 2:
						var a = data[0]
						var b = data[1]
						var c = data[2]
						if a and b and c:
							return Basis(a,b,c)
		TYPE_BOOL:
			if data:
				return true
			else:
				return false
		TYPE_COLOR:
			pass
		TYPE_COLOR_ARRAY:
			pass
		TYPE_DICTIONARY:
			pass
		TYPE_INT:
			pass
		TYPE_INT_ARRAY:
			pass
		TYPE_NIL:
			return null
		TYPE_NODE_PATH:
			pass
		TYPE_PLANE:
			pass
		TYPE_QUAT:
			pass
		TYPE_RAW_ARRAY:
			pass
		TYPE_REAL:
			pass
		TYPE_REAL_ARRAY:
			pass
		TYPE_RECT2:
			pass
		TYPE_STRING:
			pass
		TYPE_STRING_ARRAY:
			pass
		TYPE_TRANSFORM:
			pass
		TYPE_TRANSFORM2D:
			pass
		TYPE_VECTOR2:
			pass
		TYPE_VECTOR2_ARRAY:
			pass
		TYPE_VECTOR3:
			pass
		TYPE_VECTOR3_ARRAY:
			pass
		
	Debug.l("HevLib format_to_type: Cannot convert variable type. Please handle this manually.")
	return null
