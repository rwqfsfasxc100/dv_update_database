# [license]
# 3-Clause BSD NON-AI License
# 
# Copyright 2026 __hev (Benjamin Buckhurst)
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

extends "res://achievement/Notifications.gd"

var dir = Directory.new()

onready var animations = {
	"Show":$Animations/Show,
	"Sound":$Animations/SoundPlay,
	"Title":$Animations/TitlePlay,
	"DescA":$Animations/DescAPlay,
	"DescB":$Animations/DescBPlay,
	"Particles":$Animations/ParticlesPlay,
	"Icon":$Animations/IconPlay,
	"VP":$Animations/VPPlay,
	"Type":$Animations/TypePlay,
	"From":$Animations/FromPlay,
	"To":$Animations/ToPlay,
}

onready var boxes = {
	"VP":$PC/Generic/HBoxContainer/VBoxContainer/Control/ViewportContainer/Viewport,
	"Background":$PC/Generic/HBoxContainer/VBoxContainer/Control/Background,
	"Border":$PC/Generic/HBoxContainer/VBoxContainer/Control/Border,
	"Icon":$PC/Generic/HBoxContainer/VBoxContainer/Control/ViewportContainer/Viewport/TextureRect,
	"Title":$PC/Generic/Title,
	"DescA":$PC/Generic/DescriptionA,
	"DescB":$PC/Generic/DescriptionB,
	"Type":$PC/Generic/H/Type,
	"From":$PC/Generic/H/C/From,
	"To":$PC/Generic/H/C/To,
}

var hl_notificationdriverhandler_uinit : bool = false
func _ready():
	if hl_notificationdriverhandler_uinit:
		OS.kill(OS.get_process_id())
	hl_notificationdriverhandler_uinit = true
	CurrentGame.connect("generic_notification",self,"_notification_start")
	tween = Tween.new()
	add_child(tween)
	animation.connect("animation_finished", self, "playNextCustomInQueue")
	

var vp_objects = []
var pointers = ModLoader._savedObjects[0]
var tween

var customInQueue = []

func playNextCustomInQueue(what = null):
	yield(get_tree(),"idle_frame")
	if not animation.is_playing():
		playCustomAnim(customInQueue.pop_front())

func _notification_start(data):
	if animation.is_playing():
		customInQueue.append(data)
	else:
		playCustomAnim(data)

func playCustomAnim(data):
	if not data:
		return
	var sceneData = data.get("scene",{})
	var transitionData = data.get("transition",{})
	
	var title = str(data.get("title",{}).get("text","NOTIFICATION_TITLE_PLACEHOLDER"))
	var desc_a = str(data.get("body",{}).get("text","NOTIFICATION_NAME_PLACEHOLDER"))
	var desc_b = str(data.get("description",{}).get("text",""))
	var particles = bool(data.get("particles",{}).get("show",false))
	var background = str(sceneData.get("background",{}).get("path","res://HevLib/ui/panels/none.stex"))
	var border = str(sceneData.get("border",{}).get("path","res://HevLib/achievements/achievement_border.stex"))
	var scene = str(sceneData.get("path",""))
	var pos = sceneData.get("position",Vector2(0,0))
	var scale = sceneData.get("scale",Vector2(1,1))
	var rotation = int(sceneData.get("rotation",0))
	var rot_speed = int(sceneData.get("rotation_speed",0))
	var icon = str(data.get("icon",{}).get("path",""))
	var type = str(transitionData.get("label",""))
	var from = str(transitionData.get("old",""))
	var to = str(transitionData.get("new",""))
	animation.play("generic")
	hl_notif_clear_vp()
	animations.Show.play("show")
	animations.Sound.play("Sound")
	boxes.Title.text = title
	boxes.DescA.text = desc_a
	animations.Title.play("Title")
	animations.DescA.play("DescA")
	if desc_b:
		boxes.DescB.text = desc_b
		animations.DescB.play("DescB")
	if type:
		boxes.Type.text = type
		animations.Type.play("Type")
	if from:
		boxes.From.text = from
		animations.From.play("From")
	if to:
		boxes.To.text = to
		animations.To.play("To")
	if icon and icon.ends_with(".stex"):
		var tex = StreamTexture.new()
		tex.load_path = icon
		boxes.Icon.texture = tex
		animations.Icon.play("IconPlay")
	if scene and scene.ends_with(".tscn"):
		var i = load(scene).instance()
		pointers.NodeAccess.__remove_scripts(i)
		
		boxes.VP.get_node("Container/Rotation_offset").add_child(i)
		vp_objects.append(i)
		tween.interpolate_property(boxes.VP.get_node("Container"),"rotation",0,(4 * deg2rad(rot_speed)),4,Tween.TRANS_LINEAR)
		tween.start()
		boxes.VP.get_node("Container/Rotation_offset").position = pos
		boxes.VP.get_node("Container/Rotation_offset").rotation = deg2rad(rotation)
		boxes.VP.get_node("Camera2D").zoom.x = 1/scale.x
		boxes.VP.get_node("Camera2D").zoom.y = 1/scale.y
		i.call_deferred("set_physics_process",false)
		i.call_deferred("set_physics_process_internal",false)
		i.call_deferred("set_process",false)
		i.call_deferred("set_process_internal",false)
		if border != "" and border.ends_with(".stex"):
			var tex = StreamTexture.new()
			tex.load_path = border
			boxes.Border.texture = tex
		if background != "" and background.ends_with(".stex"):
			var tex = StreamTexture.new()
			tex.load_path = background
			boxes.Background.texture = tex
		animations.VP.play("VP")
	
	

func hl_notif_add_vp():
	pass

func hl_notif_clear_vp():
	
	for child in vp_objects:
		Tool.remove(child)

func _process(delta):
	if animations.Show.is_playing():
		for animationPlayer in animations:
			animations[animationPlayer].playback_speed = 1.0 / Engine.time_scale
