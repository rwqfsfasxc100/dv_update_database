# [license]
# 3-Clause BSD NON-AI License
# 
# Copyright 2026 __hev (Benjamin Buckhurst)
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

const TEMPLATES = {
	"CENTER_WEAPON_TURRETS":{
		"equipment":[
			"SYSTEM_PDTL",
			"SYSTEM_PDT",
		],
		"data":[
			{
				"property":"position",
				"value":Vector2(0,-15),
				
			}
		]
	},
	"CENTER_MIKE_TURRETS":{
		"equipment":[
			"SYSTEM_PDMWG",
		],
		"data":[
			{
				"property":"position",
				"value":Vector2(0,-16),
				
			}
		]
	},
	"LEFT_WEAPON_TURRETS":{
		"equipment":[
			"SYSTEM_PDT-L",
			"SYSTEM_PDTL-L"
		],
		"data":[
			{
				"property":"position",
				"value":Vector2(-71,19),
					
			},
			{
				"property":"rotation",
				"value":-0.523599,
				
			},
		]
	},
	"LEFT_MIKE_TURRETS":{
		"equipment":[
			"SYSTEM_PDMWG-L"
		],
		"data":[
			{
				"property":"position",
				"value":Vector2(-140,60),
				
			},
			{
				"property":"rotation",
				"value":-1.0472,
				
			},
		]
	},
	"RIGHT_WEAPON_TURRETS":{
		"equipment":[
			"SYSTEM_PDT-R",
			"SYSTEM_PDTL-R"
		],
		"data":[
			{
				"property":"position",
				"value":Vector2(71,19),
				
			},
			{
				"property":"rotation",
				"value":0.523599,
				
			},
		]
	},
	"RIGHT_MIKE_TURRETS":{
		"equipment":[
			"SYSTEM_PDMWG-R"
		],
		"data":[
			{
				"property":"position",
				"value":Vector2(140,60),
				
			},
			{
				"property":"rotation",
				"value":1.0472,
				
			},
		]
	},
	"CRADLES":{
		"equipment":[
			"SYSTEM_EXSTORAGE-L",
			"SYSTEM_EXSTORAGE-R",
			"SYSTEM_CLAIM-L",
			"SYSTEM_CLAIM-R",
			"SYSTEM_SCOOP-L",
			"SYSTEM_SCOOP-R",
			"SYSTEM_HUNK-L",
			"SYSTEM_HUNK-R",
			"SYSTEM_EXMONO-L",
			"SYSTEM_EXMONO-R",
		],
		"data":[
			{
				"property":"position",
				"value":Vector2(0,196),
				
			}
		]
	},
	"PLASMATHROWER_LOW":{
		"equipment":[
			"SYSTEM_EINAT",
			"SYSTEM_IROH"
		],
		"data":[
			{
				"property":"position",
				"value":Vector2(0,2),
				
			}
		]
	},
	"PLASMATHROWER_HIGH":{
		"equipment":[
			"SYSTEM_EINAT"
		],
		"data":[
			{
				"property":"position",
				"value":Vector2(-1,2),
				
			}
		]
	},
	"MASSDRIVERS":{
		"equipment":[
			"SYSTEM_EMD14",
			"SYSTEM_EMD17RF",
			"SYSTEM_RAILTOR",
			"SYSTEM_ACTEMD14",
		],
		"data":[
			{
				"property":"position",
				"value":Vector2(0,-30),
				
			}
		]
	},
	"MANIPULATION_ARMS":{
		"equipment":[
			"SYSTEM_SALVAGE_ARM",
		],
		"data":[
			{
				"property":"position",
				"value":Vector2(0,130),
				
			}
		]
	},
	"ORE_NANODRONES":{
		"equipment":[
			"SYSTEM_DND_TS",
			"SYSTEM_DND_HAUL"
		],
		"data":[
			{
				"property":"position",
				"value":Vector2(0,50),
				
			}
		]
	},
	"FIXED_MICROWAVES":{
		"equipment":[
			"SYSTEM_MWG"
		],
		"data":[]
	},
	"NANODRONES":{
		"equipment":[
			"SYSTEM_DND_TS",
			"SYSTEM_DND_HAUL",
			"SYSTEM_DND_FIX"
		],
		"data":[]
	},
	"LASERS":{
		"equipment":[
			"SYSTEM_CL150",
			"SYSTEM_CL600P",
			"SYSTEM_ACL200P",
			"SYSTEM_PDTL",
			"SYSTEM_PDTL-L",
			"SYSTEM_PDTL-R"
		],
		"data":[]
	},
	"GIMBALS":{
		"equipment":[
			"SYSTEM_ACL200P",
			"SYSTEM_ACTEMD14"
		],
		"data":[]
	},
	"TURRETS":{
		"equipment":[
			"SYSTEM_PDMWG",
			"SYSTEM_PDMWG-L",
			"SYSTEM_PDMWG-R",
			"SYSTEM_PDT-R",
			"SYSTEM_PDT-L",
			"SYSTEM_PDT",
			"SYSTEM_PDTL",
			"SYSTEM_PDTL-L",
			"SYSTEM_PDTL-R",
		],
		"data":[]
	},
	"FRONT_FACING_WEAPONS":{
		"equipment":[
			"SYSTEM_MWG",
			"SYSTEM_CL150",
			"SYSTEM_CL600P",
			"SYSTEM_EMD14",
			"SYSTEM_EMD17RF",
			"SYSTEM_RAILTOR",
			"SYSTEM_ACTEMD14",
			"SYSTEM_ACL200P",
			"SYSTEM_SYNCHRO-L",
			"SYSTEM_SYNCHRO-R",
			"SYSTEM_IROH"
		],
		"data":[]
	},
	"SYNCHROTRONS":{
		"equipment":[
			"SYSTEM_SYNCHRO-R",
			"SYSTEM_SYNCHRO-L"
		],
		"data":[]
	},
	"CARGO_CONTAINERS":{
		"equipment":[
			"SYSTEM_EXMONO-L",
			"SYSTEM_EXMONO-R",
			"SYSTEM_EXSTORAGE-L",
			"SYSTEM_EXSTORAGE-R"
		],
		"data":[]
	},
	"CONTAINERS":{
		"equipment":[
			"SYSTEM_EXMONO-L",
			"SYSTEM_EXMONO-R",
			"SYSTEM_EXSTORAGE-L",
			"SYSTEM_EXSTORAGE-R",
			"SYSTEM_SCOOP-R",
			"SYSTEM_SCOOP-L"
		],
		"data":[]
	},
	"MINING_COMPANIONS":{
		"equipment":[
			"SYSTEM_SCOOP-R",
			"SYSTEM_SCOOP-L"
		],
		"data":[]
	},
	"IMPACT_ABSORBERS":{
		"equipment":[
			"SYSTEM_HUNK-R",
			"SYSTEM_HUNK-L"
		],
		"data":[]
	},
	"CLAIM_BEACONS":{
		"equipment":[
			"SYSTEM_CLAIM-L",
			"SYSTEM_CLAIM-R"
		],
		"data":[]
	},
	"RAILGUNS":{
		"equipment":[
			"SYSTEM_RAILTOR",
			"SYSTEM_PDT-R",
			"SYSTEM_PDT-L",
			"SYSTEM_PDT"
		],
		"data":[]
	},
	"COILGUNS":{
		"equipment":[
			"SYSTEM_EMD14",
			"SYSTEM_EMD17RF",
			"SYSTEM_ACTEMD14"
		],
		"data":[]
	}
}
