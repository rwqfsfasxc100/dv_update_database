# [license]
# 3-Clause BSD NON-AI License
# 
# Copyright 2026 __hev (Benjamin Buckhurst)
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

const SHIP_TEMPLATES = {
	"SHIP_AT225":{
		"middleLeft":{
			"MINING_COMPANIONS":[
				{
					"property":"command",
					"value":"",
					
				},
				{
					"property":"passFireAsCommand",
					"value":"",
					
				}
			],
			"IMPACT_ABSORBERS":[
				{
					"property":"position",
					"value":Vector2( 0, 80 ),
					
				},
				{
					"property":"rotation",
					"value":0.174533,
					
				}
			],
			"LEFT_WEAPON_TURRETS":[
				{
					"property":"position",
					"value":Vector2( -69, -71 ),
					
				}
			]
		},
		"middleRight":{
			"MINING_COMPANIONS":[
				{
					"property":"command",
					"value":"",
					
				},
				{
					"property":"passFireAsCommand",
					"value":"",
					
				}
			],
			"IMPACT_ABSORBERS":[
				{
					"property":"position",
					"value":Vector2( 0, 80 ),
					
				},
				{
					"property":"rotation",
					"value":-0.174533,
					
				}
			],
			"RIGHT_WEAPON_TURRETS":[
				{
					"property":"position",
					"value":Vector2( 69, -71 ),
					
				}
			],
		},
		"leftBay1":{
			"MINING_COMPANIONS":[
				{
					"property":"command",
					"value":"",
					
				},
				{
					"property":"passFireAsCommand",
					"value":"",
					
				}
			],
			"IMPACT_ABSORBERS":[
				{
					"property":"position",
					"value":Vector2( 0, 80 )
				},
				{
					"property":"rotation",
					"value":-0.174533,
					
				}
			],
			"LEFT_WEAPON_TURRETS":[
				{
					"property":"position",
					"value":Vector2( -190, 0 ),
					
				},
				{
					"property":"rotation",
					"value":-1.0472,
					
				},
				{
					"property":"z_index",
					"value":27,
					
				}
			],
			"LEFT_MIKE_TURRETS":[
				{
					"property":"position",
					"value":Vector2( -200, 81 ),
					
				},
				{
					"property":"z_index",
					"value":27,
					
				}
			],
			"NANODRONES":[
				{
					"property":"position",
					"value":Vector2( -172, 142 ),
					
				},
				{
					"property":"rotation",
					"value":-1.5708,
					
				},
			]
		},
		"leftBay2":{
			"MINING_COMPANIONS":[
				{
					"property":"command",
					"value":"",
					
				},
				{
					"property":"passFireAsCommand",
					"value":"",
					
				}
			],
			"IMPACT_ABSORBERS":[
				{
					"property":"position",
					"value":Vector2( 0, 80 ),
					
				},
				{
					"property":"rotation",
					"value":-0.174533,
					
				}
			],
			"LEFT_WEAPON_TURRETS":[
				{
					"property":"position",
					"value":Vector2( -190, 0 ),
					
				},
				{
					"property":"rotation",
					"value":-1.0472,
					
				},
				{
					"property":"z_index",
					"value":27,
					
				}
			],
			"LEFT_MIKE_TURRETS":[
				{
					"property":"position",
					"value":Vector2( -200, 81 ),
					
				},
				{
					"property":"z_index",
					"value":27,
					
				}
			],
			"NANODRONES":[
				{
					"property":"position",
					"value":Vector2( -172, 142 ),
					
				},
				{
					"property":"rotation",
					"value":-1.5708,
					
				},
			]
		},
		"leftBay3":{
			"MINING_COMPANIONS":[
				{
					"property":"command",
					"value":"",
					
				},
				{
					"property":"passFireAsCommand",
					"value":"",
					
				}
			],
			"IMPACT_ABSORBERS":[
				{
					"property":"position",
					"value":Vector2( 0, 80 ),
					
				},
				{
					"property":"rotation",
					"value":-0.174533,
					
				}
			],
			"LEFT_WEAPON_TURRETS":[
				{
					"property":"position",
					"value":Vector2( -190, 0 ),
					
				},
				{
					"property":"rotation",
					"value":-1.0472,
					
				},
				{
					"property":"z_index",
					"value":27,
					
				}
			],
			"LEFT_MIKE_TURRETS":[
				{
					"property":"position",
					"value":Vector2( -200, 81 ),
					
				},
				{
					"property":"z_index",
					"value":27,
					
				}
			],
			"NANODRONES":[
				{
					"property":"position",
					"value":Vector2( -172, 142 ),
					
				},
				{
					"property":"rotation",
					"value":-1.5708,
					
				},
			]
		},
		"rightBay1":{
			"MINING_COMPANIONS":[
				{
					"property":"command",
					"value":"",
					
				},
				{
					"property":"passFireAsCommand",
					"value":"",
					
				}
			],
			"IMPACT_ABSORBERS":[
				{
					"property":"position",
					"value":Vector2( 0, 80 ),
					
				},
				{
					"property":"rotation",
					"value":0.174533,
					
				}
			],
			"RIGHT_WEAPON_TURRETS":[
				{
					"property":"position",
					"value":Vector2( 190, 0 ),
					
				},
				{
					"property":"rotation",
					"value":1.0472,
					
				},
				{
					"property":"z_index",
					"value":27,
					
				}
			],
			"RIGHT_MIKE_TURRETS":[
				{
					"property":"position",
					"value":Vector2( 200, 81 ),
					
				},
				{
					"property":"z_index",
					"value":27,
					
				}
			],
			"NANODRONES":[
				{
					"property":"position",
					"value":Vector2( 172, 142 ),
					
				},
				{
					"property":"rotation",
					"value":1.5708,
					
				},
			]
		},
		"rightBay2":{
			"MINING_COMPANIONS":[
				{
					"property":"command",
					"value":"",
					
				},
				{
					"property":"passFireAsCommand",
					"value":"",
					
				}
			],
			"IMPACT_ABSORBERS":[
				{
					"property":"position",
					"value":Vector2( 0, 80 ),
					
				},
				{
					"property":"rotation",
					"value":0.174533,
					
				}
			],
			"RIGHT_WEAPON_TURRETS":[
				{
					"property":"position",
					"value":Vector2( 190, 0 ),
					
				},
				{
					"property":"rotation",
					"value":1.0472,
					
				},
				{
					"property":"z_index",
					"value":27,
					
				}
			],
			"RIGHT_MIKE_TURRETS":[
				{
					"property":"position",
					"value":Vector2( 200, 81 ),
					
				},
				{
					"property":"z_index",
					"value":27,
					
				}
			],
			"NANODRONES":[
				{
					"property":"position",
					"value":Vector2( 172, 142 ),
					
				},
				{
					"property":"rotation",
					"value":1.5708,
					
				},
			]
		},
		"rightBay3":{
			"MINING_COMPANIONS":[
				{
					"property":"command",
					"value":"",
					
				},
				{
					"property":"passFireAsCommand",
					"value":"",
					
				}
			],
			"IMPACT_ABSORBERS":[
				{
					"property":"position",
					"value":Vector2( 0, 80 ),
					
				},
				{
					"property":"rotation",
					"value":0.174533,
					
				}
			],
			"RIGHT_WEAPON_TURRETS":[
				{
					"property":"position",
					"value":Vector2( 190, 0 ),
					
				},
				{
					"property":"rotation",
					"value":1.0472,
					
				},
				{
					"property":"z_index",
					"value":27,
					
				}
			],
			"RIGHT_MIKE_TURRETS":[
				{
					"property":"position",
					"value":Vector2( 200, 81 ),
					
				},
				{
					"property":"z_index",
					"value":27,
					
				}
			],
			"NANODRONES":[
				{
					"property":"position",
					"value":Vector2( 172, 142 ),
					
				},
				{
					"property":"rotation",
					"value":1.5708,
					
				},
			]
		},
	},
	"SHIP_COTHON":{
		"left":{
			"IMPACT_ABSORBERS":[
				{
					"property":"position",
					"value":Vector2( 0, 80 ),
					
				},
				{
					"property":"rotation",
					"value":0.174533,
					
				}
			]
		},
		"right":{
			"IMPACT_ABSORBERS":[
				{
					"property":"position",
					"value":Vector2( 0, 80 ),
					
				},
				{
					"property":"rotation",
					"value":-0.174533,
					
				}
			]
		},
		"leftBack":{
			"LEFT_MIKE_TURRETS":[
				{
					"property":"position",
					"value":Vector2( -150, 180 ),
					
				},
				{
					"property":"rotation",
					"value":-2.0944,
					
				}
			],
			"MINING_COMPANIONS":[
				{
					"property":"command",
					"value":"",
					
				},
				{
					"property":"passFireAsCommand",
					"value":"",
					
				}
			],
			"IMPACT_ABSORBERS":[
				{
					"property":"rotation",
					"value":-0.174533,
					
				}
			],
			"LEFT_WEAPON_TURRETS":[
				{
					"property":"position",
					"value":Vector2( -146, 165 ),
					
				},
				{
					"property":"rotation",
					"value":-2.0944,
					
				},
				{
					"property":"z_index",
					"value":18,
					
				}
			]
		},
		"rightBack":{
			"RIGHT_MIKE_TURRETS":[
				{
					"property":"position",
					"value":Vector2( 150, 180 ),
					
				},
				{
					"property":"rotation",
					"value":2.0944,
					
				}
			],
			"MINING_COMPANIONS":[
				{
					"property":"command",
					"value":"",
					
				},
				{
					"property":"passFireAsCommand",
					"value":"",
					
				}
			],
			"IMPACT_ABSORBERS":[
				{
					"property":"rotation",
					"value":0.174533,
					
				}
			],
			"RIGHT_WEAPON_TURRETS":[
				{
					"property":"position",
					"value":Vector2( 146, 165 ),
					
				},
				{
					"property":"rotation",
					"value":2.0944,
					
				},
				{
					"property":"z_index",
					"value":18,
					
				}
			]
		}
	},
	"SHIP_PROSPECTOR":{
		"left":{
			"CARGO_CONTAINERS":[
				{
					"property":"position",
					"value":Vector2( 48, -86 ),
					
				},
				{
					"property":"z_index",
					"value":-10,
					
				}
			],
			"CLAIM_BEACONS":[
				{
					"property":"position",
					"value":Vector2( 60, 60 ),
					
				}
			],
			"GIMBALS":[
				{
					"property":"position",
					"value":Vector2( -15, 0 ),
					
				},
				{
					"property":"rotation",
					"value":-0.0174533,
					
				}
			],
			"MINING_COMPANIONS":[
				{
					"property":"position",
					"value":Vector2( 52, -100 ),
					
				}
			],
			"IMPACT_ABSORBERS":[
				{
					"property":"position",
					"value":Vector2( 0, 176 ),
					
				}
			]
		},
		"right":{
			"CARGO_CONTAINERS":[
				{
					"property":"position",
					"value":Vector2( -48, -86 ),
					
				},
				{
					"property":"z_index",
					"value":-10,
					
				}
			],
			"CLAIM_BEACONS":[
				{
					"property":"position",
					"value":Vector2( -60, 60 ),
					
				}
			],
			"GIMBALS":[
				{
					"property":"position",
					"value":Vector2( 15, 0 ),
					
				},
				{
					"property":"rotation",
					"value":0.0174533,
					
				}
			],
			"MINING_COMPANIONS":[
				{
					"property":"position",
					"value":Vector2( -52, -100 ),
					
				}
			],
			"IMPACT_ABSORBERS":[
				{
					"property":"position",
					"value":Vector2( 0, 176 ),
					
				}
			]
		}
	},
	"SHIP_PROSPECTOR_VP":{
		"left":{
			"CLAIM_BEACONS":[
				{
					"property":"position",
					"value":Vector2( 50, 60 ),
					
				}
			],
		},
		"right":{
			"CLAIM_BEACONS":[
				{
					"property":"position",
					"value":Vector2( -50, 60 ),
					
				}
			],
		},
	},
	"SHIP_EIME":{
		"left":{
			"CARGO_CONTAINERS":[
				{
					"property":"position",
					"value":Vector2( 0, 64 ),
					
				}
			],
			"CRADLES":[
				{
					"property":"position",
					"value":Vector2( 0, 64 ),
					
				}
			],
			"CLAIM_BEACONS":[
				{
					"property":"position",
					"value":Vector2( 0, 64 )
				}
			],
			"MINING_COMPANIONS":[
				{
					"property":"position",
					"value":Vector2( 0, 64 ),
					
				}
			],
		},
		"right":{
			"CARGO_CONTAINERS":[
				{
					"property":"position",
					"value":Vector2( 0, 64 ),
					
				}
			],
			"CRADLES":[
				{
					"property":"position",
					"value":Vector2( 0, 64 ),
					
				}
			],
			"CLAIM_BEACONS":[
				{
					"property":"position",
					"value":Vector2( 0, 64 ),
					
				}
			],
			"MINING_COMPANIONS":[
				{
					"property":"position",
					"value":Vector2( 0, 64 ),
					
				}
			],
		},
	},
	"SHIP_OCP209":{
		"mainLeft":{
			"MANIPULATION_ARMS":[
				{
					"property":"flip",
					"value":true,
					
				},
				{
					"property":"feedVelocity",
					"value":Vector2( -140, -280 ),
					
				},
			]
		},
		"mainRight":{
			"MANIPULATION_ARMS":[
				{
					"property":"feedVelocity",
					"value":Vector2( 140, -280 ),
					
				},
			]
		},
	},
	"SHIP_TRTL_K44":{
		"leftBack":{
			"IMPACT_ABSORBERS":[
				{
					"property":"position",
					"value":Vector2( -40, 222 ),
					
				},
				{
					"property":"rotation",
					"value":-0.523599,
					
				}
			],
			"LEFT_WEAPON_TURRETS":[
				{
					"property":"position",
					"value":Vector2( -124, 211 ),
					
				},
				{
					"property":"rotation",
					"value":-2.0944,
					
				},
			]
		},
		"rightBack":{
			"IMPACT_ABSORBERS":[
				{
					"property":"position",
					"value":Vector2( 40, 222 ),
					
				},
				{
					"property":"rotation",
					"value":0.523599,
					
				}
			],
			"RIGHT_WEAPON_TURRETS":[
				{
					"property":"position",
					"value":Vector2( 124, 211 ),
					
				},
				{
					"property":"rotation",
					"value":2.0944,
					
				}
			]
		}
	}
}
