# [license]
# 3-Clause BSD NON-AI License
# 
# Copyright 2026 __hev (Benjamin Buckhurst)
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

extends VBoxContainer

var MOD_INFO = {}

var ModContainer = null

onready var icon_node = $BaseModBox/Icon
onready var icon_conflicts = $BaseModBox/Icon/Control/Conflicts
onready var icon_dependancies = $BaseModBox/Icon/Control/Dependancies
onready var icon_updates = $BaseModBox/Icon/Control/Updates
onready var icon_complementary = $BaseModBox/Icon/Control/Complementary

onready var button = $BaseModBox/ModButton
onready var button_box = $BaseModBox/ModButton/VBoxContainer
onready var button_box2 = $BaseModBox/ModButton/VBoxContainer/HBoxContainer
onready var button_label = $BaseModBox/ModButton/VBoxContainer/HBoxContainer/LABELS/NAME
onready var button_brief = $BaseModBox/ModButton/VBoxContainer/HBoxContainer/LABELS/BRIEF
onready var button_lib_icon = $BaseModBox/ModButton/VBoxContainer/HBoxContainer/VBoxContainer/Library
onready var button_children_icon = $BaseModBox/ModButton/VBoxContainer/HBoxContainer/VBoxContainer/Children
onready var button_children_count = $BaseModBox/ModButton/VBoxContainer/HBoxContainer/VBoxContainer/Children/Count

var ModButton = NodePath("ModButton")
var button_size = Vector2(0,0)

const SubModBox = preload("res://HevLib/ui/mod_menu/mod_list/SubModBox.tscn")

var MAX_SIZE = Vector2(0,0)

var information_nodes = {}

var pointers = ModLoader._savedObjects[0]
var file = File.new()


var conflicts = []
var dependancies = []
var complementary = []

var already_pressed = false
var submod_visibility = false

var has_update = false
var has_dep = false
var has_conf = false
var has_links = false
var has_bugreports = false
var has_settings = false

var is_modlet = false
var needs_restart_from_toggling = false
var modlet_toggle_restart_path = "user://cache/.Mod_Menu_2_Cache/updates/modlet_restart_requests.json"
var mod_path = ""

func _pressed():
	information_nodes["mod_list"].make_info_default_state()
	
	mod_path = MOD_INFO["file_path"]
	var mod_dir = mod_path.get_base_dir() + "/"
	
	file.open(modlet_toggle_restart_path,File.READ)
	var restarting_modlets = JSON.parse(file.get_as_text()).result
	file.close()
	if mod_path in restarting_modlets:
		needs_restart_from_toggling = true
	
	var manifestData = MOD_INFO["manifest"]["manifest_data"]
	already_pressed = false
	var mod_name = MOD_INFO["name"]
	if information_nodes["info_name"].text == translateIfCan(mod_name):
		already_pressed = true
	information_nodes["info_name"].text = translateIfCan(mod_name)
	var prio = MOD_INFO["priority"]
	if str(prio).ends_with("INF"):
		if str(prio).begins_with("-"):
			prio = "-INF"
		else:
			prio = "INF"
	var ver = MOD_INFO["version_data"]["full_version_string"]
	information_nodes["info_version"].text = translateIfCan("HEVLIB_MODMENU_VERSION") % ver
	information_nodes["info_priority"].text = translateIfCan("HEVLIB_MODMENU_PRIO") % prio
	var iconTexture = null
	if MOD_INFO["mod_icon"]["has_icon_file"]:
		var icon_filepath = MOD_INFO["mod_icon"]["icon_path"]
		if icon_filepath.ends_with(".stex"):
			var tex = StreamTexture.new()
			tex.load_path = icon_filepath
			iconTexture = tex
		elif icon_filepath.ends_with(".png"):
			iconTexture = pointers.FileAccess.__load_png(icon_filepath)
	else:
		var tex = StreamTexture.new()
		tex.load_path = "res://HevLib/ui/themes/icons/missing_icon.png.stex"
		iconTexture = tex
	information_nodes["info_icon"].texture = iconTexture
	var id = ""
	if manifestData:
		id = manifestData["mod_information"]["id"]
	information_nodes["info_mod_id"].text = id
	var author = ""
	if manifestData:
		author = manifestData["mod_information"]["author"]
	information_nodes["info_author"].parse_bbcode(translateIfCan(author))
	if author != "":
		information_nodes["info_desc_author"].parse_bbcode(translateIfCan(author))
		information_nodes["info_desc_author"].visible = true
		information_nodes["author_header"].visible = true
		information_nodes["author_splitter"].visible = true
	else:
		information_nodes["info_desc_author"].visible = true
		information_nodes["author_header"].visible = true
		information_nodes["author_splitter"].visible = true
	var description = ""
	if manifestData:
		description = manifestData["mod_information"]["description"]
	information_nodes["info_desc_text"].parse_bbcode(translateIfCan(description))
	var creditText = ""
	if manifestData:
		for item in manifestData["mod_information"]["credits"]:
			if creditText == "":
				creditText = translateIfCan(item)
			else:
				creditText = creditText + "\n" + translateIfCan(item)
	if creditText != "":
		information_nodes["info_desc_credits"].parse_bbcode(creditText)
		information_nodes["info_desc_credits"].visible = true
		information_nodes["credits_header"].visible = true
		information_nodes["credits_splitter"].visible = true
	else:
		information_nodes["info_desc_credits"].visible = false
		information_nodes["credits_header"].visible = false
		information_nodes["credits_splitter"].visible = false
	var default_URL_icon = "res://HevLib/ui/themes/icons/alias.stex"
	information_nodes["links_menu_path"].MOD_INFO = MOD_INFO
	information_nodes["links_menu_path"].update()
	if manifestData:
		var links = manifestData["links"]
		var configs = manifestData["configs"]
		var link_size = links.size()
		var config_size = configs.size()
		if link_size == 0:
			information_nodes["info_links_button"].visible = false
			information_nodes["info_bugreports_button"].visible = false
			information_nodes["info_bugreports_button"].url = ""
		else:
			
			if "HEVLIB_BUGREPORTS" in links:
				has_bugreports = true
				information_nodes["info_bugreports_button"].visible = true
				information_nodes["info_bugreports_button"].url = links["HEVLIB_BUGREPORTS"].get("URL","")
			else:
				information_nodes["info_bugreports_button"].visible = false
			if link_size == 1 and has_bugreports:
				information_nodes["info_links_button"].visible = false
			else:
				information_nodes["info_links_button"].visible = true
				has_links = true
		
		if "languages" in manifestData:
			var langData = manifestData["languages"]
			var languages = ""
			for lang in langData:
				var percent = langData[lang]
				var ov = translateIfCan("HEVLIB_MM_TOOLTIP_LANGUAGE_ENTRY") % [TranslationServer.get_locale_name(lang) + " / %s" % lang,percent]
				if languages:
					languages += "\n" + ov
				else:
					languages = ov
			if languages:
				information_nodes["info_desc_languages"].parse_bbcode(languages)
				information_nodes["info_desc_languages"].visible = true
				information_nodes["languages_header"].visible = true
				information_nodes["languages_splitter"].visible = true
			else:
				information_nodes["info_desc_languages"].visible = false
				information_nodes["languages_header"].visible = false
				information_nodes["languages_splitter"].visible = false
		else:
			information_nodes["info_desc_languages"].visible = false
			information_nodes["languages_header"].visible = false
			information_nodes["languages_splitter"].visible = false
		
		if config_size == 0:
			information_nodes["info_settings_button"].visible = false
		else:
			has_settings = true
			information_nodes["info_settings_button"].visible = true
			information_nodes["settings_menu"].SELECTED_MOD = mod_name
			information_nodes["settings_menu"].SELECTED_MOD_ID = id
		var changelog = manifestData["manifest_definitions"].get("changelog_path","")
		if changelog != "":
			var c = mod_dir + changelog
			if file.file_exists(c):
				information_nodes["info_changelog_button"].visible = true
				information_nodes["changelog_menu"].update_this(c)
			else:
				information_nodes["info_changelog_button"].visible = false
				information_nodes["changelog_menu"].clear()
		else:
			information_nodes["info_changelog_button"].visible = false
			information_nodes["changelog_menu"].clear()
		
	else:
		information_nodes["info_settings_button"].visible = false
		information_nodes["info_links_button"].visible = false
		information_nodes["info_bugreports_button"].visible = false
		information_nodes["info_changelog_button"].visible = false
		information_nodes["languages_header"].visible = false
		information_nodes["languages_splitter"].visible = false
		information_nodes["changelog_menu"].clear()
	if already_pressed:
		if get_child_count() > 1:
			for i in range(1,get_child_count()):
				var node = get_child(i)
				node.visible = !node.visible
			submod_visibility = get_child(1).visible
			yield_button_focus()
			_refocus()
	information_nodes["mod_list"].currently_selected_mod_id = ID
	file.open(update_store,File.READ)
	var update_data = JSON.parse(file.get_as_text()).result
	file.close()
	file.open(conflicts_store,File.READ)
	var conflict_data = JSON.parse(file.get_as_text()).result
	file.close()
	file.open(dependancies_store,File.READ)
	var dependancy_data = JSON.parse(file.get_as_text()).result
	file.close()
	
	
	
	if id in update_data:
		information_nodes["updates_button"].visible = true
		information_nodes["updates_button"].hint_tooltip = translateIfCan("HEVLIB_ICON_TOOLTIP_UPDATES") % [str(update_data[ID]["version"][0])+"."+str(update_data[ID]["version"][1])+"."+str(update_data[ID]["version"][2]),str(update_data[ID]["new_version"][0])+"."+str(update_data[ID]["new_version"][1])+"."+str(update_data[ID]["new_version"][2])]
		has_update = true
	else:
		information_nodes["updates_button"].visible = false
		
	
	if id in dependancy_data:
		information_nodes["dependancies_button"].visible = true
		var cd = ""
		for i in dependancy_data[id]:
			var mname = get_mod_data(i)
			if mname:
				cd = cd + "\n\t" + mname
		information_nodes["dependancies_button"].hint_tooltip = translateIfCan("HEVLIB_ICON_TOOLTIP_DEPENDANCIES") % cd
		has_dep = true
	else:
		information_nodes["dependancies_button"].visible = false
	
	if id in conflict_data:
		information_nodes["conflict_button"].visible = true
		var cd = ""
		for i in conflict_data[id]:
			var mod_id = ""
			match typeof(i):
				TYPE_STRING:
					mod_id = i
				TYPE_ARRAY:
					if i:
						mod_id = str(i[0])
				TYPE_DICTIONARY:
					mod_id = str(i.get("mod_id",""))
			if mod_id:
				var mname = get_mod_data(i)
				cd = cd + "\n" + mname
		information_nodes["conflict_button"].hint_tooltip = translateIfCan("HEVLIB_ICON_TOOLTIP_CONFLICT") % cd
		has_conf = true
	else:
		information_nodes["conflict_button"].visible = false
	
	is_modlet = MOD_INFO["mod_type"] == "modlet"
	if is_modlet:
		information_nodes["toggle_modlet_button"].change_modlet_to(self,mod_path)
	information_nodes["toggle_modlet_box"].visible = is_modlet
	
	
	focus_button_neighbours(true)

func get_mod_data(data):
	var mname:String = ""
	match typeof(data):
		TYPE_STRING:
			if data:
				mname = data
		TYPE_ARRAY:
			var names = ""
			for r in data:
				match typeof(r):
					TYPE_STRING:
						if r:
							if names:
								names += " OR %s" % r
							else:
								names = r
					TYPE_DICTIONARY:
						var rn = r.get("mod_id",r.get("mod_main",""))
						var minVer = null
						var maxVer = null
						if ("minimum_version" in r or "min_version" in r):
							var minimum = r.get("minimum_version",r.get("min_version",null))
							match typeof(minimum):
								TYPE_ARRAY,TYPE_INT_ARRAY:
									if minimum.size() > 2:
										minVer = minimum
								TYPE_DICTIONARY:
									var minarr = Vector3.ZERO
									minarr[0] = int(minimum.get("major",0))
									minarr[1] = int(minimum.get("minor",0))
									minarr[2] = int(minimum.get("bugfix",0))
									minVer = minarr
						if ("maximum_version" in r or "max_version" in r):
							var minimum = r.get("maximum_version",r.get("max_version",null))
							match typeof(minimum):
								TYPE_ARRAY,TYPE_INT_ARRAY:
									if minimum.size() > 2:
										maxVer = minimum
								TYPE_DICTIONARY:
									var minarr = Vector3.ZERO
									minarr[0] = int(minimum.get("major",0))
									minarr[1] = int(minimum.get("minor",0))
									minarr[2] = int(minimum.get("bugfix",0))
									maxVer = minarr
						var additional = ""
						if minVer != null:
							additional = "min ver %d.%d.%d" % [minVer[0],minVer[1],minVer[2]]
						if maxVer:
							if additional:
								additional += " through "
							additional += "max ver %d.%d.%d" % [maxVer[0],maxVer[1],maxVer[2]]
						if additional:
							rn += " (%s)" % additional
						if rn:
							if names:
								names += " OR %s" % rn
							else:
								names = rn
			mname = names
		TYPE_DICTIONARY:
			var rn = data.get("mod_id",data.get("mod_main",""))
			var minVer = null
			var maxVer = null
			if ("minimum_version" in data or "min_version" in data):
				var minimum = data.get("minimum_version",data.get("min_version",null))
				match typeof(minimum):
					TYPE_ARRAY,TYPE_INT_ARRAY:
						if minimum.size() > 2:
							minVer = minimum
					TYPE_VECTOR3:
						minVer = minimum
					TYPE_DICTIONARY:
						var minarr = Vector3.ZERO
						minarr[0] = int(minimum.get("major",0))
						minarr[1] = int(minimum.get("minor",0))
						minarr[2] = int(minimum.get("bugfix",0))
						minVer = minarr
			if ("maximum_version" in data or "max_version" in data):
				var minimum = data.get("maximum_version",data.get("max_version",null))
				match typeof(minimum):
					TYPE_ARRAY,TYPE_INT_ARRAY:
						if minimum.size() > 2:
							maxVer = minimum
					TYPE_VECTOR3:
						maxVer = minimum
					TYPE_DICTIONARY:
						var minarr = Vector3.ZERO
						minarr[0] = int(minimum.get("major",0))
						minarr[1] = int(minimum.get("minor",0))
						minarr[2] = int(minimum.get("bugfix",0))
						maxVer = minarr
			var additional = ""
			if minVer != null:
				additional = "min ver %d.%d.%d" % [minVer[0],minVer[1],minVer[2]]
			if maxVer:
				if additional:
					additional += " through "
				additional += "max ver %d.%d.%d" % [maxVer[0],maxVer[1],maxVer[2]]
			if additional:
				rn += " (%s)" % additional
			if rn:
				mname = rn
	return mname

var update_store = "user://cache/.Mod_Menu_2_Cache/updates/needs_updates.json"
var dependancies_store = "user://cache/.Mod_Menu_2_Cache/dependancies/dependancies.json"
var conflicts_store = "user://cache/.Mod_Menu_2_Cache/conflicts/conflicts.json"
var complementary_store = "user://cache/.Mod_Menu_2_Cache/complementary/complementary.json"

var children = {}
func _ready():
	
	if "children" in MOD_INFO.keys():
		children = MOD_INFO["children"]
	
	for i in children:
		var pdata = children[i]
		var panel = SubModBox.instance()
		var pname = pdata["name"]
		var iconTexture = null
		if pdata["mod_icon"]["has_icon_file"]:
			var icon_filepath = pdata["mod_icon"]["icon_path"]
			if icon_filepath.ends_with(".stex"):
				var tex = StreamTexture.new()
				tex.load_path = icon_filepath
				iconTexture = tex
			elif icon_filepath.ends_with(".png"):
				iconTexture = pointers.FileAccess.__load_png(icon_filepath)
		else:
			var tex = StreamTexture.new()
			tex.load_path = "res://HevLib/ui/themes/icons/missing_icon.png.stex"
			iconTexture = tex
		panel.get_node("ModButton/VBoxContainer/HBoxContainer/LABELS/NAME").text = translateIfCan(pname)
		if pdata["manifest"]["has_manifest"]:
			panel.get_node("ModButton/VBoxContainer/HBoxContainer/LABELS/BRIEF").text = translateIfCan(pdata["manifest"]["manifest_data"]["mod_information"]["brief"])
		else:
			panel.get_node("ModButton/VBoxContainer/HBoxContainer/LABELS/BRIEF").text = ""
		panel.name = pname
		panel.visible = false
		add_child(panel)
#		breakpoint
	


var ID = null


func _draw():
	MAX_SIZE = Vector2(get_parent().rect_size.x,130) - Vector2(4,0)
	
	button_lib_icon.visible = false
	button_children_icon.visible = false
	icon_complementary.visible = false
	icon_conflicts.visible = false
	icon_dependancies.visible = false
	icon_updates.visible = false
	
	mod_path = MOD_INFO["file_path"]
	is_modlet = MOD_INFO["mod_type"] == "modlet"
	file.open(modlet_toggle_restart_path,File.READ)
	var restarting_modlets = JSON.parse(file.get_as_text()).result
	file.close()
	if mod_path in restarting_modlets:
		needs_restart_from_toggling = true
	
	file.open(update_store,File.READ)
	var updt = JSON.parse(file.get_as_text()).result
	file.close()
	file.open(conflicts_store,File.READ)
	var conf = JSON.parse(file.get_as_text()).result
	file.close()
	file.open(dependancies_store,File.READ)
	var dep = JSON.parse(file.get_as_text()).result
	file.close()
	file.open(complementary_store,File.READ)
	var comp = JSON.parse(file.get_as_text()).result
	file.close()
	
	
	if ID in updt:
		icon_updates.visible = true
		icon_updates.hint_tooltip = translateIfCan("HEVLIB_ICON_TOOLTIP_UPDATES") % [str(updt[ID]["version"][0])+"."+str(updt[ID]["version"][1])+"."+str(updt[ID]["version"][2]),str(updt[ID]["new_version"][0])+"."+str(updt[ID]["new_version"][1])+"."+str(updt[ID]["new_version"][2])]
	else:
		icon_updates.visible = false
	if ID in conf:
		icon_conflicts.visible = true
		var cd = ""
		for i in conf[ID]:
			var mname = get_mod_data(i)
			cd = cd + "\n" + mname
		icon_conflicts.hint_tooltip = translateIfCan("HEVLIB_ICON_TOOLTIP_CONFLICT") % cd
	else:
		icon_conflicts.visible = false
	if ID in dep:
		icon_dependancies.visible = true
		var cd = ""
		for i in dep[ID]:
			var mname = get_mod_data(i)
			cd = cd + "\n" + mname
		icon_dependancies.hint_tooltip = translateIfCan("HEVLIB_ICON_TOOLTIP_DEPENDANCIES") % cd
	else:
		icon_dependancies.visible = false
	if ID in comp:
		icon_complementary.visible = true
		var cd = ""
		for i in comp[ID]:
			var mname = pointers.ManifestV2.__get_mod_by_id(i)["name"]
			cd = cd + "\n" + mname
		icon_complementary.hint_tooltip = translateIfCan("HEVLIB_ICON_TOOLTIP_COMPLEMENTARY") % cd
	else:
		icon_complementary.visible = false
	
	
	button_box.rect_size.x = button.rect_size.x - 4
	button_box.rect_size.y = 94
	
	var disabled_text : String = ""
	var is_disabled := false
	if is_modlet:
		if not MOD_INFO["enabled"]:
			is_disabled = true
			if needs_restart_from_toggling:
				disabled_text = translateIfCan("HEVLIB_MODMENU_MODNAME_DISABLED_NEEDS_RESTART") + " "
			else:
				disabled_text = translateIfCan("HEVLIB_MODMENU_MODNAME_DISABLED") + " "
		elif needs_restart_from_toggling:
			disabled_text = translateIfCan("HEVLIB_MODMENU_MODNAME_ENABLED_NEEDS_RESTART") + " "
	
	var mod_name = disabled_text + translateIfCan(MOD_INFO["name"])
	var prio = MOD_INFO["priority"]
	if str(prio).ends_with("INF"):
		if str(prio).begins_with("-"):
			prio = "-INF"
		else:
			prio = "INF"
	var version_arr = MOD_INFO["version_data"]["full_version_array"]
	var version_print = MOD_INFO["version_data"]["full_version_string"]
	var iconTexture = null
	if MOD_INFO["mod_icon"]["has_icon_file"]:
		var icon_filepath = MOD_INFO["mod_icon"]["icon_path"]
		if icon_filepath.ends_with(".stex"):
			var tex = StreamTexture.new()
			tex.load_path = icon_filepath
			iconTexture = tex
		elif icon_filepath.ends_with(".png"):
			iconTexture = pointers.FileAccess.__load_png(icon_filepath)
	else:
		var tex = StreamTexture.new()
		tex.load_path = "res://HevLib/ui/themes/icons/missing_icon.png.stex"
		iconTexture = tex
	var is_library = MOD_INFO["library_information"]["is_library"]
	var always_display = false
	if is_library:
		always_display = MOD_INFO["library_information"]["always_display"]
	var manifest = MOD_INFO["manifest"]
	if is_library:
		button_lib_icon.visible = true
	button_label.text = translateIfCan(mod_name)
	if is_disabled:
		get_child(0).modulate = Color(0.5,0.5,0.5,1)
	else:
		get_child(0).modulate = Color(1,1,1,1)
	icon_node.texture = iconTexture
	var tooltip_text = translateIfCan("HEVLIB_MM_TOOLTIP_HEADER")

	var md = manifest["manifest_data"]
	if md:
		ID = md["mod_information"]["id"]
		
	tooltip_text = tooltip_text + "\n" + translateIfCan("HEVLIB_MM_TOOLTIP_MV") % manifest["manifest_version"]
	if ID:
		tooltip_text = tooltip_text + "\n" + translateIfCan("HEVLIB_MM_TOOLTIP_ID") % ID
		if ID == "kodera.vanilla":
			var tex = StreamTexture.new()
			tex.load_path = "res://HevLib/ui/mod_menu/vanilla/kodera.stex"
			button_lib_icon.texture = tex
			button_lib_icon.modulate = Color(1,1,1,1)
			button_lib_icon.visible = true
	var zip = MOD_INFO["zip"]
	if zip:
		tooltip_text = tooltip_text + "\n" + translateIfCan("HEVLIB_MM_TOOLTIP_ZIP") % zip
	
	var manifestData = MOD_INFO["manifest"]["manifest_data"]
	var brief = ""
	if manifestData:
		brief = translateIfCan(manifestData["mod_information"]["brief"])
	button_brief.text = brief
	
	
	
	var showHidden = pointers.ConfigDriver.__get_value("HevLib","HEVLIB_CONFIG_SECTION_DRIVERS","show_hidden_libraries")
	if is_library:
		if showHidden or always_display:
			visible = true
		else:
			visible = false
	if is_library:
		tooltip_text += ("\n" + translateIfCan("HEVLIB_MM_TOOLTIP_LIBRARY") % [is_library,always_display])
	
	
	button.hint_tooltip = tooltip_text
	
	if is_visible_in_tree():
		var pos = get_position_in_parent()
		if pos == 0:
			button.grab_focus()
	
	if children:
		button_children_icon.visible = true
		button_children_count.visible = true
		button_children_count.text = "%s" % children.size()
		
		handle_sub_mods()
	
	
var descbox = "../ModInfo/DESC"
func _input(event):
	if Input.is_action_just_pressed("ui_focus_next") or Input.is_action_just_pressed("ui_focus_prev"):
		var foc = get_focus_owner()
		var select = ModContainer.get_node(descbox)
		if foc == button:
			select.grab_focus()
			get_viewport().set_input_as_handled()

onready var desc_box = ModContainer.get_node(descbox)

func get_button(pos):
	return get_parent().get_child(pos).get_node("BaseModBox/ModButton")

func _refocus():
	MAX_SIZE = Vector2(get_parent().rect_size.x,130) - Vector2(4,0)
	button_box.rect_size.x = button.rect_size.x - 4
	button_box.rect_size.y = 94
	var index = get_parent().get_position_in_parent()
	var parent = get_parent()
	var parent_count = parent.get_child_count()-1
	focus_button_neighbours(false)
	yield(CurrentGame.get_tree(),"idle_frame")
	if is_visible_in_tree():
		update()

func focus_button_neighbours(on_press : bool):
	var mb = button.get_path_to(button)
	button.focus_neighbour_left = mb
	button.focus_neighbour_right = button.get_path_to(desc_box)
	button.focus_next = button.get_path_to(desc_box)
	button.focus_previous = button.get_path_to(desc_box)
	
	
	var pos = get_position_in_parent()
	var end_pos = get_parent().get_node("HEVLIB_NODE_SEPARATOR_IGNORE_PLS").get_position_in_parent()
	if submod_visibility:
		if pos == 0:
			button.focus_neighbour_top = button.get_path_to(filter_button)
			button.focus_neighbour_bottom = button.get_path_to(get_child(1).get_node("ModButton"))
			get_button(pos+1).focus_neighbour_top = get_button(pos+1).get_path_to(get_child(get_child_count() - 1).get_node("ModButton"))
		elif pos + 1 == end_pos:
			button.focus_neighbour_top = button.get_path_to(get_button(pos-1))
			button.focus_neighbour_bottom = button.get_path_to(get_child(1).get_node("ModButton"))
			get_node(openMods_button).focus_neighbour_top = get_node(openMods_button).get_path_to(get_child(get_child_count() - 1).get_node("ModButton"))
		else:
			button.focus_neighbour_top = button.get_path_to(get_button(pos-1))
			button.focus_neighbour_bottom = button.get_path_to(get_child(1).get_node("ModButton"))
			get_button(pos+1).focus_neighbour_top = get_button(pos+1).get_path_to(get_child(get_child_count() - 1).get_node("ModButton"))
	else:
		if pos == 0:
			button.focus_neighbour_top = button.get_path_to(filter_button)
			button.focus_neighbour_bottom = button.get_path_to(get_button(pos+1))
			get_button(pos+1).focus_neighbour_top = get_button(pos+1).get_path_to(button)
		elif pos + 1 == end_pos:
			button.focus_neighbour_top = button.get_path_to(get_button(pos-1))
			button.focus_neighbour_bottom = button.get_path_to(get_node(openMods_button))
			get_node(openMods_button).focus_neighbour_top = get_node(openMods_button).get_path_to(button)
		else:
			button.focus_neighbour_top = button.get_path_to(get_button(pos-1))
			button.focus_neighbour_bottom = button.get_path_to(get_button(pos+1))
			get_button(pos+1).focus_neighbour_top = get_button(pos+1).get_path_to(button)
	
	
	if on_press:
		if has_links:
			information_nodes["info_desc"].focus_neighbour_top = NodePath("../LINKBOX/LINKS")
		elif has_bugreports:
			information_nodes["info_desc"].focus_neighbour_top = NodePath("../LINKBOX/BUGREPORTS")
		elif is_modlet:
			information_nodes["info_desc"].focus_neighbour_top = NodePath("../Header/MODLET_TOGGLE/TOGGLE_MODLET")
		elif has_settings:
			information_nodes["info_desc"].focus_neighbour_top = NodePath("../Header/SETTINGS/SETTINGS")
		else:
			information_nodes["info_desc"].focus_neighbour_top = NodePath("../../SPLIT/ListHeader/OptionButtonBox/DOWNLOAD")
		if has_update:
			information_nodes["info_desc"].focus_neighbour_top = NodePath("../WarningButtons/UB")
		elif has_dep:
			information_nodes["info_desc"].focus_neighbour_top = NodePath("../WarningButtons/DB")
		elif has_conf:
			information_nodes["info_desc"].focus_neighbour_top = NodePath("../WarningButtons/CFB")
		if has_settings:
			if is_modlet:
				information_nodes["info_settings_button"].focus_neighbour_left = NodePath("../../MODLET_TOGGLE/TOGGLE_MODLET")
				information_nodes["info_settings_button"].focus_previous = NodePath("../../MODLET_TOGGLE/TOGGLE_MODLET")
			else:
				information_nodes["info_settings_button"].focus_neighbour_left = NodePath("../../../../SPLIT/ListHeader/OptionButtonBox/DOWNLOAD")
				information_nodes["info_settings_button"].focus_previous = NodePath("../../../../SPLIT/ListHeader/OptionButtonBox/DOWNLOAD")


var isfocus = false


var filter_button_path = "../../../../ListHeader/OptionButtonBox/FILTER"
onready var filter_button = get_node(filter_button_path)
var openMods_button = "../../../../../../FooterButtons/OpenFolder"

var mod_menu_panel_path = "../../../../../../../../.."
onready var mod_menu_panel = get_node(mod_menu_panel_path)

var filterContainerPath = mod_menu_panel_path + "/FilterPopup/base/FilterContainer"
onready var filter_container = get_node(filterContainerPath)

var cache_folder = "user://cache/.Mod_Menu_2_Cache/"
var filter_cache_file = "menu_filter_cache.json"

func _process(_delta):
	handle_sub_mods()
	if mod_menu_panel and mod_menu_panel.visible:
		var manifestData = MOD_INFO["manifest"]["manifest_data"]
		var check_against = MOD_INFO["name"].to_upper()
		var id_against = ""
		if manifestData:
			id_against = manifestData["mod_information"]["id"].to_upper()
		var current_selection = filter_button.keys_pressed
		
		if all_tags:
			file.open(cache_folder + filter_cache_file,File.READ)
			var filter_data = JSON.parse(file.get_as_text()).result
			file.close()
			if filter_data.size() >= 1:
				var tag_visible = false
				for tag in all_tags:
					if not tag in filter_data:
						var tag_mods = all_tags[tag]
						for md in tag_mods:
							if md.to_upper() == id_against:
								tag_visible = true
				visible = tag_visible
			else:
				visible = true
			if visible:
				if current_selection and current_selection != "":
					var i = check_against.countn(current_selection)
					var f = id_against.countn(current_selection)
					if i or f:
						visible = true
					else:
						visible = false
				else:
					visible = true
	var btnResize = Vector2($BaseModBox.rect_size.x - $BaseModBox/ModButton.rect_position.x,$BaseModBox.rect_size.y)
	$BaseModBox/ModButton.rect_size = btnResize
	button_box.rect_size.x = button.rect_size.x - 4
	button_box.rect_size.y = 94

func _visibility_changed():
	MAX_SIZE = Vector2(get_parent().rect_size.x,130) - Vector2(4,0)
	button_box.rect_size.x = button.rect_size.x - 4
	button_box.rect_size.y = 94
	_refocus()
	handle_sub_mods()
#	button.focus_neighbor_top = get_path_to(upper)
#	button.focus_neighbor_bottom = get_path_to(lower)
	if is_visible_in_tree():
		if get_position_in_parent() == 0:
			
			button.grab_focus()

func handle_sub_mods():
	var panels = get_child_count()
	if panels >= 2:
		for i in range(1,panels):
			var panel = get_child(i)
			if panel.visible:
#				panel.rect_pivot_offset = Vector2(panel.rect_size.x / 2,panel.rect_size.y / 2)
#				panel.rect_scale = Vector2(0.5,0.5)
#				if i == panels - 1:
#					panel.get_node("Label/Line2D").points.size(3)
				
				panel.get_node("ModButton/VBoxContainer").rect_size.x = panel.get_node("ModButton").rect_size.x - 4
#				breakpoint
	
var all_tags = pointers.ManifestV2.__get_tags()

func yield_button_focus():
	yield(CurrentGame.get_tree(),"idle_frame")
	button.grab_focus()

var modTranslations = {}
var fetchedModTranslations = false

var tlCache = {}
func translateIfCan(translation : String):
	if translation:
		if translation in tlCache:
			return tlCache[translation]
		else:
			var newTL = TranslationServer.translate(translation)
			if newTL == translation:
				var current_locale = Settings.cfg.locale.language
				var master_locale = MOD_INFO["master_locale"]
				if not fetchedModTranslations:
					if "REPLACE_TRANSLATIONS.gd" in MOD_INFO["drivers"]:
						modTranslations = MOD_INFO["drivers"]["REPLACE_TRANSLATIONS.gd"].get("TRANSLATIONS",{})
					fetchedModTranslations = true
				if current_locale in modTranslations:
					var tlData = modTranslations[current_locale]
					if translation in tlData:
						var rt = tlData[translation]
						match typeof(rt):
							TYPE_DICTIONARY:
								newTL = rt.get("string",newTL)
							TYPE_STRING:
								newTL = rt
				if current_locale != master_locale and master_locale in modTranslations:
					var tlData = modTranslations[master_locale]
					if translation in tlData:
						var rt = tlData[translation]
						match typeof(rt):
							TYPE_DICTIONARY:
								newTL = rt.get("string",newTL)
							TYPE_STRING:
								newTL = rt
			tlCache[translation] = newTL
			return newTL
	return ""
