# [license]
# 3-Clause BSD NON-AI License
# 
# Copyright 2026 __hev (Benjamin Buckhurst)
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

tool
extends HBoxContainer

export (bool) var emit_update_signal = false

signal changed()

var Xvalue:float = 0.0
var Yvalue:float = 0.0
var Zvalue:float = 0.0

func get_property_value():
	_X_text_changed($XBOX/X.text)
	_Y_text_changed($YBOX/X.text)
	_Z_text_changed($ZBOX/X.text)
	return [Vector3(Xvalue,Yvalue,Zvalue),"Vector3( %s , %s , %s )" % [str(Xvalue),str(Yvalue),str(Zvalue)]]

func set_property_value(property):
	if property is Vector3:
		var xb = $XBOX/X
		var yb = $YBOX/X
		var zb = $ZBOX/X
		xb.text = str(property.x)
		yb.text = str(property.y)
		zb.text = str(property.z)

func _ready():
	if not $XBOX/X.is_connected("text_entered",self,"_X_text_changed"):
		$XBOX/X.connect("text_entered",self,"_X_text_changed")
	if not $XBOX/X.is_connected("focus_exited",self,"_X_lost_focus"):
		$XBOX/X.connect("focus_exited",self,"_X_lost_focus")
	if not $YBOX/X.is_connected("text_entered",self,"_Y_text_changed"):
		$YBOX/X.connect("text_entered",self,"_Y_text_changed")
	if not $YBOX/X.is_connected("focus_exited",self,"_Y_lost_focus"):
		$YBOX/X.connect("focus_exited",self,"_Y_lost_focus")
	if not $ZBOX/X.is_connected("text_entered",self,"_Z_text_changed"):
		$ZBOX/X.connect("text_entered",self,"_Z_text_changed")
	if not $ZBOX/X.is_connected("focus_exited",self,"_Z_lost_focus"):
		$ZBOX/X.connect("focus_exited",self,"_Z_lost_focus")

var last_x = 0.0
func _X_text_changed(text:String):
	var ft = float(text)
	if ft != last_x:
		last_x = ft
		$XBOX/X.text = str(ft)
		Xvalue = ft
		_on_changed()

func _X_lost_focus():
	var txt = $XBOX/X.text
	_X_text_changed(txt)

var last_y = 0.0
func _Y_text_changed(text:String):
	var ft = float(text)
	if ft != last_y:
		last_y = ft
		$YBOX/X.text = str(ft)
		Yvalue = ft
		_on_changed()

func _Y_lost_focus():
	var txt = $YBOX/X.text
	_Y_text_changed(txt)

var last_z = 0.0
func _Z_text_changed(text:String):
	var ft = float(text)
	if ft != last_z:
		last_z = ft
		$ZBOX/X.text = str(ft)
		Zvalue = ft
		_on_changed()

func _Z_lost_focus():
	var txt = $ZBOX/X.text
	_Z_text_changed(txt)

func _on_changed():
	if emit_update_signal:
		emit_signal("changed")
