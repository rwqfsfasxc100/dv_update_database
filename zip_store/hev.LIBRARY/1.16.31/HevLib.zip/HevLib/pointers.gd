# [license]
# 3-Clause BSD NON-AI License
# 
# Copyright 2026 __hev (Benjamin Buckhurst)
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

extends Node
class_name HevLibPointers

var http:HTTPRequest = HTTPRequest.new()

var equipment_modmain:Node
var webtranslate_modmain:Node

var Achievements : _Achievements = _Achievements.new(self,http)
var ConfigDriver : _ConfigDriver = _ConfigDriver.new(self)
var FileAccess : _FileAccess = _FileAccess.new(self)
var DataFormat : _DataFormat = _DataFormat.new(self)
var DriverManagement : _DriverManagement = _DriverManagement.new(self)
var Equipment : _Equipment = _Equipment.new(self)
var Events : _Events = _Events.new(self)
var FolderAccess : _FolderAccess = _FolderAccess.new(self)
var Github : _Github = _Github.new(self)
var HevLib : _HevLib = _HevLib.new(self)
var Keymapping : _Keymapping = _Keymapping.new(self)
var ManifestV1 : _ManifestV1 = _ManifestV1.new(self)
var ManifestV2 : _ManifestV2 = _ManifestV2.new(self)
var Math : _Math = _Math.new(self)
var NodeAccess : _NodeAccess = _NodeAccess.new(self)
var RingInfo : _RingInfo = _RingInfo.new(self)
var RPC : _RPC = _RPC.new(self)
var SafeMode : _SafeMode = _SafeMode.new(self)
var Scripting : _Scripting = _Scripting.new(self,http)
var TimeAccess : _TimeAccess = _TimeAccess.new(self)
var Translations : _Translations = _Translations.new(self)
var WebTranslate : _WebTranslate = _WebTranslate.new(self)
var Zip : _Zip = _Zip.new(self)

var Classes = {
	"Achievements":Achievements,
	"ConfigDriver":ConfigDriver,
	"DataFormat":DataFormat,
	"DriverManagement":DriverManagement,
	"Equipment":Equipment,
	"Events":Events,
	"FileAccess":FileAccess,
	"FolderAccess":FolderAccess,
	"Github":Github,
	"HevLib":HevLib,
	"Keymapping":Keymapping,
	"ManifestV1":ManifestV1,
	"ManifestV2":ManifestV2,
	"Math":Math,
	"NodeAccess":NodeAccess,
	"RingInfo":RingInfo,
	"RPC":RPC,
	"TimeAccess":TimeAccess,
	"Translations":Translations,
	"WebTranslate":WebTranslate,
	"Zip":Zip,
}


var copyrights:String = "© 2024-2026 Benjamin Buckhurst a.k.a. __hev. All rights reserved."

const HEVLIB_CACHE_VERSION : int = 6

var logging_frame_interval:float = 0
var logging_current_frame_timer:int = 0

var pause_on_unfocus:bool = false

func _physics_process(delta:float):
	if ConfigDriver.mk_c:
		# If a config was changed in the loaded profile, handle
		# it and make sure connections get the updated values
		ConfigDriver.handle_change_made()
	logging_current_frame_timer += 1
	if logging_frame_interval and logging_current_frame_timer > logging_frame_interval:
		# Handle storing logs to file.
		# This won't run until the interval is fetched after being onready
		logging_current_frame_timer = 0
		storeLogCache()
		VisualServer.render_loop_enabled = (not pause_on_unfocus or OS.is_window_focused())

func recheck_unfocused_unrendering(how:bool):
	pause_on_unfocus = how

var dir:Directory = Directory.new()
var file:File = File.new()
func _ready():
	# Ensure the log directory exists, and create it if it doesn't
	if not dir.dir_exists(deviceinfostore):
		dir.make_dir_recursive(deviceinfostore)
	# Set the logging interval
	logging_frame_interval = ConfigDriver.__get_value("HevLib","HEVLIB_CONFIG_SECTION_DEBUG","pointer_logging_frame_interval")
	# Initialize Configs, Achievements, & RPC
	ConfigDriver.ready()
	Achievements.ready()
	RPC.ready()
	# Declutter webtranslate's children.
	# This is necessary considering it creates a lot of mess as it fetches data
	if ConfigDriver.__get_value("HevLib","HEVLIB_CONFIG_SECTION_DRIVERS","safe_mod_loading"):
		ConfigDriver.non_static[""].declutter_webtranslate_scraps(webtranslate_modmain)
	yield(get_tree(),"idle_frame")
	# Ensures that this node is lower in the scene tree
	get_parent().move_child(self,get_parent().get_child_count())
	# This node cannot be paused
	pause_mode = Node.PAUSE_MODE_PROCESS
	# Setup pausing on lost focus
	pause_on_unfocus = ConfigDriver.__get_value("HevLib","HEVLIB_CONFIG_SECTION_DRIVERS","stop_rendering_on_lost_focus")
	ConfigDriver.__subscribe_to_setting_change("recheck_unfocused_unrendering",self,"HevLib","HEVLIB_CONFIG_SECTION_DRIVERS","stop_rendering_on_lost_focus")
	if TranslationServer.translate("HEVLIB_INCORRECT_SHIP") == "HEVLIB_INCORRECT_SHIP":
		l("HevLib translations did not get initialized, quitting and ensuring the user is aware.","pointers.Translations")
		Translations.__updateTL_from_dictionary(load("HEVLIB_MENU/REPLACE_TRANSLATIONS.gd").get_script().get_script_constant_map().get("TRANSLATIONS",{}))
		NodeAccess.__exit(false,TranslationServer.translate("HEVLIB_ERRORCHECK_MISSING_TRANSLATIONS"),"pointers.Translations",0.0,"https://forms.gle/RmC4Zgonp6frFgnK7",true)
	if TranslationServer.translate("SYSTEM_AMMO_10000_DESC") == "SYSTEM_AMMO_10000_DESC":
		l("Vanilla translations did not get initialized, queued exit for 200 seconds to preserve report-ready state.","pointers.Translations")
		NodeAccess.__exit(false,TranslationServer.translate("HEVLIB_ERRORCHECK_MISSING_VANILLA_LOCALES"),"pointers.Translations",200)
var is_editor_and_needs_restart:bool = false
signal updates_fetched
func fetch_mod_updates():
	var rHTTP:HTTPRequest=HTTPRequest.new()
	rHTTP.timeout=20
	add_child(rHTTP)
	rHTTP.request(updateDB_url)
	var rba:Array = yield(rHTTP,"request_completed")
	if rba[0]==0&&rba[1]==200:
		var p:Dictionary=JSON.parse(rba[3].get_string_from_utf8()).result
		var ids:PoolStringArray=ManifestV2.__get_mod_ids()
		var updates:Dictionary={}
		for ID in p:if ID in ids:
			var fetchData:Dictionary=p[ID]
			var modData:Dictionary=ManifestV2.__get_mod_by_id(ID)
			var current_version:Dictionary=modData["version_data"]
			var doUpdate:bool=false
			var newVer:Array=[fetchData["major"],fetchData["minor"],fetchData["bugfix"]]
			var ctr:int=0
			while(!doUpdate)and(ctr<3):
				match ctr:
					0:
						if newVer[0]>current_version["version_major"]:doUpdate=true
						elif newVer[0]<current_version["version_major"]:ctr=5
					1:
						if newVer[1]>current_version["version_minor"]:doUpdate=true
						elif newVer[1]<current_version["version_minor"]:ctr=5
					2:
						if newVer[2]>current_version["version_bugfix"]:doUpdate=true
						elif newVer[2]<current_version["version_bugfix"]:ctr=5
				ctr+=1
			if doUpdate:
				var file_name:String=fetchData.get("file_name","file.zip")
				var mod_name:String=modData.get("name","")
				updates[ID]={"name":mod_name,"id":ID,"version":[current_version["version_major"],current_version["version_minor"],current_version["version_bugfix"]],"new_version":newVer,"github":"https://github.com/rwqfsfasxc100/dv_update_database/raw/refs/heads/main/zip_store/%s/%d.%d.%d/%s"%[ID,newVer[0],newVer[1],newVer[2],file_name],"file_name":file_name,"display":mod_name+"("+ID+")"}
		var dont:bool=false
		if libid in p:
			var curr:Dictionary=ManifestV2.__get_mod_by_id(libid)["version_data"]
			var major:int=p[libid].major
			var minor:int=p[libid].minor
			var bugfix:int=p[libid].bugfix
			var cm:int=curr.version_major
			var cn:int=curr.version_minor
			var cb:int=curr.version_bugfix
			if major>cm:
				if minor>0:dont=true
				elif bugfix>5:dont=true
			elif minor>cn:if bugfix>cb+4:dont=true
			elif bugfix>cb+10:dont=true
		if dont:
			DataFormat.__exit(false,"cannot collect version specific data. Is HevLib out of date?","pointers.SafeMode",60.0)
		file.open(update_store,File.WRITE)
		file.store_string(JSON.print(updates))
		file.close()
		emit_signal("updates_fetched")
		if!is_editor||ConfigDriver.__get_value("HevLib","HEVLIB_CONFIG_SECTION_DEBUG","always_send_new_mods"):
			var md:Dictionary=ManifestV2.__get_mod_data()
			for mod in ManifestV2.__get_mod_list_keys():
				var mid:String = ManifestV2.__match_mod_file_path_to_id(mod)
				if mid:
					var mod_data:Dictionary=md[mod]
					var manifest:Dictionary=mod_data["manifest"]["manifest_data"]
					if mid&&!mid in p:
						var mURL:String=""
						var gURL:String=""
						if"manifest_definitions"in manifest:
							mURL=manifest["manifest_definitions"].get("manifest_url","")
						if"links"in manifest:
							if"HEVLIB_GITHUB"in manifest["links"]:
								gURL=manifest["links"]["HEVLIB_GITHUB"].get("URL","")
						if mURL&&gURL:
							var payload:String=JSON.print({
								"event_type":"add_mod_entry",
								"client_payload":{
									"data":JSON.print({
										"id":mid,
										"manifest_url":mURL,
										"github_url":gURL
									})
								}
							})
							var tHTTP:HTTPRequest=HTTPRequest.new()
							add_child(tHTTP)
							tHTTP.request(api_url,[],true,HTTPClient.METHOD_POST,payload)
							yield(get_tree().create_timer(300),"timeout")
							Tool.deferCallInPhysics(Tool,"remove",[tHTTP])
	Tool.deferCallInPhysics(Tool,"remove",[rHTTP])

const api_url:String="https://publicactiontrigger.azurewebsites.net/api/dispatches/rwqfsfasxc100/dv_update_database"
const updateDB_url:String="https://raw.githubusercontent.com/rwqfsfasxc100/dv_update_database/refs/heads/main/manifest_path_store.json"
const update_store:String="user://cache/.Mod_Menu_2_Cache/updates/needs_updates.json"
const libid:String="hev.LIBRARY"

var is_editor:bool = OS.has_feature("editor")

const SUPPORTED_IMAGE_EXTENSIONS = PoolStringArray(["png","stex","jpg","jpeg","bmp","webp"])

var resource_path:String = ""
func _init(r,e):
	name = "HevLib~Pointers"
	resource_path = r
	equipment_modmain = e
	dir.make_dir_recursive(deviceinfostore)

# Logging function used for cases where critial info must not be overwritten by game logs
# cycling back to dv_log_0 (and yes this is from a specific bug report with AI slop code,
# you didn't ask for permission to use any of my code in an LLM so fuck you)
var logCache:String = ""
var messageNr:int = 0
const messagesPerFile:float = 1000.0
func l(msg:String, title:String = ""):
	Debug.l(("[%s]: %s" % [title, msg]) if title else msg)
	if logCache:
		logCache += "[%s]: %s\n" % [("%s %s" % [Debug.timeString(),title]) if title else Debug.timeString(),msg]
	else:
		logCache = "[%s]: %s\n" % [("%s %s" % [Debug.timeString(),title]) if title else Debug.timeString(),msg]

# Notetaking function used to mark an important event in the game's performance logs
func n(msg:String, title:String = ""):
	Debug.n(("[%s]: %s" % [title, msg]) if title else msg)
	if logCache:
		logCache += "[%s]: %s\n" % [("%s %s" % [Debug.timeString(),title]) if title else Debug.timeString(),msg]
	else:
		logCache = "[%s]: %s\n" % [("%s %s" % [Debug.timeString(),title]) if title else Debug.timeString(),msg]

const deviceinfostore:String = "user://cache/.HevLib_Cache/logs/"
const deviceinfocache:String = deviceinfostore + "pointer_logs_%d.txt"
var currentFileName:String = ""
const testmode = false
# Method for storing stored logs to file
# This isn't done by the logger to help reduce write operations.
# Useful if you perform the log operation multiple times in succession
func storeLogCache():
	if logCache:
		messageNr += 1
		var logFileName:String = deviceinfocache % int(messageNr / messagesPerFile)
		if currentFileName != logFileName:
			currentFileName = logFileName
			file.open(currentFileName,File.WRITE)
			file.store_string("")
			file.close()
		file.open(currentFileName, File.READ_WRITE)
		file.seek_end()
		file.store_string(logCache)
		file.close()
		logCache = ""

class _Achievements:
	var scripts : Array = [
		
	]
	
	static func get_class_documentation() -> Dictionary:
		return {
			"description":"Helper functions to fetch achievement and stat data",
			"methods":{
				"__get_achievement_data":{
					"description":"Fetches information regarding a specific achievement",
					"args":[
						"achievementID -> (String) achievement ID to fetch the data of."
					],
					"return":[
						"Dictionary with the following formatting:",
						" name (String) -> the achievement name. Identical to the achievementID arg.",
						" isUnlocked (bool) -> whether the achievement is registered as unlocked.",
						" stat (String/null) -> if the achievement has a respective stat. Will be null if it does not.",
						" limit (int/float/null) -> if the achievement has a stat, will be the required value of the stat for the achievement to be earned. Will be null if it doesn't have a stat",
						" data (Array/null) -> if the achievement has additional information, will be provided through an array. currently only used by playtime achievements to list the required ships/equipment to earn the achievement, and if not will be null",
						" rare (bool) -> whether the achievement is considered to be rare by the game",
						" spoiler (bool) -> whether the achievement is spoilered on Steam",
					],
				},
				"__get_stat_data":{
					"description":"Fetches information regarding a specific stat.",
					"args":[
						"STAT (String) -> The stat to fetch. If it does not start with 'stat:', it will be added to make sure that it can be fetched."
					],
					"return":[
						"Integer or float for the value of the stat"
					]
				},
				"__get_achievement_percentage":{
					"description":"Provides your current achievement completion percentage",
					"return":[
						"Float for the completion percentage out of 100"
					]
				},
				"__get_current_achievements":{
					"description":"Provides a dictionary containing all achievement and stat data",
					"return":[
						"Dictionary containing all achievement-adjacent information",
						" allAchievements (Array) -> the names of all achievements currently registered by the game",
						" unlockedAchievements (Array) -> the names of all currently achieved achievements",
						" lockedAchievements (Array) -> the names of all locked achievements",
						" stats (Array) -> the names of all stats currently with earned values. Not all stats may be registered",
					]
				},
				"__get_steam_achievement_percentages":{
					"description":"Provides a dictionary containing every achievement with the Steam unlock percentage as it's key",
					"return":[
						"Dictionary containing every achievement with the Steam unlock percentage as it's key"
					]
				},
			}
		}
	
	const achievementsFile : String = "user://achievements.dv"
	const password : String = "b0ngadabonga"
	var http:HTTPRequest
	
	var pointers:HevLibPointers
	
	const non_statics:Dictionary = {}
	
	func _init(p,h):
		non_statics["pointers"] = p
		non_statics["http"] = h
		http = h
		pointers = p
		h.timeout = 20
		p.add_child(h)
	
	
	func ready():
		get_current_achievements()
		requestSteamStats()
	
	var steam_node = null
	var steam_singleton = null
	# These achievements aren't marked as needing stats in the achievement file, but need them anyway
	const annoyingAsFuckAchievements : Dictionary = {
		"DIVER_10":10,
		"DIVER_50":50,
		"DIVER_ENCKE":3000,
		"DIVER_DRAGONS":3005,
		"LEAF_2":2000,
		"LEAF_5":5000,
		"LEAF_20":20000,
		"PLAYSTYLE_MANUAL":900
	}
	const spoiler_achievements : Array = [
		# The following URL is to a profile with little enough playtime to provide a good idea of spoilered achievements: https://steamcommunity.com/profiles/76561198067601574/stats/846030/?tab=achievements
		# This is ordered in SteamDB order, to help with double checking
		"DISCOVER_MOONLET",
		"DISCOVER_PHAGE",
		"DISCOVER_URANIUM",
		"ESCAPE_VELOCITY",
		"DISCOVER_ANARCHY",
		"SHIP_CAT",
		"LEAF_20",
		"TOUCH_SINGULARITY",
		"DISCOVER_DESTROYED_HABITAT",
		"LEVEL_TOP",
		"STORY_TESLA",
		"DISCOVER_FROZEN_BODY",
		"STORY_G4A_DESTROYED",
		"STORY_BBW_DESTROYED",
		"PLAYSTYLE_B8BACK",
		"PLAYSTYLE_CRAZYIVAN",
		"STORY_LOTR_DESTROYED",
		"STORY_INFILTRATE"
	]
	
	
	const completionCache : Dictionary = {}
	const currentAchievementCache : Dictionary = {}
	const cached_playtime_ach_and_data : Array = []
	
	static func l(text:String,header:String = "pointers.Achievements"):
		non_statics["pointers"].l(text,header)
	
	# Fetches data from a specific achievement.
	static func __get_achievement_data(achievementID: String) -> Dictionary:
		var playtimeStats = Achivements.playtimeStats
		var playtimeAchievements = Achivements.playtimeAchievements
		var statsWithAchievements = Achivements.statsWithAchievements
		var storyAchievements = Achivements.storyAchievements
		
		var stat = null
		var limit = null
		var additional_stat_data = null
		
		# If the achievement is related to ship/equipment playtime,
		# define the associated stat and limit to reach for the achievement
		# and set the additional stat data part to the associated ship/equipment names
		for p in playtimeAchievements:
			if p[2] == achievementID:
				for o in playtimeStats:
					if p[0] == o[0]:
						stat = o[1]
						limit = p[1]
						additional_stat_data = p[0]
		
		# If the achievement isn't playtime, check to see if it's related to other stats
		# and define the stat and limit
		if not stat:
			for a in statsWithAchievements:
				var ps = statsWithAchievements[a]
				for s in ps:
					var ac = ps[s]
					if ac == achievementID:
						stat = a
						limit = s
		
		# If it's not a stat-based achievement, see if it's a story-related achievement and
		# set the additional stat data to the dictionary containing story names and limits
		if not stat:
			for a in storyAchievements:
				if a[1] == achievementID:
					additional_stat_data = a[0]
		
		# If it's not a defined stat-based achievement, see if it's a stat not defined in the 
		# achievements script and set the stat and limit appropriately
		if not stat:
			if achievementID in annoyingAsFuckAchievements:
				var prefix = achievementID.split("_")[0]
				limit = annoyingAsFuckAchievements[achievementID]
				match prefix:
					"DIVER":
						stat = "maxDepth"
					"LEAF":
						stat = "leaf"
					"PLAYSTYLE":
						stat = "manual"
		
		var returnData : Dictionary = {
			"name":achievementID, # achievement ID
			"isUnlocked":achievementID in currentAchievementCache.get("unlockedAchievements",[]), # if the achievement has been unlocked
			"stat":stat, # related stat if applicable
			"limit":limit, # related stat limit if applicable
			"data":additional_stat_data, # additional data
			"rare":Achivements.achievementRarity.get(achievementID,0) > 0, # if the game considers the achievement to be rare
			"spoiler":achievementID in spoiler_achievements # if the achievement is spoilered on Steam
		}
		return returnData
	
	# Fetches data about a stat
	static func __get_stat_data(STAT: String) -> float:
		if not STAT.begins_with("stat:"):
			STAT = "stat:" + STAT # Adds the stat: prefix if it's not provided by the input
		return Achivements.achivements.get(STAT,0.0) # Returns data on the stat, or 0.0 if nothing is stored
	
	# Fetches the completion percentage based on what's achieved within the achievement store file
	static func __get_achievement_percentage() -> float:
		var percent : float = 0.0
		var ach:Dictionary = Achivements.achievementRarity
		var size = float(Achivements.achievementRarity.size())
		var achivements : Dictionary = {}
		var file:File = File.new()
		if file.file_exists(achievementsFile):
			if file.open_encrypted_with_pass(achievementsFile, File.READ, password) == OK:
				var sg : String = file.get_line()
				achivements = parse_json(sg)
			else:l("Error loading achievements file")
		file.close()
		
		var count : float = 0.0
		
		for i in ach:
			if i in achivements and achivements[i]:
				count += 1
		
		if count:
			percent = count/size
		return percent * 100.0
	
	
	
	# Fetches the current cache for achievements
	static func __get_current_achievements() -> Dictionary:
		return currentAchievementCache
	
	# Fetches the current completion percentages fetched from Steam
	static func __get_steam_achievement_percentages() -> Dictionary:
		return completionCache
	
	# Caches achievement data
	static func get_current_achievements():
		var unlockedAchievements : Array = []
		var lockedAchievements : Array = []
		var allAchievements : Array = []
		var stats : Array = []
		var achievementData:Dictionary = Achivements.achivements
		var rarity:Dictionary = Achivements.achievementRarity
		for m in achievementData:
			# Separates stored data between achievements and stats
			if not str(m).begins_with("stat:"):
				unlockedAchievements.append(m)
			else:
				stats.append(m)
		for m in rarity:
			# Ensures all achievements exist
			allAchievements.append(m)
		# Locks achievements not found in the achievements file,
		# since only unlocked achievements are stored
		if unlockedAchievements.size() != allAchievements.size():
			for f in allAchievements:
				if not unlockedAchievements.has(f):
					lockedAchievements.append(f)
		currentAchievementCache["allAchievements"] = allAchievements
		currentAchievementCache["unlockedAchievements"] = unlockedAchievements
		currentAchievementCache["lockedAchievements"] = lockedAchievements
		currentAchievementCache["stats"] = stats
	
	# Gets the Steam singleton node
	func getSteamNode():
		steam_node = Achivements.get_node("AchievementSteam")
		steam_singleton = Engine.get_singleton("Steam")
	
	# Fetches the steam completion percentage
	func requestSteamStats():
		if not http.is_connected("request_completed",self,"out"):
			http.connect("request_completed",self,"out")
		http.request("https://api.steampowered.com/ISteamUserStats/GetGlobalAchievementPercentagesForApp/v0002/?gameid=846030")
		
		if Engine.has_singleton("Steam"):
			# If the game is running with Steam, get Steam singleton
			getSteamNode()
		
	
	# Handles all netdata for the achievement fetching
	func out(result, response_code, headers, body):
		if result == 0:
			var d:Dictionary = JSON.parse(body.get_string_from_utf8()).result
			if d:
				var data : Array = d.get("achievementpercentages").get("achievements")
				for dic in data:
					completionCache[dic.get("name")] = dic.get("percent")
		http.disconnect("request_completed",self,"out")
		pointers.Scripting.log_essential_info_for_bugreports()

class _ConfigDriver:
	var scripts : Array = [
		
	]
	
	static func get_class_documentation() -> Dictionary:
		return {
			"description":"Provides functions that unify and handle a configuration system for mods",
			"methods":{
				"__store_config":{
					"description":"Stores an entire dictionary's worth of data inside a config. Will override settings if they already exist, otherwise will be added to the config.",
					"args":[
						"configuration -> (Dictionary) providing the configs. Must be at least three levels deep to cover sections, keys, and their values (i.e. {'section':{'setting_1':true,'setting_2':false}})",
						"mod_id -> (String) providing the mod/identifier to store the config behind. Cannot contain forward slashes (/) or spaces ( ), and these will be removed when being processed.",
						"cfg_filename (optional) -> (String) used for the file this config is stored in within the 'user://cfg/' folder. Defaults to 'Mod_Configurations.cfg'"
					],
				},
				"__store_value":{
					"description":"Stores an individual setting to the config.",
					"args":[
						"mod_id -> (String) providing the mod/identifier to store the config to. Cannot contain forward slashes (/) or spaces ( ), and these will be removed when being processed.",
						"section -> (String) for the config's section to store under",
						"key -> (String) for the setting value to store.",
						"value -> The value being stored to the config.",
						"cfg_filename (optional) -> (String) used for the file this config is stored in within the 'user://cfg/' folder. Defaults to 'Mod_Configurations.cfg'"
					],
				},
				"__get_config":{
					"description":"Fetches the entire config dictionary for a given mod/identifier",
					"args":[
						"mod_id -> (String) providing the mod/identifier to fetch the config from. Cannot contain forward slashes (/) or spaces ( ), and these will be removed when being processed.",
						"cfg_filename (optional) -> (String) used for the file this config is stored in within the 'user://cfg/' folder. Defaults to 'Mod_Configurations.cfg'"
					],
					"return":[
						"Dictionary containing the entire config."
					]
				},
				"__get_value":{
					"description":"Fetches an individual setting and returns it's value",
					"args":[
						"mod_id -> (String) providing the mod/identifier to fetch the config from. Cannot contain forward slashes (/) or spaces ( ), and these will be removed when being processed.",
						"section -> (String) for the config's section to fetch from.",
						"key -> (String) for the setting value to get.",
						"default (optional) -> (Variant) a default value to return if the config doesn't exist. Defaults to null",
						"cfg_filename (optional) -> (String) used for the file this config is stored in within the 'user://cfg/' folder. Defaults to 'Mod_Configurations.cfg'"
					],
					"return":[
						"Variant from the setting. Indeterminable from a documentation standpoint."
					]
				},
				"__establish_connection":{
					"description":"Connects a method within an object to be called whenever the config changes",
					"args":[
						"method -> (String) method name to be called when the config changes",
						"node -> (Object) the object that will be receiving the method call",
						"type (optional) -> (String) for the connection mode. Accepts the following: config -> will update whenever the config changes; input -> will update only whenever an input-type config changes; both -> connects with both type, but has to use a separate method to connect the input type due to technical limitations",
						"input_method (optional) -> (String) for the method name the input change uses when `type` is set to `both`. Even if using the default method name, this should at least be defined when calling this to help readability. Defaults to 'input_changed'.",
					],
				},
				"__remove_connection":{
					"description":"Disconnects any connections made by __establish_connection, using the same operands",
					"args":[
						"method -> (String) method name that the object has been connected to",
						"node -> (Object) the object that would have been receiving the method call",
						"type (optional) -> (String) for the connection mode. Accepts the following: config -> will update whenever the config changes; input -> will update only whenever an input-type config changes; both -> connects with both type, but has to use a separate method to connect the input type due to technical limitations",
						"input_method (optional) -> (String) for the method name the input change used when connected to the `both` type, and needs to be used if `both` was ever used to connect. Defaults to 'input_changed'",
					],
				},
				"__load_configs":{
					"description":"Internal method used to initialize a configuration file. Only use if you know what you're doing",
					"args":[
						"cfg_filename (optional) -> (String) used for the file this config is stored in within the 'user://cfg/' folder. Defaults to 'Mod_Configurations.cfg'"
					],
				},
				"__load_inputs_from_string_array":{
					"description":"Creates input action events for a specific action based on an array of strings for key names",
					"args":[
						"key -> (String) used for the action event name to add the events behind",
						"strings -> (Array) used for the input events. Mouse events are prefixed with `Mouse X`; joy button events are prefixed with `JoyButton X`, and joy axis events are prefixed with `JoyAxis X`. Joy axis events can have their number be negative to trigger it in the opposite direction. Anything not using those prefixes will be handled as keyboard inputs.",
					],
				},
				"__change_made":{
					"description":"Marks the config as needing to be saved on the next physics frame.",
				},
				"__subscribed_changes":{
					"description":"Internal method used to process any changes for objects subscribed to a setting change",
				},
				"__input_change_made":{
					"description":"Internal method used to process any changes made specifically to input type configs",
				},
				"__subscribe_to_setting_change":{
					"description":"Connects an object to call a method when a specific setting has been changed",
					"args":[
						"method -> (String) for the method to connect to",
						"object -> (Object) to connect to for the method call",
						"id -> (String) mod/identifier for the config to check",
						"section -> (String) the config section to get the setting from",
						"setting -> (String) the specific setting to check against"
					]
				},
				"__disconnect_subscription":{
					"description":"Disconnects any established subscriptions made for a setting",
					"args":[
						"method -> (String) for the method to connect to",
						"object -> (Object) to connect to for the method call",
						"id -> (String) mod/identifier for the config to check",
						"section -> (String) the config section to get the setting from",
						"setting -> (String) the specific setting to check against"
					]
				},
				"__get_minmax_string_from_dict":{
					"description":"Creates a string for a mod from a dictionary, with possible versions shown if provided",
					"args":[
						"requirement -> (Dictionary) containing the mod data. MUST have `mod_id` for the mod ID string, can also have `minimum_version`/`min_version` for the minimum mod version, or `maximum_version`/`max_version` for the maximum mod version"
					],
					"return":[
						"String containing the mod's data"
					]
				},
				"__truncate_mod_id":{
					"description":"Formats a string as if it were being handled as a config mod/identifier, stripping out all spaces and forward slashes",
					"args":[
						"mod_id -> (String) used for the formatted mod/identifier"
					],
					"return":[
						"String formatted to a mod id"
					]
				},
				"__truncate_section":{
					"description":"Formats a string for sections by stripping out forward slashes",
					"args":[
						"section -> (String) used for formatting"
					],
					"return":[
						"String formatted to a section name"
					]
				},
				"__truncate_to_setting_entry":{
					"description":"Converts a mod/identifier and section to fetch the config by it's internal name. Formatting is handled by the method, so inputs do not need to be sanitized",
					"args":[
						"mod_id -> (String) used for the formatted mod/identifier",
						"section -> (String) used for formatting"
					],
					"return":[
						"String formatted by mod_id/section, with all other parts cut out."
					]
				},
				"__validate_dictionary":{
					"description":"Checks a dictionary for any config and mod limitations to see if it would be permitted",
					"args":[
						"data_dict -> (Dictionary) input data dictionary for checking.",
						"check_config (optional) -> (bool) whether configs should be checked. Defaults to `true`",
						"check_requirements (optional) -> (bool) whether mod requirements should be checked. Defaults to `true`",
						"check_incompatibilities (optional) -> (bool) whether mod incompatibilities should be checked. Defaults to `true`",
						"config_entry_override (optional) -> (String) the entry name that is checked against the dictionary for what it uses to store config data. Defaults to 'config'",
						"mod_requirements_entry_override (optional) -> (String) the entry name that is checked against the dictionary for what it uses to store mod requirements data. Defaults to 'mod_requirements'",
						"mod_incompatibilities_entry_override (optional) -> (String) the entry name that is checked against the dictionary for what it uses to store mod incompatibility data. Defaults to 'mod_incompatibilities'"
					],
					"return":[
						"bool for whether the dictionary is valid for processing"
					]
				},
				"__config_parse":{
					"description":"Opens a config file and converts it to a dictionary",
					"args":[
						"file_path -> (String) filepath for the config file to open"
					],
					"return":[
						"Dictionary containing the config's data"
					]
				},
				"__config_store":{
					"description":"Stores a dictionary as a raw config as literally as possible",
					"args":[
						"dictionary -> (Dictionary) the data being stored",
						"file_path -> (String) filepath storing the config to"
					],
				},
			}
		}
	
	const non_static:Dictionary = {}
	func _init(d):
		non_static["pointers"] = d
		non_static["self"] = self
	
	static func ready():
		pushCFG()
	
	static func l(text:String,header:String = "pointers.ConfigDriver"):
		non_static["pointers"].l(text,header)
	
	# Signals used for 
	signal config_changed()
	signal input_changed()
	
	# Hash info to simplify checking for changes
	var settingsHash : int = 0
	var settingsInputHash : int = 0
	var settings : Dictionary = {}
	
	# Stores for pushing updates to specifically subscribed settings
	var subscriptions : Dictionary = {}
	var changes : Dictionary = {}
	
	# Stores an entire config to an ID
	static func __store_config(configuration: Dictionary, mod_id: String, cfg_filename : String = "Mod_Configurations" + ".cfg"):
		var made_change : bool = false
		var profiles_dir : String = "user://cfg/.profiles/"
		var cfg_folder : String = "user://cfg/"
		var tmpf : File = File.new()
		var cfg_file : String = cfg_folder + cfg_filename
		if not tmpf.file_exists(cfg_file):
			# Writes a blank config file if it doesn't exist
			# Ensures that later parts run cleanly even on fresh installs
			tmpf.open(cfg_folder+cfg_file,File.WRITE)
			tmpf.store_string("")
			tmpf.close()
		var cfg : ConfigFile = ConfigFile.new()
		var FileCFG : File = File.new()
		FileCFG.open(cfg_file,File.READ)
		var txt : String = FileCFG.get_as_text(true)
		cfg.parse(txt)
		FileCFG.close()
		# Formats the mod_id to be valid for configs.
		# This removes forward slashes and spaces
		mod_id = __truncate_mod_id(mod_id)
		# Iterates through the sections in the provided config
		var base:Dictionary = non_static["self"]
		var settings:Dictionary = base.settings
		var changes:Dictionary = non_static["self"].changes
		for section in configuration.keys():
			# Similar process to format the section
			# Also concatenates it with the mod id to form
			# an identifier that fits in ini configs
			section = __truncate_section(section)
			var sect_name : String = mod_id + "/" + section
			# Gets the data within this specific configuration
			var sect_data = configuration[section]
			
			if not sect_name in settings.keys():
				# Implies a new section is being added,
				# automatically marks for an update 
				settings[sect_name] = {}
				made_change = true
			# Iterates through the section entries
			for s in sect_data.keys():
				# Entry data
				var sr = sect_data[s]
				var current = settings[sect_name].get(s,null)
				if current != sr:
					# Sets data and marks as a change made if the
					# value is different to what's already in the file
					settings[sect_name][s] = sr
					made_change = true
					if not sect_name in changes.keys():
						changes[sect_name] = []
					changes[sect_name].append(s)
					cfg.set_value(sect_name,s,sr)
		
		
		# The profile name for the config
		var profile = cfg.get_value("HevLib/HEVLIB_CONFIG_SECTION_DRIVERS","profile_name","default")
		# Saves file and saves a copy to the profiles directory as backup
		cfg.save(cfg_file)
		cfg.save(profiles_dir+profile + ".cfg")
		if made_change:
			# If changes were made, emit signals and show the save icon
			__change_made()
			if Loader:
				Loader.saved()
	
	# Stores a value under an ID's section and entry
	static func __store_value(mod_id:String, section:String, key:String, value, cfg_filename : String = "Mod_Configurations" + ".cfg"):
		var made_change : bool = false
		var cfg_folder : String = "user://cfg/"
		var profiles_dir : String = "user://cfg/.profiles/"
		var cfg : ConfigFile = ConfigFile.new()
		cfg.load(cfg_folder+cfg_filename)
		# Automatically converts the ID and section into what
		# can be fetched from the config file
		var modSection : String = __truncate_to_setting_entry(mod_id,section)
		cfg.set_value(modSection,key,value)
		var profile= cfg.get_value("HevLib/HEVLIB_CONFIG_SECTION_DRIVERS","profile_name","default")
		var settings:Dictionary = non_static["self"].settings
		var changes:Dictionary = non_static["self"].changes
		if not modSection in settings.keys():
			# Automatically mark as a new change if new parts have to be added
			settings[modSection] = {}
			made_change = true
		var current = settings[modSection].get(key,null)
		if current != value:
			settings[modSection][key] = value
			made_change = true
		cfg.save(cfg_folder+cfg_filename)
		cfg.save(profiles_dir+profile + ".cfg")
		if made_change:
			# If changes were made, add them to the changes list to have them updated
			if not modSection in changes:
				changes[modSection] = []
			changes[modSection].append(key)
			# emit signals and show save icon
			__change_made()
			if Loader:
				Loader.saved()
	
	# Fetches a config as a dictionary
	static func __get_config(mod_id, cfg_filename : String = "Mod_Configurations" + ".cfg") -> Dictionary:
		var dictionary : Dictionary = {}
		# Formats the mod_id to be valid for configs.
		# This removes forward slashes and spaces 
		mod_id = __truncate_mod_id(mod_id)
		var settings:Dictionary = non_static["self"].settings
		if non_static["self"].settingsHash:
			# Hash usually means the data is already cached
			for section in settings.keys():
				var split : PoolStringArray = section.split("/")
				# Checks if the first part of the section matches the ID
				# If they match, recurse through the section to add configs to the output
				if split[0] == mod_id:
					dictionary[split[1]] = settings[section].duplicate(true)
		else:
			# No hash means it has to be fetched from the file directly
			var cfg:ConfigFile = ConfigFile.new()
			var error:int = cfg.load("user://cfg/"+cfg_filename)
			if error != OK:
				# File probably doesn't exist, aborting
				l("HevLib Config File: Error loading settings %s" % error)
				return {}
			for section in cfg.get_sections():
				var split:PoolStringArray = section.split("/")
				# Checks if the first part of the section matches the ID
				# If they match, recurse through the section to add configs to the output
				if split[0] == mod_id:
					var sub : Dictionary = {}
					for key in cfg.get_section_keys(section):
						sub[key] = cfg.get_value(section, key)
					dictionary[split[1]] = sub
		return dictionary
	
	# Fetches a specific value from the config
	# Will return null if it does not exist
	static func __get_value(mod_id: String, section: String, key: String, default = null, cfg_filename : String = "Mod_Configurations" + ".cfg"):
		var full : String = __truncate_to_setting_entry(mod_id,section)
		# Truncate to get the section directly
		if non_static["self"].settingsHash:
			var settings:Dictionary = non_static["self"].settings
			# Config is cached, may as well fetch from there
			if full in settings.keys():
				if key in settings[full].keys():
					var out = settings[full][key]
					# Hard duplicating array or dictionary types to ensure no reference weirdness
					if out is Array or out is Dictionary:
						return out.duplicate(true)
					return out
			return default
		else:
			# Not cached, fetch from file instead
			var cfg:ConfigFile = ConfigFile.new()
			var error:int = cfg.load("user://cfg/"+cfg_filename)
			if error != OK:
				# File probably doesn't exist, aborting
				l("HevLib Config File: Error loading settings %s" % error,"pointers.ConfigDriver")
				return default
			
			if cfg.has_section(full):
				if key in cfg.get_section_keys(full):
					return cfg.get_value(full,key,default)
			return default
	
	# Method called onready to prepare the config and hashes, and push any connections
	static func pushCFG(cfg_filename : String = "Mod_Configurations" + ".cfg"):
		var current_config : Dictionary = __config_parse("user://cfg/" + cfg_filename)
		non_static["self"].settings = current_config
		non_static["self"].settingsHash = current_config.hash()
		__change_made()
	
	# All-encompassing handler to connect a method to handle any changes to configs
	static func __establish_connection(method: String, node: Object, type: String = "config", input_method: String = "input_changed"): # Type accepts "config", "input", or "both"
		var base = non_static["self"]
		match type.to_lower():
			# Emitted when any config changes
			"config":
				if node.has_method(method):
					if not base.is_connected("config_changed",node,method):
						base.connect("config_changed",node,method)
					else:l("node %s already connected with the method '%s', connect failed" % [str(node),method])
				else:l("node %s does not have the method '%s', cannot connect" % [str(node),method])
			# Emitted only when configs of input type change
			"input":
				if node.has_method(method):
					if not base.is_connected("input_changed",node,method):
						base.connect("input_changed",node,method)
					else:l("node %s already connected with the method '%s', connect failed" % [str(node),method])
				else:l("node %s does not have the method '%s', cannot connect" % [str(node),method])
			# Connects two methods within the object to the 'config' and 'input' types respectively
			# 'input_method' should at least be defined when calling this to help readability
			"both":
				if node.has_method(input_method):
					if not base.is_connected("input_changed",node,input_method):
						base.connect("input_changed",node,input_method)
					else:l("node %s already connected with the method '%s', connect failed" % [str(node),method])
				else:l("node %s does not have the method '%s', cannot connect" % [str(node),input_method])
				if node.has_method(method):
					if not base.is_connected("config_changed",node,method):
						base.connect("config_changed",node,method)
					else:l("node %s already connected with the method '%s', connect failed" % [str(node),method])
				else:l("node %s does not have the method '%s', cannot connect" % [str(node),method])
	
	# Inverse method to __establish connection
	# See that method for comments, as this just disconnects those connections
	static func __remove_connection(method: String, node: Object, type: String = "config", input_method: String = "input_changed"): # Type accepts "config", "input", or "both"
		var base = non_static["self"]
		match type.to_lower():
			"config":
				if node.has_method(method):
					if base.is_connected("config_changed",node,method):
						base.disconnect("config_changed",node,method)
					else:l("node %s not connected with the method '%s', disconnect failed" % [str(node),method])
				else:l("node %s does not have the method '%s', cannot disconnect" % [str(node),method])
			"input":
				if node.has_method(method):
					if base.is_connected("input_changed",node,method):
						base.disconnect("input_changed",node,method)
					else:l("node %s not connected with the method '%s', disconnect failed" % [str(node),method])
				else:l("node %s does not have the method '%s', cannot disconnect" % [str(node),method])
			"both":
				if node.has_method(input_method):
					if base.is_connected("input_changed",node,input_method):
						base.disconnect("input_changed",node,input_method)
					else:l("node %s not connected with the method '%s', disconnect failed" % [str(node),method])
				else:l("node %s does not have the method '%s', cannot disconnect" % [str(node),input_method])
				if node.has_method(method):
					if base.is_connected("config_changed",node,method):
						base.disconnect("config_changed",node,method)
					else:l("node %s not connected with the method '%s', disconnect failed" % [str(node),method])
				else:l("node %s does not have the method '%s', cannot disconnect" % [str(node),method])
	
	# Called from the EquipmentDriver ModMain and initializes configs
	static func __load_configs(cfg_filename : String = "Mod_Configurations" + ".cfg"):
		# Fetches game default configs, including those in the config file
		# Config-based inputs are defined as such
		# Inputs added in future updates throw errors, and let me know to update it
		var dir:Directory = Directory.new()
		var c:ConfigFile = ConfigFile.new()
		# Directory and file definitions
		var keybinds_cache : String = "user://cache/.HevLib_Cache/Keybinds/"
		var cfg_file : String = "user://cfg/" + cfg_filename
		var profiles_dir : String = "user://cfg/.profiles/"
		var profiles_setter : String = ".profiles.ini"
		# Initializes profiles and keybind cache directories
		dir.make_dir_recursive(profiles_dir)
		dir.make_dir_recursive(keybinds_cache)
		# Stores default binds
		# I don't remember why I cache this, although since the MultiBinds
		# project is on hold, might be for something I never wrote down 
		var pointers:Node = non_static["pointers"]
		var file:File = File.new()
		file.open(keybinds_cache + "defined_control_configs.json",File.WRITE)
		file.store_string("{}")
		file.close()
		if not file.file_exists(profiles_dir + profiles_setter):
			# If no profile ini file exists, initializes it and sets 'Default' as the profile
			c.clear()
			c.set_value("profiles","selected","Default")
			c.save(profiles_dir + profiles_setter)
			c.clear()
		if not file.file_exists(cfg_file):
			# Creates the config file if it doesn't exist
			# Will be blank to prevent issues and make sure
			# defaults are loaded from manifests
			file.open(cfg_file,File.WRITE)
			file.store_string("")
			file.close()
		c.load(profiles_dir + profiles_setter)
		# Fetches the currently desired profile
		var desired_profile = c.get_value("profiles","selected","Default")
		c.clear()
		c.load(cfg_file)
		# Gets the current profile name
		var current_profile = c.get_value("HevLib/HEVLIB_CONFIG_SECTION_DRIVERS","profile_name","Default")
		var profile_is_current:bool = true
		# If current is not desired profile, search profiles directory
		if current_profile != desired_profile:
			# Copies this into the profiles directory to ensure it doesn't get overwritten
			dir.copy(cfg_file,profiles_dir + current_profile + ".cfg")
			profile_is_current = false
			dir.remove(cfg_file)
			# Recurses over files in the profiles directory
			for m in pointers.FolderAccess.__fetch_folder_files("user://cfg/.profiles/"):
				# File is not the profiles ini
				if m != ".profiles.ini":
					c.clear()
					c.load(profiles_dir + m)
					# Gets this file's profile
					var this_profile = c.get_value("HevLib/HEVLIB_CONFIG_SECTION_DRIVERS","profile_name")
					if this_profile == desired_profile:
						# Copies the currently open config if it matches the desired profile 
						dir.copy(profiles_dir + m,cfg_file)
						profile_is_current = true
					c.clear()
					c.load(cfg_file)
		# Config not found, falling back and creating anew
		if not profile_is_current:
			c.clear()
			c.set_value("HevLib/HEVLIB_CONFIG_SECTION_DRIVERS","profile_name",desired_profile)
			c.save(cfg_file)
		
		# Gets all mod data
		var mod_entries : Dictionary = pointers.ManifestV2.__get_mod_data()
		l("[%s] mod entries found" % mod_entries.size())
		# Fetches disabled modlets
		# This is not used here, but lets me log
		# what it finds and ensure the cache exists
		var disabled_modlets:Dictionary = pointers.ManifestV2.__get_disabled_modlets()
		var DMIDs:PoolStringArray = PoolStringArray()
		for i in disabled_modlets:
			DMIDs.append(disabled_modlets[i])
		pointers.l("[%s] disabled modlets found: [%s]" % [disabled_modlets.size(),",".join(DMIDs)],"pointers.ConfigDriver")
		# Store for the raw config information
		var configs : Dictionary = {}
		var current_config : Dictionary = __config_parse(cfg_file)
		var incorrect_paths : Array = Array()
		var problematic_mods : Dictionary = {}
		for mod in pointers.ManifestV2.__get_mod_list_keys():
			var manifest : Dictionary = mod_entries[mod]["manifest"]
			var has_manifest:bool = manifest["has_manifest"]
			if has_manifest:
				var missing_requirements : Array = Array()
				var incompatible_mods : Array = Array()
				var mod_name : String = mod_entries[mod]["name"]
				var manifest_version : float = float(manifest["manifest_version"])
				if manifest_version > 2.0:
					var cfg : Dictionary = manifest["manifest_data"]["configs"]
					if not hash(cfg) == hash({}):
						configs[mod_name] = cfg
				# Checking for mods that require specific filepaths
				var expected_path:String = manifest["manifest_data"]["manifest_definitions"]["expected_manifest_path"]
				var actual_path:String = manifest["manifest_file_path"]
				if expected_path and expected_path.to_lower() != actual_path.to_lower():
					incorrect_paths.append([manifest["manifest_data"]["mod_information"]["id"],expected_path,actual_path])
				for requirement in manifest["manifest_data"]["manifest_definitions"]["dependancy_mod_ids"]:
					match typeof(requirement):
						TYPE_ARRAY:
							var doesHaveAny = false
							var needsEitherOf = PoolStringArray()
							for i in requirement:
								if typeof(i) == TYPE_DICTIONARY and i.get("blocking",false) and not pointers.ManifestV2.__mod_exists(i):
									var ov = __get_minmax_string_from_dict(i)
									if ov:
										needsEitherOf.append(ov)
								else:
									doesHaveAny = true
							if not doesHaveAny:
								missing_requirements.append(" OR ".join(needsEitherOf))
						TYPE_DICTIONARY:
							if requirement.get("blocking",false) and not pointers.ManifestV2.__mod_exists(requirement):
								var ov = __get_minmax_string_from_dict(requirement)
								if ov:
									missing_requirements.append(ov)
				for incompat in manifest["manifest_data"]["manifest_definitions"]["conflicting_mod_ids"]:
					match typeof(incompat):
						TYPE_ARRAY:
							var doesHaveAny = false
							var needsEitherOf = PoolStringArray()
							for i in incompat:
								if typeof(i) == TYPE_DICTIONARY and i.get("blocking",false) and pointers.ManifestV2.__mod_exists(i):
									var ov = __get_minmax_string_from_dict(i)
									if ov:
										needsEitherOf.append(ov)
										doesHaveAny = true
							if doesHaveAny:
								incompatible_mods.append(" OR ".join(needsEitherOf))
						TYPE_DICTIONARY:
							if incompat.get("blocking",false) and pointers.ManifestV2.__mod_exists(incompat):
								var ov = __get_minmax_string_from_dict(incompat)
								if ov:
									incompatible_mods.append(ov)
				if missing_requirements or incompatible_mods:
					problematic_mods[mod_name] = {}
					if missing_requirements:
						problematic_mods[mod_name]["missing_requirements"] = missing_requirements
					if incompatible_mods:
						problematic_mods[mod_name]["incompatible_mods"] = incompatible_mods
		# If incorrectly placed mods are found
		if incorrect_paths:
			var error_text = "The following mod(s) expect a specific file path, however are located at a different resource path than what it expects:\n\n%s\n\nPlease make sure you have downloaded the mod(s) correctly, and restart the game. If you have any further issues, please ask in the ∆V Discord [https://discord.gg/dv]"
			var path_concat = ""
			for i in incorrect_paths:
				if path_concat:
					path_concat += "\n\n%s: Expected manifest path: [%s]; actual manifest path: [%s]" % [i[0],i[1],i[2]]
				else:
					path_concat = "%s: Expected manifest path: [%s]; actual manifest path: [%s]" % [i[0],i[1],i[2]]
			# Throws an error box and exits the game to let the user know that their mod(s) are broken.
			pointers.NodeAccess.__exit(false,error_text % path_concat,"pointers.ConfigDriver",0.0,"",true)
		# If any blocking conflicts or missing requirements exist
		if problematic_mods:
			var mod_error_text:String = "The following mods have issues with the currently installed mods and are unable to run as a result. This can be due to incorrect/out-of-date mod versions, missing mods, or mods that aren't compatible.\n%s\nPlease ensure all requirements are met before being able to launch the game."
			var mod_concat:String = ""
			for mod_name in problematic_mods.keys():
				mod_concat += "\n%s\n" % mod_name
				var missing_requirements = problematic_mods[mod_name].get("missing_requirements",PoolStringArray())
				var incompatible_mods = problematic_mods[mod_name].get("incompatible_mods",PoolStringArray())
				if missing_requirements:
					mod_concat += "    Missing requirements:"
					for i in missing_requirements:
						mod_concat += "     -> %s\n" % i
				if incompatible_mods:
					mod_concat += "    Incompatible mods:\n"
					for i in incompatible_mods:
						mod_concat += "     -> %s\n" % i
			pointers.NodeAccess.__exit(false,mod_error_text % mod_concat,"pointers.ConfigDriver",0.0,"",true)
		pointers.l("config contains [%s] mods" % configs.size(),"pointers.ConfigDriver")
		for mod in configs.keys():
			var data : Dictionary = configs[mod]
			mod = __truncate_mod_id(mod)
			for section in data.keys():
				var sectData : Dictionary = data[section]
				var sect : String = mod + "/" + __truncate_section(section)
				if not sect in current_config.keys():
					current_config[sect] = {}
				for key in sectData.keys():
					var key_data : Dictionary = sectData[key]
					if typeof(key_data) == TYPE_DICTIONARY:
						var type : String = key_data.get("type","")
						if not type:
							continue
						type = type.to_lower()
						if key in current_config[sect].keys():
							if type == "input":
								var val : Dictionary = current_config[sect]
								var out : Array = []
								for a in val[key]:
									if typeof(a) == TYPE_STRING:
										a = [a]
									out.append(a)
								current_config[sect][key] = out
						else:
							match type:
								"input":
									var out : Array = []
									for a in key_data.get("default",[]):
										if typeof(a) == TYPE_STRING:
											a = [a]
										out.append(a)
									current_config[sect][key] = out
								_:
									if "default" in key_data:
										current_config[sect][key] = key_data["default"]
								
		if not "profile_name" in current_config.get("HevLib/HEVLIB_CONFIG_SECTION_DRIVERS",{}):
			current_config["HevLib/HEVLIB_CONFIG_SECTION_DRIVERS"]["profile_name"] = "Default"
		for section in current_config:
			for key in current_config[section]:
				c.set_value(section,key,current_config[section][key])
		non_static["self"].settings = current_config
		non_static["self"].settingsHash = current_config.hash()
		__change_made()
		c.save(cfg_file)
		c.save(profiles_dir + current_config.get("HevLib/HEVLIB_CONFIG_SECTION_DRIVERS",{}).get("profile_name","Default") + ".cfg")
		pointers.l("loaded [%s] mod configurations" % configs.size(),"pointers.ConfigDriver")
		var actionList : Array = InputMap.get_actions()
		for mod in configs.keys():
			pointers.l("inspecting [%s]" % mod,"pointers.ConfigDriver")
			var data = __get_config(mod)
			pointers.l("found [%s] sections" % data.size(),"pointers.ConfigDriver")
			for section in configs[mod].keys():
				pointers.l("inspecting section [%s]" % section,"pointers.ConfigDriver")
				var sectData = configs[mod][section]
				for key in sectData.keys():
					var key_data = sectData[key]
					pointers.l("found entry [%s] of type [%s] with a default of [%s]" % [key,key_data["type"],key_data.get("default","Null")],"pointers.ConfigDriver")
					if key_data["type"].to_lower() == "input":
						var p = __get_value(mod,section,key)
						pointers.l("value of [%s] is [%s]" % [key,p],"pointers.ConfigDriver")
						var default = key_data.get("default",[])
						pointers.l("[%s] default is [%s]" % [key,default],"pointers.ConfigDriver")
						var b = []
						for h in p:
							if typeof(h) == TYPE_STRING:
								h = [h]
							b.append(h)
						p = b
						var deadzone = key_data.get("deadzone",0.5) # Control deadzone value
						
						var opts = pointers.Keymapping.__get_opts_from_key_data(key_data)
						if p == null:
							p = default
						if not key in actionList:
							pointers.l("Adding input key [%s]" % key,"pointers.ConfigDriver")
							InputMap.add_action(key,deadzone)
							actionList.append(key)
						else:pointers.l("Input key [%s] already exists, skipping" % key,"pointers.ConfigDriver")
						pointers.Keymapping.__load_input_data(key,p,opts)
		
	
	static func __get_minmax_string_from_dict(requirement:Dictionary) -> String:
		var MID = str(requirement.get("mod_id",""))
		var MDM = str(requirement.get("mod_main",""))
		var pointers:Node = non_static["pointers"]
		if typeof(MID) == TYPE_STRING and MID:
			var minVer = null
			var maxVer = null
			if ("minimum_version" in requirement or "min_version" in requirement):
				var minimum = requirement.get("minimum_version",requirement.get("min_version",null))
				match typeof(minimum):
					TYPE_ARRAY,TYPE_INT_ARRAY:
						if minimum.size() > 2:
							minVer = minimum
					TYPE_VECTOR3:
						minVer = minimum
					TYPE_DICTIONARY:
						var minarr = Vector3.ZERO
						minarr[0] = int(minimum.get("major",0))
						minarr[1] = int(minimum.get("minor",0))
						minarr[2] = int(minimum.get("bugfix",0))
						minVer = minarr
			if ("maximum_version" in requirement or "max_version" in requirement):
				var minimum = requirement.get("maximum_version",requirement.get("max_version",null))
				match typeof(minimum):
					TYPE_ARRAY,TYPE_INT_ARRAY:
						if minimum.size() > 2:
							maxVer = minimum
					TYPE_VECTOR3:
						maxVer = minimum
					TYPE_DICTIONARY:
						var minarr = Vector3.ZERO
						minarr[0] = int(minimum.get("major",0))
						minarr[1] = int(minimum.get("minor",0))
						minarr[2] = int(minimum.get("bugfix",0))
						maxVer = minarr
			var mdOut = MID
			var additional = ""
			if minVer != null:
				additional = "min ver %d.%d.%d" % [minVer[0],minVer[1],minVer[2]]
			if maxVer:
				if additional:
					additional += " through "
				additional += "max ver %d.%d.%d" % [maxVer[0],maxVer[1],maxVer[2]]
			if additional:
				mdOut += " (%s)" % additional
			return mdOut
		elif typeof(MDM) == TYPE_STRING and MDM and MDM in pointers.ManifestV2.__get_mod_list_keys():
			var zip = pointers.ManifestV2.__match_mod_path_to_zip(MDM)
			if zip:
				return zip.get_file()
			else:
				return MDM.split("/",false)[1]
		return ""
	
	static func __load_inputs_from_string_array(key:String, strings: Array):
		for i in strings:
			if i.begins_with("Mouse "):
				var event:InputEventMouseButton = InputEventMouseButton.new()
				event.button_index = int(i.split("Mouse ")[1])
				if not InputMap.action_has_event(key,event):
					l("Adding input event [%s] for [%s]" % [i,key],"pointers.ConfigDriver")
					InputMap.action_add_event(key, event)
				else:l("Input event [%s] for [%s] already exists, skipping" % [i,key],"pointers.ConfigDriver")
			if i.begins_with("JoyButton "):
				var event:InputEventJoypadButton = InputEventJoypadButton.new()
				event.button_index = int(i.split("JoyButton ")[1])
				if not InputMap.action_has_event(key,event):
					l("Adding input event [%s] for [%s]" % [i,key],"pointers.ConfigDriver")
					InputMap.action_add_event(key, event)
				else:l("Input event [%s] for [%s] already exists, skipping" % [i,key],"pointers.ConfigDriver")
			if i.begins_with("JoyAxis "):
				var event:InputEventJoypadMotion = InputEventJoypadMotion.new()
				event.axis = abs(int(i.split("JoyAxis ")[1]))
				if i.split("JoyAxis ")[1].begins_with("-"):
					event.axis_value = -1.0
				else:
					event.axis_value = 1.0
				if not InputMap.action_has_event(key,event):
					l("Adding input event [%s] for [%s]" % [i,key],"pointers.ConfigDriver")
					InputMap.action_add_event(key, event)
				else:l("Input event [%s] for [%s] already exists, skipping" % [i,key],"pointers.ConfigDriver")
				
			else:
				var event:InputEventKey = InputEventKey.new()
				event.scancode = OS.find_scancode_from_string(i)
				if not InputMap.action_has_event(key,event):
					l("Adding input event [%s] for [%s]" % [i,key],"pointers.ConfigDriver")
					InputMap.action_add_event(key, event)
				else:l("Input event [%s] for [%s] already exists, skipping" % [i,key],"pointers.ConfigDriver")
		
	static func set_button_focus(button,check_button):
		var parent = button.get_parent()
		var children = parent.get_children()
		var pos = button.get_position_in_parent()
		var icon_button
		var reset_button
		if button.has_method("get_label"):
			icon_button = button.get_label()
		else: breakpoint
		if button.has_method("get_reset"):
			reset_button = button.get_reset()
		else: breakpoint
		
		icon_button.focus_neighbour_top = "."
		reset_button.focus_neighbour_top = "."
		check_button.focus_neighbour_top = "."
		icon_button.focus_neighbour_bottom = "."
		reset_button.focus_neighbour_bottom = "."
		check_button.focus_neighbour_bottom = "."
		
		if children.size() == 1:
			return
		elif pos == 0:
			icon_button.focus_neighbour_top = "."
			reset_button.focus_neighbour_top = "."
			check_button.focus_neighbour_top = "."
			var direction = 1
			var neighbour = parent.get_child(pos + direction)
			var script : Script = neighbour.get_script()
			if script != null:
				if neighbour:
					if neighbour.has_method("get_label"):
						var label = neighbour.get_label(direction)
						if label:
							icon_button.focus_neighbour_bottom = icon_button.get_path_to(label)
					else: breakpoint
					if neighbour.has_method("get_reset"):
						var reset = neighbour.get_reset(direction)
						if reset:
							reset_button.focus_neighbour_bottom = reset_button.get_path_to(reset)
					else: breakpoint
					if neighbour.has_method("get_focusable"):
						var focusable = neighbour.get_focusable(direction)
						if focusable:
							check_button.focus_neighbour_bottom = check_button.get_path_to(focusable)
					else: breakpoint
		elif pos == children.size() - 1:
			var direction = -1
			var neighbour = parent.get_child(pos + direction)
			var script : Script = neighbour.get_script()
			if script != null:
				if neighbour:
					if neighbour.has_method("get_label"):
						var label = neighbour.get_label(direction)
						if label:
							icon_button.focus_neighbour_top = icon_button.get_path_to(label)
					else: breakpoint
					if neighbour.has_method("get_reset"):
						var reset = neighbour.get_reset(direction)
						if reset:
							reset_button.focus_neighbour_top = reset_button.get_path_to(reset)
					else: breakpoint
					if neighbour.has_method("get_focusable"):
						var focusable = neighbour.get_focusable(direction)
						if focusable:
							check_button.focus_neighbour_top = check_button.get_path_to(focusable)
					else: breakpoint
		else:
			var direction1 = -1
			var neighbour1 = parent.get_child(pos + direction1)
			var script1 : Script = neighbour1.get_script()
			if script1 != null:
				if neighbour1:
					if neighbour1.has_method("get_label"):
						var label = neighbour1.get_label(direction1)
						if label:
							icon_button.focus_neighbour_top = icon_button.get_path_to(label)
					else: breakpoint
					if neighbour1.has_method("get_reset"):
						var reset = neighbour1.get_reset(direction1)
						if reset:
							reset_button.focus_neighbour_top = reset_button.get_path_to(reset)
					else: breakpoint
					if neighbour1.has_method("get_focusable"):
						var focusable = neighbour1.get_focusable(direction1)
						if focusable:
							check_button.focus_neighbour_top = check_button.get_path_to(focusable)
					else: breakpoint
			var direction2 = 1
			var neighbour2 = parent.get_child(pos + direction2)
			var script : Script = neighbour2.get_script()
			if script != null:
				if neighbour2:
					if neighbour2.has_method("get_label"):
						var label = neighbour2.get_label(direction2)
						if label:
							icon_button.focus_neighbour_bottom = icon_button.get_path_to(label)
					else: breakpoint
					if neighbour2.has_method("get_reset"):
						var reset = neighbour2.get_reset(direction2)
						if reset:
							reset_button.focus_neighbour_bottom = reset_button.get_path_to(reset)
					else: breakpoint
					if neighbour2.has_method("get_focusable"):
						var focusable = neighbour2.get_focusable(direction2)
						if focusable:
							check_button.focus_neighbour_bottom = check_button.get_path_to(focusable)
					else: breakpoint
	var mk_c : bool = false
	static func __change_made():
		non_static["self"].mk_c = true
	
	static func handle_change_made():
		var base = non_static["self"]
		var shs:int = base.settings.hash()
		if shs != base.settingsHash:
			__input_change_made()
			__subscribed_changes()
			base.emit_signal("config_changed")
			base.settingsHash = shs
		base.mk_c = false
	
	static func __subscribed_changes():
		var base = non_static["self"]
		var changes:Dictionary = base.changes
		var subscriptions:Dictionary = base.subscriptions
		for i in changes.keys():
			if i in subscriptions.keys():
				var sub:Dictionary = subscriptions[i]
				var s:PoolStringArray = i.split("/")
				var entries = changes[i]
				for entry in entries:
					if entry in sub:
						var val = __get_value(s[0],s[1],entry)
						var out = sub[entry]
						for o in out:
							var obj = o[0]
							if Tool.ov(obj):
								obj.callv(o[1],[val])
		changes.clear()
	
	var cached_input_config_names : Dictionary = {}
	
	static func __input_change_made():
		var ic : Array = []
		var inputnames : Dictionary = {}
		var base = non_static["self"]
		var cached_input_config_names:Dictionary = base.cached_input_config_names
		if cached_input_config_names:
			inputnames = cached_input_config_names
		else:
			var ax : Dictionary = non_static["pointers"].ManifestV2.__get_manifest_cache()
			for sect in ax.keys():
				var dv : Dictionary = ax[sect]
				var dl : Dictionary = dv.get("configs",{})
				for sec in dl.keys():
					var sv : Dictionary = dl[sec]
					for setting in sv.keys():
						var data : Dictionary = sv[setting]
						if data.get("type").to_lower() == "input":
							var n : String = __truncate_mod_id(dv["mod_information"]["name"])
							if not n in cached_input_config_names:
								cached_input_config_names[n] = {}
							if not sec in cached_input_config_names[n]:
								cached_input_config_names[n][sec] = []
							cached_input_config_names[n][sec].append(setting)
			inputnames = cached_input_config_names
		for n in inputnames.keys():
			var nd : Dictionary = inputnames[n]
			for sec in nd.keys():
				var sc : Array = nd[sec]
				for setting in sc:
					var vf : Array = __get_value(n,sec,setting)
					var out : Array = []
					var resave:bool = false
					for a in vf:
						if typeof(a) == TYPE_STRING:
							a = [a]
							resave = true
						out.append(a)
					if resave:
						__store_value(n,sec,setting,out)
					ic.append(str(n)+str(sec)+str(setting)+str(out))
		var shs:int = ic.hash()
		if shs != base.settingsInputHash:
			base.emit_signal("input_changed")
			base.settingsInputHash = shs
	
	static func __subscribe_to_setting_change(method: String,object: Object,id: String,section: String,setting: String):
		if object.has_method(method):
			var subscriptions:Dictionary = non_static["self"].subscriptions
			var top : String = __truncate_to_setting_entry(id,section)
			if not top in subscriptions.keys():
				subscriptions[top] = {}
			if not setting in subscriptions[top].keys():
				subscriptions[top][setting] = []
			var do:bool = true
			for item in subscriptions[top][setting]:
				if item[0] == object and item[1] == method:
					do = false
			if do:
				subscriptions[top][setting].append([object,method])
		else:l("node %s does not have the method '%s'" % [str(object),method])
			
	
	static func __disconnect_subscription(method: String,object: Object,id: String,section: String,setting: String):
		var top : String = __truncate_to_setting_entry(id,section)
		var subscriptions:Dictionary = non_static["self"].subscriptions
		if top in subscriptions.keys():
			if setting in subscriptions[top].keys():
				for item in subscriptions[top][setting]:
					if item[0] == object:
						if item[1] == method:
							subscriptions[top][setting].erase(item)
	
	static func __truncate_mod_id(mod_id:String) -> String:
		var pointers = non_static["pointers"].DataFormat
		mod_id = pointers.__array_to_string(mod_id.split("/"))
		mod_id = pointers.__array_to_string(mod_id.split(" "))
		return mod_id
	
	static func __truncate_section(section:String) -> String:
		return non_static["pointers"].DataFormat.__array_to_string(section.split("/"))
	
	static func __truncate_to_setting_entry(mod_id:String,section:String) -> String:
		var sect_name : String = __truncate_mod_id(mod_id) + "/" + __truncate_section(section)
		return sect_name
	
	static func __validate_dictionary(data_dict : Dictionary,check_config : bool = true, check_requirements : bool = true, check_incompatibilities : bool = true, config_entry_override : String = "config", mod_requirements_entry_override : String = "mod_requirements", mod_incompatibilities_entry_override : String = "mod_incompatibilities"):
		if data_dict == null:
			return false
		var ddk:Array = data_dict.keys()
		var pointers = non_static["pointers"].ManifestV2
		if check_config and config_entry_override in ddk and data_dict[config_entry_override] is Dictionary:
			var cfg:Dictionary = data_dict[config_entry_override]
			var config_id : String = cfg.get("id",cfg.get("mod",cfg.get("mod_id","")))
			var config_section : String = cfg.get("section","")
			var config_setting : String = cfg.get("entry",cfg.get("setting",cfg.get("key",cfg.get("value",cfg.get("opt","")))))
			var invert_config:bool = cfg.get("invert_config",cfg.get("invert",false))
			if config_id and config_section and config_setting:
				var cfg_opt = __get_value(config_id,config_section,config_setting)
				if cfg_opt != null:
					var how:bool = true
					if invert_config:
						if cfg_opt:
							how = false
					else:
						if !cfg_opt:
							how = cfg_opt
					if not how:
						return false
		if check_requirements and mod_requirements_entry_override in ddk and data_dict[mod_requirements_entry_override] is Array:
			var needs : Array = data_dict[mod_requirements_entry_override]
			var can:int = 0
			for a in needs:
				var tx = typeof(a)
				if tx == TYPE_ARRAY or tx == TYPE_STRING_ARRAY:
					for f in a:
						if pointers.__mod_exists(f):
							can += 1
			if can != needs.size():
				return false
		if check_incompatibilities and mod_incompatibilities_entry_override in ddk and data_dict[mod_incompatibilities_entry_override] is Array:
			var needs : Array = data_dict[mod_incompatibilities_entry_override]
			var can:int = 0
			for a in needs:
				var tx = typeof(a)
				if tx == TYPE_ARRAY or tx == TYPE_STRING_ARRAY:
					for f in a:
						if pointers.__mod_exists(f):
							can += 1
			if can == needs.size():
				return false
		return true
	
	static func __config_parse(file_path: String) -> Dictionary:
		var file:File = File.new()
		if not file.file_exists(file_path) and not ResourceLoader.exists(file_path):
			return {}
		var cfg:ConfigFile = ConfigFile.new()
		cfg.load(file_path)
		var cfg_sections : Array = cfg.get_sections()
		var cfg_dictionary : Dictionary = {}
		for section in cfg_sections:
			var data : Dictionary = {}
			for key in cfg.get_section_keys(section):
				data[key] = cfg.get_value(section,key)
			cfg_dictionary[section] = data
		return cfg_dictionary
	
	static func __config_store(dict : Dictionary,filepath:String):
		var cfg:ConfigFile = ConfigFile.new()
		for section in dict.keys():
			var keys = dict[section]
			for key in keys.keys():
				cfg.set_value(section,key,keys[key])
		cfg.save(filepath)
	
	
	
	
class _DataFormat:
	var scripts : Array = [
		
	]
	
	func get_class_documentation():
		return {
			"description":"Methods used to assist with the manipulation and loading of data",
			"methods":{
				"__array_to_string":{
					"description":"Converts an array into a string. Unlike String.join(), accepts any array type and will convert components to a string as best as possible.",
					"args":[
						"arr -> (Array) input array to be concatenated into a string"
					],
					"return":[
						"String containing the concatenated array"
					]
				},
				"__get_vanilla_version":{
					"description":"Fetches the game's current version. May break if any mods change the version label.",
					"return":[
						"Array containing the major, minor, and bugfix versions"
					]
				},
				"__sift_dictionary":{
					"description":"Checks a dictionary for any keys matching within an array.",
					"args":[
						"dictionary -> (Dictionary) the dictionary checked for keys",
						"search_keys -> (Array) containing all keys that are being looked for. Note that values for keys will also be checked as well"
					],
					"return":[
						"Array containing all found keys and values matching the searched keys array"
					]
				},
				"__convert_arr_to_vec2arr":{
					"description":"Converts an array containing integers and/or floats into a PoolVector2Array",
					"args":[
						"array -> (Array) for the data being converted into a PoolVector2Arr."
					],
					"return":[
						"PoolVector2Array for the output variables.",
						"NOTE: If the input array has an odd length, or contains any variables that are not of int/float type, the returning PoolVector2Array will be empty."
					]
				},
				"__compare_versions":{
					"description":"Compares two semantically formatted versions. Primary version must be equal or newer than the checked version to return true, otherwise returns false.",
					"args":[
						"primary_major -> (int) major version number of the primary version",
						"primary_minor -> (int) minor version number of the primary version",
						"primary_bugfix -> (int) bugfix version number of the primary version",
						"compare_major -> (int) major version number of the compared version",
						"compare_minor -> (int) minor version number of the compared version",
						"compare_bugfix -> (int) bugfix version number of the compared version",
					],
					"return":[
						"Bool that's true only when the primary version is equal or higher than the compared version"
					]
				},
				"__sift_ship_config":{
					"description":"Similar to __sift_dictionary, however assumes the dictionary is a ship config and returns the entries in a ship config-like format (i.e. cargo.equipment.SYSTEM_CARGO_MPU_BULK)",
					"args":[
						"dictionary -> (Dictionary) the ship config to sort through",
						"search_keys -> (Array) list of string entries to search for",
						"cfgs_to_ignore -> (Array) any keys within the config to remove from the search. Due to the way this works, it's highly recommended to do a deep duplication of the dictionary before searching.",
						"return_only_system_names (optional) -> (bool) whether the output array should ONLY be system names and not the entire config path. Defaults to false"
					],
					"return":[
						"Array of systems that exist within the dictionary, with the config directory attached."
					]
				},
				"__get_script_constant_map_without_load":{
					"description":"Similar to the Script.get_script_constant_map() method, however does not load the script and unlike that method is deterministic in the order of constants.",
					"args":[
						"script_path -> (String) for the file path to open"
					],
					"return":[
						"Dictionary containing each constant and it's value"
					]
				},
				"__get_script_variables_without_load":{
					"description":"Fetches the initial values of a script without loading it. NOTE: There may be issues with some variables that set their value on initialization.",
					"args":[
						"script_path -> (String) for the file path to open"
					],
					"return":[
						"Dictionary containing each variable and it's value"
					]
				},
				"__trim_scripts":{
					"description":"Opens a script and fetches information regarding variables and nodes without loading it.",
					"args":[
						"file_path -> (String) filepath of the script",
						"get_detailed_operands (optional) -> (bool) Whether any arguments and return types for methods or signals should be checked. Only use if you need it, as it slows down the process a lot. Defaults to `false`",
						"trim_unnecessary_newlines (optional) -> (bool) Whether the returned script should have any multiline variables (i.e. Arrays, Dictionaries, etc.) concatenated into a single line. Defaults to `false`",
						"recurse_through_base_scripts (optional) -> (bool) If the script extends from another script, this allows it to recurse through the extended script(s) to fetch information from those. NOTE: Scripts extended by mods do affect this. Defaults to `true`",
					],
					"return":[
						"Array containing several constituent parts for specific data types",
						" script -> (String) containing source code for the fetched script only containing variables, and constants from the script",
						" variables -> (Array) containing the names of all variables within the script",
						" constants -> (Array) containing the names of all constants within the script",
						" signals -> (Array) containing the names of all signals within the script",
						" methods -> (Array) containing the names of all methods within the script",
						" signal args -> (Array) of arrays containing the names of all arguments for the respective signal. The index of each array is respective of the index of the signal's name, and will be empty if the signal has no arguments",
						" method args -> (Array) of arrays containing the names and types for the respective method. The index of each array is respective of the index of the method's name, and will be empty if the method has no arguments. If an argument uses a specific type, will be formatted as `<arg name>: <arg type>`",
						" method return type -> (Array) of strings for the type that the method will return as. If not specified, will be blank. NOTE: If the method explicitely returns void, then it will state a void return type.",
					]
				},
				"__trim_script_object":{
					"description":"Identical to __trim_scripts, however file_path is replaced by script_source and uses a script object.",
					"args":[
						"script_source -> (Script) script object to be trimmed",
						"get_detailed_operands (optional) -> (bool) Whether any arguments and return types for methods or signals should be checked. Only use if you need it, as it slows down the process a lot. Defaults to `false`",
						"trim_unnecessary_newlines (optional) -> (bool) Whether the returned script should have any multiline variables (i.e. Arrays, Dictionaries, etc.) concatenated into a single line. Defaults to `false`",
						"recurse_through_base_scripts (optional) -> (bool) If the script extends from another script, this allows it to recurse through the extended script(s) to fetch information from those. NOTE: Scripts extended by mods do affect this. Defaults to `true`",
					],
					"return":[
						"Array containing several constituent parts for specific data types",
						" script -> (String) containing source code for the fetched script only containing variables, and constants from the script",
						" variables -> (Array) containing the names of all variables within the script",
						" constants -> (Array) containing the names of all constants within the script",
						" signals -> (Array) containing the names of all signals within the script",
						" methods -> (Array) containing the names of all methods within the script",
						" signal args -> (Array) of arrays containing the names of all arguments for the respective signal. The index of each array is respective of the index of the signal's name, and will be empty if the signal has no arguments",
						" method args -> (Array) of arrays containing the names and types for the respective method. The index of each array is respective of the index of the method's name, and will be empty if the method has no arguments. If an argument uses a specific type, will be formatted as `<arg name>: <arg type>`",
						" method return type -> (Array) of strings for the type that the method will return as. If not specified, will be blank. NOTE: If the method explicitely returns void, then it will state a void return type.",
					]
				},
				"__compile_script":{
					"description":"Compiles provided source code into a new script object",
					"args":[
						"source_code -> (String) the source code for the script"
					],
					"return":[
						"Script object using the provided source"
					]
				},
				"__compile_script_object":{
					"description":"Compiles provided source code into a new script and creates a new object from it. NOTE: This is a cached operation, and the provided object will be the same if generated from previous code unless set to use a new object.",
					"args":[
						"source_code -> (String) the source code for the script.",
						"params (optional) -> Any parameters for the object if needed by it's `_init` method. Multiple arguments can be passed by using an array. Defaults to `[]`",
						"new_object (optional) -> (bool) whether to create a new object instead of fetching the old one from the cache. Defaults to `false`",
					],
					"return":[
						"Object with the new script set as it's script"
					]
				},
				"__extend_script":{
					"description":"Extends a script from a filepath. Similar to the installScriptExtension method used in ModMain scripts",
					"args":[
						"file_path -> (String) file path for the script extension.",
					],
				},
				"__compile_and_extend_script":{
					"description":"Compiles a script and extends it. Similar to the installScriptExtension method used in ModMain scripts",
					"args":[
						"source_code -> (String) source code for the script extension.",
					],
				},
				"__extend_script_with_script_object":{
					"description":"Extends a script with a provided script object. Similar to the installScriptExtension method used in ModMain scripts.",
					"args":[
						"script -> (String) script object to extend the base script with.",
					],
				},
				"__compile_and_extend_script_with_scene":{
					"description":"Similar to __compile_and_extend_script, additionally creates and updates one or more scenes after overriding the script in case script needs to have scenes reloaded to apply the update.",
					"args":[
						"source_code -> (String) source code for the script extension.",
						"scene_path (optional) -> (String/PoolStringArray) String or PoolStringArray containing the file path or paths to scenes to be updated. Using array of paths will have them update in order. Defaults to `PoolStringArray()`"
					],
				},
				"__extend_script_with_script_object_and_scene":{
					"description":"Similar to __compile_and_extend_script_with_scene, using a script object to extend the script instead of compiling from source.",
					"args":[
						"source_code -> (String) script object to extend the base script with.",
						"scene_path (optional) -> (String/PoolStringArray) String or PoolStringArray containing the file path or paths to scenes to be updated. Using array of paths will have them update in order. Defaults to `PoolStringArray()`"
					],
				},
				"__override_script":{
					"description":"Overrides a script with another script.",
					"args":[
						"file_path -> (String) file path for the script extension.",
						"original_path -> (String) file path for the script to be overriden",
					],
				},
				"__compile_and_override_script":{
					"description":"Compiles a script and overrides the script at the provided path.",
					"args":[
						"source_code -> (String) source code for the script extension.",
						"original_path -> (String) file path for the script to be overriden",
					],
				},
				"__override_script_with_script_object":{
					"description":"Overrides a script with a provided script object.",
					"args":[
						"script -> (Script) script object to extend the base script with.",
						"original_path -> (String) file path for the script to be overriden",
					],
				},
				"__compile_and_override_script_with_scene":{
					"description":"Similar to __compile_and_override_script, additionally creates and updates one or more scenes after overriding the script in case script needs to have scenes reloaded to apply the update.",
					"args":[
						"source_code -> (String) source code for the script override.",
						"original_path -> (String) file path for the script to be overriden",
						"scene_path (optional) -> (String/PoolStringArray) String or PoolStringArray containing the file path or paths to scenes to be updated. Using array of paths will have them update in order. Defaults to `PoolStringArray()`"
					],
				},
				"__override_script_with_script_object_and_scene":{
					"description":"Similar to __compile_and_override_script_with_scene, using a script object to override the script instead of compiling from source.",
					"args":[
						"script -> (Script) script object to extend the base script with.",
						"original_path -> (String) file path for the script to be overriden",
						"scene_path (optional) -> (String/PoolStringArray) String or PoolStringArray containing the file path or paths to scenes to be updated. Using array of paths will have them update in order. Defaults to `PoolStringArray()`"
					],
				},
				"__reload_scene":{
					"description":"Recreates and updates a scene to load changed sub-resources",
					"args":[
						"scene_path -> (String) the file path to the scene to be updated.",
					],
				},
				"__replace_scene":{
					"description":"Compiles a scene, updates it's instance if an override path is provided, and returns it.",
					"args":[
						"scene_data -> (String) data for the scene stored as a string. This must be a valid scene structure for this operation to work.",
						"override_path (optional) -> (String) if provided, the file path to update a pre-existing scene with. Scene must be visible to the engine to be replaced. Defaults to ''",
						"scene_file_path (optional) -> (String) if set, defines a specific path to save the scene to. If left blank, instead stores it in the Variable_Fetch cache with a random name. Defaults to ''",
						"cache_scene (optional) -> (bool) whether to cache the file to prevent it from being garbage collected. Caching automatically happens if updating a file at override_path. Defaults to true."
					],
					"return":[
						"If the scene data was valid, a PackedScene as the compiled scene, otherwise null."
					]
				},
				"__replace_resource":{
					"description":"Sets the path for a resource to a specific path, equivalent to the replaceScene methods from modmains.",
					"args":[
						"resource_path -> (String) the file path of the scene or resource to be used to update the resource.",
						"original_path -> (String) the original file path of the scene to be updated.",
					],
				},
				"__convert_var_from_string":{
					"description":"Converts a string containing a variable in the literal sense (as if it were written in a script) into it's variant form. NOTE: Strings need to have their quotes inside the string quotes to be considered valid. E.g. `\"\"this is a string\"\"`, \"Vector2(1,2)\"",
					"args":[
						"string -> (String) the variable written in the literal sense as a string",
						"constant (optional) -> Whether the variable should use a constant or variant definition for it. Setting this to false can be useful if the desired output cannot be stored as a constant when in a script. Defaults to `true`",
					],
					"return":[
						"Variant from the literal conversion"
					]
				},
				"__load_if_can":{
					"description":"Loads a resource at the provided filepath and stores it, acting as a boolean to check if it exists or not. Stored objects will be initialized as null, and if the output of this method would be null, will be reflected by the last load.",
					"args":[
						"filepath -> (String) the file path to the desired resource to load",
						"override_cache (optional) -> (bool) whether to load the resource anew, ignoring the cache. Equivalent to the similar property for ResourceLoader.load(). NOTE: Setting this true can be problematic with extended scripts. Defaults to false",
						"type_hint (optional) -> (String) whether to define a specific resource type that this object has to be. Equivalent to the similar property for ResourceLoader.load(). Defaults to \"\"",
					],
					"return":[
						"Bool for whether the object was loaded or not."
					]
				},
				"__get_load":{
					"description":"Fetches the last object loaded by __load_if_can. Note that if the load failed or if the object is invalid, it will null the object, so make sure to use that method to confirm a load before trying to fetch the object.",
					"args":[
						"get_last_successful (optional) -> (bool) whether to get the last successfully loaded object by __load_if_can. Since this initializes as null, __load_if_can needs to have been successful at least once. Defaults to false",
					],
					"return":[
						"Bool for whether the object was loaded or not."
					]
				},
				"__is_valid_url":{
					"description":"Checks a provided URL to see if it's valid.",
					"args":[
						"URL -> (String) the URL to be checked",
					],
					"return":[
						"Bool for whether the URL is valid."
					]
				},
				"__loadDLC":{
					"description":"Clears cache as a fix for issues with loading DLC."
				},
				"__split_array_by_length":{
					"description":"splits a provided array (or array of any Pool type) into an array containing arrays of the input's type by the splitting ammount. Also lets you return one of these specific sections instead.",
					"args":[
						"arr -> (Array/PoolArray) input array for ",
						"length -> (int) the size of each section to be split into. If the array does not split evenly by this ammount, the last array will be the remainder",
						"specific_section (optional) -> (int) the index of the specific section to be fetched. If this value is out of bounds of the indeces of the usual output array, it will return an empty array. This can be useful to get specific parts of a very large array without needing to hang the game trying to fetch all at once. Defaults to `-1`",
					],
					"return":[
						"Array containing the arrays/pools for each section split by length",
						"If specific_section is set and in bounds of the usual output, will instead return the corresponding array/pool."
					]
				},
				"__stringify_property":{
					"description":"Converts a property into a string literal that can be used inside a script file.",
					"args":[
						"property -> (Variant) the property to be converted into a string literal.",
						"depth (optional) -> (int) for any array-like or dictionary properties, the base tab depth for the properties. If not doing anything clever, best leaving at default. Defaults to '0'.",
						"stringify (optional) -> (bool) whether the output should be encased in double quotes and ready to be inserted into a script file. Should only be disabled if the returned string is being added to another output. Defaults to 'true'.",
					],
					"return":[
						"String containing the property as could be inserted into a script file. Will still need property identifiers (var, const, etc.)"
					]
				},
				"__reserve_in_array":{
					"description":"A safer resize method for arrays that works on a relative size change, and initializes blank spaces with a blanked/zeroed value (or null for regular arrays). Can also reduce size safely and ensures the size never goes below zero. Returns null if inputting any non-array property.",
					"args":[
						"array -> (ANY Array/PoolArray) the array to be resized. Returns null if not an array constructor.",
						"count -> (int) the size to change the array by. Can be negative to reduce the size by X indeces.",
						"absolute (optional) -> (bool) whether count acts as the absolute size instead of the relative size change."
					],
					"return":[
						"Array/PoolArray of the respective input type with the readjusted size.",
						"null if `array` was not an array constructor."
					]
				},
				"__to_uint32":{
					"description":"Converts an integer into an unsigned 32 bit integer",
					"args":[
						"integer -> (int) the input integer"
					],
					"return":[
						"int for the unsigned 32 bit value"
					]
				},
				"__get_crc_32":{
					"description":"Calculates the 32-bit CRC checksum from a set of bytes",
					"args":[
						"bytes -> (PoolByteArray) bytes to generate the checksum from"
					],
					"return":[
						"int for the 32 bit checksum"
					]
				},
				"__get_uint32_from_buffer":{
					"description":"Fetches the next 32 bits from a PoolByteArray and provides it as an unsigned 32 bit int",
					"args":[
						"buffer -> (PoolByteArray) bytes to fetch the integer from",
						"offset (optional) -> (int) the position to offset the bytes to fetch. Defaults to 0"
					],
					"return":[
						"int for the unsigned 32 bit value"
					]
				},
				"__get_uint16_from_buffer":{
					"description":"Fetches the next 16 bits from a PoolByteArray and provides it as an unsigned 16 bit int",
					"args":[
						"buffer -> (PoolByteArray) bytes to fetch the integer from",
						"offset (optional) -> (int) the position to offset the bytes to fetch. Defaults to 0"
					],
					"return":[
						"int for the unsigned 16 bit value"
					]
				},
				"__decompress_raw_deflate_stream":{
					"description":"Decompresses a DEFLATE data stream without the header or uint32 Adler. PoolByteArray.decompress() requires the proper headers, which can't be created without knowing the decompressed data.",
					"args":[
						"buffer -> (PoolByteArray) bytes that form the DEFLATE stream",
						"max_size (optional) -> (int) if above zero, the maximum size for the output data. Use for potentially untrustworthy data. Defaults to 0"
					],
					"return":[
						"PoolByteArray for the raw, uncompressed data"
					]
				},
				"__compress_to_raw_deflate_stream":{
					"description":"Compresses a PoolByteArray to form a DEFLATE data stream without the header or uint32 Adler",
					"args":[
						"buffer -> (PoolByteArray) bytes for the raw, uncompressed data."
					],
					"return":[
						"PoolByteArray that form the DEFLATE stream"
					]
				},
			}
		}
	
	const non_statics:Dictionary = {}
	
	func _init(f):
		non_statics["pointers"] = f
		non_statics["miniz"] = load("res://HevLib/scripts/miniz/miniz.gdns").new()
		var urlRegex = RegEx.new()
		urlRegex.compile("^https?:\\/\\/(?:www\\.)?[-a-zA-Z0-9@:%._\\+~#=]{1,256}\\.[a-zA-Z0-9()]{1,63}\\b(?:[-a-zA-Z0-9()@:%_\\+.~#?&\\/=]*)$")
		non_statics["urlRegex"] = urlRegex
	
	var crcTable = load("res://HevLib/scripts/crc32cache.gd").new()
	
	const bitmask_uint8:int = 0xFF
	const bitmask_int8:int = 0x7F
	const bitmask_uint16:int = 0xFFFF
	const bitmask_int16:int = 0x7FFF
	const bitmask_uint32:int = 0xFFFFFFFF
	const bitmask_int32:int = 0x7FFFFFFF
	const bitmask_int64:int = 0x7FFFFFFFFFFFFFFF
	
	const bitmask_byte_1:int = 0x00000000000000FF
	const bitmask_byte_2:int = 0x000000000000FF00
	const bitmask_byte_3:int = 0x0000000000FF0000
	const bitmask_byte_4:int = 0x00000000FF000000
	const bitmask_byte_5:int = 0x000000FF00000000
	const bitmask_byte_6:int = 0x0000FF0000000000
	const bitmask_byte_7:int = 0x00FF000000000000
	const bitmask_byte_8:int = 0x7F00000000000000
	
	static func __array_to_string(arr: Array) -> String:
		return "".join(PoolStringArray(arr))
	
	const vanilla_version : PoolIntArray = PoolIntArray([1,0,0])
	static func __get_vanilla_version() -> PoolIntArray:
		if deep_equal(vanilla_version, PoolIntArray([1,0,0])):
			var lb : Node = load("res://VersionLabel.tscn").instance()
			var textData : PoolStringArray = lb.text.split(".",false)
			lb.queue_free()
			if textData.size() > 2:
				vanilla_version[0] = int(textData[0])
				vanilla_version[1] = int(textData[1])
				vanilla_version[2] = int(textData[2])
		return vanilla_version
	
	static func __sift_dictionary(dictionary: Dictionary,search_keys: Array) -> Array:
		var returning_keys : Array = []
		for key in dictionary.keys():
			if key in search_keys:
				returning_keys.append(key)
			var kdata = dictionary[key]
			if kdata in search_keys:
				returning_keys.append(kdata)
			if typeof(kdata) == TYPE_DICTIONARY:
				returning_keys.append_array(__sift_dictionary(kdata,search_keys))
		return returning_keys
	static func l(text:String,header:String = "pointers.DataFormat"):
		non_statics["pointers"].l(text,header)
	
	static func __convert_arr_to_vec2arr(array: Array) -> PoolVector2Array:
		var converted:PoolVector2Array = PoolVector2Array()
		var size:int = int(floor(array.size() / 2.0))
		converted.resize(size)
		for r in size:
			var index:int = r * 2
			var aRaw = array[index]
			var bRaw = array[index + 1]
			if not (aRaw is float or aRaw is int or aRaw is String):
				l("Cannot convert type [%s] for PoolVector2Array" % aRaw)
				return converted
			if not (bRaw is float or bRaw is int or bRaw is String):
				l("Cannot convert type [%s] for PoolVector2Array" % bRaw)
				return converted
			converted[r] = Vector2(float(aRaw),float(bRaw))
		return converted
	
	static func __compare_versions(primary_major : int,primary_minor : int,primary_bugfix : int, compare_major : int, compare_minor : int, compare_bugfix : int) -> bool:
		if primary_major < compare_major:
			return false
		elif primary_major == compare_major:
			if primary_minor < compare_minor:
				return false
			elif primary_minor == compare_minor:
				if primary_bugfix < compare_bugfix:
					return false
		return true
	
	static func __sift_ship_config(dictionary: Dictionary,search_keys: Array,cfgs_to_ignore:Array,return_only_system_names:bool = false,parent:String = "") -> Array:
		for i in cfgs_to_ignore:
			dictionary.erase(i)
		var arr : Array = []
		var splitter : String = "."
		var prefab : String = ""
		if parent:
			prefab = parent + splitter
		for key in dictionary.keys():
			var kdata = dictionary[key]
			match typeof(kdata):
				TYPE_STRING:
					if kdata in search_keys:
						if return_only_system_names:
							arr.append(kdata)
						else:
							arr.append(prefab + key + splitter + kdata)
				TYPE_DICTIONARY:
					arr.append_array(__sift_ship_config(kdata,search_keys,[],return_only_system_names,prefab + key))
		return arr
	
	static func __get_script_constant_map_without_load(script_path : String) -> Dictionary:
		var pathway : Array = __trim_scripts(script_path)
		if not pathway[2]: return {}
		var dict : Dictionary = {}
		var l : Dictionary = __compile_script(pathway[0]).get_script_constant_map()
		for i in pathway[2]:
			dict[i] = l[i]
		return dict
	
	static func __get_script_variables_without_load(script_path : String) -> Dictionary:
		var pathway : Array = __trim_scripts(script_path)
		if not pathway[1]: return {}
		var dict : Dictionary = {}
		var l = __compile_script_object(pathway[0])
		for i in pathway[1]:
			dict[i] = l.get(i)
		return dict
		
	const function_prefixes = PoolStringArray(["func ","static func ","remote func ","master func ","puppet func ","remotesync func ","mastersync func ","puppetsync func ","sync func "])
	const all_prefixes = PoolStringArray(["func ","static func ","remote func ","master func ","puppet func ","remotesync func ","mastersync func ","puppetsync func ","sync func ","onready ","var ","signal ","const ","export ","extends "])
	static func __trim_scripts(file_path : String, get_detailed_operands : bool = false, trim_unnecessary_newlines : bool = false, recurse_through_base_scripts : bool = true):
		if __load_if_can(file_path,false,"Script"):
			var script_source:Script = __get_load()
			if script_source:
				return __trim_script_object(script_source,get_detailed_operands,trim_unnecessary_newlines,recurse_through_base_scripts)
		return ["extends Node",[],[],[],[],[],[],[]]
	
	static func __trim_script_object(script_source : Script, get_detailed_operands : bool = false, trim_unnecessary_newlines : bool = false, recurse_through_base_scripts : bool = true):
		var concat : String = ""
		var var_names : Array = []
		var const_names : Array = []
		var method_names : Array = []
		var signal_names : Array = []
		var method_values : Array = []
		var method_output_type : Array = []
		var signal_values : Array = []
		if script_source:
			var extend_this:bool = true
			if recurse_through_base_scripts:
				var base_script:Script = script_source.get_base_script()
				if base_script:
					var base_data : Array = __trim_script_object(base_script,get_detailed_operands,trim_unnecessary_newlines,recurse_through_base_scripts)
					concat += base_data[0]
					if concat.find("extends ") > -1:
						extend_this = false
					if not concat.ends_with("\n"):
						concat += "\n"
					for i in base_data[1]:
						if not i in var_names:
							var_names.append(i)
					for i in base_data[2]:
						if not i in const_names:
							const_names.append(i)
					for f in base_data[3].size():
						var i = base_data[3][f]
						if not i in signal_names:
							signal_names.append(i)
							signal_values.append(base_data[5][f])
					for f in base_data[4].size():
						var i = base_data[4][f]
						if not i in method_names:
							method_names.append(i)
							method_values.append(base_data[6][f])
							method_output_type.append(base_data[7][f])
			var data : String = script_source.get_source_code()
			var streaming:bool = false
			var this_stream : String = ""
			var lines:PoolStringArray = data.split("\n")
			for line in lines:
				var result : String = ""
				var is_part_of_string:bool = false
				var prev_char_escape:bool = false
				while line != "":
					var part:String = line.substr(0,1)
					if part == "\\":
						prev_char_escape = !prev_char_escape
					else:
						prev_char_escape = false
					if part == "\"" and not prev_char_escape:
						is_part_of_string = !is_part_of_string
					if part == "#" and (not is_part_of_string and not prev_char_escape):
						break
					line.erase(0,1)
					result += part
				line = result
				var has_prefix:bool = false
				var has_sig:bool = false
				for prefix in function_prefixes:
					if line.begins_with(prefix):
						has_prefix = true
				if line.begins_with("signal "):
					has_sig = true
				if has_prefix:
					if streaming:
						concat += this_stream.strip_edges() + "\n"
						this_stream = ""
						streaming = false
					var av:PoolStringArray = line.split("func ")[1].split("(")
					var mname : String = av[0]
					if get_detailed_operands:
						var operands : String = line.split(mname)[1].strip_edges()
						var os:PoolStringArray = operands.split("->")
						var outputType : String = ""
						if os.size() > 1:
							outputType = os[1].rstrip(":")
							operands = os[0].strip_edges()
						if operands.begins_with("("):
							operands = operands.substr(1, operands.length())
						if operands.ends_with(":"):
							operands = operands.substr(0, operands.length() - 1)
						if operands.ends_with(")"):
							operands = operands.substr(0,operands.length() - 1)
						var opvalues : Array = []
						var thisOpValue : String = ""
						var colonDelim:bool = false
						var bracketDelim:bool = false
						for i in operands:
							if not colonDelim and i == ":":
								colonDelim = true
							if colonDelim and i == ",":
								colonDelim = false
							if not bracketDelim and i == "(":
								bracketDelim = true
							if bracketDelim and i == ")":
								bracketDelim = false
							if not bracketDelim and i == ",":
								opvalues.append(thisOpValue.strip_edges())
								thisOpValue = ""
							else:
								thisOpValue += i
						if thisOpValue:
							opvalues.append(thisOpValue.strip_edges())
							thisOpValue = ""
						method_values.append(opvalues)
						method_output_type.append(outputType.strip_edges())
					method_names.append(mname)
				elif has_sig:
					if streaming:
						concat += this_stream.strip_edges() + "\n"
						this_stream = ""
						streaming = false
					var av:PoolStringArray = line.split("signal ")[1].split("(")
					var sname : String = av[0]
					if get_detailed_operands:
						var op = []
						if av.size() > 1:
							var operands : String = av[1].rstrip(")")
							if operands:
								for o in operands.split(","):
									op.append(o.strip_edges())
						signal_values.append(op)
					signal_names.append(sname)
				elif line.begins_with("const "):
					if streaming:
						concat += this_stream.strip_edges() + "\n"
						this_stream = ""
						streaming = false
					var cname : String = line.split("=",false)[0].strip_edges().split("const ",true)[1].strip_edges().split(":",false)[0].strip_edges()
					const_names.append(cname)
					streaming = true
				elif line.begins_with("var "):
					if streaming:
						concat += this_stream.strip_edges() + "\n"
						this_stream = ""
						streaming = false
					var vname : String = line.split("=",false)[0].strip_edges().split("var ",true)[1].strip_edges().split(":",false)[0].strip_edges()
					var_names.append(vname)
					streaming = true
				elif line.begins_with("export ") and " var " in line:
					if streaming:
						concat += this_stream.strip_edges() + "\n"
						this_stream = ""
						streaming = false
					var vname : String = line.split("=",false)[0].strip_edges().split("var ",true)[1].strip_edges().split(":",false)[0].strip_edges()
					var_names.append(vname)
					streaming = true
				elif line.begins_with("onready ") and " var " in line:
					if streaming:
						concat += this_stream.strip_edges() + "\n"
						this_stream = ""
						streaming = false
					var vname : String = line.split("=",false)[0].strip_edges().split("var ",true)[1].strip_edges().split(":",false)[0].strip_edges()
					var_names.append(vname)
					streaming = true
				elif line.begins_with("extends "):
					if streaming:
						concat += this_stream.strip_edges() + "\n"
						this_stream = ""
						streaming = false
					if extend_this:
						streaming = true
				if streaming:
					this_stream = this_stream + "\n" + line
			if streaming:
				concat += this_stream.strip_edges() + "\n"
				this_stream = ""
				streaming = false
		if trim_unnecessary_newlines:
			var reconcat : String = ""
			for line in concat.split("\n"):
				var newline:bool = false
				var ls : String = line.strip_edges()
				for a in all_prefixes:
					if ls.begins_with(a):
						newline = true
				if newline and reconcat:
					ls = "\n" + ls
				reconcat += ls
			concat = reconcat
		return [concat if concat !="" else "extends Node",var_names,const_names,signal_names,method_names,signal_values,method_values,method_output_type]
	
	const compiled_scripts : Dictionary = {}
	const csk:Array = Array()
	const compiled_script_object_storage : Dictionary = {}
	const csosk:Array = Array()
	
	static func __compile_script(source_code : String) -> Script:
		var shash:int = hash(source_code)
		l("Compiling script resource [%d]" % shash)
		if shash in csk:
			l("Fetching from cache")
			return compiled_scripts[shash]
		var out:GDScript = GDScript.new()
		out.set_source_code(source_code)
		out.reload()
		compiled_scripts[shash] = out
		csk.append(shash)
		return out
	
	
	static func __compile_script_object(source_code : String, params = [],new_object : bool = false) -> Script:
		if not params is Array:
			params = [params]
		var shash : String = ""
		if params:
			shash = "%s_%s"% [hash(source_code) + hash(params)]
		else:
			shash = str(hash(source_code))
		l("Compiling script as object @ [%s]; parameters: %s, new object: %s" % [shash,params,new_object])
		if not new_object and shash in csosk:
			l("Fetching from cache")
			return compiled_script_object_storage[shash]
		
		var gd:GDScript = GDScript.new()
		gd.set_source_code(source_code)
		gd.reload()
		var out
		if params:
			var f:FuncRef = funcref(gd,"new")
			var param_part:String = "_%d"
			var pb:String = ""
			var pd:String = ""
			for i in params.size():
				var pv = param_part % i
				if pb:
					pb += "," + pv
				else:
					pb = pv
				if pd:
					pd += "\n\tvar %s = arr[%d]" % [pv,i]
				else:
					pd = "\n\tvar %s = arr[%d]" % [pv,i]
			var g:GDScript = GDScript.new()
			g.set_source_code("static func parse(ref,arr):%s\n\treturn ref.call_func(%s)" % [pd,pb])
			g.reload()
			g.new()
			out = g.parse(f,params)
		else:
			out = gd.new()
		compiled_script_object_storage[shash] = out
		csosk.append(shash)
		return out
	
	const _savedScriptObjects : Array = []
	
	static func __extend_script(file_path : String):
		l("Attempting to install script extension at [%s]" % file_path)
		if __load_if_can(file_path,false,"Script"):
			var sc:Script = __get_load()
			l("Script extension successful with length of %s, passing to compiler" % sc.get_source_code().length())
			__extend_script_with_script_object(sc)
	
	static func __compile_and_extend_script(source_code : String) -> void:
		l("Compiling script for script extension with length of %d" % source_code.length())
		non_statics["pointers"].equipment_modmain.installScriptExtensionFromSource(source_code)
	
	static func __extend_script_with_script_object(script : Script) -> void:
		l("Installing script extension with script %s" % str(script))
		non_statics["pointers"].equipment_modmain.installScriptExtensionFromScript(script)
	
	static func __compile_and_extend_script_with_scene(source_code : String, scene_path = [], override : bool = false) -> void:
		if not scene_path is Array and not scene_path is PoolStringArray:
			scene_path = PoolStringArray([scene_path])
		l("Attempting to compile and extend script (with scene override) with script of length %d, [%d] scene path(s) to reload" % [source_code.length(),scene_path.size()])
		__compile_and_extend_script(source_code)
		for i in scene_path.size():
			var sc:String = scene_path[i]
			l("Passing scene replacement [%s/%d] to reloader: %s" % [i,scene_path.size(),str(sc)])
			__reload_scene(sc,override)
	
	static func __extend_script_with_script_object_and_scene(script : Script, scene_path = [], override : bool = false) -> void:
		if not scene_path is Array and not scene_path is PoolStringArray:
			scene_path = PoolStringArray([scene_path])
		l("Attempting to extend script (with scene override) with script %s, [%d] scene path(s) to reload" % [str(script),scene_path.size()])
		__extend_script_with_script_object(script)
		for i in scene_path.size():
			var sc:String = scene_path[i]
			l("Passing scene replacement [%s/%d] to reloader: %s" % [i,scene_path.size(),sc])
			__reload_scene(sc,override)
	
	static func __override_script(script_path : String, original_path : String):
		l("Attempting to install script override @ [%s], overwriting [%s]" % [script_path,original_path])
		if __load_if_can(script_path,false,"Script"):
			var sc:Script = __get_load()
			l("Script override successful with length of %d, passing to compiler" % sc.get_source_code().length())
			__override_script_with_script_object(sc, original_path)
	
	static func __compile_and_override_script(source_code : String, original_path : String) -> void:
		l("Compiling script for script override overwriting [%s] with a length of %d" % [original_path,source_code.length()])
		non_statics["pointers"].equipment_modmain.installScriptOverrideFromSource(source_code, original_path)
	
	static func __override_script_with_script_object(script : Script, original_path : String) -> void:
		l("Installing script override with script %s, overwriting [%s]" % [str(script),original_path])
		non_statics["pointers"].equipment_modmain.installScriptOverrideFromScript(script, original_path)
	
	static func __compile_and_override_script_with_scene(source_code : String, original_path : String, scene_path = [], override : bool = false) -> void:
		if not scene_path is Array and not scene_path is PoolStringArray:
			scene_path = PoolStringArray([scene_path])
		l("Attempting to compile and overwrite [%s] (with scene override) with script of length %d, [%d] scene path(s) to reload" % [original_path,source_code.length(),scene_path.size()])
		__compile_and_override_script(source_code, original_path)
		for i in scene_path.size():
			var sc:String = scene_path[i]
			l("Passing scene replacement [%s/%d] to reloader: %s" % [i,scene_path.size(),str(sc)])
			__reload_scene(sc,override)
	
	static func __override_script_with_script_object_and_scene(script : Script, original_path : String, scene_path = [], override : bool = false) -> void:
		if not scene_path is Array and not scene_path is PoolStringArray:
			scene_path = PoolStringArray([scene_path])
		l("Attempting to override overwriting [%s] (with scene override) with script %s, [%d] scene path(s) to reload" % [original_path,str(script),scene_path.size()])
		__override_script_with_script_object(script, original_path)
		for i in scene_path.size():
			var sc:String = scene_path[i]
			l("Passing scene replacement [%s/%d] to reloader: %s" % [i,scene_path.size(),sc])
			__reload_scene(sc,override)
	
	static func __reload_scene(scene_path : String, override : bool = false):
		l("Attempting to reload scene at [%s]" % scene_path)
		if __load_if_can(scene_path,override,"PackedScene"):
			var scn = __get_load().instance()
			var root : String = scn.name
			if Tool.validex != null:
				Tool.remove(scn)
			else:
				if is_instance_valid(scn) and not scn.is_queued_for_deletion():
					scn.queue_free()
			var p : String = "[gd_scene load_steps=2 format=2]\n\n[ext_resource path=\"%s\" type=\"PackedScene\" id=1]\n\n[node name=\"%s\" instance=ExtResource( 1 )]" % [scene_path,root]
			l("Successfully found data for reloading scene with root [%s], passing to scene replacer" % root)
			__replace_scene(p,scene_path)
	
	static func __replace_resource(resource_path:String, original_path:String):
		if not ResourceLoader.exists(resource_path) or not ResourceLoader.exists(original_path):
			l("Cannot replace resource at [%s] as it either does not exist or is not visible to the engine" % resource_path)
			return
		l("Replacing resource at [%s] with [%s], passing to ModMain" % [original_path,resource_path])
		non_statics["pointers"].equipment_modmain.replaceSceneLiteral(resource_path,original_path)
	
	static func __replace_scene(scene_data:String,override_path:String = "",scene_file_path:String = "",cache_scene:bool = true) -> PackedScene:
		var scene_replacement : String = (scene_file_path) if scene_file_path else ("user://cache/.HevLib_Cache/Variable_Fetch/scene_replacement_%d.tscn" % Time.get_ticks_usec())
		l("__replace scene called with [override: %s / store path: %s / force cache: %s]" % [override_path,scene_replacement,str(cache_scene)])
		non_statics["pointers"].FolderAccess.__check_folder_exists("user://cache/.HevLib_Cache/Variable_Fetch")
		var file:File = File.new()
		file.open(scene_replacement,File.WRITE)
		file.store_string(scene_data)
		file.close()
		if override_path and ResourceLoader.exists(override_path):
			non_statics["pointers"].equipment_modmain.replaceSceneLiteral(scene_replacement,override_path)
		var scene : PackedScene = load(scene_replacement)
		var store:Array = non_statics["pointers"].equipment_modmain._savedObjects
		if cache_scene and not scene in store:
			store.append(scene)
		if scene and scene.can_instance():
			l("Successfully created scene")
			return scene
		l("Scene creation failed")
		return null
	
	const var_hash : Dictionary = {}
	const vhk:Array = Array()
	static func __convert_var_from_string(string : String, constant = true):
		var shash:int = hash(string + str(constant))
		if shash in vhk:
			return var_hash[shash]
		var header : String 
		if constant:
			header = "extends Reference\nconst VARIABLE = "
		else:
			header = "extends Reference\nvar VARIABLE = "
		var script = __compile_script_object(header + string)
		var variable = script.VARIABLE
		var_hash[shash] = variable
		vhk.append(shash)
		return variable
	
	const last_successful_object = [null]
	const last_load = [null]
	
	static func __load_if_can(filepath : String, override_cache : bool = false, type_hint : String = ""):
		if not filepath:
			return false
		if non_statics["pointers"].FileAccess.__file_exists(filepath):
			var obj = ResourceLoader.load(filepath,type_hint,override_cache)
			if obj:
				last_load[0] = obj
				last_successful_object[0] = obj
				return true
		last_load[0] = null
		return false
	
	static func __get_load(get_last_successful : bool = false):
		if get_last_successful:
			if not Tool.ovnolock(last_successful_object[0]):
				last_successful_object[0] = null
			return last_successful_object[0]
		if not Tool.ovnolock(last_load[0]):
			last_load[0] = null
		return last_load[0]
	
	
	static func __is_valid_url(URL:String) -> bool:
		return non_statics["urlRegex"].search(URL) != null
	
	static func __ensure_string_is_url(URL:String):
		if URL and not __is_valid_url(URL):
			if not URL.begins_with("https://"):
				if not URL.begins_with("//"):
					URL = "//" + URL
				if not URL.begins_with(":"):
					URL = ":" + URL
				if not URL.begins_with("https"):
					URL = "https" + URL
		return URL
	
	static func __loadDLC():
		l("Loading DLC as workaround")
		var DLCLoader:Settings = load("res://Settings.gd").new()
		DLCLoader.loadDLC()
		DLCLoader.queue_free()
		l("Finished loading DLC")
	
	static func __split_array_by_length(arr,length:int,specific_section = -1) -> Array:
		var out = []
		match typeof(arr):
			TYPE_ARRAY,TYPE_COLOR_ARRAY,TYPE_INT_ARRAY,TYPE_RAW_ARRAY,TYPE_REAL_ARRAY,TYPE_STRING_ARRAY,TYPE_VECTOR2_ARRAY,TYPE_VECTOR3_ARRAY:
				pass
			_:
				return out
		var arrsize = arr.size()
		if arrsize < length:
			return arr
		if specific_section >= 0:
			var sections = int(ceil(arrsize/float(length)))
			if specific_section > sections:
				return out[0]
			match typeof(arr):
				TYPE_ARRAY:
					out = []
				TYPE_COLOR_ARRAY:
					out = PoolColorArray()
				TYPE_INT_ARRAY:
					out = PoolIntArray()
				TYPE_RAW_ARRAY:
					out = PoolByteArray()
				TYPE_REAL_ARRAY:
					out = PoolRealArray()
				TYPE_STRING_ARRAY:
					out = PoolStringArray()
				TYPE_VECTOR2_ARRAY:
					out = PoolVector2Array()
				TYPE_VECTOR3_ARRAY:
					out = PoolVector3Array()
			var offset = (specific_section * length)
			for i in min(arrsize - offset,length):
				out.append(arr[i + offset])
			return out
		for i in int(ceil(arrsize / float(length))):
			match typeof(arr):
				TYPE_ARRAY:
					out.append([])
				TYPE_COLOR_ARRAY:
					out.append(PoolColorArray())
				TYPE_INT_ARRAY:
					out.append(PoolIntArray())
				TYPE_RAW_ARRAY:
					out.append(PoolByteArray())
				TYPE_REAL_ARRAY:
					out.append(PoolRealArray())
				TYPE_STRING_ARRAY:
					out.append(PoolStringArray())
				TYPE_VECTOR2_ARRAY:
					out.append(PoolVector2Array())
				TYPE_VECTOR3_ARRAY:
					out.append(PoolVector3Array())
		for r in arrsize:
			var current_part = int(floor(r / float(length)))
			var ipart = out[current_part]
			ipart.append(arr[r])
			out[current_part] = ipart
		return out
	
	static func __compress_text(txt:String) -> String:
		var utf8 = txt.to_utf8()
		var size = utf8.size()
		var compressed = utf8.compress(1)
		var concat:String = ""
		for i in compressed:
			if concat:
				concat += "," + str(i)
			else:
				concat = str(i)
		return "PoolByteArray([%s]).decompress(%d,1)" % [concat,size]
	
	static func __stringify_property(property,depth:int = 0,stringify:bool = true):
		var out = ""
		var type = typeof(property)
		match type:
			TYPE_NIL:
				out = "null"
			TYPE_ARRAY,TYPE_COLOR_ARRAY,TYPE_INT_ARRAY,TYPE_RAW_ARRAY,TYPE_REAL_ARRAY,TYPE_STRING_ARRAY,TYPE_VECTOR2_ARRAY,TYPE_VECTOR3_ARRAY:
				var l = ""
				match type:
					TYPE_ARRAY:
						l = "%s"
					TYPE_COLOR_ARRAY:
						l = "PoolColorArray(%s)"
					TYPE_INT_ARRAY:
						l = "PoolIntArray(%s)"
					TYPE_RAW_ARRAY:
						l = "PoolByteArray(%s)"
					TYPE_REAL_ARRAY:
						l = "PoolRealArray(%s)"
					TYPE_STRING_ARRAY:
						l = "PoolStringArray(%s)"
					TYPE_VECTOR2_ARRAY:
						l = "PoolVector2Array(%s)"
					TYPE_VECTOR3_ARRAY:
						l = "PoolVector3Array(%s)"
					
				if property.empty():
					if type == TYPE_ARRAY:
						out = "[]"
					else:
						out = l % ""
				else:
					l = l % "[%s\n%s]"
					var combine = ""
					var nd = depth + 1
					var tabs = ""
					var etabs = ""
					for i in depth:
						etabs += "\t"
					for i in nd:
						tabs += "\t"
					for i in property:
						var r = __stringify_property(i,nd,false)
						var p = tabs + r
						if combine:
							combine += ","
						combine += "\n%s" % p
					out = l % [combine,etabs]
			TYPE_BOOL:
				out = ("true") if property else ("false")
			TYPE_COLOR:
				out = "Color( %s, %s, %s, %s )" % [property.r,property.g,property.b,property.a]
			TYPE_DICTIONARY:
				if property.empty():
					out = "{}"
				else:
					var l = "{%s\n%s}"
					var st = ""
					var nd = depth + 1
					var tabs = ""
					var etabs = ""
					for i in depth:
						etabs += "\t"
					for i in nd:
						tabs += "\t"
					for key in property:
						var item = "%s:%s" % [__stringify_property(key,depth,false),__stringify_property(property[key],nd,false)]
						var p = tabs + item
						if st:
							st += ","
						st += "\n%s" % p
					out = l % [st,etabs]
			TYPE_INT,TYPE_REAL:
				out = str(property)
			TYPE_NODE_PATH:
				out = "NodePath( %s )" % str(property)
			TYPE_RECT2:
				out = "Rect2( %s, %s, %s, %s )" % [property.position.x,property.position.y,property.size.x,property.size.y]
			TYPE_STRING:
				out = "\"%s\"" % property
			TYPE_TRANSFORM2D:
				out = "Transform2D( %s, %s, %s )" % [__stringify_property(property.x,depth,false),__stringify_property(property.y,depth,false),__stringify_property(property.origin,depth,false)]
			TYPE_VECTOR2:
				out = "Vector2( %s, %s )" % [property.x,property.y]
			TYPE_VECTOR3:
				out = "Vector3( %s, %s, %s )" % [property.x,property.y,property.z]
			TYPE_AABB:
				out = "AABB( %s, %s )" % [__stringify_property(property.position,depth,false),__stringify_property(property.size,depth,false)]
			TYPE_BASIS:
				out = "Basis( %s, %s, %s )" % [__stringify_property(property.x,depth,false),__stringify_property(property.y,depth,false),__stringify_property(property.z,depth,false)]
			TYPE_PLANE:
				out = "Plane( %s, %s )" % [__stringify_property(property.normal,depth,false),property.d]
			TYPE_QUAT:
				out = "Quat( %s, %s, %s, %s )" % [property.x,property.y,property.z,property.w]
			TYPE_TRANSFORM:
				out = "Transform( %s, %s )" % [__stringify_property(property.basis,depth,false),__stringify_property(property.origin,depth,false)]
			_:
				printerr("Property ",property," uses type not currently supported")
		if stringify:
			out = "\"%s\"" % out
		return out
	
	static func __reserve_in_array(array,count:int,absolute:bool = false):
		match typeof(array):
			TYPE_ARRAY:
				var size = array.size()
				if absolute:
					size = 0
				var new_count = max(size + count,0)
				array.resize(new_count)
				if new_count > size:
					for i in (new_count - size):
						array[i + size] = null
			TYPE_COLOR_ARRAY:
				var size = array.size()
				if absolute:
					size = 0
				var new_count = max(size + count,0)
				array.resize(new_count)
				if new_count > size:
					for i in (new_count - size):
						array[i + size] = Color.black
			TYPE_INT_ARRAY:
				var size = array.size()
				if absolute:
					size = 0
				var new_count = max(size + count,0)
				array.resize(new_count)
				if new_count > size:
					for i in (new_count - size):
						array[i + size] = 0
			TYPE_RAW_ARRAY:
				var size = array.size()
				if absolute:
					size = 0
				var new_count = max(size + count,0)
				array.resize(new_count)
				if new_count > size:
					for i in (new_count - size):
						array[i + size] = 0x0
			TYPE_REAL_ARRAY:
				var size = array.size()
				if absolute:
					size = 0
				var new_count = max(size + count,0)
				array.resize(new_count)
				if new_count > size:
					for i in (new_count - size):
						array[i + size] = 0.0
			TYPE_STRING_ARRAY:
				var size = array.size()
				if absolute:
					size = 0
				var new_count = max(size + count,0)
				array.resize(new_count)
				if new_count > size:
					for i in (new_count - size):
						array[i + size] = ""
			TYPE_VECTOR2_ARRAY:
				var size = array.size()
				if absolute:
					size = 0
				var new_count = max(size + count,0)
				array.resize(new_count)
				if new_count > size:
					for i in (new_count - size):
						array[i + size] = Vector2.ZERO
			TYPE_VECTOR3_ARRAY:
				var size = array.size()
				if absolute:
					size = 0
				var new_count = max(size + count,0)
				array.resize(new_count)
				if new_count > size:
					for i in (new_count - size):
						array[i + size] = Vector3.ZERO
			_:
				return null
		return array
	
	static func __to_uint32(integer:int) -> int:
		return integer & bitmask_uint32
	
	static func __get_crc_32(bytes: PoolByteArray) -> int:
		return non_statics["miniz"].crc32(bytes)
	
	static func __get_uint32_from_buffer(buffer: PoolByteArray, offset: int = 0) -> int:
		return buffer[offset] | (buffer[offset + 1] << 8) | (buffer[offset + 2] << 16) | (buffer[offset + 3] << 24)
	
	static func __get_uint16_from_buffer(buffer: PoolByteArray, offset: int = 0) -> int:
		return buffer[offset] | (buffer[offset + 1] << 8)
	
	static func __decompress_raw_deflate_stream(data: PoolByteArray, max_size:int = 0) -> PoolByteArray:
		return non_statics["miniz"].decompress_zlib(data,max_size)
	
	static func __compress_to_raw_deflate_stream(data: PoolByteArray,compression_level:int = 6) -> PoolByteArray:
		var miniz = non_statics["miniz"]
		miniz.compression_level = compression_level
		return miniz.compress_zlib(data)
	
	static func __store_8_in_buffer(byte:int,buffer:PoolByteArray = PoolByteArray()) -> PoolByteArray:
		buffer.append(byte % bitmask_uint8)
		return buffer
	
	static func __store_16_in_buffer(byte:int,buffer:PoolByteArray = PoolByteArray(),little_endian:bool = true) -> PoolByteArray:
		byte %= bitmask_uint16
		var first = byte & bitmask_byte_1
		var second = (byte & bitmask_byte_2) >> 8
		if little_endian:
			buffer.append(first)
			buffer.append(second)
		else:
			buffer.append(second)
			buffer.append(first)
		return buffer
	
	static func __store_32_in_buffer(byte:int,buffer:PoolByteArray = PoolByteArray(),little_endian:bool = true) -> PoolByteArray:
		byte %= bitmask_uint32
		var first = byte & bitmask_byte_1
		var second = (byte & bitmask_byte_2) >> 8
		var third = (byte & bitmask_byte_3) >> 16
		var fourth = (byte & bitmask_byte_4) >> 24
		if little_endian:
			buffer.append(first)
			buffer.append(second)
			buffer.append(third)
			buffer.append(fourth)
		else:
			buffer.append(fourth)
			buffer.append(third)
			buffer.append(second)
			buffer.append(first)
		return buffer
	
	static func __store_64_in_buffer(byte:int,buffer:PoolByteArray = PoolByteArray(),little_endian:bool = true) -> PoolByteArray:
		byte %= bitmask_int64
		var first = byte & bitmask_byte_1
		var second = (byte & bitmask_byte_2) >> 8
		var third = (byte & bitmask_byte_3) >> 16
		var fourth = (byte & bitmask_byte_4) >> 24
		var fifth = (byte & bitmask_byte_5) >> 32
		var sixth = (byte & bitmask_byte_6) >> 40
		var seventh = (byte & bitmask_byte_7) >> 48
		var eighth = (byte & bitmask_byte_8) >> 56
		if little_endian:
			buffer.append(first)
			buffer.append(second)
			buffer.append(third)
			buffer.append(fourth)
			buffer.append(fifth)
			buffer.append(sixth)
			buffer.append(seventh)
			buffer.append(eighth)
		else:
			buffer.append(eighth)
			buffer.append(seventh)
			buffer.append(sixth)
			buffer.append(fifth)
			buffer.append(fourth)
			buffer.append(third)
			buffer.append(second)
			buffer.append(first)
		return buffer


class _DriverManagement:
	var scripts : Array = [
		
	]
	
	static func get_class_documentation():
		return {
			"description":"Contains methods used to fetch driver information from mods",
			"methods":{
				"__get_drivers":{
					"description":"Fetches driver data from the filesystem",
					"args":[
						"get_ids (optional) -> (Array) mod IDs to fetch specific drivers from. If left empty, fetches all drivers. Defaults to `[]`"
					],
					"return":[
						"Array of dictionaries for each mod's drivers, with each dictionary being formatted as such:",
						" drivers -> dictionary containing all drivers for the specific mod, with each entry formatted as such: {<driver name (String, e.g. ADD_EQUIPMENT_ITEMS.gd)>:<driver contents (Dictionary)>}",
						" id -> (String) ID of this mod. Not present if the mod doesn't have an ID.",
						" priority -> (int) mod's priority. Will be zero if not defined in the mod main.",
						" mod_directory -> (String) the path to the mod's directory, or where the ModMain.gd file exists in",
					]
				},
				"__get_drivers_from_modmain_path":{
					"description":"Fetches drivers from a ModMain.gd filepath",
					"args":[
						"file_path -> (String) the filepath to the ModMain.gd file",
						"get_fresh_drivers (optional) -> (bool) since drivers are cached, whether the cache should be renewed and refetch drivers. Defaults to `false`"
					],
					"return":[
						"Dictionary with each driver script name as a key, with a dictionary containing it's constant map as the respective value."
					]
				},
				"__is_driver_file":{
					"description":"Checks a provided filepath to see if it's a driver file or not",
					"args":[
						"file_path -> (String) the filepath to check. Does not need to exist, rather just if it could be a valid driver."
					],
					"return":[
						"bool for whether the filepath is a valid driver or not"
					]
				}
			}
		}
	
	
	const non_static = {}
	func _init(f):
		non_static["pointers"] = f
		var driver_file_regex = RegEx.new()
		driver_file_regex.compile("[a-z]")
		non_static["regex"] = driver_file_regex
		non_static["self"] = self
	
	static func __get_drivers(get_ids : Array = []) -> Array:
		var base = non_static["self"]
		var mod_drivers : Array = []
		var pointers = non_static["pointers"]
		for modmain_path in (pointers.ManifestV2.__get_modmain_files() + pointers.ManifestV2.__get_modlet_files()):
			var has_manifest:bool = false
			var manifest_path : String = ""
			var modFolder : String = modmain_path.get_base_dir() + "/"
			var modFile : String = modmain_path.get_file().to_lower()
			if modFile.begins_with("mod") and modFile.ends_with(".manifest"):
				has_manifest = true
				manifest_path = modmain_path
			else:
				for item in pointers.FolderAccess.__fetch_folder_files(modFolder,false,true):
					var modEntryName = item.get_file().to_lower()
					if modEntryName.begins_with("mod") and modEntryName.ends_with(".manifest"):
						has_manifest = true
						manifest_path = item
			if not has_manifest:
				continue
			var this_mod_data : Dictionary = {}
			var manifest : Dictionary = pointers.ManifestV2.__parse_file_as_manifest(manifest_path)
			var mrv:Dictionary = manifest.get("manifest_definitions",{})
			var manifest_ver : float = mrv.get("manifest_version",1.0)
			if manifest_ver < 2.2:
				continue
			var id : String = manifest.get("mod_information",{}).get("id","")
			if not id:
				continue
			this_mod_data["id"] = id
			
			this_mod_data["priority"] = mrv.get("modlet_priority",0)
			
			this_mod_data["drivers"] = __get_drivers_from_modmain_path(modmain_path,false,manifest_ver >= 2.3)
			
			this_mod_data["mod_directory"] = modFolder
			if this_mod_data["drivers"]:
				if (not get_ids) or (get_ids and id in get_ids):
					mod_drivers.append(this_mod_data)
		
		mod_drivers.sort_custom(base,"compare_driver_dictionaries")
		return mod_drivers.duplicate(true)
	
	static func compare_driver_dictionaries(a, b):
		var aPrio:int = a.get("priority",0)
		var bPrio:int = b.get("priority",0)
		if aPrio != bPrio:
			return aPrio < bPrio
		
		var aPath : String = a.get("mod_directory","")
		var bPath : String = b.get("mod_directory","")
		if aPath != bPath:
			return aPath < bPath

		return false
	
	const driver_get_cache : Dictionary = {}
	const dgck:Array = Array()
	const driver_ext = PoolStringArray([
		"gd",
		"gdc",
	])
	
	const driver_dirs = PoolStringArray([
		"HEVLIB_EQUIPMENT_DRIVER_TAGS/",
		"HEVLIB_MENU/",
		"HEVLIB_MINERAL_DRIVER_TAGS/",
		"HEVLIB_DRIVERS/",
	])
	
	static func __get_drivers_from_modmain_path(file_path : String, get_fresh_drivers : bool = false, require_uid_check : bool = false):
		var file:File = File.new()
		if get_fresh_drivers or not file_path in dgck:
			var this_mod_data : Dictionary = {}
			if not file.file_exists(file_path):
				return {}
			var pointers:HevLibPointers = non_static["pointers"]
			var uid_path : String = "res://%s/.uid/.%%s.uid" % file_path.split("/",false)[1]
			var folder_path : String = file_path.get_base_dir() + "/"
			var folderCheck : Array = pointers.FolderAccess.__fetch_folder_files(folder_path,true)
			for driverDir in driver_dirs:
				if driverDir in folderCheck:
					var driverFolder : String = folder_path + driverDir
					for driver in pointers.FolderAccess.__fetch_folder_files(driverFolder):
						var driver_filepath : String = driverFolder + driver
						if __is_driver_file(driver_filepath):
							if require_uid_check:
								var druid : String = uid_path % driver_filepath.sha256_text()
								if not file.file_exists(druid) or pointers.FileAccess.__get_file_content(druid) != pointers.FileAccess.__get_uid_of_file(driver_filepath):
									continue
							this_mod_data[driver] = {}
							var consts : Dictionary = pointers.DataFormat.__get_script_constant_map_without_load(driver_filepath)
							for i in consts.keys():
								this_mod_data[driver][i] = consts[i]
			driver_get_cache[file_path] = this_mod_data
			dgck.append(file_path)
		return driver_get_cache[file_path].duplicate(true)
	
	
	
	static func __is_driver_file(file_path:String) -> bool:
		var fext:String = file_path.get_extension()
		if(fext in driver_ext and file_path.get_base_dir().split("/")[-1] + "/" in driver_dirs and not non_static["regex"].search(file_path.get_file().rstrip("." + fext))):
			return true
		return false
	

class _Equipment:
	var scripts : Array = [
		
	]
	static func get_class_documentation():
		return {
			"description":"Contains internal methods used for creating equipment scenes. Use at your own discretion",
			"methods":{
				"__make_upgrades_scene":{
					"description":"Internal method that initializes and creates multiple scene and script handles, as well as data caches, all used by equipment-adjacent processes.",
				},
				"__make_equipment_for_scene":{
					"description":"Internal method for creating a scene string for an equipment item to be added to an Upgrades.tscn scene package.",
					"args":[
						"equipment_data -> (Dictionary) the dictionary containing equipment item data",
						"slot_node_name -> (String) the node name for the slot the equipment is being added to",
						"system_slot -> (String) the ship slot the equipment is being added to"
					],
					"return":[
						"String containing a full equipment item"
					]
				},
				"__make_slot_for_scene":{
					"description":"Internal method for creating a scene string for a slot to be added to an Upgrades.tscn scene package.",
					"args":[
						"slot_data -> (Dictionary) dictionary containing slot data"
					],
					"return":[
						"Array containing a full slot item"
					]
				},
			}
		}
	
	var vanilla_equipment : Dictionary
	var vanilla_data = load("res://HevLib/scenes/equipment/vanilla_defaults/slot_tagging.gd")
	var hardpoint_types : Array
	var alignments : Array
	var equipment_types : Array
	var slot_types : Array
	var slot_defaults : Dictionary
	var vanilla_equipment_defaults_for_reference : Dictionary

	var file:File = File.new()
	
	var pointers:HevLibPointers
	
	func _init(d):
		pointers = d
		
		vanilla_equipment = pointers.DataFormat.__get_script_constant_map_without_load("res://HevLib/scenes/equipment/vanilla_defaults/equipment.gd")
		hardpoint_types = vanilla_data.hardpoint_types.duplicate(true)
		alignments = vanilla_data.alignments.duplicate(true)
		equipment_types = vanilla_data.equipment_types.duplicate(true)
		slot_types = vanilla_data.slot_types.duplicate(true)
		slot_defaults = vanilla_data.slot_defaults.duplicate(true)
		vanilla_equipment_defaults_for_reference = vanilla_data.vanilla_equipment_defaults_for_reference.duplicate(true)
	
	# DATA SERIALIZATION STORAGE
	var ship_equipment_template_internals : Dictionary = {}
	var ship_equipment_modification_internals : Dictionary = {}
	var ship_equipment_modification_internals_completed : Dictionary = {}
	var ws_stuff_to_add : Array = []
	var ws_stuff_to_modify : Array = []
	var add_ships_store : Array = []
	var ship_build_mod_store : Array = []
	var register_ship_numerics_store : Dictionary = {}
	var weaponslot_modify_templates:Dictionary = {}
	var weaponslot_modify_standalone:Dictionary = {}
	var weaponslot_ship_templates:Dictionary = {}
	var weaponslot_ship_standalone:Dictionary = {}
	var ws_equipment_names:Array = []
	var equipment_slot_order:Array = []
	var relative_equipment_slot_order:Dictionary = {}
	var save_button_cache:Array = []
	var processed_storage_mods:Dictionary = {}
	var node_definitions_cache:Dictionary = {}
	var ship_node_register:Array = []
	var auxslot_data:Dictionary = {}
	var ship_node_modify:Dictionary = {}
	var ship_thruster_colors:Dictionary = {}
	var modify_ship_numerics:Dictionary = {}
	var namer_store:Dictionary = {"crew":[],"ships":[],"remove_crew":[],"remove_ships":[]}
	var processed_storage_systems:Array = []
	var drone_delivery_speed:Dictionary = {}
	var event_driver_event_entries:Array = []
	var rpc_second_state_store:Dictionary = {"ring":[],"enceladus_prime":[],"title_screen":[]}
	var rpc_non_autoload_object_persist:Dictionary = {}
	
	var ADD_EQUIPMENT_ITEMS:Array = []
	var ADD_EQUIPMENT_SLOTS:Array = []
	var EQUIPMENT_TAGS:Array = []
	var SLOT_TAGS:Array = []
	var AUX_POWER_AND_THRUSTERS:Array = []
	var WEAPONSLOT_ADD:Array = []
	
	var research_store : Dictionary = {}
	# END OF DATA STORAGE
	
	var equipment_validity_for_slots:Dictionary = {}
	
	var AUTOLOAD_REF_STORE:Dictionary = {}
	
	var version : PoolIntArray = PoolIntArray([1,0,0])
	
	var validation_check_path:String = "user://cache/.HevLib_Cache/SafeMode/recache_validation.json"
	
	func __make_upgrades_scene():
		
		var exhaust_cache_path : String = "user://cache/.HevLib_Cache/AuxAndThrusterDriver/"
		pointers.FolderAccess.__check_folder_exists(exhaust_cache_path)
		
		version = pointers.DataFormat.__get_vanilla_version()
		pointers.l("observed game version of %s" % str(version),"pointers.Equipment")
		
		var UpgradeMenu : Node = load("res://enceladus/Upgrades.tscn").instance()
		var nodes_parent:Node = UpgradeMenu.get_node("VB/MarginContainer/ScrollContainer/MarginContainer/Items")
		var vanilla_slot_names : Array = []
		var vanilla_slot_types : Dictionary = {}
		
		for slot in nodes_parent.get_children():
			var children : Array = slot.get_node("VBoxContainer").get_children()
			if children.size() < 2:
				continue
			var iname:String = slot.name
			vanilla_slot_names.append(iname)
			var sys_slot : String = slot.slot
			var index:int = 1
			while not sys_slot:
				sys_slot = children[index].slot
				index += 1
			vanilla_slot_types[iname] = sys_slot
		
		var ws_default_templates : Dictionary = pointers.DataFormat.__get_script_constant_map_without_load("res://HevLib/scenes/weaponslot/data_storage/templates.gd") #load("res://HevLib/scenes/weaponslot/data_storage/templates.gd").get_script_constant_map()
		var ws_ship_templates : Dictionary = pointers.DataFormat.__get_script_constant_map_without_load("res://HevLib/scenes/weaponslot/data_storage/ship_templates.gd") #load("res://HevLib/scenes/weaponslot/data_storage/ship_templates.gd").get_script_constant_map()
		var ws_ship_templates_2 : Dictionary = pointers.DataFormat.__get_script_constant_map_without_load("res://HevLib/scenes/weaponslot/data_storage/ship_templates_2.gd") #load("res://HevLib/scenes/weaponslot/data_storage/ship_templates_2.gd").get_script_constant_map()
		var ship_register : Dictionary = pointers.DataFormat.__get_script_constant_map_without_load("res://HevLib/scenes/equipment/ShipModificationDriver/ship_register_vanilla.gd") #load("res://HevLib/scenes/equipment/ShipModificationDriver/ship_register_vanilla.gd").get_script_constant_map()
		for item in ship_register.keys():
			ship_node_register.append(ship_register[item])
		
		weaponslot_modify_templates = ws_default_templates.get("TEMPLATES", {})
		weaponslot_ship_templates = ws_ship_templates_2.get("SHIP_TEMPLATES",{})
		weaponslot_ship_standalone = ws_ship_templates.get("SHIP_MODIFY",{})
		
		var drivers : Dictionary = {}
		var mods : Dictionary = pointers.ManifestV2.__get_mod_data()
		for md in pointers.ManifestV2.__get_mod_list_keys():
			var mod_id:String = pointers.ManifestV2.__match_mod_file_path_to_id(md)
			if mod_id:
				var mod = mods[md]
				if "drivers" in mod.keys() and mod.drivers:
					drivers[mod_id] = mod.drivers
		mods.clear()
		
		for i in ProjectSettings.get_property_list():
			if i.name.begins_with("autoload/"):
				var autoName = i.name.split("autoload/")[1]
				AUTOLOAD_REF_STORE[autoName] = CurrentGame.get_node("/root/" + autoName)
		for i in pointers.Classes:
			AUTOLOAD_REF_STORE["pointers." + i] = pointers.Classes[i]
		AUTOLOAD_REF_STORE["pointers"] = pointers
		
		for i in vanilla_equipment.keys():
			var item = vanilla_equipment[i]
			var sys = item.get("system")
			if sys:
				var type = item.get("equipment_type")
				if not sys in equipment_validity_for_slots.keys():
					equipment_validity_for_slots[sys] = []
				if type and not type in equipment_validity_for_slots[sys]:
					equipment_validity_for_slots[sys].append(type)
		
		for mod_id in drivers.keys():
			var cvh:Dictionary = drivers[mod_id]
			for last_bit in cvh.keys():
				var constants : Dictionary = cvh[last_bit]
				var constKeys:Array = constants.keys()
				match last_bit:
					"ADD_EQUIPMENT_ITEMS.gd":
						for item in constKeys:
							var equipment = constants.get(item)
							var eqkeys:Array = equipment.keys()
							if pointers.ConfigDriver.__validate_dictionary(equipment,false):
								match equipment.get("slot_type","HARDPOINT"):
									"HARDPOINT":
										if "weapon_slot" in eqkeys:
											var obj : Dictionary = equipment.get("weapon_slot").duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(obj,false):
												var wname : String = equipment.get("system","")
												var wprice:int = equipment.get("price",0)
												var objdata : Array = obj.get("data",[])
												var has_price:bool = false
												if not "name" in obj.keys():
													obj["name"] = wname
												for d in objdata:
													if d.get("property","") == "repairReplacementPrice":
														d["value"] = wprice
														has_price = true
												if not has_price:
													objdata.append({
														"property":"repairReplacementPrice",
														"value":wprice
													})
												obj["data"] = objdata.duplicate(true)
												WEAPONSLOT_ADD.append(obj)
										if "WEAPONSLOT_ADD" in eqkeys:
											var obj : Dictionary = equipment.get("WEAPONSLOT_ADD").duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(obj,false):
												var wname : String = equipment.get("system","")
												var wprice:int = equipment.get("price",0)
												var objdata : Array = obj.get("data",[])
												var has_price:bool = false
												if not "name" in obj.keys():
													obj["name"] = wname
												for d in objdata:
													if d.get("property","") == "repairReplacementPrice":
														d["value"] = wprice
														has_price = true
												if not has_price:
													objdata.append({
														"property":"repairReplacementPrice",
														"value":wprice
													})
												obj["data"] = objdata.duplicate(true)
												WEAPONSLOT_ADD.append(obj)
									"MASS_DRIVER_AMMUNITION":
										if "REGISTER_AMMO" in eqkeys:
											if not "REGISTER_AMMO" in register_ship_numerics_store:
												register_ship_numerics_store["REGISTER_AMMO"] = []
											var bp : Dictionary = equipment["REGISTER_AMMO"].duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(bp,false):
												if not "price" in bp:
													bp["price"] = equipment["price"]
												var dc : Dictionary = {equipment.get("num_val",0):bp}
												register_ship_numerics_store["REGISTER_AMMO"].append(dc)
									"NANODRONE_STORAGE":
										if "REGISTER_NANO" in eqkeys:
											if not "REGISTER_NANO" in register_ship_numerics_store:
												register_ship_numerics_store["REGISTER_NANO"] = []
											var bp : Dictionary = equipment["REGISTER_NANO"].duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(bp,false):
												if not "price" in bp:
													bp["price"] = equipment["price"]
												var dc : Dictionary = {equipment.get("num_val",0):bp}
												register_ship_numerics_store["REGISTER_NANO"].append(dc)
									"STANDARD_REACTION_CONTROL_THRUSTERS":
										if "AUX_POWER_SLOT" in eqkeys:
											var bp : Dictionary = equipment["AUX_POWER_SLOT"].duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(bp,false):
												if not "system" in bp:
													bp["system"] = equipment["system"]
												if not "price" in bp:
													bp["price"] = equipment["price"]
												AUX_POWER_AND_THRUSTERS.append(bp)
										if "THRUSTERS" in eqkeys:
											var bp : Dictionary = equipment["THRUSTERS"].duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(bp,false):
												if not "system" in bp:
													bp["system"] = equipment["system"]
												if not "price" in bp:
													bp["price"] = equipment["price"]
												AUX_POWER_AND_THRUSTERS.append(bp)
										if "AUX_POWER_AND_THRUSTERS" in eqkeys:
											var bp : Dictionary = equipment["AUX_POWER_AND_THRUSTERS"].duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(bp,false):
												if not "system" in bp:
													bp["system"] = equipment["system"]
												if not "price" in bp:
													bp["price"] = equipment["price"]
												AUX_POWER_AND_THRUSTERS.append(bp)
									"STANDARD_MAIN_ENGINE":
										if "AUX_POWER_SLOT" in eqkeys:
											var bp : Dictionary = equipment["AUX_POWER_SLOT"].duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(bp,false):
												if not "system" in bp:
													bp["system"] = equipment["system"]
												if not "price" in bp:
													bp["price"] = equipment["price"]
												AUX_POWER_AND_THRUSTERS.append(bp)
										if "THRUSTERS" in eqkeys:
											var bp : Dictionary = equipment["THRUSTERS"].duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(bp,false):
												if not "system" in bp:
													bp["system"] = equipment["system"]
												if not "price" in bp:
													bp["price"] = equipment["price"]
												AUX_POWER_AND_THRUSTERS.append(bp)
										if "AUX_POWER_AND_THRUSTERS" in eqkeys:
											var bp : Dictionary = equipment["AUX_POWER_AND_THRUSTERS"].duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(bp,false):
												if not "system" in bp:
													bp["system"] = equipment["system"]
												if not "price" in bp:
													bp["price"] = equipment["price"]
												AUX_POWER_AND_THRUSTERS.append(bp)
									"FISSION_RODS":
										if "REGISTER_REACTOR_RODS" in eqkeys:
											if not "REGISTER_REACTOR_RODS" in register_ship_numerics_store:
												register_ship_numerics_store["REGISTER_REACTOR_RODS"] = []
											var bp : Dictionary = equipment["REGISTER_REACTOR_RODS"].duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(bp,false):
												if not "price" in bp:
													bp["price"] = equipment["price"]
												var dc : Dictionary = {equipment.get("num_val",0):bp}
												register_ship_numerics_store["REGISTER_REACTOR_RODS"].append(dc)
									"ULTRACAPACITOR":
										if "REGISTER_ULTRACAPACITORS" in eqkeys:
											if not "REGISTER_ULTRACAPACITORS" in register_ship_numerics_store:
												register_ship_numerics_store["REGISTER_ULTRACAPACITORS"] = []
											var bp : Dictionary = equipment["REGISTER_ULTRACAPACITORS"].duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(bp,false):
												if not "price" in bp:
													bp["price"] = equipment["price"]
												var dc : Dictionary = {equipment.get("num_val",0):bp}
												register_ship_numerics_store["REGISTER_ULTRACAPACITORS"].append(dc)
									"FISSION_TURBINE":
										if "REGISTER_TURBINES" in eqkeys:
											if not "REGISTER_TURBINES" in register_ship_numerics_store:
												register_ship_numerics_store["REGISTER_TURBINES"] = []
											var bp : Dictionary = equipment["REGISTER_TURBINES"].duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(bp,false):
												if not "price" in bp:
													bp["price"] = equipment["price"]
												var dc : Dictionary = {equipment.get("num_val",0):bp}
												register_ship_numerics_store["REGISTER_TURBINES"].append(dc)
									"AUX_POWER_SLOT":
										if "auxiliary_power_unit" in eqkeys:
											var bp : Dictionary = equipment["auxiliary_power_unit"].duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(bp,false):
												if not "system" in bp:
													bp["system"] = equipment["system"]
												if not "price" in bp:
													bp["price"] = equipment["price"]
												AUX_POWER_AND_THRUSTERS.append(bp)
										if "AUX_POWER_SLOT" in eqkeys:
											var bp : Dictionary = equipment["AUX_POWER_SLOT"].duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(bp,false):
												if not "system" in bp:
													bp["system"] = equipment["system"]
												if not "price" in bp:
													bp["price"] = equipment["price"]
												AUX_POWER_AND_THRUSTERS.append(bp)
										if "THRUSTERS" in eqkeys:
											var bp : Dictionary = equipment["THRUSTERS"].duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(bp,false):
												if not "system" in bp:
													bp["system"] = equipment["system"]
												if not "price" in bp:
													bp["price"] = equipment["price"]
												AUX_POWER_AND_THRUSTERS.append(bp)
										if "AUX_POWER_AND_THRUSTERS" in eqkeys:
											var bp : Dictionary = equipment["AUX_POWER_AND_THRUSTERS"].duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(bp,false):
												if not "system" in bp:
													bp["system"] = equipment["system"]
												if not "price" in bp:
													bp["price"] = equipment["price"]
												AUX_POWER_AND_THRUSTERS.append(bp)
									"PROPELLANT_TANK":
										if "REGISTER_PROPELLANT" in eqkeys:
											if not "REGISTER_PROPELLANT" in register_ship_numerics_store:
												register_ship_numerics_store["REGISTER_PROPELLANT"] = []
											var bp : Dictionary = equipment["REGISTER_PROPELLANT"].duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(bp,false):
												if not "price" in bp:
													bp["price"] = equipment["price"]
												var dc : Dictionary = {equipment.get("num_val",0):bp}
												register_ship_numerics_store["REGISTER_PROPELLANT"].append(dc)
								ADD_EQUIPMENT_ITEMS.append(equipment)
					"ADD_EQUIPMENT_SLOTS.gd":
						for item in constKeys:
							var equipment = constants.get(item)
							if pointers.ConfigDriver.__validate_dictionary(equipment,false):
								ADD_EQUIPMENT_SLOTS.append(equipment)
					"EQUIPMENT_TAGS.gd":
						var ar : Dictionary = constants.get("EQUIPMENT_TAGS",{})
						EQUIPMENT_TAGS.append(ar)
					"SLOT_ORDER.gd":
						var orders : Array = constants.get("SLOT_ORDER",[])
						for order in orders:
							if not order in equipment_slot_order:
								equipment_slot_order.append(order)
						
						var orders2 : Dictionary = constants.get("SLOT_ORDER_RELATIVE",{})
						for order in orders2:
							if not order in relative_equipment_slot_order:
								relative_equipment_slot_order[order] = orders2[order]
						
					"SLOT_TAGS.gd":
						var ar : Dictionary = constants.get("SLOT_TAGS",{})
						SLOT_TAGS.append(ar)
					"AUX_POWER_SLOT.gd","THRUSTERS.gd","AUX_POWER_AND_THRUSTERS.gd":
						for item in constKeys:
							var equipment : Dictionary = constants.get(item)
							
							if pointers.ConfigDriver.__validate_dictionary(equipment,false):
								AUX_POWER_AND_THRUSTERS.append(equipment)

					"MODIFY_INTERNALS.gd":
						if "MODIFY_INTERNALS" in constKeys:
							var pdata : Array = constants.MODIFY_INTERNALS
							
							for item in pdata:
								if pointers.ConfigDriver.__validate_dictionary(item,false):
									var listingSystemName : String = item.get("system","SYSTEM_MISSING_NAME")
									if not listingSystemName in processed_storage_systems:
										processed_storage_systems.append(listingSystemName)
									if not listingSystemName in processed_storage_mods:
										processed_storage_mods[listingSystemName] = []
									var ls : Dictionary = {}
									
									for data in item:
										match data:
											"force_type","specific_ship":
												ls[data] = str(item[data])
											"recurse_to_variants":
												ls[data] = bool(item[data])
											"mass_per_tonne_of_processed_ore","mass_per_crew_member","mass","crew_morale","storage_flat","nano_speed_add","ammo_speed_add","mass_per_tonne_storage_added","mass_per_tonne_total_storage_added","minimum_propellant_utilization_for_reduction","minimum_nano_utilization_for_reduction","minimum_ammo_utilization_for_reduction","emp_shielding":
												ls[data] = float(item[data])
											"crew_count":
												ls[data] = int(item[data])
											"storage_ammo","storage_ammunition":
												ls["storage_ammo"] = float(item[data])
											"storage_nano","storage_nanodrones":
												ls["storage_nano"] = float(item[data])
											"storage_propellant","storage_prop":
												ls["storage_propellant"] = float(item[data])
											"display_system":
												var val : Dictionary = item["display_system"]
												ls["display_system"] = {
													"name":val.get("name",""),
													"can_display_multiple":val.get("can_display_multiple",false),
													"power":val.get("power",0.0),
													"status":val.get("status",100.0),
													"affect_inspection":val.get("affect_inspection",false)
												}
									if "storage_multi_upper" in item or "storage_multi_lower" in item:
										ls["storage_multi"] = float(item.get("storage_multi_upper",1.0))/float(item.get("storage_multi_lower",1.0))
									if "ammo_multi_upper" in item or "ammo_multi_lower" in item:
										ls["ammo_multi"] = float(item.get("ammo_multi_upper",1.0))/float(item.get("ammo_multi_lower",1.0))
									if "nano_multi_upper" in item or "nano_multi_lower" in item:
										ls["nano_multi"] = float(item.get("nano_multi_upper",1.0))/float(item.get("nano_multi_lower",1.0))
									if "propellant_multi_upper" in item or "propellant_multi_lower" in item:
										ls["propellant_multi"] = float(item.get("propellant_multi_upper",1.0))/float(item.get("propellant_multi_lower",1.0))
									if "mass_multi_upper" in item or "mass_multi_lower" in item:
										ls["mass_multi"] = float(item.get("mass_multi_upper",1.0))/float(item.get("mass_multi_lower",1.0))
									if "ammo_speed_multi_upper" in item or "ammo_speed_multi_lower" in item:
										ls["ammo_speed_multi"] = float(item.get("ammo_speed_multi_upper",1.0))/float(item.get("ammo_speed_multi_lower",1.0))
									if "nano_speed_multi_upper" in item or "nano_speed_multi_lower" in item:
										ls["nano_speed_multi"] = float(item.get("nano_speed_multi_upper",1.0))/float(item.get("nano_speed_multi_lower",1.0))
									if "emp_scale_multi_upper" in item or "emp_scale_multi_lower" in item:
										ls["emp_scale_multi"] = float(item.get("emp_scale_multi_upper",1.0))/float(item.get("emp_scale_multi_lower",1.0))
									
									processed_storage_mods[listingSystemName].append(ls)
					"NODE_DEFINITIONS.gd":
						
						for item in constKeys:
							node_definitions_cache[item] = constants[item]
							
					"SHIP_NODE_REGISTER.gd":
						for item in constKeys:
							ship_node_register.append(constants[item])
					"SHIP_NODE_MODIFY.gd":
						
						for item in constKeys:
							var ship : String = constants[item].get("ship_name","")
							if ship != "":
								if not ship in ship_node_modify:
									ship_node_modify[ship] = []
								for modification in constants[item].get("modifications",[]):
									ship_node_modify[ship].append(modification)
						
					"SHIP_THRUSTER_COLORS.gd":
						var cd : Dictionary = constants.get("SHIP_THRUSTER_COLORS",{})
						if cd.size() > 0:
							
							for ship in cd:
								if not ship in ship_thruster_colors:
									ship_thruster_colors[ship] = {"node":{},"type":{}}
								if "type" in cd[ship]:
									ship_thruster_colors[ship]["type"].merge(cd[ship]["type"],true)
								if "node" in cd[ship]:
									ship_thruster_colors[ship]["node"].merge(cd[ship]["node"],true)
								if "recurse_to_variants" in cd[ship]:
									ship_thruster_colors[ship]["recurse_to_variants"] = cd[ship]["recurse_to_variants"]
								if "config" in cd[ship]:
									ship_thruster_colors[ship]["config"] = cd[ship]["config"]
								

					"WEAPONSLOT_ADD.gd":
						for item in constKeys:
							var equipment : Dictionary = constants.get(item)
							var n : String = equipment.get("name","")
							if n:
								if not n in ws_equipment_names:
									ws_equipment_names.append(n)
								if pointers.ConfigDriver.__validate_dictionary(equipment,false):
									WEAPONSLOT_ADD.append(equipment)
					"WEAPONSLOT_MODIFY_TEMPLATES.gd":
						var ar : Dictionary = constants.get("WEAPONSLOT_MODIFY_TEMPLATES",{})
						for template in ar:
							if template in weaponslot_modify_templates:
								for datapoint in ar[template]:
									match datapoint:
										"equipment":
											for item in ar[template][datapoint]:
												if not item in ws_equipment_names:
													ws_equipment_names.append(item)
												if not item in weaponslot_modify_templates[template][datapoint]:
													weaponslot_modify_templates[template][datapoint].append(item)
										"data":
											var data_formatted : Dictionary = {}
											for item in ar[template][datapoint]:
												var property = item.get("property")
												var value = item.get("value")
												if item.get("use_stringified_value",false):
													value = pointers.DataFormat.__convert_var_from_string(value)
												data_formatted[property] = value
											for key in data_formatted:
												var is_in_dict:bool = false
												for lps in weaponslot_modify_templates[template][datapoint]:
													if lps.get("property") == key:
														is_in_dict = true
														lps["value"] = data_formatted[key]
												if not is_in_dict:
													weaponslot_modify_templates[template][datapoint].append({"property":key,"value":data_formatted.get(key)})
							else:
								weaponslot_modify_templates[template] = ar.get(template)
						
					"WEAPONSLOT_MODIFY.gd":
						var ar = constants.get("WEAPONSLOT_MODIFY",{})
						
						for item in ar:
							if not item in ws_equipment_names:
								ws_equipment_names.append(item)
							if item in weaponslot_modify_standalone:
								var dict : Dictionary = {}
								for c in ar[item]:
									var prop : String = c.get("property","")
									var val = c.get("value","")
									if c.get("use_stringified_value",false):
										val = pointers.DataFormat.__convert_var_from_string(val)
									if prop and val:
										dict[prop] = val
								var current_item_data : Dictionary = weaponslot_modify_standalone[item]
								for c in current_item_data:
									var prop : String = c.get("property","")
									var val = c.get("value","")
									if c.get("use_stringified_value",false):
										val = pointers.DataFormat.__convert_var_from_string(val)
									if prop and val:
										dict[prop] = val
								var processed : Array = []
								for u in dict:
									processed.append({"property":u,"value":dict[u]})
								weaponslot_modify_standalone[item] = processed
							else:
								weaponslot_modify_standalone[item] = ar[item]
							
						
					"WEAPONSLOT_SHIP_TEMPLATES.gd":
						var ar : Dictionary = constants.get("WEAPONSLOT_SHIP_TEMPLATES",{})
						for ship in ar:
							var shipdata : Dictionary = ar[ship]
							if ship in weaponslot_ship_templates:
								for slot in shipdata:
									if slot in weaponslot_ship_templates[ship]:
										var compile : Dictionary = {}
										var current_dict : Dictionary = {}
										for type in weaponslot_ship_templates[ship][slot]:
											if not type in compile:
												compile[type] = []
											if not type in current_dict:
												current_dict[type] = {}
											for equip in weaponslot_ship_templates[ship][slot][type]:
												var property = equip.get("property")
												var value = equip.get("value")
												current_dict[type][property] = value
										for type in shipdata[slot]:
											if not type in compile:
												compile[type] = []
											if not type in current_dict:
												current_dict[type] = {}
											for equip in shipdata[slot][type]:
												var property = equip.get("property")
												var value = equip.get("value")
												current_dict[type][property] = value
										for item in current_dict:
											for equip in current_dict[item]:
												compile[item].append({"property":equip,"value":current_dict[item].get(equip)})
										weaponslot_ship_templates[ship][slot] = compile
									else:
										weaponslot_ship_templates[ship][slot] = shipdata.get(slot)
							else:
								weaponslot_ship_templates[ship] = shipdata
						
					"WEAPONSLOT_SHIP_MODIFY.gd":
						var ar = constants.get("WEAPONSLOT_SHIP_MODIFY",{})
						for ship in ar:
							var slots : Dictionary = ar[ship]
							for slot in slots:
								var equipment = slots[slot]
								for item in equipment:
									if not item in ws_equipment_names:
										ws_equipment_names.append(item)
							
							var shipdata : Dictionary = ar.get(ship)
							if ship in weaponslot_ship_standalone:
								for slot in shipdata:
									if slot in weaponslot_ship_standalone[ship]:
										var compile : Dictionary = {}
										var current_dict : Dictionary = {}
										for type in weaponslot_ship_standalone[ship][slot]:
											if not type in compile:
												compile[type] = []
											if not type in current_dict:
												current_dict[type] = {}
											for equip in weaponslot_ship_standalone[ship][slot][type]:
												var property = equip.get("property")
												var value = equip.get("value")
												current_dict[type][property] = value
										for type in shipdata[slot]:
											if not type in compile:
												compile[type] = []
											if not type in current_dict:
												current_dict[type] = {}
											for equip in shipdata[slot][type]:
												var property = equip.get("property")
												var value = equip.get("value")
												if equip.get("use_stringified_value",false):
													value = pointers.DataFormat.__convert_var_from_string(value)
												current_dict[type][property] = value
										for item in current_dict:
											for equip in current_dict[item]:
												compile[item].append({"property":equip,"value":current_dict[item].get(equip)})
										weaponslot_ship_standalone[ship][slot] = compile
									else:
										weaponslot_ship_standalone[ship][slot] = shipdata.get(slot)
							else:
								weaponslot_ship_standalone[ship] = shipdata
						
					"SAVE_BUTTONS.gd":
						var ar : Array = constants.get("SAVE_BUTTONS",[])
						for button in ar:
							if pointers.ConfigDriver.__validate_dictionary(button,false):
								save_button_cache.append(button)
					"ADD_SHIPS.gd":
						for ar in constKeys:
							var ac : Dictionary = constants[ar]
							if pointers.ConfigDriver.__validate_dictionary(ac,false):
								add_ships_store.append(ac)
					"MODIFY_SHIP_BUILDS.gd":
						for ar in constKeys:
							var sorting = {}
							var dict : Dictionary = constants[ar]
							if pointers.ConfigDriver.__validate_dictionary(dict):
								var shipNames = dict.get("ship_name",[])
								match typeof(shipNames):
									TYPE_STRING:
										shipNames = PoolStringArray([shipNames])
									TYPE_ARRAY:
										var ovr = PoolStringArray()
										for i in shipNames:
											if typeof(i) == TYPE_STRING:
												ovr.append(i)
										shipNames = ovr
									TYPE_STRING_ARRAY:
										pass
									_: continue
								var recurse = dict.get("recurse_for_alias",false)
								for entry in dict:
									match entry:
										"if_equipment_in_slot","if_tag_in_slot","random","if_equipment","if_tag","check_numerics","config":
											for i in dict[entry]:
												if "do_add_if" in i:
													for st in i["do_add_if"]:
														if not st:
															i["do_add_if"].erase(st)
														for r in st:
															if not r:
																st.erase(r)
												if "dont_add_if" in i:
													for st in i["dont_add_if"]:
														if not st:
															i["dont_add_if"].erase(st)
														for r in st:
															if not r:
																st.erase(r)
												if i.get("slot",null) and i.get("system",null):
													var prio = i.get("priority",0)
													if not prio in sorting:
														sorting[prio] = []
													i["mode"] = entry
													i["recurse_for_alias"] = recurse
													for shipName in shipNames:
														i["ship_name"] = shipName
														for _r in i.get("weight",1):
															sorting[prio].append(i.duplicate(true))
							
							var sKeys:Array = sorting.keys()
							sKeys.sort()
							for o in sKeys:
								seed(hash(sorting))
								sorting[o].shuffle()
								for i in sorting[o]:
									ship_build_mod_store.append(i)
					"REGISTER_SHIP_NUMERICS.gd":
						for ar in constKeys:
							if not ar in register_ship_numerics_store:
								register_ship_numerics_store[ar] = []
							var ac:Dictionary = constants[ar]
							for v in ac.keys():
								var ax:Dictionary = ac[v]
								if pointers.ConfigDriver.__validate_dictionary(ax,false):
									register_ship_numerics_store[ar].append({v:ax})
					"MODIFY_SHIP_NUMERICS.gd":
						for item in constKeys:
							var di : Dictionary = constants[item]
							var ship : String = di.get("ship_name","")
							if not ship.empty():
								if not ship in modify_ship_numerics:
									modify_ship_numerics[ship] = []
								modify_ship_numerics[ship].append(di)
					"NAMER.gd":
						
						if "CREW" in constKeys:
							var d : Array = constants["CREW"]
							namer_store["crew"].append_array(d)
						
						if "SHIPS" in constKeys:
							var d : Array = constants["SHIPS"]
							namer_store["ships"].append_array(d)
						
						if "REMOVE_CREW" in constKeys:
							var d : Array = constants["REMOVE_CREW"]
							namer_store["remove_crew"].append_array(d)
						
						if "REMOVE_SHIPS" in constKeys:
							var d : Array = constants["REMOVE_SHIPS"]
							namer_store["remove_ships"].append_array(d)
						
					"EVENT_DRIVER.gd":
						for entry in constKeys:
							event_driver_event_entries.append(constants[entry])
					
					"RESEARCH.gd":
						for entry in constKeys:
							if not mod_id in research_store:
								research_store[mod_id] = {}
							research_store[mod_id][entry] = constants[entry]
					
					"RPC_EXTRA_STATES.gd":
						var data:Dictionary = constants.get("RPC_EXTRA_STATES",{})
						for type in data:
							if type in rpc_second_state_store:
								var states:Array = Array()
								for item in data[type]:
									if "sensors" in item:
										for i in item.sensors.size():
											var sensorItem = item.sensors[i]
											match typeof(sensorItem):
												TYPE_DICTIONARY:
													if "func_object_path" in sensorItem and "func_method_name" in sensorItem:
														var object_name:String = sensorItem.func_object_path
														if object_name.begins_with("res://") and object_name.get_extension() == "gd":
															if object_name in rpc_non_autoload_object_persist:
																sensorItem["funcref"] = funcref(rpc_non_autoload_object_persist[object_name],sensorItem.func_method_name)
															elif pointers.DataFormat.__load_if_can(object_name,false,"Script"):
																var refobject = pointers.DataFormat.__get_load().new()
																sensorItem["funcref"] = funcref(refobject,sensorItem.func_method_name)
																rpc_non_autoload_object_persist[object_name] = refobject
															else: continue
														elif object_name in AUTOLOAD_REF_STORE:
															sensorItem["funcref"] = funcref(AUTOLOAD_REF_STORE[object_name],sensorItem.func_method_name)
														else: continue
												TYPE_STRING:
													states.append(item)
												_: continue
									if "function_outputs" in item:
										for i in item.function_outputs.size():
											var sensorItem = item.function_outputs[i]
											if typeof(sensorItem) == TYPE_DICTIONARY:
												if "func_object_path" in sensorItem and "func_method_name" in sensorItem:
													var object_name:String = sensorItem.func_object_path
													if object_name.begins_with("res://") and object_name.get_extension() == "gd":
														if object_name in rpc_non_autoload_object_persist:
															sensorItem["funcref"] = funcref(
																rpc_non_autoload_object_persist[object_name],
																sensorItem.func_method_name
															)
														elif pointers.DataFormat.__load_if_can(object_name,false,"Script"):
															var refobject = pointers.DataFormat.__get_load().new()
															sensorItem["funcref"] = funcref(
																refobject,
																sensorItem.func_method_name
															)
															rpc_non_autoload_object_persist[object_name] = refobject
														else: continue
													elif object_name in AUTOLOAD_REF_STORE:
														sensorItem["funcref"] = funcref(
															AUTOLOAD_REF_STORE[object_name],
															sensorItem.func_method_name
														)
													else: continue
											else: continue
									states.append(item)
								rpc_second_state_store[type].append_array(states)
					
		
		var all_slot_node_names : Array = []
		all_slot_node_names.append_array(vanilla_slot_names)
		var slots_for_adding : Array = []
		var slots_for_adding_dict : Dictionary = {}
		var tag_modifications : Array = []
		
		var ship_limitations : Dictionary = {}
		
		var slotDefKeys:Array = slot_defaults.keys()
		for nodes in EQUIPMENT_TAGS:
			if nodes:
				var slotTypes : Array = Array(nodes.get("slot_types",[]))
				var equipmentItems : Array = Array(nodes.get("equipment_types",[]))
				var align : Array = Array(nodes.get("alignments",[]))
				var hardpointTypes : Array = Array(nodes.get("hardpoint_types",[]))
				var slotDefaults : Dictionary = nodes.get("slot_defaults",{})
				if slotTypes:
					for st in slotTypes:
						if not st in slot_types:
							slot_types.append(st)
				if equipmentItems.size() > 0:
					for st in equipmentItems:
						if not st in equipment_types:
							equipment_types.append(st)
				if align:
					for st in align:
						if not st in alignments:
							alignments.append(st)
				if hardpointTypes:
					for st in hardpointTypes:
						if not st in hardpoint_types:
							hardpoint_types.append(st)
				if slotDefaults:
					for st in slotDefaults.keys():
						if st in slotDefKeys:
							for item in slotDefaults.get(st):
								if not item in slot_defaults.get(st):
									slot_defaults[st].append(item)
						else:
							slot_defaults[st] = slotDefaults.get(st)
		for slotDict in ADD_EQUIPMENT_SLOTS:
			var snn : String = slotDict.get("slot_node_name","")
			var spp : Dictionary = ship_limitations.get(snn,{})
			var sppKeys:Array = spp.keys()
			if "limit_ships" in slotDict:
				var val : Array = Array(slotDict["limit_ships"]).duplicate()
				if snn in ship_limitations:
					if "limit_ships" in sppKeys:
						for i in val:
							if not i in sppKeys:
								ship_limitations[snn]["limit_ships"] = i
					else:
						ship_limitations[snn]["limit_ships"] = spp["limit_ships"]
				else:
					ship_limitations[snn] = {}
					ship_limitations[snn]["limit_ships"] = val
			if "prevent_ships" in slotDict:
				var val : Array = Array(slotDict["prevent_ships"]).duplicate()
				if snn in ship_limitations:
					if "prevent_ships" in sppKeys:
						for i in val:
							if not i in sppKeys:
								ship_limitations[snn]["prevent_ships"] = i
					else:
						ship_limitations[snn]["prevent_ships"] = spp["prevent_ships"]
				else:
					ship_limitations[snn] = {}
					ship_limitations[snn]["prevent_ships"] = val
			slots_for_adding.append(slotDict)
			slots_for_adding_dict[snn] = slotDict
			all_slot_node_names.append(snn)
		for node in SLOT_TAGS:
			if node:
				tag_modifications.append(node)
				for snn in node:
					var data : Dictionary = node[snn]
					var spp : Dictionary = ship_limitations.get(snn,{})
					if "limit_ships" in data:
						var val : Array = Array(data["limit_ships"]).duplicate()
						if snn in ship_limitations:
							if "limit_ships" in spp.keys():
								for f in val:
									if not f in spp["limit_ships"]:
										ship_limitations[snn]["limit_ships"].append(f)
							else:
								ship_limitations[snn]["limit_ships"] = spp["limit_ships"]
						else:
							ship_limitations[snn] = {"limit_ships":val}
					if "prevent_ships" in data:
						var val : Array = Array(data["prevent_ships"]).duplicate()
						if snn in ship_limitations:
							if "prevent_ships" in spp.keys():
								for f in val:
									if not f in spp["prevent_ships"]:
										ship_limitations[snn]["prevent_ships"].append(f)
							else:
								ship_limitations[snn]["prevent_ships"] = spp["prevent_ships"]
						else:
							ship_limitations[snn] = {"prevent_ships":val}
		
		var slots_format : PoolStringArray = []
		var editable_paths : PoolStringArray = []
		
		var slot_allowed_equipment : Dictionary = {}
		
		for slot in slots_for_adding:
			var m : String = slot.get("slot_node_name","")
			var format : Array = __make_slot_for_scene(slot)
			
			# FUTURE ME: Write a mod that tag modifies a modded slot, need to double check functionality of this code + define types
			for data in tag_modifications:
				if m in data.keys():
					var slot_override_additive = format[2]["override_additive"]
					var slot_override_subtractive = format[2]["override_subtractive"]
					var override_additive = Array(data[m].get("override_additive",[]))
					var override_subtractive = Array(data[m].get("override_subtractive",[]))
					for over in override_additive:
						if not over in slot_override_additive:
							slot_override_additive.append(over)
					for over in override_subtractive:
						if not over in slot_override_subtractive:
							slot_override_subtractive.append(over)
			slots_format.append(format[0])
			editable_paths.append(format[1])
		for slot in vanilla_equipment_defaults_for_reference:
			var vslot_data : Dictionary = vanilla_equipment_defaults_for_reference[slot]
			var vslot_additives : Array = Array(vslot_data.get("override_additive",[]))
			var vslot_subtractives : Array = Array(vslot_data.get("override_subtractive",[]))
			for dict in tag_modifications:
				if slot in dict:
					var tag_data : Dictionary = dict[slot]
					var tag_add : Array = Array(tag_data.get("override_additive",[]))
					var tag_sub : Array = Array(tag_data.get("override_subtractive",[]))
					for add in tag_add:
						if not add in vslot_additives:
							vslot_additives.append(add)
					for sub in tag_sub:
						if not sub in vslot_subtractives:
							vslot_subtractives.append(sub)
			if vslot_additives != []:
				vslot_data["override_additive"] = vslot_additives
			if vslot_subtractives != []:
				vslot_data["override_subtractive"] = vslot_subtractives
			vanilla_equipment_defaults_for_reference[slot] = vslot_data
			
			
		for slot in all_slot_node_names:
			if slot in vanilla_equipment_defaults_for_reference:
				var data : Dictionary = vanilla_equipment_defaults_for_reference[slot]
				var slot_type : String = data.get("slot_type","HARDPOINT").to_upper()
				if slot_type == "HARDPOINT":
					var hardpoint : String = data.get("hardpoint_type", "")
					var items : Array = Array(slot_defaults.get(hardpoint,[])).duplicate(true)
					var additives : Array = Array(data.get("override_additive",[]))
					var subtractives : Array = Array(data.get("override_subtractive",[]))
					for item in additives:
						if not item in items:
							items.append(item)
					for item in subtractives:
						var tmp : Array = []
						for i in items:
							if not i in subtractives:
								tmp.append(i)
						items = tmp
					
					slot_allowed_equipment[slot] = items
				else:
					var items : Array = Array(slot_defaults.get(slot_type,[])).duplicate(true)
					var additives : Array = Array(data.get("override_additive",[]))
					var subtractives : Array = Array(data.get("override_subtractive",[]))
					for item in additives:
						if not item in items:
							items.append(item)
					for item in subtractives:
						var tmp : Array = []
						for i in items:
							if not i in subtractives:
								tmp.append(i)
						items = tmp
					slot_allowed_equipment[slot] = items
			elif slot in slots_for_adding_dict:
				var data : Dictionary = slots_for_adding_dict[slot]
				var slot_type : String = data.get("slot_type","HARDPOINT").to_upper()
				if slot_type == "HARDPOINT":
					var hardpoint : String = data.get("hardpoint_type", "")
					var items : Array = Array(slot_defaults.get(hardpoint,[])).duplicate(true)
					var additives : Array = Array(data.get("override_additive",[]))
					var subtractives : Array = Array(data.get("override_subtractive",[]))
					for item in additives:
						if not item in items:
							items.append(item)
					for item in subtractives:
						var tmp : Array = []
						for i in items:
							if not i in subtractives:
								tmp.append(i)
						items = tmp
					
					slot_allowed_equipment[slot] = items
				else:
					slot_allowed_equipment[slot] = Array(slot_defaults.get(slot_type,[])).duplicate(true)
		
		
		var equipment_format : PoolStringArray = PoolStringArray()
		
		for slot in slots_for_adding:
			if slot.get("add_vanilla_equipment",true):
				for equip in vanilla_equipment:
					var item : Dictionary = vanilla_equipment[equip]
					if confirm_equipment(vanilla_equipment[equip], slot.get("slot_type",""), slot.get("alignment",""), slot.get("restriction",""), Array(slot_allowed_equipment.get(slot.get("slot_node_name",""),[]))):
						var system_slot : String = slot.get("system_slot","")
						var string : String = __make_equipment_for_scene(item, slot.get("slot_node_name",""), system_slot)
						
						equipment_format.append(string)
		var sfaKeys :Array = slots_for_adding_dict.keys()
		var vedfrKeys :Array = vanilla_equipment_defaults_for_reference.keys()
		for slot in all_slot_node_names:
			if slot in slot_allowed_equipment:
				for item in ADD_EQUIPMENT_ITEMS:
					var slot_type : String = ""
					var alignment : String = ""
					var restriction : String = ""
					var system_slot : String = ""
					if slot in vedfrKeys:
						slot_type = vanilla_equipment_defaults_for_reference[slot].get("slot_type","")
						alignment = vanilla_equipment_defaults_for_reference[slot].get("alignment","")
						restriction = vanilla_equipment_defaults_for_reference[slot].get("restriction","")
						system_slot = vanilla_slot_types[slot]
					elif slot in sfaKeys:
						slot_type = slots_for_adding_dict[slot].get("slot_type","")
						alignment = slots_for_adding_dict[slot].get("alignment","")
						restriction = slots_for_adding_dict[slot].get("restriction","")
						system_slot = slots_for_adding_dict[slot].get("system_slot","")
					if confirm_equipment(item, slot_type, alignment, restriction, Array(slot_allowed_equipment.get(slot,[]))):
						var string : String = __make_equipment_for_scene(item, slot, system_slot)
						var this_sys = item.get("system","")
						if this_sys:
							var this_type = item.get("equipment_type")
							if not this_sys in equipment_validity_for_slots:
								equipment_validity_for_slots[this_sys] = []
							if this_type and not this_type in equipment_validity_for_slots[this_sys]:
								equipment_validity_for_slots[this_sys].append(this_type)
						if not string in equipment_format:
							equipment_format.append(string)
		
		
		
		var concat : String = "[gd_scene load_steps=4 format=2]\n\n[ext_resource path=\"res://enceladus/Upgrades.tscn\" type=\"PackedScene\" id=1]\n[ext_resource path=\"res://HevLib/scenes/equipment/hardpoints/WeaponSlotUpgradeTemplate.tscn\" type=\"PackedScene\" id=2]\n[ext_resource path=\"res://enceladus/SystemShipUpgradeUI.tscn\" type=\"PackedScene\" id=3]\n\n[sub_resource type=\"ViewportTexture\" id=1]\nflags = 5\nviewport_path = NodePath(\"VB/WindowMargin/TabHintContainer/Window/UPGRADE_SIMULATION/VP/Contain1/Viewport\")\n\n[sub_resource type=\"ViewportTexture\" id=2]\nviewport_path = NodePath(\"VB/WindowMargin/TabHintContainer/Window/UPGRADE_SIMULATION/VP/Contain2/Control\")\n\n[node name=\"Upgrades\" instance=ExtResource( 1 )]\n\n[node name=\"TextureRect\" parent=\"VB/WindowMargin/TabHintContainer/Window/UPGRADE_SIMULATION/VP\"]\ntexture = SubResource( 1 )\n\n[node name=\"ControlTexture\" parent=\"VB/WindowMargin/TabHintContainer/Window/UPGRADE_SIMULATION/VP\"]\ntexture = SubResource( 2 )\n\n[node name=\"TextureRect2\" parent=\"VB/WindowMargin/TabHintContainer/Window/UPGRADE_MANUAL/Sims\"]\ntexture = SubResource( 1 )\n\n[node name=\"ControlTexture2\" parent=\"VB/WindowMargin/TabHintContainer/Window/UPGRADE_MANUAL/Sims\"]\ntexture = SubResource( 2 )"
		for ref in slots_format:
			concat += "\n\n" + ref
		for equip in equipment_format:
			concat += "\n\n" + equip
		for path in editable_paths:
			concat += "\n\n" + path
		
		var ws_header : String = "[gd_scene load_steps=2 format=2]\n\n[ext_resource path=\"res://weapons/WeaponSlot.tscn\" type=\"PackedScene\" id=1]\n\n[node name=\"WeaponSlot\" instance=ExtResource( 1 )]"
		
		var equipment_header : String = "[node name=\"%s\" parent=\"%s\" instance_placeholder=\"%s\"]"
		var equipment_header_noref : String = "[node name=\"%s\" parent=\"%s\"]"
		var equipment_editable_path_base : String = "[editable path=\"%s\"]"
		
		
		var weaponslot_string : String = ws_header
		var ws_editable_paths : String = ""
		var weaponslot_properties : Dictionary = {}
		
		var all_slot_types = vanilla_slot_types.duplicate(true)
		for i in all_slot_node_names:
			if not i in all_slot_types:
				var slotType = slots_for_adding_dict[i].get("system_slot","")
				all_slot_types[i] = slotType
		
		
		
		
		for add in WEAPONSLOT_ADD:
			if pointers.ConfigDriver.__validate_dictionary(add,false):
				var aname : String = add.get("name","SYSTEM_ERROR")
				var apath : String = add.get("path","")
				var item_data : Dictionary = {}
				var config : Dictionary = add.get("config",{})
				for it in add.get("data",[]):
					var ws_property : String = it.get("property")
					var ws_value = it.get("value")
					if it.get("use_stringified_value",false):
						ws_value = pointers.DataFormat.__convert_var_from_string(ws_value)
					var split:PoolStringArray = ws_property.split("/")
					var splitSize:int = split.size()
					if splitSize > 2:
						var node : String = split[splitSize - 2]
						var nonode:PoolStringArray = ws_property.split(node)
						if nonode[0].ends_with("/"):
							nonode[0] = nonode[0].rstrip("/")
						if nonode[1].begins_with("/"):
							nonode[1] = nonode[1].lstrip("/")
						if not nonode[0] in item_data:
							item_data[nonode[0]] = []
						item_data[nonode[0]].append([nonode[1],ws_value])
					elif splitSize == 2:
						if not split[0] in item_data:
							item_data[split[0]] = []
						item_data[split[0]].append([split[1],ws_value])
					else:
						if not "." in item_data:
							item_data["."] = []
						item_data["."].append([ws_property,ws_value])
				if apath:
					ws_stuff_to_add.append({"name":aname,"path":apath,"data":item_data,"config":config})
				else:
					ws_stuff_to_modify.append({"name":aname,"data":item_data})
			
			var aname : String = add.get("name","SYSTEM_ERROR")
			var apath : String = add.get("path","")
			var add_header : String = (equipment_header % [aname,".",apath]) if apath else (equipment_header_noref % [aname,"."])
			weaponslot_properties[add_header] = []
			if ws_editable_paths:
				ws_editable_paths += "\n" + equipment_editable_path_base % aname
			else:
				ws_editable_paths = equipment_editable_path_base % aname
			
			for it in add.get("data",[]):
				var ws_property : String = it.get("property")
				var ws_value = it.get("value")
				if it.get("use_stringified_value",false):
					ws_value = pointers.DataFormat.__convert_var_from_string(ws_value)
				var split:PoolStringArray = ws_property.split("/")
				if split.size() > 2:
					var node : String = split[split.size() - 2]
					var nonode:PoolStringArray = ws_property.split(node)
					if nonode[0].ends_with("/"):
						nonode[0] = nonode[0].rstrip("/")
					if nonode[1].begins_with("/"):
						nonode[1] = nonode[1].lstrip("/")
					var prop_header : String = equipment_header_noref % [node,aname + "/" + nonode[0]]
					if not prop_header in weaponslot_properties:
						weaponslot_properties[prop_header] = []
					weaponslot_properties[prop_header].append([nonode[1],ws_value])
				elif split.size() == 2:
					var prop_header : String = equipment_header_noref % [split[0],aname]
					if not prop_header in weaponslot_properties:
						weaponslot_properties[prop_header] = []
					weaponslot_properties[prop_header].append([split[1],ws_value])
				else:
					if not add_header in weaponslot_properties:
						weaponslot_properties[add_header] = []
					weaponslot_properties[add_header].append([ws_property,ws_value])
		
		for property in weaponslot_properties:
			weaponslot_string = weaponslot_string + "\n\n" + property
			var data : Array = weaponslot_properties.get(property)
			for dp in data:
				weaponslot_string = weaponslot_string + "\n" + dp[0] + " = " + var2str(dp[1])
		
		file.open(validation_check_path,File.READ)
		var validation_check:Dictionary = JSON.parse(file.get_as_text()).result
		file.close()
		
		for data in AUX_POWER_AND_THRUSTERS:
			
			var equipSlots : Array = data.get("slots",[])
			for slot in equipSlots:
				slot = slot.split(".")[0]
				if not slot in auxslot_data:
					auxslot_data[slot] = []
				auxslot_data[slot].append(data)
			
			
			var aux_path : String = data.get("path","")
			var aux_type : String = data.get("type","MPDG").to_upper()
			match aux_type:
				"THRUSTER","RCS","TORCH","MAIN_PROPULSION":
					match aux_type:
						"THRUSTER":
							aux_type = "RCS"
						"MAIN_PROPULSION":
							aux_type = "TORCH"
					if aux_path != "":
						continue
					var sys : String = data.get("system","SYSTEM_NAME_MISSING")
					var auxTypePath : String = exhaust_cache_path + aux_type
					
					pointers.FolderAccess.__check_folder_exists(auxTypePath)
					
					var this_thruster_path : String = auxTypePath + "/" + sys + "_thruster.tscn"
					
					
					var this_exhaust_path : String = auxTypePath + "/" + sys + "_exhaust.tscn"
					var exhaust_text : String = make_exhaust_scene(data,sys)
					file.open(this_exhaust_path,File.WRITE)
					file.store_string(exhaust_text)
					file.close()
					
					var thruster_scene : String = make_thruster_scene(data,sys,aux_type,exhaust_cache_path)
					file.open(this_thruster_path,File.WRITE)
					file.store_string(thruster_scene)
					file.close()
					
		var ship_limitation_string : String = "[gd_scene load_steps=2 format=2]\n\n[ext_resource path=\"res://enceladus/Upgrades.tscn\" type=\"PackedScene\" id=1]\n\n[node name=\"Upgrades\" instance=ExtResource( 1 )]"
		var lim_item : String = "[node name=\"%s\" parent=\"VB/MarginContainer/ScrollContainer/MarginContainer/Items\"]"
		for i in ship_limitations:
			var cc : String = "\n\n" + lim_item % i
			var data : Dictionary = ship_limitations[i]
			if "limit_ships" in data:
				var sl : String = "limit_ships = [ "
				if typeof(data["limit_ships"]) == TYPE_STRING:
					data["limit_ships"] = [data["limit_ships"]]
				for f in data["limit_ships"].size():
					if f < (data["limit_ships"].size() - 1):
						sl += "\"" + data["limit_ships"][f] + "\", "
					else:
						sl += "\"" + data["limit_ships"][f] + "\" ]"
				cc += "\n" + sl
			if "prevent_ships" in data:
				var sl : String = "prevent_ships = [ "
				if typeof(data["prevent_ships"]) == TYPE_STRING:
					data["prevent_ships"] = [data["prevent_ships"]]
				for f in data["prevent_ships"].size():
					if f < (data["prevent_ships"].size() - 1):
						sl += "\"" + data["prevent_ships"][f] + "\", "
					else:
						sl += "\"" + data["prevent_ships"][f] + "\" ]"
				cc += "\n" + sl
			ship_limitation_string += cc
		
		if not ws_editable_paths == "":
			weaponslot_string = weaponslot_string + "\n\n" + ws_editable_paths
		
		
		pointers.DataFormat.__replace_scene(concat,"res://enceladus/Upgrades.tscn")
		pointers.DataFormat.__replace_scene(ship_limitation_string,"res://enceladus/Upgrades.tscn")
		
		UpgradeMenu.free()

	var tagged_vanilla_slots : PoolStringArray = PoolStringArray()

	const SLOT_HEADER = "[node name=\"%s\" parent=\"VB/MarginContainer/ScrollContainer/MarginContainer/Items\" instance=ExtResource( 2 )]"
	
	var generated_tex : Dictionary = {}
	
	func create_compiled_tex(texturepath:String, cached_tex_path:String, save_type:String):
		return texturepath
		var filepath : String = ""
		if texturepath in generated_tex:
			filepath = generated_tex[texturepath]
		else:
			filepath = cached_tex_path % save_type
			generated_tex[texturepath] = filepath
			var flareTexture:Texture
			if texturepath.get_extension() == "png":
				flareTexture = pointers.FileAccess.__load_png(texturepath)
			elif texturepath.get_extension() == "stex":
				var st:StreamTexture = StreamTexture.new()
				st.load_path = texturepath
				flareTexture = st
			ResourceSaver.save(filepath,flareTexture)
		
		return filepath
	
	
	func make_thruster_scene(data,sys,aux_type,exhaust_cache_path) -> String:
		var this_sys_path : String = exhaust_cache_path + aux_type + "/" + sys
		
		var cached_exhaust_path : String = this_sys_path + "_exhaust.tscn"
		var cached_tex_path : String = this_sys_path + "_texture_%s.res"
		
		var thruster_header : String = "[gd_scene load_steps=%d format=2]\n\n[ext_resource path=\"res://sfx/thruster.tscn\" type=\"PackedScene\" id=1]"
		var nozzle_footer : String = "[editable path=\"nozzle\"]"
		var extra_nozzle_footer : String = "[editable path=\"%s\"]"
		
		var thruster_node_header : String = "\n\n[node name=\"thruster\" instance=ExtResource( 1 )]"
		var this_nozzle_header : String = "\n\n[node name=\"%s\" parent=\".\" index=\"%d\" instance=ExtResource( %d )]"
		var audio_loop_header : String = "\n\n[node name=\"AudioLoop\" parent=\".\" index=\"0\"]"
		var audio_start_header : String = "\n\n[node name=\"AudioStart\" parent=\".\" index=\"1\"]"
		var flare_header : String = "\n\n[node name=\"Flare\" parent=\".\" index=\"2\"]"
		var nozzle_header : String = "\n\n[node name=\"nozzle\" parent=\".\" index=\"%d\"]"
		
		var ext_path_counter:int = 1
		var ext_path_entry : String = "[ext_resource path=\"%s\" type=\"%s\" id=%d]"
		
		var ext_entries : Array = []
		
		
		var thruster_vars : String = thruster_node_header
		# Base thruster programming
		
		var mass:float = data.get("mass",0)
		thruster_vars += "\n" + "mass = %d" % mass
		var systemName : String = sys
		thruster_vars += "\n" + "systemName = \"%s\"" % systemName
		var priorityOffset:float = data.get("priority_offset",1.0 if aux_type == "RCS" else 8.0)
		thruster_vars += "\n" + "priorityOffset = %f" % priorityOffset
		var mainBrightRatio:float = data.get("main_bright_ratio",0.01)
		thruster_vars += "\n" + "mainBrightRatio = %f" % mainBrightRatio
		var repairReplacementPrice:int = data.get("price",3000 if aux_type == "RCS" else 15000)
		thruster_vars += "\n" + "repairReplacementPrice = %d" % repairReplacementPrice
		var repairReplacementTime:float = data.get("repair_time",1 if aux_type == "RCS" else 4)
		thruster_vars += "\n" + "repairReplacementTime = %d" % repairReplacementTime
		var repairFixPrice:int = data.get("fix_price",500 if aux_type == "RCS" else 1000)
		thruster_vars += "\n" + "repairFixPrice = %d" % repairFixPrice
		var repairFixTime:float = data.get("fix_time",4 if aux_type == "RCS" else 12)
		thruster_vars += "\n" + "repairFixTime = %d" % repairFixTime
		var exhaustEmitOffset:float = data.get("exhaust_emit_offset",8)
		thruster_vars += "\n" + "exhaustEmitOffset = %f" % exhaustEmitOffset
		var scaleOffsetWithPower:bool = data.get("scale_offset_with_power",false)
		thruster_vars += "\n" + "scaleOffsetWithPower = %s" % ("true" if scaleOffsetWithPower else "false")
		var distanceScale:float = data.get("distance_scale",5)
		thruster_vars += "\n" + "distanceScale = %f" % distanceScale
		var plumesFromSettings:bool = data.get("plumes_from_settings",true)
		thruster_vars += "\n" + "plumesFromSettings = %s" % "true" if plumesFromSettings else "false"
		var angularDegreedRange:float = data.get("angular_degree_range",30)
		thruster_vars += "\n" + "angularDegreedRange = %f" % angularDegreedRange
		var rotationRange:float = data.get("rotation_range",PI)
		thruster_vars += "\n" + "rotationRange = %f" % rotationRange
		var consumeCargo:PoolStringArray = data.get("consume_cargo",PoolStringArray())
		var cc : Array = Array(PoolStringArray(consumeCargo))
		thruster_vars += "\n" + "consumeCargo = PoolStringArray(%s)" % (String(cc) if cc.size() else "")
		var canFizzle:bool = data.get("can_fizzle",true)
		thruster_vars += "\n" + "canFizzle = %s" % "true" if canFizzle else "false"
		var wearPowerMaxChance:float = data.get("wear_power_max_chance",0.95)
		thruster_vars += "\n" + "wearPowerMaxChance = %f" % wearPowerMaxChance
		var wearChance:float = data.get("wear_chance",0.01)
		thruster_vars += "\n" + "wearChance = %f" % wearChance
		var accelerationFailLimit:float = data.get("acceleration_fail_limit",400)
		thruster_vars += "\n" + "accelerationFailLimit = %f" % accelerationFailLimit
		var accelerationFailScale:float = data.get("acceleration_fail_scale",200)
		thruster_vars += "\n" + "accelerationFailScale = %f" % accelerationFailScale
		var lightLagChance:float = data.get("light_lag_chance",0.5)
		thruster_vars += "\n" + "lightLagChance = %f" % lightLagChance
		var startJolt:float = data.get("start_jolt",0)
		thruster_vars += "\n" + "startJolt = %f" % startJolt
		var thrust:float = data.get("thrust",1000 if aux_type == "RCS" else 7500)
		thruster_vars += "\n" + "thrust = %f" % thrust
		var command : String = data.get("command","m" if aux_type == "TORCH" else "")
		thruster_vars += "\n" + "command = \"%s\"" % command
		var particleChance:float = data.get("particle_chance",0.5 if aux_type == "RCS" else 1.0)
		thruster_vars += "\n" + "particleChance = %f" % particleChance
		var chokeParticleAdjust:float = data.get("choke_particle_adjust",1)
		thruster_vars += "\n" + "chokeParticleAdjust = %f" % chokeParticleAdjust
		var fadeSeconds:float = data.get("fade_seconds",0.2 if aux_type == "RCS" else 0.4)
		thruster_vars += "\n" + "fadeSeconds = %f" % fadeSeconds
		var windUpSeconds:float = data.get("wind_up_seconds",0.017)
		thruster_vars += "\n" + "windUpSeconds = %f" % windUpSeconds
		var particleScale:float = data.get("particle_scale",5)
		thruster_vars += "\n" + "particleScale = %f" % particleScale
		var randomness:float = data.get("randomness",0.5)
		thruster_vars += "\n" + "randomness = %f" % randomness
		var heatCone:float = data.get("heat_cone",0.5)
		thruster_vars += "\n" + "heatCone = %f" % heatCone
		var minPower:float = data.get("min_power",0.2 if aux_type == "RCS" else 0.8)
		thruster_vars += "\n" + "minPower = %f" % minPower
		var damageWearCapacity:float = data.get("damage_wear_capacity",3600)
		thruster_vars += "\n" + "damageWearCapacity = %f" % damageWearCapacity
		var damageBentCapacity:float = data.get("damage_bent_capacity",3000)
		thruster_vars += "\n" + "damageBentCapacity = %f" % damageBentCapacity
		var damageBentThreshold:float = data.get("damage_bent_threshold",200)
		thruster_vars += "\n" + "damageBentThreshold = %f" % damageBentThreshold
		var damageChokeCapacity:float = data.get("damage_choke_capacity",6000)
		thruster_vars += "\n" + "damageChokeCapacity = %f" % damageChokeCapacity
		var damageChokeThreshold:float = data.get("damage_choke_threshold",400)
		thruster_vars += "\n" + "damageChokeThreshold = %f" % damageChokeThreshold
		var specialFuelLimit:float = data.get("special_fuel_limit",0)
		thruster_vars += "\n" + "specialFuelLimit = %f" % specialFuelLimit
		var heatFireThreshold:float = data.get("heat_fire_threshold",200)
		thruster_vars += "\n" + "heatFireThreshold = %f" % heatFireThreshold
		var heatFireScale:float = data.get("heat_fire_scale",8000)
		thruster_vars += "\n" + "heatFireScale = %f" % heatFireScale
		var heatFireMax:float = data.get("heat_fire_max",0.5)
		thruster_vars += "\n" + "heatFireMax = %f" % heatFireMax
		var maxMissalignment:float = data.get("max_misalignment",0.262 if aux_type == "RCS" else 0.02)
		thruster_vars += "\n" + "maxMissalignment = %f" % maxMissalignment
		var bendWearRatio:float = data.get("bend_wear_ratio",0.025)
		thruster_vars += "\n" + "bendWearRatio = %f" % bendWearRatio
		var specificImpulse:float = data.get("specific_impulse",65 if aux_type == "RCS" else 15)
		thruster_vars += "\n" + "specificImpulse = %f" % specificImpulse
		var thermalFactor:float = data.get("thermal_factor",40)
		thruster_vars += "\n" + "thermalFactor = %f" % thermalFactor
		var powerDraw:float = data.get("power_draw",5000 if aux_type == "RCS" else 100000)
		thruster_vars += "\n" + "powerDraw = %f" % powerDraw
		var gimbalPowerDraw:float = data.get("gimbal_power_draw",100)
		thruster_vars += "\n" + "gimbalPowerDraw = %f" % gimbalPowerDraw
		var thermalHitFactor:float = data.get("thermal_hit_factor",1)
		thruster_vars += "\n" + "thermalHitFactor = %f" % thermalHitFactor
		var inspection:bool = data.get("inspection",true)
		thruster_vars += "\n" + "inspection = %s" % "true" if inspection else "false"
		var gimbal:float = deg2rad(data.get("gimbal",0))
		thruster_vars += "\n" + "gimbal = %f" % gimbal
		var safetyProtocol:bool = data.get("safety_protocol",true)
		thruster_vars += "\n" + "safetyProtocol = %s" % "true" if safetyProtocol else "false"
		var safetyGimbalClear:float = data.get("safety_gimbal_clear",0.419)
		thruster_vars += "\n" + "safetyGimbalClear = %f" % safetyGimbalClear
		var ignitionsPerSecond:float = data.get("ignitions_per_second",10)
		thruster_vars += "\n" + "ignitionsPerSecond = %f" % ignitionsPerSecond
		var gimbalAccurancy:float = data.get("gimbal_accuracy",0.262)
		thruster_vars += "\n" + "gimbalAccurancy = %f" % gimbalAccurancy
		var gimbalPerSecond:float = data.get("gimbal_per_second",3.14)
		thruster_vars += "\n" + "gimbalPerSecond = %f" % gimbalPerSecond
		var gimbalRestAngle:float = data.get("gimbal_rest_angle",0)
		thruster_vars += "\n" + "gimbalRestAngle = %f" % gimbalRestAngle
		var gimbalVectoredThrust:bool = data.get("gimbal_vectored_thrust",false)
		thruster_vars += "\n" + "gimbalVectoredThrust = %s" % ("true" if gimbalVectoredThrust else "false")
		var pulsePerSecond:float = data.get("pulse_per_second",10 if aux_type == "RCS" else 4)
		thruster_vars += "\n" + "pulsePerSecond = %f" % pulsePerSecond
		var pulseEngine:bool = data.get("pulse_engine",true)
		thruster_vars += "\n" + "pulseEngine = %s" % ("true" if pulseEngine else "false")
		var externalPower:bool = data.get("external_power",false)
		thruster_vars += "\n" + "externalPower = %s" % ("true" if externalPower else "false")
		var safetyMaxPower:float = data.get("safety_max_power",1)
		thruster_vars += "\n" + "safetyMaxPower = %f" % safetyMaxPower
		var safetyExtraMargin:float = data.get("safety_extra_margin",1)
		thruster_vars += "\n" + "safetyExtraMargin = %f" % safetyExtraMargin
		var tuneThrustMin:float = data.get("tune_thrust_min",0.5)
		thruster_vars += "\n" + "tuneThrustMin = %f" % tuneThrustMin
		var tuneThrustMax:float = data.get("tune_thrust_max",1.5)
		thruster_vars += "\n" + "tuneThrustMax = %f" % tuneThrustMax
		var sweepHostilityFactor:float = data.get("sweep_hostility_factor",0.2)
		thruster_vars += "\n" + "sweepHostilityFactor = %f" % sweepHostilityFactor
		var damageHostilityScale:int = data.get("damage_hostility_scale",40000000)
		thruster_vars += "\n" + "damageHostilityScale = %f" % damageHostilityScale
		var maxVolume:float = data.get("max_volume",-20)
		thruster_vars += "\n" + "maxVolume = %f" % maxVolume
		var rangeOverride:float = data.get("range_override",0)
		thruster_vars += "\n" + "rangeOverride = %f" % rangeOverride
		var boresightAngleoverride:float = data.get("boresight_angle_override",0)
		thruster_vars += "\n" + "boresightAngleoverride = %f" % boresightAngleoverride
		var pitchOverride:float = data.get("pitch_override",0)
		thruster_vars += "\n" + "pitchOverride = %f" % pitchOverride
		var minChoke:float = data.get("min_choke",0.25)
		thruster_vars += "\n" + "minChoke = %f" % minChoke
		var modulate:Color = Color(data.get("modulate",Color.white))
		thruster_vars += "\n" + "modulate = Color( %f , %f , %f , %f )" % [modulate.r,modulate.g,modulate.b,modulate.a]
		var self_modulate:Color = Color(data.get("self_modulate",Color(1,1,1,0)))
		thruster_vars += "\n" + "self_modulate = Color( %f , %f , %f , %f )" % [self_modulate.r,self_modulate.g,self_modulate.b,self_modulate.a]
		var offset:Vector2 = Vector2(-32,-16)
		var po = data.get("plume_offset",[-32,-16])
		if (po is Vector2) or ((po is Array or po is PoolIntArray or po is PoolRealArray) and po.size() > 1):
			offset[0] = po[0]
			offset[1] = po[1]
		thruster_vars += "\n" + "offset = Vector2( %f , %f )" % [offset.x,offset.y]
		var centered:bool = data.get("plume_centered",false)
		thruster_vars += "\n" + "centered = %s" % ("true" if centered else "false")
		var flip_h:bool = data.get("plume_flip_h",false)
		thruster_vars += "\n" + "flip_h = %s" % ("true" if flip_h else "false")
		var flip_v:bool = data.get("plume_flip_v",false)
		thruster_vars += "\n" + "flip_v = %s" % ("true" if flip_v else "false")
		var hframes:int = data.get("plume_horizontal_frames",8)
		thruster_vars += "\n" + "hframes = %f" % hframes
		var vframes:int = data.get("plume_vertical_frames",1)
		thruster_vars += "\n" + "vframes = %f" % vframes
		var frame:int = data.get("plume_frame",1)
		thruster_vars += "\n" + "frame = %f" % frame
		var frame_coords:Vector2 = Vector2.RIGHT
		var plumeFrameCoords = data.get("plume_frame_coords",frame_coords)
		if (plumeFrameCoords is Vector2) or (plumeFrameCoords is Array and plumeFrameCoords.size() > 1):
			frame_coords[0] = plumeFrameCoords[0]
			frame_coords[1] = plumeFrameCoords[1]
		thruster_vars += "\n" + "frame_coords = Vector2( %f , %f )" % [frame_coords.x,frame_coords.y]
		var region_enabled:bool = data.get("plume_region_enabled",false)
		thruster_vars += "\n" + "region_enabled = %s" % ("true" if region_enabled else "false")
		var region_rect:Rect2 = Rect2(0,0,0,0)
		var plRect = data.get("plume_region_rect",Rect2(0,0,0,0))
		if (plRect is Array or plRect is PoolIntArray or plRect is PoolRealArray) and plRect.size() > 3:
			region_rect = Rect2(plRect[0],plRect[1],plRect[2],plRect[3])
		elif plRect is Rect2:
			region_rect = plRect
		thruster_vars += "\n" + "region_rect = Rect2( %f , %f , %f , %f )" % [region_rect.position.x,region_rect.position.y,region_rect.size.x,region_rect.size.y]
		var region_filter_clip:float = data.get("plume_region_filter_clip",false)
		thruster_vars += "\n" + "region_filter_clip = %s" % ("true" if region_filter_clip else "false")
		var position:Vector2 = Vector2(0,-3)
		var tp = data.get("position",position)
		if tp is Vector2 or ((tp is Array or tp is PoolIntArray or tp is PoolRealArray) and tp.size() > 1):
			position[0] = tp[0]
			position[1] = tp[1]
		thruster_vars += "\n" + "position = Vector2( %f , %f )" % [position.x,position.y]
		var rotation:float = deg2rad(data.get("rotation",0))
		thruster_vars += "\n" + "rotation = %f" % rotation
		var scale:Vector2 = Vector2(0.2,0.2) if aux_type == "RCS" else Vector2(0.939,1.395)
		var ts = data.get("scale",scale)
		if ts is Vector2 or ((ts is Array or ts is PoolIntArray or ts is PoolRealArray) and ts.size() > 1):
			scale[0] = ts[0]
			scale[1] = ts[1]
		thruster_vars += "\n" + "scale = Vector2( %f , %f )" % [scale.x,scale.y]
		
		var flare_vars : String = flare_header
		# Flare programming
		var flare_essentiality:float = data.get("flare_essentiality",0.5 if aux_type == "RCS" else 0.8)
		flare_vars += "\n" + "essentiality = %f" % flare_essentiality
		var flare_offsetByCamera:bool = data.get("flare_offset_by_camera",false)
		flare_vars += "\n" + "offsetByCamera = %s" % ("true" if flare_offsetByCamera else "false")
		var flare_energy:float = data.get("flare_energy",5)
		flare_vars += "\n" + "energy = %f" % flare_energy
		var flare_range_height:float = data.get("flare_range_height",-15)
		flare_vars += "\n" + "range_height = %f" % flare_range_height
		var flare_range_z_min:float = data.get("flare_range_z_min",-4096)
		flare_vars += "\n" + "range_z_min = %f" % flare_range_z_min
		var flare_range_z_max:float = data.get("flare_range_z_max",4096)
		flare_vars += "\n" + "range_z_max = %f" % flare_range_z_max
		var flare_range_layer_min:float = data.get("flare_range_layer_min",-1)
		flare_vars += "\n" + "range_layer_min = %f" % flare_range_layer_min
		var flare_range_layer_max:float = data.get("flare_range_layer_max",1)
		flare_vars += "\n" + "range_layer_max = %f" % flare_range_layer_max
		var flare_offset:Vector2 = Vector2.ZERO
		var fo = data.get("flare_offset",flare_offset)
		if fo is Vector2 or ((fo is Array or fo is PoolIntArray or fo is PoolRealArray) and fo.size() > 1):
			flare_offset[0] = fo[0]
			flare_offset[1] = fo[1]
		flare_vars += "\n" + "offset = Vector2( %f , %f )" % [flare_offset.x,flare_offset.y]
		var flare_texture_scale:float = data.get("flare_texture_scale",6)
		flare_vars += "\n" + "texture_scale = %f" % flare_texture_scale
		var flare_rotation:float = deg2rad(data.get("flare_rotation",0))
		flare_vars += "\n" + "rotation = %f" % flare_rotation
		var flare_position:Vector2 = Vector2.ZERO
		var fp = data.get("flare_position",Vector2.ZERO)
		if fp is Vector2 or ((fp is Array or fp is PoolIntArray or fp is PoolRealArray) and fp.size() > 1):
			flare_position[0] = fp[0]
			flare_position[1] = fp[1]
		var flare_scale:Vector2 = Vector2.ONE
		var fs = data.get("flare_scale",Vector2.ONE)
		if fs is Vector2 or ((fs is Array or fs is PoolIntArray or fs is PoolRealArray) and fs.size() > 1):
			flare_scale[0] = fs[0]
			flare_scale[1] = fs[1]
		flare_vars += "\n" + "scale = Vector2( %f , %f )" % [flare_scale.x,flare_scale.y]
		var flare_color:Color = Color(data.get("flare_color","3bafff"))
		flare_vars += "\n" + "color = Color( %f , %f , %f , %f )" % [flare_color.r, flare_color.g, flare_color.b, flare_color.a]
		
		
		
		
		
		
		
		
		
		
		
		
		# Exhaust scene
		var exhaust_path : String = "res://sfx/exhaust.tscn"
		match data.get("exhaust_type",""):
			"regular":
				exhaust_path = "res://sfx/exhaust.tscn"
			"fusion":
				exhaust_path = "res://sfx/exhaust-fusion.tscn"
			_:
				if file.file_exists(cached_exhaust_path):
					exhaust_path = cached_exhaust_path
				else:
					exhaust_path = "res://sfx/exhaust.tscn"
		ext_path_counter += 1
		var exhaust_ext : String = ext_path_entry % [exhaust_path,"PackedScene",ext_path_counter]
		ext_entries.append(exhaust_ext)
		thruster_vars += "\n" + "exhaust = ExtResource( %d )" % ext_path_counter
		
		# Material
		var material : String = "res://sfx/AddOnly.material"
		if data.get("plume_has_material",true):
			var matpath : String = data.get("plume_material_path",material)
			if file.file_exists(matpath):
				material = matpath
		else:
			material = ""
		if material:
			ext_path_counter += 1
			var material_ext = ext_path_entry % [material,"Material",ext_path_counter]
			ext_entries.append(material_ext)
			thruster_vars += "\n" + "material = ExtResource( %d )" % ext_path_counter
		else:
			thruster_vars += "\n" + "material = null"
		
		# Plume texture
		var plume_texture : String = "res://sfx/thrusters.png"
		var plumeTex : String = data.get("plume_texture",plume_texture)
		if ResourceLoader.exists(plumeTex):
			plume_texture = plumeTex
		var plumepath : String = create_compiled_tex(plume_texture,cached_tex_path,"plume")
		
		ext_path_counter += 1
		var plume_ext : String = ext_path_entry % [plumepath,"StreamTexture" if plumepath.ends_with(".stex") else "Texture",ext_path_counter]
		ext_entries.append(plume_ext)
		thruster_vars += "\n" + "texture = ExtResource( %d )" % ext_path_counter
		
		# Flare texture
		var flare_texture : String = "res://lights/plume.png"
		var flareTex : String = data.get("flare_texture",flare_texture)
		if ResourceLoader.exists(flareTex):
			flare_texture = flareTex
		var flarepath : String = create_compiled_tex(flare_texture,cached_tex_path,"flare")
		
		ext_path_counter += 1
		var flare_ext : String = ext_path_entry % [flarepath,"StreamTexture" if flarepath.ends_with(".stex") else "Texture",ext_path_counter]
		ext_entries.append(flare_ext)
		flare_vars += "\n" + "texture = ExtResource( %d )" % ext_path_counter
		
		
		# Nozzle handles
		var after_nozzles : Array = []
		var before_nozzles : Array = []
		var nd : Dictionary = convert_to_nozzle(data.get("nozzle",{}))
		for i in data.get("extra_nozzles",[]):
			if i.get("order","after") == "before":
				before_nozzles.append(convert_to_nozzle(i))
			else:
				after_nozzles.append(convert_to_nozzle(i))
		var nozzle_groups:PoolStringArray = PoolStringArray()
		var footer_groups:PoolStringArray = PoolStringArray()
		var node_index:int = 2
		
		var nozzle_scene_path : String = "res://ships/modules/nozzle-conventonal.tscn"
		var nozzle_scene_ext:int = 0
		if before_nozzles.size() or after_nozzles.size():
			ext_path_counter += 1
			nozzle_scene_ext = ext_path_counter
			var nozzle_s_ext : String = ext_path_entry % [nozzle_scene_path,"PackedScene",nozzle_scene_ext]
			ext_entries.append(nozzle_s_ext)
		for n in before_nozzles:
			node_index += 1
			var nozzlename : String = "nozzle_%d" % node_index
			var header : String = this_nozzle_header % [nozzlename,node_index,nozzle_scene_ext]
			var nz : Array = format_nozzle(n,header,nozzlename,ext_path_counter,cached_tex_path,ext_path_entry)
			ext_path_counter = nz[1]
			ext_entries.append_array(nz[2])
			nozzle_groups.append(nz[0])
			footer_groups.append(extra_nozzle_footer % nozzlename)
			
		node_index += 1
		var basenozzlename : String = "nozzle"
		var baseheader : String = nozzle_header % node_index
		var basenz : Array = format_nozzle(nd,baseheader,basenozzlename,ext_path_counter,cached_tex_path,ext_path_entry)
		ext_path_counter = basenz[1]
		ext_entries.append_array(basenz[2])
		nozzle_groups.append(basenz[0])
		footer_groups.append(nozzle_footer)
		
		for n in after_nozzles:
			node_index += 1
			var nozzlename : String = "nozzle_%d" % node_index
			var header : String = this_nozzle_header % [nozzlename,node_index,nozzle_scene_ext]
			var nz : Array = format_nozzle(n,header,nozzlename,ext_path_counter,cached_tex_path,ext_path_entry)
			ext_path_counter = nz[1]
			ext_entries.append_array(nz[2])
			nozzle_groups.append(nz[0])
			footer_groups.append(extra_nozzle_footer % nozzlename)
			
		
		var nodes_to_add:PoolStringArray = PoolStringArray()
		
		# Extra nodes
		var extra_nodes : Array = data.get("extra_nodes",[])
		for node in extra_nodes:
			if ResourceLoader.exists(node):
				var vm = load(node).instance()
				var nodename : String = vm.name
				Tool.remove(vm)
				ext_path_counter += 1
				node_index += 1
				var nodeExt : String = ext_path_entry % [node,"PackedScene",ext_path_counter]
				var nodeId : String = this_nozzle_header % [nodename,node_index,ext_path_counter]
				ext_entries.append(nodeExt)
				nodes_to_add.append(nodeId)
		
		var header_compile : String = ""
		if ext_entries:
			header_compile = thruster_header % (ext_entries.size() + 3)
			for i in ext_entries:
				header_compile += "\n" + i
		
		var nozzle_compile : String = ""
		for i in nozzle_groups:
				nozzle_compile += i
		
		var extra_node_compile : String = ""
		for i in nodes_to_add:
			extra_node_compile += i
		
		var footer : String = "\n"
		for i in footer_groups:
			footer += "\n" + i
		
		var thruster_text : String = header_compile + thruster_vars + flare_vars + nozzle_compile + extra_node_compile + footer
		
		
		return thruster_text
	
	func format_nozzle(nd:Dictionary,header:String,nozzlename:String,current_ext:int,cached_tex_path:String,ext_path_entry:String) -> Array:
		var ext_entries : Array = []
		var nozzle_vars : String = header
		var peakTemperature:int = nd.peak_temperature
		var coolTime:float = nd.cool_time
		var heatTime:float = nd.heat_time
		
		nozzle_vars += "\n" + "coolTime = %f" % coolTime
		nozzle_vars += "\n" + "heatTime = %f" % heatTime
		nozzle_vars += "\n" + "peakTemperature = %f" % peakTemperature
		
		var texture : String = "res://ships/modules/nozzle-cd.png"
		var normal : String = "res://ships/modules/nozzle-n.png"
		var tx : String = nd.texture
		if ResourceLoader.exists(tx):
			texture = tx
		var nx : String = nd.normal
		if ResourceLoader.exists(nx):
			normal = nx
		var texturepath : String = create_compiled_tex(texture,cached_tex_path,"nozzle_texture")
		
		current_ext += 1
		var sprite_ext : String = ext_path_entry % [texturepath,"StreamTexture" if texturepath.ends_with(".stex") else "Texture",current_ext]
		ext_entries.append(sprite_ext)
		nozzle_vars += "\n" + "texture = ExtResource( %d )" % current_ext
		
		var normalpath : String = create_compiled_tex(normal,cached_tex_path,"nozzle_normal")
		
		current_ext += 1
		var normal_ext : String = ext_path_entry % [normalpath,"StreamTexture" if normalpath.ends_with(".stex") else "Texture",current_ext]
		ext_entries.append(normal_ext)
		nozzle_vars += "\n" + "normal_map = ExtResource( %d )" % current_ext
		
		
		var offset = nd.offset
		if offset is Vector2 or ((offset is Array or offset is PoolIntArray or offset is PoolRealArray) and offset.size() > 1):
			nozzle_vars += "\n" + "offset = Vector2( %f , %f )" % [offset[0],offset[1]]
		var centered:bool = nd.centered
		nozzle_vars += "\n" + "centered = %s" % ("true" if centered else "false")
		var flip_h:bool = nd.flip_h
		nozzle_vars += "\n" + "flip_h = %s" % ("true" if flip_h else "false")
		var flip_v:bool = nd.flip_v
		nozzle_vars += "\n" + "flip_v = %s" % ("true" if flip_v else "false")
		var hframes:int = nd.horizontal_frames
		nozzle_vars += "\n" + "hframes = %f" % hframes
		var vframes:int = nd.vertical_frames
		nozzle_vars += "\n" + "vframes = %f" % vframes
		var frame:int = nd.frame
		nozzle_vars += "\n" + "frame = %f" % frame
		var frame_coords = nd.frame_coords
		if frame_coords is Vector2 or ((frame_coords is Array or frame_coords is PoolIntArray or frame_coords is PoolRealArray) and frame_coords.size() > 1):
			nozzle_vars += "\n" + "frame_coords = Vector2( %f , %f )" % [frame_coords[0],frame_coords[1]]
		var region_enabled:bool = nd.region_enabled
		nozzle_vars += "\n" + "region_enabled = %s" % ("true" if region_enabled else "false")
		var region_rect = nd.region_rect
		match typeof(region_rect):
			TYPE_ARRAY, TYPE_INT_ARRAY, TYPE_REAL_ARRAY:
				if region_rect.size() > 3:
					nozzle_vars += "\n" + "region_rect = Rect2( %f , %f , %f , %f )" % [region_rect[0],region_rect[1],region_rect[2],region_rect[3]]
			TYPE_RECT2:
				nozzle_vars += "\n" + "region_rect = Rect2( %f , %f , %f , %f )" % [region_rect.position.x,region_rect.position.y,region_rect.size.x,region_rect.size.y]
		var region_filter_clip:bool = nd.region_filter_clip
		nozzle_vars += "\n" + "region_filter_clip = %s" % ("true" if region_filter_clip else "false")
		var position = nd.position
		if position is Vector2 or ((position is Array or position is PoolIntArray or position is PoolRealArray) and position.size() > 1):
			nozzle_vars += "\n" + "position = Vector2( %f , %f )" % [position[0],position[1]]
		var rotation:float = deg2rad(nd.rotation)
		nozzle_vars += "\n" + "rotation = %f" % rotation
		var scale = nd.scale
		if scale is Vector2 or ((scale is Array or scale is PoolIntArray or scale is PoolRealArray) and scale.size() > 1):
			nozzle_vars += "\n" + "scale = Vector2( %f , %f )" % [scale[0],scale[1]]
		
		nozzle_vars += "\n\n[node name=\"heat\" parent=\"%s\" index=\"0\"]" % nozzlename
		
		var heat : String = "res://ships/modules/nozzle-cl.png"
		var heat_normal : String = ""
		var hx : String = nd.heat
		if ResourceLoader.exists(hx):
			heat = hx
		var hn : String = nd.heat_normal
		if ResourceLoader.exists(hn):
			heat_normal = hn
		
		var heattexturepath : String = create_compiled_tex(heat,cached_tex_path,"nozzle_heat")
		
		current_ext += 1
		var heat_sprite_ext : String = ext_path_entry % [heattexturepath,"StreamTexture" if heattexturepath.ends_with(".stex") else "Texture",current_ext]
		ext_entries.append(heat_sprite_ext)
		nozzle_vars += "\n" + "texture = ExtResource( %d )" % current_ext
		if heat_normal:
			var heatnormalpath : String = create_compiled_tex(heat_normal,cached_tex_path,"nozzle_heat_normal")
			
			current_ext += 1
			var heatnormal_ext : String = ext_path_entry % [heatnormalpath,"StreamTexture" if heatnormalpath.ends_with(".stex") else "Texture",current_ext]
			ext_entries.append(heatnormal_ext)
			nozzle_vars += "\n" + "normal_map = ExtResource( %d )" % current_ext
		
		
		var heat_offset = nd.offset
		if heat_offset is Vector2 or ((heat_offset is Array or heat_offset is PoolIntArray or heat_offset is PoolRealArray) and heat_offset.size() > 1):
			nozzle_vars += "\n" + "offset = Vector2( %f , %f )" % [heat_offset[0],heat_offset[1]]
		var heat_centered:bool = nd.heat_centered
		nozzle_vars += "\n" + "centered = %s" % ("true" if heat_centered else "false")
		var heat_flip_h:bool = nd.heat_flip_h
		nozzle_vars += "\n" + "flip_h = %s" % ("true" if heat_flip_h else "false")
		var heat_flip_v:bool = nd.heat_flip_v
		nozzle_vars += "\n" + "flip_v = %s" % ("true" if heat_flip_v else "false")
		var heat_hframes:int = nd.heat_horizontal_frames
		nozzle_vars += "\n" + "hframes = %f" % heat_hframes
		var heat_vframes:int = nd.heat_vertical_frames
		nozzle_vars += "\n" + "vframes = %f" % heat_vframes
		var heat_frame:int = nd.heat_frame
		nozzle_vars += "\n" + "frame = %f" % heat_frame
		var heat_frame_coords = nd.heat_frame_coords
		if heat_frame_coords is Vector2 or ((heat_frame_coords is Array or heat_frame_coords is PoolIntArray or heat_frame_coords is PoolRealArray) and heat_frame_coords.size() > 1):
			nozzle_vars += "\n" + "frame_coords = Vector2( %f , %f )" % [heat_frame_coords[0],heat_frame_coords[1]]
		var heat_region_enabled:bool = nd.heat_region_enabled
		nozzle_vars += "\n" + "region_enabled = %s" % ("true" if heat_region_enabled else "false")
		var heat_region_rect = nd.heat_region_rect
		match typeof(heat_region_rect):
			TYPE_ARRAY, TYPE_INT_ARRAY, TYPE_REAL_ARRAY:
				if heat_region_rect.size() > 3:
					nozzle_vars += "\n" + "region_rect = Rect2( %f , %f , %f , %f )" % [heat_region_rect[0],heat_region_rect[1],heat_region_rect[2],heat_region_rect[3]]
			TYPE_RECT2:
				nozzle_vars += "\n" + "region_rect = Rect2( %f , %f , %f , %f )" % [heat_region_rect.position.x,heat_region_rect.position.y,heat_region_rect.size.x,heat_region_rect.size.y]
		var heat_region_filter_clip:bool = nd.heat_region_filter_clip
		nozzle_vars += "\n" + "region_filter_clip = %s" % ("true" if heat_region_filter_clip else "false")
		var heat_position = nd.heat_position
		if heat_position is Vector2 or ((heat_position is Array or heat_position is PoolIntArray or heat_position is PoolRealArray) and heat_position.size() > 1):
			nozzle_vars += "\n" + "position = Vector2( %f , %f )" % [heat_position[0],heat_position[1]]
		var heat_rotation:float = deg2rad(nd.heat_rotation)
		nozzle_vars += "\n" + "rotation = %f" % heat_rotation
		var heat_scale = nd.heat_scale
		if heat_scale is Vector2 or ((heat_scale is Array or heat_scale is PoolIntArray or heat_scale is PoolRealArray) and heat_scale.size() > 1):
			nozzle_vars += "\n" + "scale = Vector2( %f , %f )" % [heat_scale[0],heat_scale[1]]
		
		var out : Array = [nozzle_vars,current_ext,ext_entries]
		return out
	
	const nozzle_template = {
		"peak_temperature":2500,
		"cool_time":4,
		"heat_time":0.25,
		"texture":"res://ships/modules/nozzle-cd.png",
		"normal":"res://ships/modules/nozzle-n.png",
		"heat":"res://ships/modules/nozzle-cl.png",
		"heat_normal":"",
		"centered":true,
		"offset":Vector2.ZERO,
		"flip_h":false,
		"flip_v":false,
		"horizontal_frames":1,
		"vertical_frames":1,
		"frame":0,
		"frame_coords":Vector2.ZERO,
		"region_enabled":false,
		"region_rect":Rect2(0,0,0,0),
		"region_filter_clip":false,
		"position":Vector2.ZERO,
		"rotation":0,
		"scale":Vector2.ONE,
		"heat_centered":true,
		"heat_offset":Vector2.ZERO,
		"heat_flip_h":false,
		"heat_flip_v":false,
		"heat_horizontal_frames":1,
		"heat_vertical_frames":1,
		"heat_frame":0,
		"heat_frame_coords":Vector2.ZERO,
		"heat_region_enabled":false,
		"heat_region_rect":Rect2(0,0,0,0),
		"heat_region_filter_clip":false,
		"heat_position":Vector2.ZERO,
		"heat_rotation":0,
		"heat_scale":Vector2.ONE,
	}
	var nozKeys = nozzle_template.keys()
	func convert_to_nozzle(noz):
		var nozzle:Dictionary = nozzle_template.duplicate(true)
		for i in nozKeys:
			if i in noz and match_array_to_vector_or_rect(nozzle[i],noz[i]):
				nozzle[i] = set_array_to_vector_or_rect(nozzle[i],noz[i])
		return nozzle
	
	func set_array_to_vector_or_rect(main,setter):
		var maintype = typeof(main)
		var settertype = typeof(setter)
		match settertype:
			TYPE_ARRAY,TYPE_REAL_ARRAY,TYPE_INT_ARRAY:
				match maintype:
					TYPE_VECTOR2:
						return Vector2(setter[0],setter[1])
					TYPE_VECTOR3:
						return Vector3(setter[0],setter[1],setter[2])
					TYPE_RECT2:
						return Rect2(Vector2(setter[0],setter[1]),Vector2(setter[2],setter[3]))
		return setter
	
	func match_array_to_vector_or_rect(main,setter) -> bool:
		var maintype = typeof(main)
		var settertype = typeof(setter)
		match maintype:
			TYPE_VECTOR2:
				match settertype:
					TYPE_ARRAY,TYPE_REAL_ARRAY,TYPE_INT_ARRAY:
						if setter.size() > 1:
							return true
					TYPE_VECTOR2:
						return true
			TYPE_VECTOR3:
				match settertype:
					TYPE_ARRAY,TYPE_REAL_ARRAY,TYPE_INT_ARRAY:
						if setter.size() > 2:
							return true
					TYPE_VECTOR3:
						return true
			TYPE_RECT2:
				match settertype:
					TYPE_ARRAY,TYPE_REAL_ARRAY,TYPE_INT_ARRAY:
						if setter.size() > 3:
							return true
					TYPE_RECT2:
						return true
			_:
				return maintype == settertype
		return false
	
	func make_exhaust_scene(data:Dictionary,sys:String) -> String:
		var exhaust_header : String = "[gd_scene load_steps=3 format=2]\n\n[ext_resource path=\"res://sfx/exhaust.tscn\" type=\"PackedScene\" id=1]\n[ext_resource path=\"%s\" type=\"%s\" id=2]\n\n[sub_resource type=\"CircleShape2D\" id=1]\nradius = %s\n\n[node name=\"exhaust\" instance=ExtResource( 1 )]"
		var exhaust_footer : String = "[node name=\"Sprite\" parent=\".\" index=\"1\"]\ntexture = ExtResource( 2 )"
		
		var light_lag_chance:float = data.get("exhaust_light_lag_chance",0)
		var base_lifetime:float = data.get("exhaust_base_lifetime",0.25)
		var lifetime:float = data.get("exhaust_lifetime",0.25)
		var end_scale:float = data.get("exhaust_end_scale",0.02)
		var self_remove:float = data.get("exhaust_self_remove",0.02)
		var mass:float = data.get("exhaust_mass",0.1)
		var sprite : String = data.get("exhaust_sprite","res://sfx/ball-of-flame.png")
		var sprite_scale = data.get("exhaust_sprite_scale",Vector2(0.5,0.5))
		var radius:float = data.get("exhaust_collider_radius",2.87)
		
		var tex_type : String = ""
		if sprite.get_extension().to_lower() == "png":
			tex_type = "Texture"
		elif sprite.get_extension().to_lower() == "stex":
			tex_type = "StreamTexture"
		else:
			tex_type = "Texture"
			sprite = "res://sfx/ball-of-flame.png"
		
		var exhaust_text : String = exhaust_header % [sprite,tex_type,str(radius)]
		
		exhaust_text += "\nmass = %s" % mass
		exhaust_text += "\nlightLagChance = %s" % light_lag_chance
		exhaust_text += "\nbaseLifetime = %s" % base_lifetime
		exhaust_text += "\nlifetime = %s" % lifetime
		exhaust_text += "\nendScale = %s" % end_scale
		if self_remove:
			exhaust_text += "\nselfRemove = true"
		else:
			exhaust_text += "\nselfRemove = false"
		
		exhaust_text += "\n\n[node name=\"CollisionShape2D\" parent=\".\" index=\"0\"]\nshape = SubResource( 1 )\n\n" + exhaust_footer
		if sprite_scale is Vector2 or ((sprite_scale is Array or sprite_scale is PoolIntArray or sprite_scale is PoolRealArray) and sprite_scale.size() > 1):
			exhaust_text += "\nscale = Vector2(%s,%s)" % [sprite_scale[0],sprite_scale[1]]
		return exhaust_text

	func confirm_equipment(equipment_node, slot_type, slot_alignment, slot_restriction, slot_allowed_equipment) -> bool:
		var e_slot_type : String = equipment_node.get("slot_type","")
		var e_equipment : String = equipment_node.get("equipment_type","")
		var e_alignment : String = equipment_node.get("alignment","")
		var e_restriction : String = equipment_node.get("restriction","")
		if equipment_node.get("system","") in vanilla_data.min_version:
			var data : Array = vanilla_data.min_version.get(equipment_node.system)
			var failtext : String = "Equipment %s not adding due to old game version. Needed min version: %s ; observed game version: %s" % [str(equipment_node.get("system","")), str(data), str(version)]
			if data[0] < version[0]:
				pass
			elif data[0] == version[0]:
				if data[1] < version[1]:
					pass
				elif data[1] == version[1]:
					if data[2] <= version[2]:
						pass
					else:
						pointers.l(failtext)
						return false
				else:
					pointers.l(failtext)
					return false
			else:
				pointers.l(failtext)
				return false
			
		if e_slot_type == slot_type:
			var passes_slot_check:bool = false
			if e_equipment in slot_allowed_equipment:
				var tp:int = typeof(slot_type)
				if tp == TYPE_STRING:
					if slot_type == "HARDPOINT":
						if slot_alignment in alignments:
							if e_alignment in alignments:
								if e_alignment == slot_alignment:
									passes_slot_check = true
								else:
									return false
							else:
								passes_slot_check = true
						else:
							passes_slot_check = true
					else:
						passes_slot_check = true
				elif tp == TYPE_ARRAY:
					for s in slot_type:
						if s == "HARDPOINT":
							if slot_alignment in alignments:
								if e_alignment in alignments:
									if e_alignment == slot_alignment:
										passes_slot_check = true
									else:
										return false
								else:
									passes_slot_check = true
							else:
								passes_slot_check = true
						
						else:
							passes_slot_check = true
				else:
					passes_slot_check = false
			else:
				return false
			if passes_slot_check:
				if slot_restriction:
					if e_restriction:
						if e_restriction == slot_restriction:
							return true
					else:
						return true
				else:
					return true
		return false
	
	func __make_equipment_for_scene(equipment_data: Dictionary, slot_node_name : String, system_slot: String) -> String:
		var num_val:int = equipment_data.get("num_val", -1)
		var system : String = equipment_data.get("system", "")
		var capability_lock:bool = equipment_data.get("capability_lock", false)
		var name_override : String = equipment_data.get("name_override", "")
		var description : String = equipment_data.get("description", "")
		var manual : String = equipment_data.get("manual", "")
		var specs : String = equipment_data.get("specs", "")
		var price:int = equipment_data.get("price", 0)
		var test_protocol : String = equipment_data.get("test_protocol", "fire")
		var default:bool = equipment_data.get("default", false)
		var control : String = equipment_data.get("control", "")
		var story_flag : String = equipment_data.get("story_flag", "")
		var story_flag_min:int = equipment_data.get("story_flag_min", -1)
		var story_flag_max:int = equipment_data.get("story_flag_max", -1)
		var warn_if_thermal_below:float = equipment_data.get("warn_if_thermal_below", 0)
		var warn_if_electric_below:float = equipment_data.get("warn_if_electric_below", 0)
		var sticker_price_format : String = equipment_data.get("sticker_price_format", "%s E$")
		var sticker_price_multi_format : String = equipment_data.get("sticker_price_multi_format", "%s E$ (x%d)")
		var installed_color:Color = equipment_data.get("installed_color", Color(0.0, 1.0, 0.0, 1.0))
		var disabled_color:Color = equipment_data.get("disabled_color", Color(0.2, 0.2, 0.2, 1.0))
		var normal_color:Color = equipment_data.get("normal_color", Color(1.0, 1.0, 1.0, 1.0))
		
		var cfg : Dictionary = equipment_data.get("config",{})
		
		var base : String = "[node name=\"%s\" parent=\"VB/MarginContainer/ScrollContainer/MarginContainer/Items/%s/VBoxContainer\" instance=ExtResource( 3 )]" % [system.to_upper(),slot_node_name]
		if num_val != -1:
			base += "\nnumVal = %d" % num_val
		base += "\nslot = \"%s\"" % system_slot
		if system:
			base += "\nsystem = \"%s\"" % system
		if capability_lock:
			base += "\ncapabilityLock = true"
#		else:
#			base += "\ncapabilityLock = false"
		if name_override:
			base += "\nnameOverride = \"%s\"" % name_override
		if description:
			base += "\ndescription = \"%s\"" % description
		if manual:
			base += "\nmanual = \"%s\"" % manual
		if specs:
			base += "\nspecs = \"%s\"" % specs
		if price > 0:
			base += "\nprice = %d" % price
		if test_protocol && test_protocol != "fire":
			base += "\ntestProtocol = \"%s\"" % test_protocol
		if default:
			base += "\ndefault = true"
#		else:
#			base += "\ndefault = false"
		if control:
			base += "\ncontrol = \"%s\"" % control
		if story_flag:
			base += "\nstoryFlag = \"%s\"" % story_flag
		if story_flag_min != -1:
			base += "\nstoryFlagMin = %d" % story_flag_min
		if story_flag_max != -1:
			base += "\nstoryFlagMax = %d" % story_flag_max
		if warn_if_thermal_below > 0:
			base += "\nwarnIfThermalBelow = %0.1f" % warn_if_thermal_below
		if warn_if_electric_below > 0:
			base += "\nwarnIfElectricBelow = %0.1f" % warn_if_thermal_below
		if sticker_price_format != "%s E$":
			base += "\nstickerPriceFormat = \"%s\"" % sticker_price_format
		if sticker_price_multi_format != "%s E$ (x%d)":
			base += "\nstickerPriceMultiFormat = \"%s\"" % sticker_price_multi_format
		if installed_color != Color(0.0, 1.0, 0.0, 1.0):
			base += "\ninstalledColor = Color( %s, %s, %s, %s )" % [installed_color.r,installed_color.g,installed_color.b,installed_color.a]
		if disabled_color != Color(0.2, 0.2, 0.2, 1.0):
			base += "\ndisabledColor = Color( %s, %s, %s, %s )" % [disabled_color.r,disabled_color.g,disabled_color.b,disabled_color.a]
		
		if cfg:
			var cfg_id : String = cfg.get("id","")
			var cfg_section : String = cfg.get("section","")
			var cfg_setting : String = cfg.get("entry","")
			var cfg_invert:bool = cfg.get("invert_config",false)
			base += "\nconfig_id = \"%s\"" % cfg_id
			base += "\nconfig_section = \"%s\"" % cfg_section
			base += "\nconfig_setting = \"%s\"" % cfg_setting
			if cfg_invert:
				base += "\ninvert_config = true"
			else:
				base += "\ninvert_config = false"
		if normal_color != Color(1.0, 1.0, 1.0, 1.0):
			base += "[node name=\"System\" parent=\"HBox\" index=\"0\"]\nmodulate = Color( %s, %s, %s, %s )" % [normal_color.r,normal_color.g,normal_color.b,normal_color.a]
		return base
	
	func __make_slot_for_scene(slot_data: Dictionary) -> Array:
		var systemSlot : String = slot_data.get("system_slot", "")
		var slotNodeName : String = slot_data.get("slot_node_name", "MISSING_SLOT_NAME")
		var slotDisplayName : String = slot_data.get("slot_display_name", "SLOT_MISSING_DATA")
		var hasNone:bool = slot_data.get("has_none", true)
		var alwaysDisplay:bool = slot_data.get("always_display", true)
		var restrictType : String = slot_data.get("restrict_type", "")
		var openByDefault:bool = slot_data.get("open_by_default", false)
		var limitShips : Array = slot_data.get("limit_ships", [])
		var preventShips : Array = slot_data.get("prevent_ships", [])
		var add_vanilla_equipment:bool = slot_data.get("add_vanilla_equipment", true)
		var hardpoint_type : String = slot_data.get("hardpoint_type","")
		var alignment : String = slot_data.get("alignment","")
		var restriction : String = slot_data.get("restriction","")
		var override_additive : Array = Array(slot_data.get("override_additive",[]))
		var override_subtractive : Array = Array(slot_data.get("override_subtractive",[]))
		var restrict_hold_type : String = slot_data.get("restrict_hold_type","")
		
		var cfg : Dictionary = slot_data.get("config",{})
		
		var base : String = "[node name=\"%s\" parent=\"VB/MarginContainer/ScrollContainer/MarginContainer/Items\" instance=ExtResource( 2 )]" % slotNodeName
		if systemSlot:
			base += "\nslot = \"%s\"" % systemSlot
		if alwaysDisplay:
			base += "\nalways = true"
		else:
			base += "\nalways = false"
		if openByDefault:
			base += "\nopenByDefault = true"
		else:
			base += "\nopenByDefault = false"
		if cfg:
			var cfg_id : String = cfg.get("id","")
			var cfg_section : String = cfg.get("section","")
			var cfg_setting : String = cfg.get("entry","")
			var cfg_invert:bool = cfg.get("invert_config",false)
			base += "\nconfig_id = \"%s\"" % cfg_id
			base += "\nconfig_section = \"%s\"" % cfg_section
			base += "\nconfig_setting = \"%s\"" % cfg_setting
			if cfg_invert:
				base += "\ninvert_config = true"
			else:
				base += "\ninvert_config = false"
		if restrictType != "":
			base += "\nrestrictType = \"%s\"" % restrictType
		if not limitShips.empty():
			var initial : String = ""
			for item in limitShips:
				if initial: initial += ", "
				else: initial = "\nlimit_ships = ["
				initial += "\"%s\"" % item
			initial += "]"
			base += initial
		if not preventShips.empty():
			var initial : String = ""
			for item in preventShips:
				if initial: initial += ", "
				else: initial = "\nprevent_ships = ["
				initial += "\"%s\"" % item
			initial += "]"
			base += initial
		if restrict_hold_type:
			base += "\nrestrict_hold_type = \"%s\"" % restrict_hold_type
		base += "\n\n[node name=\"CheckButton\" parent=\"VB/MarginContainer/ScrollContainer/MarginContainer/Items/%s/VBoxContainer/HBoxContainer\"]\ntext = \"%s\"" % [slotNodeName,slotDisplayName]
		
		if hasNone: base += "\n\n" + __make_equipment_for_scene({"system":"SYSTEM_NONE","default":true,"name":"None"}, slotNodeName, systemSlot)
		var editable_path : String = "[editable path=\"VB/MarginContainer/ScrollContainer/MarginContainer/Items/%s\"]" % slotNodeName
		var dict : Dictionary = {
				"add_vanilla_equipment":add_vanilla_equipment,
				"hardpoint_type":hardpoint_type,
				"alignment":alignment,
				"restriction":restriction,
				"override_additive":override_additive,
				"override_subtractive":override_subtractive,
			}
		
		return [base, editable_path, dict]
	
	
	

class _Events:
	var scripts : Array = [
		
	]
	
	static func get_class_documentation():
		return {
			"description":"Contains methods to help spawn or clear events in the ring",
			"methods":{
				"__spawn_event":{
					"description":"Spawns an event in the rings",
					"args":[
						"event -> (String) the event name to be spawned",
						"ring -> TheRing node. Must be present to work.",
						"parameters (optional) -> (Dictionary) Any parameters used for spawning events. Defaults to `{}`. Currently supports:",
						"	legacy -> (bool) whether it should use a very old hacky method of hijacking the testSpecificStoryElement property to spawn the event. Has to wait at least 0.1 seconds inbetween spawns. Defaults to `false`",
						"	inject -> (bool) whether the event should be placed directly in the ring, bypassing any event handling methods. Has issues with POI-based events. Defaults to `false`",
#						"	x_direction -> (float) horizontal direction which the event will be spawned in. Will be clamped if it exceeds -1 or 1. Defaults to a random range between -1 and 1.",
#						"	y_direction -> (float) vertical direction which the event will be spawned in. Will be clamped if it exceeds -1 or 1. Defaults to a random range between -1 and 1.",
#						"	spawn_direction_scale -> (float) how much your ship's velocity will be scaled by when calculating the offset added by your velocity. Defaults to 0.75",
#						"	oddity_spawn_radius_min -> (int) minimum distance the event will spawn under normal conditions. NOTE: 1 unit represents 100 cm. Defaults to 24000",
#						"	oddity_spawn_radius_min_cutscene -> (int) minimum distance the event will spawn while in a cutscene (which only happens during astrogation in the vanilla game to make POI events close to the ship when travelling). NOTE: 1 unit represents 100 cm. Defaults to 6000",
#						"	oddity_spawn_radius_max -> (int) maximum distance the event is allowed to spawn at under normal conditions",
						"delay_seconds (optional) -> (float) if set above zero, the number of seconds before the event is spawned",
					],
				},
				"__clear_event":{
					"description":"Clears all objects related to a defined event from the ring",
					"args":[
						"event -> (String) the event name to be removed",
						"ring -> TheRing node. Must be present to work.",
						"clear_related_poi -> (bool) Whether any POI with the same event name near deleted objects should be deleted as well. Defaults to `true`",
						"clear_in_cargo -> (bool) Whether to remove any event-related oddities considered inside the cargo bay of or attached to other ships. Defaults to `false`"
					],
				},
			}
		}
	
	const non_static = {}
	func _init(p):
		non_static["pointers"] = p
	
	
	const busy = [false,null]
	static func __spawn_event(event : String,ring : Node,parameters : Dictionary = {},delay_seconds = 0.0):
		if not busy[0]:
			var pointers = non_static["pointers"]
			if (not ring) or (not ring.has_method("hl_thering_UV")):
				pointers.l("No ring object specified, returning","pointers.EventDriver")
				return
			if delay_seconds > 0.0:
				pointers.l("Delaying event spawn by %0.1f seconds" % delay_seconds,"pointers.EventDriver")
				yield(CurrentGame.get_tree().create_timer(delay_seconds),"timeout")
			if parameters.get("legacy",false):
				busy[0] = true
				var counter = ring.oddityCounter
				ring.oddityCounter = 0x0FFFFFFF
				ring.testSpecificStoryElement = event
				yield(ring.get_tree(),"idle_frame")
				yield(ring.get_tree(),"idle_frame")
				ring.testSpecificStoryElement = ""
				ring.oddityCounter = counter
			elif parameters.get("inject",false):
				var focusObject = CurrentGame.getPlayerShip()
				if focusObject and focusObject.zone == "rings":
					var tree = ring.get_tree()
					var event_node = ring.get_node_or_null(event)
					if event_node and event_node.has_method("canBeAt") and event_node.has_method("makeAt"):
						var pos = getPos(parameters)
						event_node.canBeAt(pos)
						var oddity = event_node.makeAt(pos)
						if oddity and ring.has_method("request_event"):
							ring.request_event(oddity, event)
							pointers.n("injecting oddity %s" % event,"pointers.EventDriver")
				busy[1] = focusObject
			else:
				var focusObject = CurrentGame.getPlayerShip()
				busy[1] = focusObject
				if focusObject and focusObject.zone == "rings":
					var tree = ring.get_tree()
					var event_node = ring.get_node_or_null(event)
					if event_node and event_node.has_method("canBeAt") and event_node.has_method("makeAt"):
						var pos = getPos(parameters)
						event_node.canBeAt(pos)
						var oddity = event_node.makeAt(pos)
						
						var randomOddityKey = ""
						if oddity:
							ring.addNearbyOddity(event, oddity, pos)
							if oddity is Array:
								for o in oddity:
									o.connect("tree_entered", ring, "forcedOddityConfirmed", [randomOddityKey])
							else:
								oddity.connect("tree_entered", ring, "forcedOddityConfirmed", [randomOddityKey])
							ring.unspawnedOddities[randomOddityKey] = oddity
							ring.unspawnedOdditiesLocation[randomOddityKey] = pos
							pointers.n("force spawning oddity %s" % event,"pointers.EventDriver")
				
			busy[0] = false
	
	static func __clear_event(event : String, ring, clear_related_poi : bool = true,clear_in_cargo : bool = false,delay_seconds : float = 0.0):
		var pointers = non_static["pointers"]
		pointers.n("clearing oddities %s" % event,"pointers.EventDriver")
		if (not ring) or (not ring.has_method("hl_thering_UV")):
			pointers.l("No ring object specified, returning","pointers.EventDriver")
			return
		if delay_seconds > 0.0:
			pointers.l("Delaying event clear by %0.1f seconds" % delay_seconds,"pointers.EventDriver")
			yield(CurrentGame.get_tree().create_timer(delay_seconds),"timeout")
		if event == "" or event == "none":
			var events = ring.all_oddities
			for e in events:
				if Tool.claim(e):
					if e.is_node_ready() and clear_if_cargo(e,clear_in_cargo):
						ring.all_oddities.erase(e)
						Tool.release(e)
						Tool.remove(e)
						
		elif event in ring.group:
			var events = ring.group[event]
			if events:
				for e in events:
					if Tool.claim(e):
						if e.is_node_ready() and clear_if_cargo(e,clear_in_cargo):
							if clear_related_poi:
								clear_poi_for(e.global_position,event)
							ring.group[event].erase(e)
							Tool.release(e)
							Tool.remove(e)
	
	static func getPos(params : Dictionary):
		var x_direction = clamp(params.get("x_direction",rand_range( - 1, 1)),-1,1)
		var y_direction = clamp(params.get("y_direction",rand_range( - 1, 1)),-1,1)
		
		var spawnDirectionScale = params.get("spawn_direction_scale",0.75)
		var odditySpawnRadiusMin = params.get("oddity_spawn_radius_min",24000)
		var odditySpawnRadiusMinCutscene = params.get("oddity_spawn_radius_min_cutscene",6000)
		var odditySpawnRadiusMax = params.get("oddity_spawn_radius_max",38000)
		var odditySpawnRadiusSafemax = params.get("oddity_spawn_radius_safe_max",80000)
		var odditySpawnFailures = params.get("oddity_spawn_failures",0)
		var odditySpawnRadiusSafemaxSteps = params.get("oddity_spawn_radius_safe_max_steps",40)
		var focusObject = busy[1]
		if Tool.claim(focusObject):
			
			var cutscene = ("cutscene" in focusObject and focusObject.cutscene) and ("fastTravelDirection" in focusObject and focusObject.fastTravelDirection < 0)
			var focusPoint = focusObject.global_position
			var randomVector = Vector2(x_direction,y_direction).normalized()
			var directionVector = focusObject.linear_velocity.normalized() * spawnDirectionScale
			var dirvec = (randomVector + directionVector).normalized()
			if dirvec.length() < 0.9:
				dirvec = randomVector
			var failBasedMax = clamp(float(odditySpawnFailures) / float(odditySpawnRadiusSafemaxSteps), 0, 1)
			var oRangeMax = lerp(odditySpawnRadiusMax, odditySpawnRadiusSafemax, failBasedMax)
			var oddityFocusOffset = dirvec * rand_range(odditySpawnRadiusMin if not cutscene else odditySpawnRadiusMinCutscene, lerp(odditySpawnRadiusMax, odditySpawnRadiusSafemax, clamp(float(odditySpawnFailures) / float(odditySpawnRadiusSafemaxSteps), 0, 1)))
			
			var oddityPoint = focusPoint + oddityFocusOffset
			Tool.release(focusObject)
			return CurrentGame.globalCoords(oddityPoint)
	
	static func clear_if_cargo(object,do):
		if not do:
			var focus = CurrentGame.getPlayerShip()
			if object in focus.cargo:
				return false
		return true
	static func clear_poi_for(globalPos : Vector2,this_event: String):
		var nearby = CurrentGame.getEventNear(CurrentGame.globalCoords(globalPos))
		while nearby and nearby.event == this_event:
			var astro = CurrentGame.state.astrogation
			for event in astro:
				var ev = astro[event]
				if ev.event == nearby.event and Vector2(ev.vector.x,ev.vector.y).distance_to(nearby.vector) < 2000:
					CurrentGame.forgetPoi(event)
			nearby = CurrentGame.getEventNear(CurrentGame.globalCoords(globalPos))
	

class _FileAccess:
	var scripts : Array = [
		
	]
	
	static func get_class_documentation():
		return {
			"description":"Methods to aide with file interactions",
			"methods":{
				"__get_file_content":{
					"description":"Method that simplifies the usual process of File.get_as_text()",
					"args":[
						"file_path -> (String) the file path to be read"
					],
					"return":[
						"String with the contents of the file"
					]
				},
				"__copy_file":{
					"description":"Copies a file to a folder, overriding files without warning. Automatically handles conversion of file path formatting.",
					"args":[
						"file_path -> (String) the path to the file to be copied",
						"folder -> (String) the directory to copy the file to",
					],
					"return":[
						"Error code for the copy operation"
					]
				},
				"__load_png":{
					"description":"Reads and parses a PNG file during runtime, without the need to precompile to STEX. Also supports JPG/JPEG, BMP, and WEBP formats.",
					"args":[
						"filepath -> (String) the file path to the PNG file",
						"fallback (optional) -> (Image) an image resource to use as a fallback if the image file provided by filepath fails to load."
					],
					"return":[
						"ImageTexture containing the image."
					]
				},
				"__precache_mod_file":{
					"description":"Prepares a file to be copied to the mod folder. This will mark the game for needing a restart, which Mod Menu 2 will start requesting upon opening it.",
					"args":[
						"filepath -> (String) the file path to the mod."
					],
				},
				"__load_precached_mods":{
					"description":"Copies any prepared mods to the mod folder, and reboots if there are mods to copy. Normally this is done on game boot to provide a reliable experience for players. NOTE: Rebooting will happen at all cases with mods existing, even if it's safe to copy. Double check 'user://cache/.Mod_Menu_2_Cache/updates/has_updated.txt', which will have a `1` stored if there are mods to copy, and `0` otherwise.",
				},
				"__save_stex(image:Image, file_path:String, flags:int=0)":{
					"description":"Saves a provided image resource as a .stex file",
					"args":[
						"image -> (Image) the image data to be saved.",
						"file_path -> (String) the file path to save the .stex file to. Note that this always changes the extension to .stex",
						"flags (optional) -> (int) the texture flags for the image. Check the Texture.Flags enum for reference."
					]
				},
				"__get_uid_of_file":{
					"description":"Returns a unique identifier string for the provided file.",
					"args":[
						"file_path -> (String) file path to check."
					],
					"return":[
						"String for the file uid. Will be an empty string if the file does not exist."
					]
				},
				"__file_output_to_buffer":{
					"description":"Ensures a file input is a PoolByteArray.",
					"args":[
						"content -> (String/PoolByteArray) file content. Can be either a string or PoolByteArray"
					],
					"return":[
						"PoolByteArray for the output buffer."
					]
				},
				"__file_exists":{
					"description":"An all-encompassing method to determine if a file exists in the filesystem, without the need to query File and ResourceLoader directly",
					"args":[
						"file_path -> (String) the file path to the desired resource to check. Can be both relative, global, or OS-global",
					],
					"return":[
						"Bool for whether the file at file_path exists or not."
					]
				},
				"__get_real_filename_from_compiled_resource":{
					"description":"If the provided filepath would match a compiled resource (extension is .gdc or .converted.res), matches an appropriate filepath where the actual resource exists for it.",
					"args":[
						"file_path -> (String) Filepath for the file to check"
					],
					"return":[
						"Actual resource path for the file. Returns the provided filepath if it doesn't match."
					]
				},
				"__get_dependancies_for_file":{
					"description":"Fetches all resource dependancies for the provided filepath, including compiled .res and .gdc files found within the .pck file. Can optionally perform a deep check for res:// filepaths not exposed by ResourceLoader.",
					"args":[
						"file_path -> (String) the resource's filepath to check.",
						"deep_search (optional) -> (bool) whether to perform a deep search for all res:// file paths within the resource. Defaults to false"
					],
					"return":[
						"PoolStringArray containing all dependancy file paths."
					]
				}
			}
		}
	
	const non_static = {}
	func _init(f):
		non_static["pointers"] = f
	
	static func __get_file_content(file_path: String) -> String:
		var file:File = File.new()
		file.open(file_path, File.READ)
		var s : String = file.get_as_text(true)
		file.close()
		return s
	
	static func __save_file_content(file_path: String,data:String):
		var file:File = File.new()
		file.open(file_path, File.WRITE)
		file.store_string(data)
		file.close()
	
	static func __store_default_if_file_missing(file_path: String,data:String) -> bool:
		var file:File = File.new()
		if not file.file_exists(file_path):
			__save_file_content(file_path,data)
			return false
		return true
	
	static func __copy_file(file_path : String, folder : String):
		var prepfile : String = ProjectSettings.localize_path(file_path)
		var dir:Directory = Directory.new()
		return dir.copy(prepfile,folder + "/" + prepfile.split("/")[prepfile.split("/").size() - 1])
	
	const PNG_HEADER = PoolByteArray([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A])
	const BMP_HEADER = PoolByteArray([0x42, 0x4D])
	const JPG_HEADERS = [PoolByteArray([0xFF, 0xD8, 0xFF, 0xDB]),PoolByteArray([0xFF, 0xD8, 0xFF, 0xE0]),PoolByteArray([0xFF, 0xD8, 0xFF, 0xE1]),PoolByteArray([0xFF, 0xD8, 0xFF, 0xEE])]
	const WEBP_HEADERS = [PoolByteArray([0x42, 0x49, 0x46, 0x46]),PoolByteArray([0x57, 0x45, 0x42, 0x50])]
	
	static func __load_png(path,fallback:Image = Image.new()) -> Texture:
		var file:File = File.new()
		file.open(path, File.READ)
		var bytes:PoolByteArray = file.get_buffer(file.get_len())
		file.close()
		var img:Image = Image.new()
		var loaded:bool = false
		if bytes.subarray(0,7) == PNG_HEADER:
			loaded = img.load_png_from_buffer(bytes) == OK
		elif bytes.subarray(0,3) in JPG_HEADERS:
			loaded = img.load_jpg_from_buffer(bytes) == OK
		elif bytes.subarray(0,1) == BMP_HEADER:
			loaded = img.load_bmp_from_buffer(bytes) == OK
		elif bytes.subarray(0,3) == WEBP_HEADERS[0] and bytes.subarray(8,11) == WEBP_HEADERS[1]:
			loaded = img.load_webp_from_buffer(bytes) == OK
		if not loaded:
			img = fallback
		var imgtex:ImageTexture = ImageTexture.new()
		imgtex.create_from_image(img)
		return imgtex
	
	const updateCacheDir : String = "user://cache/.Mod_Menu_2_Cache/updates"
	const updateCacheFile : String = updateCacheDir + "/mods_to_update.json"
	const modCacheDir : String = updateCacheDir + "/zip_cache"
	const has_updated_store : String = updateCacheDir + "/has_updated.txt"
	static func __precache_mod_file(filepath:String):
		var file:File = File.new()
		filepath = ProjectSettings.localize_path(filepath)
		non_static["pointers"].FolderAccess.__check_folder_exists(modCacheDir)
		if file.file_exists(filepath):
			var exists:int = OK
			var modDir : String = filepath.get_base_dir()
			if modDir != modCacheDir:
				exists = __copy_file(filepath,modCacheDir)
				filepath = modCacheDir + filepath.split(modDir)[1]
			var cache : Array = []
			if file.file_exists(updateCacheFile): cache = JSON.parse(__get_file_content(updateCacheFile)).result
			if not filepath in cache: cache.append(filepath)
			file.open(updateCacheFile,File.WRITE)
			file.store_string(JSON.print(cache))
			file.close()
			if exists == OK:
				file.open(has_updated_store,File.WRITE)
				file.store_string("1")
				file.close()
	const foundnewfiles:String = "new mods found, attempting to copy"
	const exitMsg:String = "new and/or updated mods detected, rebooting game"
	static func __load_precached_mods():
		var gameInstallDirectory:String = OS.get_executable_path().get_base_dir()
		if OS.get_name() == "OSX":
			gameInstallDirectory = gameInstallDirectory.get_base_dir().get_base_dir().get_base_dir()
		var modPathPrefix:String = gameInstallDirectory.plus_file("mods")
		var file:File = File.new()
		if file.file_exists(updateCacheFile):
			var files_to_copy : Array = JSON.parse(__get_file_content(updateCacheFile)).result
			file.open(updateCacheFile,File.WRITE)
			file.store_string("[]")
			file.close()
			if not files_to_copy.empty():
				print(foundnewfiles)
				var pointers:HevLibPointers = non_static["pointers"]
				pointers.l(foundnewfiles,"pointers.FileAccess")
				for mod in files_to_copy:
					if file.file_exists(mod) and __copy_file(mod,modPathPrefix) == OK:
						var newmodmsg:String = "copied new mod %s" % mod.get_file()
						print(newmodmsg)
						pointers.l(newmodmsg,"pointers.FileAccess")
				print(exitMsg)
				pointers.NodeAccess.__exit(true,exitMsg,"pointers.FileAccess")
			
	static func __get_uid_of_file(file_path:String) -> String:
		if not __file_exists(file_path):
			return ""
		var file:File = File.new()
		file.open(file_path,File.READ)
		var num:int = non_static["pointers"].DataFormat.__get_crc_32(file.get_buffer(file.get_len()))
		file.close()
		return (PoolByteArray([(num>>16)&0xFF,(num>>24)&0xFF,(num)&0xFF,(num>>8)&0xFF]).hex_encode() + file_path).sha256_text()
	
	# Code sourced from lifelike's Godot Animator Import plugin
	# https://github.com/lifelike/godot-animator-import
	static func __save_stex(image:Image, file_path:String, flags:int=0):
		var out_path:String = "%s.stex" % file_path.get_basename()
		var tmppng:String = "%s-tmp.png" % file_path
		image.save_png(tmppng)
		var file = File.new()
		file.open(tmppng, File.READ)
		var pnglen:int = file.get_len()
		var pngdata:PoolByteArray = file.get_buffer(pnglen)
		file.close()
		Directory.new().remove(tmppng)
		file.open(out_path, File.WRITE)
		if file.is_open():
			file.store_8(0x47) # G
			file.store_8(0x44) # D
			file.store_8(0x53) # S
			file.store_8(0x54) # T
			file.store_32(image.get_width())
			file.store_32(image.get_height())
			file.store_32(flags)
			file.store_32(0x07100000) # data format
			file.store_32(1) # nr mipmaps
			file.store_32(pnglen + 6)
			file.store_8(0x50) # P
			file.store_8(0x4e) # N
			file.store_8(0x47) # G
			file.store_8(0x20) # space
			file.store_buffer(pngdata)
			file.close()
			return out_path
		else:
			return ""
	
	static func __file_output_to_buffer(content) -> PoolByteArray:
		match typeof(content):
			TYPE_STRING:
				return content.to_utf8()
			TYPE_RAW_ARRAY:
				return content
			_:
				non_static["pointers"].l("ERROR: content must be a String or PoolByteArray to be converted to buffer","pointers.FileAccess")
				return PoolByteArray()
	
	static func __file_exists(file_path:String) -> bool:
		file_path = ProjectSettings.localize_path(file_path)
		var file:File = File.new()
		return (ResourceLoader.exists(file_path) or file.file_exists(file_path))
	
	static func __get_real_filename_from_compiled_resource(file_path:String) -> String:
		match file_path.get_extension():
			"res":
				return file_path.get_basename().get_basename()
			"gdc":
				return file_path.get_basename() + ".gd"
		return file_path
	
	const deeperSearch:PoolStringArray = PoolStringArray(["tres","tscn","gd","res"])
	const resHex:String = "7265733a2f2f" # "res://".to_ascii().hex_encode()
	
	static func __get_dependancies_for_file(file_path:String,deep_search:bool = false) -> PoolStringArray:
		var dependencies:PoolStringArray = ResourceLoader.get_dependencies(file_path)
		var file:File = File.new()
		if deep_search and file_path.get_extension() in deeperSearch:
			var nfp:String = file_path
			if not non_static["pointers"].is_editor:
				if file_path.get_extension().to_lower() == "gd":
					nfp = file_path.get_basename() + ".gdc"
				else:
					nfp += ".converted.res"
			file.open(nfp,File.READ)
			var fileBytes:PoolByteArray = file.get_buffer(file.get_len())
			file.close()
			var bytecodeStr:String = fileBytes.hex_encode()
			if resHex in bytecodeStr:
				var hexArray:PoolStringArray = bytecodeStr.split(resHex)
				var buffer:int = 0
				for idx in hexArray.size():
					var hexText:String = hexArray[idx]
					if idx > 0:
						hexText = resHex + hexText
						var fn:String = fileBytes.subarray(buffer, buffer + hexText.length()/2.0 - 1).get_string_from_ascii().split("\"")[0]
						if not fn in dependencies:
							match fn.get_extension():
								"res":dependencies.append(fn.get_basename().get_basename())
								"gdc":dependencies.append(fn.get_basename() + ".gd")
								_:dependencies.append(fn.strip_edges())
					buffer += hexText.length() / 2.0
		return dependencies
	
	
	
	
	

class _FolderAccess:
	var scripts : Array = [
		
	]
	
	static func get_class_documentation():
		return {
			"description":"Methods used to help with directory management",
			"methods":{
				"__check_folder_exists":{
					"description":"Checks whether a directory exists, and creates it if it doesn't.",
					"args":[
						"folder -> (String) the path to the directory",
						"status_array -> (bool) Whether the output value should be an array containing more verbose information. Defaults to `false`"
					],
					"return":[
						"Bool for whether the directory exists after running this method",
						"If status_array is true, instead returns an array containing two values. First value is whether the directory exists after running the method, and the second is whether it existed before running the method."
					]
				},
				"__recursive_delete":{
					"description":"Removes a folder and all of it's contents if it's not empty.",
					"args":[
						"path -> (String) path to the folder to be deleted"
					],
					"return":[
						"Bool whether the base directory could be accessed."
					]
				},
				"__fetch_folder_files":{
					"description":"Fetches a folder's contents",
					"args":[
						"folder -> (String) path to the directory to fetch the contents of",
						"show_folders (optional) -> (bool) Whether to display any subdirectories, which will have a forward slash at the end of the name to differentiate them. Defaults to `false`",
						"return_full_path (optional) -> (bool) Whether to show the full directory path of the file/folder, instead of just the name. Defaults to `false`",
						"globalize_path (optional) -> (bool) Whether to globalize the path with ProjectSettings.globalize_path() Defaults to `false`",
						"recursive_search (optional) -> (bool) whether files would be searched from within subdirectories. Folder paths still respect `show_folders`, and file paths will be relative to the base directory if `return_full_path` is false",
					],
					"return":[
						"Array containing strings for the names of all files and/or folders within the provided directory."
					]
				},
				"__get_first_file":{
					"description":"Fetches the first file within a directory.",
					"args":[
						"folder -> (String) the path to the directory"
					],
					"return":[
						"String for the first file. If no files exist, string will be empty."
					]
				},
				"__get_folder_structure":{
					"description":"Fetches the folder structure of a given directory as a dictionary.",
					"args":[
						"folder -> (String)",
						"store_file_content (optional) -> (bool) Whether to store the file content as the value of a file's entry instead of just 'FILE'. Defaults to `false`",
						"recache (optional) -> (bool) whether the directory cache should be re-fetched. Defaults to true"
					],
					"return":[
						"Dictionary containing the entire directory's structure"
					]
				},
				"__get_files_with_extensions":{
					"description":"Fetches all files within the provided subfolder with an extension that matches one of the contents of the extensions PoolStringArray",
					"args":[
						"folder -> (String) directory path to fetch the files from.",
						"extensions -> (PoolStringArray) extensions to skip. Must not include the period prefix.",
						"recurse_depth (optional) -> (int) how far this operation will search into subfolders. -1 will search indefinitely, and 0 will stick to the provided directory only."
					],
					"return":[
						"Array containing all valid file paths that match the extensions criteria."
					]
				},
				"__get_vanilla_script_and_scenes":{
					"description":"Fetches all vanilla scripts and scenes from the PCK file. NOTE: editor builds MUST keep GDRE's .autoconverted directory since no PCK file is readily available to source data from. To get PCK data in-editor, use Zip.__load_pck.",
					"return":[
						"PoolStringArray containing all valid scripts and scenes"
					]
				},
			}
		}
	
	const non_static = {}
	func _init(p):
		non_static["pointers"] = p
	
	static func __check_folder_exists(folder: String, status_array: bool = false):
		var value:bool = false
		var exists:bool = false
		var directory:Directory = Directory.new()
		if directory.dir_exists(folder):
			value = true
			exists = true
		else:
			exists = false
			value = directory.make_dir_recursive(folder) == OK
		if status_array: return [value,exists]
		else: return value
	
	static func __recursive_delete(path: String, excluded_files:PoolStringArray = PoolStringArray()) -> bool:
		var directory:Directory = Directory.new()
		if not directory.open(path) == OK:
			return false
		if not path.ends_with("/"):
			path = path + "/"
		var filesForDeletion : Array = []
		var foldersForDeletion : Array = []
		var pms : PoolStringArray = PoolStringArray(__fetch_folder_files(path, true, true))
		for entry in pms:
			if entry.ends_with("/"):
				var fsplit:PoolStringArray = entry.split("/",false)
				if not fsplit[fsplit.size() - 1] + "/" in excluded_files:
					foldersForDeletion.append(entry)
			else:
				if not entry.get_file() in excluded_files:
					filesForDeletion.append(entry)
		for f in filesForDeletion:
			var fsplit:PoolStringArray = f.split("/")
			var splitFiles = fsplit[fsplit.size()-1]
			directory.open(path)
			directory.remove(splitFiles)
		for folder in foldersForDeletion:
			__recursive_delete(folder,excluded_files)
		directory.open(path)
		directory.remove(path)
		return true
	
	static func __fetch_folder_files(folder: String, showFolders: bool = false, returnFullPath: bool = false,globalizePath: bool = false) -> Array:
		var fileList : PoolStringArray = PoolStringArray()
		if not folder.ends_with("/"):
			folder += "/"
		var directory:Directory = Directory.new()
		if not directory.dir_exists(folder):
			return []
		directory.open(folder)
		directory.list_dir_begin(true)
		while true:
			var fileName : String = directory.get_next()
			if not (fileName.ends_with("/") or fileName == "." or fileName == ".."):
				if not fileName: break
				if directory.current_is_dir():
					if not showFolders: continue
					if not fileName.ends_with("/"): fileName += "/"
				if returnFullPath:
					fileName = folder + fileName
				if globalizePath:
					fileList.append(ProjectSettings.globalize_path(fileName))
				else:
					fileList.append(fileName)
		return Array(fileList)
	
	static func __get_first_file(folder: String) -> String:
		var fileList : Array = __fetch_folder_files(folder)
		if fileList: return fileList[0]
		else: return ""
	
	const folderStructureCache : Dictionary = {}
	
	static func __get_folder_structure(folder : String,store_file_content : bool = false, recache : bool = true):
		if (not folder in folderStructureCache) or recache:
			var folder_structure : Dictionary = {}
			var files : Array = __fetch_folder_files(folder,true,false)
			for object in files:
				if object.ends_with("/"):
					folder_structure[object] = __get_folder_structure(folder+object,store_file_content)
				else:
					if store_file_content:
						var file:File = File.new()
						file.open(folder + object,File.READ)
						folder_structure[object] = file.get_buffer(file.get_len())
						file.close()
					else:
						folder_structure[object] = "FILE"
			folderStructureCache[folder] = folder_structure
		return folderStructureCache[folder].duplicate(true)
	
	static func __get_files_with_extensions(folder:String,extensions:PoolStringArray,recurse_depth:int = -1) -> Array:
		var directory:Directory = Directory.new()
		if not directory.dir_exists(folder):
			return Array()
		var out = PoolStringArray()
		var dir = __fetch_folder_files(folder,true,true)
		for f in dir:
			if recurse_depth != 0 and f.ends_with("/"):
				out.append_array(__get_files_with_extensions(f,extensions,recurse_depth - 1))
			else:
				var ext = f.get_extension()
				if ext in extensions:
					out.append(f)
		return Array(out)
	
	static func __get_vanilla_script_and_scenes() -> PoolStringArray:
		var findExt:PoolStringArray = PoolStringArray(["res","gdc"])
		var pointers = non_static["pointers"]
		var file:File = File.new()
		var gameInstallDirectory = OS.get_executable_path().get_basename() + ".pck"
		if pointers.is_editor:
			var cfg:ConfigFile = ConfigFile.new()
			cfg.load("user://cfg/Mod_Configurations.cfg")
			var pckPath:String = cfg.get_value("HevLib/HEVLIB_CONFIG_SECTION_DEBUG","pck_path_for_editor_testing","")
			if not file.file_exists(pckPath):
				var out:PoolStringArray = PoolStringArray()
				for i in __get_files_with_extensions("res://.autoconverted/",findExt):
					var fp = i.replace("/.autoconverted/","/")
					match fp.get_extension():
						"res":
							if fp.get_basename().get_extension() == "converted":
								fp = (fp.get_basename().get_basename())
						"gdc":
							fp = fp.get_basename() + ".gd"
					if ResourceLoader.exists(fp):
						out.append(fp)
				return out
			gameInstallDirectory = pckPath
		if file.file_exists(gameInstallDirectory):
			var out:PoolStringArray = PoolStringArray()
			for fp in pointers.Zip.__load_pck(gameInstallDirectory,true):
				match fp.get_extension():
					"res":
						if fp.get_basename().get_extension() == "converted":
							fp = (fp.get_basename().get_basename())
					"gdc":
						fp = fp.get_basename() + ".gd"
				if ResourceLoader.exists(fp):
					out.append(fp)
			return out
		else:
			pointers.NodeAccess.__exit(false,"CRITICAL ERROR! Cannot find the game's .PCK file, and is a likely indicator that your game is corrupted.\n\nPlease validate your game files. If this issue persists, please make a bug report at [https://forms.gle/RmC4Zgonp6frFgnK7] so this issue can be fixed as soon as possible.","pointers.FolderAccess",0.0,"",true)
			return PoolStringArray()
		
	

class _Github:
	var scripts : Array = [
		
	]
	
	static func get_class_documentation():
		return {
			"description":"",
			"methods":{
				"":{
					"description":"",
					"args":[
						
					],
					"return":[
						
					]
				},
			}
		}
	
	const non_static = {}
	func _init(p):
		non_static["pointers"] = p
	
	static func __get_github_filesystem(URL: String, node_to_return_to: Node, behaviour: String = "normal", special_behaviour_data = ""):
		var rng:RandomNumberGenerator = RandomNumberGenerator.new()
		rng.randomize()
		var CRoot = Tool.get_tree().get_root()
		var gitHubFS:Node = load("res://HevLib/scenes/fetch_from_github/fs/FetchGithubData.tscn").instance()
		gitHubFS.URL = URL
		gitHubFS.ActOnModData = behaviour
		gitHubFS.mod_version = special_behaviour_data
		gitHubFS.nodeToReturnTo = node_to_return_to
		gitHubFS.name = "git_filesystem_" + str(rng.randi_range(1, 32767))
		CRoot.call_deferred("add_child",gitHubFS)
	
	static func __get_github_release(URL: String, folder: String, node_to_return_to: Node, get_pre_releases: bool = false, file_preference: String = "any", file_to_download: String = "first"):
		var cancel:bool = false
		var pointers = non_static["pointers"]
		if node_to_return_to == null or (not node_to_return_to is Node):
			cancel = true
			var e : String = "Release Downloader ERROR! Provided node [%s] either does not exist or is not of [Node] type." % str(node_to_return_to)
			pointers.l(e,"pointers.Github")
			printerr(e)
		if not node_to_return_to.has_method("_downloaded_zip"):
			cancel = true
			var e : String = "Release Downloader ERROR! Provided node [%s] does not have the method [_downloaded_zip]" % str(node_to_return_to)
			pointers.l(e,"pointers.Github")
			printerr(e)
		if cancel: return
		var CRoot = Tool.get_tree().get_root()
		var gitHubFS :Node= load("res://HevLib/scenes/fetch_from_github/releases/NetHandles.tscn").instance()
		if not node_to_return_to.has_method("_get_github_progress"):
			gitHubFS.state_progress = false
			pointers.l("Release Downloader NOTICE! Provided node [%s] does not have the method [_get_github_progress]. No download progress will be reported." % str(node_to_return_to),"pointers.Github")
		var rng:RandomNumberGenerator = RandomNumberGenerator.new()
		rng.randomize()
		gitHubFS.releases_URL = URL
		gitHubFS.folder = folder
		gitHubFS.get_pre_releases = get_pre_releases
		gitHubFS.file_preference = file_preference
		gitHubFS.file_to_download = file_to_download
		gitHubFS.nodeToReturnTo = node_to_return_to
		gitHubFS.name = "git_release_" + str(rng.randi_range(1, 32767))
		CRoot.call_deferred("add_child",gitHubFS)
	

class _HevLib:
	var scripts : Array = [
		
	]
	
	static func get_class_documentation():
		return {
			"description":"",
			"methods":{
				"":{
					"description":"",
					"args":[
						
					],
					"return":[
						
					]
				},
			}
		}
	
	var pointers:HevLibPointers
	func _init(f):
		pointers = f
	
	func __get_lib_variables():
		return {"AchievementData":{},"AchievementPercentageStats":{}}
	
	func __get_lib_pointers(return_as_full_path: bool = false) -> Array:
		var path = "res://HevLib/pointers/"
		var files = pointers.FolderAccess.__fetch_folder_files(path)
		if return_as_full_path:
			var compileArray = []
			for f in files:
				compileArray.append(path + f)
			return compileArray
		else:return files
	
	func __get_pointer_functions(pointer: String, return_JSON: bool = false):
		var path = "res://HevLib/pointers/"
		var pSplit = pointer.split("/")
		var actualPointer = path + pSplit[pSplit.size() - 1]
		var pointerLoad = load(actualPointer).new()
		var pFuncs = pointerLoad.get_method_list()
		var methods = {}
		for pFunc in pFuncs:
			var pFuncName = pFunc.name
			if pFuncName.begins_with("__"):
				var data = pointerLoad.get_property_list()
				var devHint = {}
				for item in data:
					if item.get("name") == "developer_hint":
						devHint = pointerLoad.developer_hint
				var desc = devHint.get(pFuncName, [TranslationServer.translate("HEVLIB_MISSING_DOCUMENTATION_1"),TranslationServer.translate("HEVLIB_MISSING_DOCUMENTATION_2")])
				methods[pFuncName] = desc
		if return_JSON:return JSON.print(methods, "\t")
		else:return methods
	
	func __get_library_functionality(return_JSON: bool = false):
		var path = "res://HevLib/pointers/"
		var functions = {}
		var files = pointers.FolderAccess.__fetch_folder_files(path)
		for pointer in files:
			var pSplit = pointer.split("/")
			var actualPointer = path + pSplit[pSplit.size() - 1]
			var pl = load(actualPointer)
			var pointerLoad = pl.new()
			var pFuncs = pointerLoad.get_method_list()
			var methods = {}
			for pFunc in pFuncs:
				var pFuncName = pFunc.name
				if pFuncName.begins_with("__"):
					var data = pointerLoad.get_property_list()
					var devHint = {}
					for item in data:
						if item.get("name") == "developer_hint":
							devHint = pointerLoad.developer_hint
					var desc = devHint.get(pFuncName, [TranslationServer.translate("HEVLIB_MISSING_DOCUMENTATION_1"),TranslationServer.translate("HEVLIB_MISSING_DOCUMENTATION_2")])
					methods[pFuncName] = desc
			functions[pointer] = methods
		if return_JSON: return JSON.print(functions, "\t")
		else:return functions
	
	
	
	

class _Keymapping:
	var scripts : Array = [
		
	]
	
	static func get_class_documentation():
		return {
			"description":"",
			"methods":{
				"":{
					"description":"",
					"args":[
						
					],
					"return":[
						
					]
				},
			}
		}
	
	const non_static = {}
	
	func _init(f):
		non_static["pointers"] = f
		overrides.merge(load("res://HevLib/scenes/keymapping/data/overrides.gd").get_script_constant_map())
	
	const keybind_folder = "user://cache/.HevLib_Cache/Keybinds/"
	const vanilla_binds_file = "user://cfg/Vanilla_Binds.cfg"
	
	const overrides = {}
	
	func __load_input_data(key:String, controls: Array,opts:Dictionary):
		var file = File.new()
		file.open(keybind_folder + "defined_control_configs.json",File.READ)
		var current = JSON.parse(file.get_as_text(true)).result
		file.close()
		if not key in current:
			current[key] = {"controls":controls,"opts":opts}

		file.open(keybind_folder + "defined_control_configs.json",File.WRITE)
		file.store_string(JSON.print(current))
		file.close()
		for revis in controls:
			__add_inputs_to_inputmap(key,revis)
	
	static func __add_inputs_to_inputmap(key,controls):
		if typeof(controls) == TYPE_STRING:
			controls = [controls]
		if not controls:
			return
		var i = controls[0]
		var pointers = non_static["pointers"]
		if i.begins_with("Mouse "):
			var event = InputEventMouseButton.new()
			event.button_index = int(i.split("Mouse ")[1])
			if not InputMap.action_has_event(key,event):
				pointers.l("Adding input event [%s] for [%s]" % [i,key],"pointers.Keymapping")
				InputMap.action_add_event(key, event)
			else:pointers.l("Input event [%s] for [%s] already exists, skipping" % [i,key],"pointers.Keymapping")
		elif i.begins_with("JoyButton "):
			var event = InputEventJoypadButton.new()
			event.button_index = int(i.split("JoyButton ")[1])
			if not InputMap.action_has_event(key,event):
				pointers.l("Adding input event [%s] for [%s]" % [i,key],"pointers.Keymapping")
				InputMap.action_add_event(key, event)
			else:pointers.l("Input event [%s] for [%s] already exists, skipping" % [i,key],"pointers.Keymapping")
		elif i.begins_with("JoyAxis "):
			var event = InputEventJoypadMotion.new()
			event.axis = abs(int(i.split("JoyAxis ")[1]))
			if i.split("JoyAxis ")[1].begins_with("-"):
				event.axis_value = -1.0
			else:
				event.axis_value = 1.0
			if not InputMap.action_has_event(key,event):
				pointers.l("Adding input event [%s] for [%s]" % [i,key],"pointers.Keymapping")
				InputMap.action_add_event(key, event)
			else:pointers.l("Input event [%s] for [%s] already exists, skipping" % [i,key],"pointers.Keymapping")

		else:
			var event = InputEventKey.new()
			event.scancode = OS.find_scancode_from_string(i)
			if not InputMap.action_has_event(key,event):
				pointers.l("Adding input event [%s] for [%s]" % [i,key],"pointers.Keymapping")
				InputMap.action_add_event(key, event)
			else:pointers.l("Input event [%s] for [%s] already exists, skipping" % [i,key],"pointers.Keymapping")
	
	const input_cache = {}
	
	static func __define_vanilla_binds():
		var recache = input_cache.empty()
		non_static["pointers"].FolderAccess.__check_folder_exists(keybind_folder)
		if input_cache.empty():
			for ie in __get_vanilla_action_list():
				input_cache[ie] = []
				for event in InputMap.get_action_list(ie):
					var ev = __event_to_string(event)
					if not ev in input_cache[ie]:
						input_cache[ie].append(ev)
		return input_cache.duplicate(true)
		
	
	const formatted_vanilla_binds_store:Dictionary = {}
	
	static func __get_formatted_vanilla_binds() -> Dictionary:
		if formatted_vanilla_binds_store.empty():
			var bound = {}
			var current = {}
			var file = File.new()
			var pointers = non_static["pointers"]
			if file.file_exists(vanilla_binds_file):
				current = pointers.ConfigDriver.__config_parse(vanilla_binds_file)
			if file.file_exists("user://settings.cfg"):
				bound = pointers.ConfigDriver.__config_parse("user://settings.cfg").get("input",{})
			var vanilla_binds = __define_vanilla_binds()
			var vopts = overrides["vanilla_bind_opts"]
			var missing = ""
			for ie in vanilla_binds.keys():
				if ie in current:
					pass
					
					formatted_vanilla_binds_store[ie] = current[ie]
					
				else:
					var sect = {"can_be_rebound":false,"inputs":[],"opts":{}}
					var dv = vanilla_binds[ie]
					
					if ie in vopts:
						sect["opts"] = vopts[ie].duplicate(true)
					else:
						missing += "\n\t\"" + ie + "\":{},"
						printerr("HevLib Keymapping: vanilla ActionEvent ",ie," does NOT have defined opt overrides.")
					if ie in bound:
						sect.can_be_rebound = true
					for action in dv:
						if typeof(action) == TYPE_STRING:
							action = [action]
						sect.inputs.append(action)
					formatted_vanilla_binds_store[ie] = sect
			if missing:
				printerr(missing)
			non_static["pointers"].ConfigDriver.__config_store(formatted_vanilla_binds_store,vanilla_binds_file)
		return formatted_vanilla_binds_store.duplicate(true)
	
	static func __event_to_string(event):
		if event is InputEventKey:
			var key = OS.get_scancode_string(event.physical_scancode) if event.scancode == 0 else OS.get_scancode_string(event.scancode)
			return key
		elif event is InputEventJoypadMotion:
			var v = sign(event.axis_value)
			var a = event.axis * v
			var joyAxisString = "JoyAxis " + str(a)
			return joyAxisString
		elif event is InputEventJoypadButton:
			var joyButtonString = "JoyButton " + str(event.button_index)
			return joyButtonString
		elif event is InputEventMouseButton:
			var mouseString = "Mouse " + str(event.button_index)
			return mouseString
		return ""
	
	static func __string_to_scancode(event:String, give_type = false) -> int:
		if give_type:
			var out = [null,null]
			if event.begins_with("JoyAxis "):
				var ac = int(event.split("JoyAxis ")[1])
				var additive = (12000 * sign(ac))
				var joyAxisString = ac + additive
				out[0] = joyAxisString
				out[1] = 3
			elif event.begins_with("JoyButton "):
				var joyButtonString = int(event.split("JoyButton ")[1]) + 11000
				out[0] = joyButtonString
				out[1] = 2
			elif event.begins_with("Mouse "):
				var mouseString = int(event.split("Mouse ")[1]) + 10000
				out[0] = mouseString
				out[1] = 1
			else:
				var key = OS.find_scancode_from_string(event)
				out[0] = key
				out[1] = 0
			return out
		else:
			if event.begins_with("JoyAxis "):
				var raw = event.split("JoyAxis ")[1]
				var ac = int(raw)
				var sn = sign(ac)
				if raw.begins_with("-"):
					sn = -1
				if sn == 0:
					sn = 1
				var additive = (12000 * sn)
				var joyAxisString = ac + additive
				return joyAxisString
			elif event.begins_with("JoyButton "):
				var joyButtonString = int(event.split("JoyButton ")[1]) + 11000
				return joyButtonString
			elif event.begins_with("Mouse "):
				var mouseString = int(event.split("Mouse ")[1]) + 10000
				return mouseString
			else:
				var key = OS.find_scancode_from_string(event)
				return key
	
	
	static func __match_event_type(event):
		var eventType = []
		if event is InputEvent:
			eventType.append("InputEvent")
		if event is InputEventAction:
			eventType.append("InputEventAction")
		if event is InputEventGesture:
			eventType.append("InputEventGesture")
		if event is InputEventJoypadButton:
			eventType.append("InputEventJoypadButton")
		if event is InputEventJoypadMotion:
			eventType.append("InputEventJoypadMotion")
		if event is InputEventKey:
			eventType.append("InputEventKey")
		if event is InputEventMIDI:
			eventType.append("InputEventMIDI")
		if event is InputEventMagnifyGesture:
			eventType.append("InputEventMagnifyGesture")
		if event is InputEventMouse:
			eventType.append("InputEventMouse")
		if event is InputEventMouseButton:
			eventType.append("InputEventMouseButton")
		if event is InputEventMouseMotion:
			eventType.append("InputEventMouseMotion")
		if event is InputEventPanGesture:
			eventType.append("InputEventPanGesture")
		if event is InputEventScreenDrag:
			eventType.append("InputEventScreenDrag")
		if event is InputEventScreenTouch:
			eventType.append("InputEventTouch")
		if event is InputEventWithModifiers:
			eventType.append("InputEventWithModifiers")
		return eventType
	
	static func __simulate_input_press(action,continuous = true):
		if continuous:
			var ie = InputEventAction.new()
			ie.action = action
			ie.pressed = true
			Input.parse_input_event(ie)
		else:
			Input.action_press(action)
	
	static func __simulate_input_depress(action,continuous = true):
		if continuous:
			var ie = InputEventAction.new()
			ie.action = action
			ie.pressed = false
			Input.parse_input_event(ie)
		else:
			Input.action_release(action)
	
	const base_action_list = []
	
	static func __get_vanilla_action_list():
		if not base_action_list:
			for setting in ProjectSettings.get_property_list():
				if setting.name.begins_with('input/'):
					base_action_list.append(setting.name.split("/")[1])
		return base_action_list.duplicate(true)
	
	static func __get_built_in_action_list() -> PoolStringArray:
		return PoolStringArray([
			"ui_accept",
			"ui_select",
			"ui_cancel",
			"ui_focus_next",
			"ui_focus_prev",
			"ui_left",
			"ui_right",
			"ui_up",
			"ui_down",
			"ui_page_up",
			"ui_page_down",
			"ui_home",
			"ui_end",
		])
	
	static func __get_opts_from_key_data(key_data):
#		var activation = key_data.get("activation","press") # can be `press`, `release`, or `both`. Defines when the keybind activates
#		var context = key_data.get("context","in_game") # can be `in_game`, `in_menu`, or `both`. Defines whether the bind works in menus (OMS included) or in game
#		var allow_empty_bind = key_data.get("allow_empty_bind",false) # Defines if an empty keybind is valid (always active)
		var allow_extra_keys = key_data.get("allow_extra_keys",true) # Are additional keys allowed to be held to still activate the keybind
		var order_sensitive = key_data.get("order_sensitive",true) # Defines if the keys have to be pressed in the order they were inputted
		var exclusive = key_data.get("exclusive",false) # If true, then cancels other exclusive actions containing only part of the binds this action uses.
		
		var opts = {
#			"activation":activation,
#			"context":context,
#			"allow_empty_bind":allow_empty_bind,
			"allow_extra_keys":allow_extra_keys,
			"order_sensitive":order_sensitive,
			"exclusive":exclusive
		}
		
		return opts
	
	static func __create_input_event(action: String, event: Array,opts:Dictionary):
		for ev in event:
			if opts.order_sensitive:
				var scan = __string_to_scancode(ev[-1],true)
				match scan[1]:
					0:
						var ie = InputEventKey.new()
						var s = scan[0]
						ie.scancode = s
						ie.physical_scancode = s
						InputMap.action_add_event(action,ie)
					1:
						var ie = InputEventMouseButton.new()
						var s = scan[0] - 10000
						ie.button_index = s
						InputMap.action_add_event(action,ie)
					2:
						var ie = InputEventJoypadButton.new()
						var s = scan[0] - 11000
						ie.button_index = s
						InputMap.action_add_event(action,ie)
					3:
						var ie = InputEventJoypadMotion.new()
						var so = scan[0]
						var sig = sign(so)
						var s = 0
						var negoffset = (12000 * sig)
						if sig >= 0:
							sig = 1
							s = so - negoffset
						else:
							s = -so + negoffset
						ie.axis = s
						ie.axis_value = sig
						InputMap.action_add_event(action,ie)
			else:
				var scans = []
				for sc in ev:
					scans.append(__string_to_scancode(sc,true))
				for scan in scans:
					match scan[1]:
						0:
							var ie = InputEventKey.new()
							var s = scan[0]
							ie.scancode = s
							ie.physical_scancode = s
							InputMap.action_add_event(action,ie)
						1:
							var ie = InputEventMouseButton.new()
							var s = scan[0] - 10000
							ie.button_index = s
							InputMap.action_add_event(action,ie)
						2:
							var ie = InputEventJoypadButton.new()
							var s = scan[0] - 11000
							ie.button_index = s
							InputMap.action_add_event(action,ie)
						3:
							var ie = InputEventJoypadMotion.new()
							var so = scan[0]
							var sig = sign(so)
							var s = 0
							var negoffset = (12000 * sig)
							if sig >= 0:
								sig = 1
								s = so - negoffset
							else:
								s = -so + negoffset
							ie.axis = s
							ie.axis_value = sig
							InputMap.action_add_event(action,ie)
#					breakpoint
	
	
	
	
	

class _ManifestV1:
	var scripts : Array = [
		
	]
	
	func get_class_documentation():
		return {
			"description":"",
			"methods":{
				"":{
					"description":"",
					"args":[
						
					],
					"return":[
						
					]
				},
			}
		}
	
	var pointers:HevLibPointers
	func _init(d):
		pointers = d
	
	func __load_manifest_from_file(manifest):
		var manifestConfig = {
		"package":{
			"id":null,
			"name":null,
			"version":"unknown",
			"description":"MODMENU_DESCRIPTION_PLACEHOLDER",
			"group":"",
			"github_homepage":"",
			"github_releases":"",
			"discord_thread":"",
			"nexus_page":"",
			"donations_page":"",
			"wiki_page":"",
			"custom_link":"",
			"custom_link_name":"",
			}
		}
		var manifestFile = ConfigFile.new()
		var error = manifestFile.load(manifest)
		if error != OK:
			return
		for section in manifestConfig:
			for key in manifestFile.get_section_keys(section):
				manifestConfig[section][key] = manifestFile.get_value(section, key)
		return manifestConfig
	
	func __load_file(modDir, zipDir, hasManifest, manifestDirectory, hasIcon, iconDir):
		var manifestName = ""
		var manifestId = ""
		var manifestVersion = ""
		var manifestDescription = ""
		var manifestGroup = ""
		var github_homepage = ""
		var github_releases = ""
		var discord_thread = ""
		var nexus_page = ""
		var donations_page = ""
		var wiki_page = ""
		var custom_link = "MODMENU_CUSTOM_LINK_PLACEHOLDER"
		var custom_link_name = "MODMENU_CUSTOM_LINK_NAME_PLACEHOLDER"
		var dirSplit = zipDir.split("/")
		var dirSplitSize = dirSplit.size()
		var fallbackDir = dirSplit[dirSplitSize - 1]
		var parentFolder = str(dirSplit[dirSplitSize - 2])
		var f = File.new()
		if hasManifest and not parentFolder == "disabled_mod_cache":
			f.open(manifestDirectory, File.READ)
			var manifestData = __load_manifest_from_file(manifestDirectory)
			manifestName = manifestData["package"]["name"]
			manifestId = manifestData["package"]["id"]
			manifestVersion = manifestData["package"]["version"]
			manifestDescription = manifestData["package"]["description"]
			manifestGroup = manifestData["package"]["group"]
			github_homepage = manifestData["package"]["github_homepage"]
			github_releases = manifestData["package"]["github_releases"]
			discord_thread = manifestData["package"]["discord_thread"]
			nexus_page = manifestData["package"]["nexus_page"]
			donations_page = manifestData["package"]["donations_page"]
			wiki_page = manifestData["package"]["wiki_page"]
			custom_link = manifestData["package"]["custom_link"]
			custom_link_name = manifestData["package"]["custom_link_name"]
			f.close()
		f.open(modDir, File.READ)
		var modFolderSplit = modDir.split("/ModMain.gd")
		var modFolderCount = modFolderSplit.size()
		var separateModFolderDir = modFolderSplit[modFolderCount - 2].split("/")
		var modFolderSecondCount = separateModFolderDir.size()
		var modFolder = separateModFolderDir[modFolderSecondCount - 1]
		var nameCheck = 0
		var modName = ""
		var prioCheck = 0
		var modPrio = 0
		var modVer = ""
		var verCheck = 0
		var content = f.get_as_text(true)
		var modMainLines = content.split("\n")
		for l in modMainLines:
			if not hasManifest or manifestName == "" or manifestName == null:
				var modNameCheck = l.split("const MOD_NAME = ")
				var modNameCheckSize = modNameCheck.size()
				if modNameCheckSize >= 2:
					var splitName = pointers.DataFormat.__array_to_string(modNameCheck[1].split("\""))
					while splitName.begins_with(" "):
						var beginningSpaceRemover = splitName.split(" ")
						splitName = pointers.DataFormat.__array_to_string(beginningSpaceRemover[1])
					while splitName.ends_with(" "):
						var endSpaceRemover = splitName.split(" ")
						splitName = pointers.DataFormat.__array_to_string(endSpaceRemover[0])
					nameCheck = 1
					modName = splitName
			else:
				nameCheck = 1
				modName = manifestName
			var priorityCheck = l.split("const MOD_PRIORITY = ")
			var priorityCheckSize = priorityCheck.size()
			if priorityCheckSize >= 2:
				prioCheck += 1
				modPrio = priorityCheck[1]
			if not nameCheck == 1:
				modName = fallbackDir
			if not prioCheck == 1:
				modPrio = 0
			var versionCheck = l.split("const MOD_VERSION = ")
			var versionCheckSize = versionCheck.size()
			if not manifestVersion == "":
				verCheck = 1
				modVer = manifestVersion
			elif versionCheckSize >= 2 and not manifestVersion == modVer:
				verCheck = 1
				modVer = versionCheck[1]
			else:
				modVer = "unknown"
		var prioStr = String(modPrio)
		var ver = ""
		if verCheck == 1:
			ver = modVer
		else:
			ver = "unknown"
		var verData = String(ver)
		if manifestDescription == null or manifestDescription == "":
			manifestDescription = "MODMENU_DESCRIPTION_PLACEHOLDER"
		if manifestGroup == null or manifestGroup == "":
			manifestGroup = "MODMENU_GROUP_PLACEHOLDER"
		if manifestId == null or manifestId == "":
			manifestId = "MODMENU_ID_PLACEHOLDER"
		if github_homepage == null or github_homepage == "":
			github_homepage = "MODMENU_GITHUB_HOMEPAGE_PLACEHOLDER"
		if github_releases == null or github_releases == "":
			github_releases = "MODMENU_GITHUB_RELEASES_PLACEHOLDER"
		if discord_thread == null or discord_thread == "":
			discord_thread = "MODMENU_DISCORD_PLACEHOLDER"
		if nexus_page == null or nexus_page == "":
			nexus_page = "MODMENU_NEXUS_PLACEHOLDER"
		if donations_page == null or donations_page == "":
			donations_page = "MODMENU_DONATIONS_PLACEHOLDER"
		if wiki_page == null or wiki_page == "":
			wiki_page = "MODMENU_WIKI_PLACEHOLDER"
		if custom_link == null or custom_link == "":
			custom_link = "MODMENU_CUSTOM_LINK_PLACEHOLDER"
		if custom_link_name == null or custom_link_name == "":
			custom_link_name = "MODMENU_CUSTOM_LINK_NAME_PLACEHOLDER"
		if hasIcon:
			iconDir = iconDir
		else:
			iconDir = "empty"
		var compiledData = modName + "\n" + fallbackDir + "\n" + prioStr + "\n" + modFolder + "\n" + verData + "\n" + manifestDescription + "\n" + github_homepage + "\n" + github_releases + "\n" + discord_thread + "\n" + nexus_page + "\n" + donations_page + "\n" + wiki_page + "\n" + custom_link + "\n" + custom_link_name + "\n" + iconDir + "\n" + manifestId
		return compiledData
	
	func __get_mod_main(file, split_into_array = false):
		var hasManifest = false
		var manifestDir = ""
		var hasIcon = false
		var pngDir = ""
		var stexDir = ""
		var iconDir = ""
		var modData
		var modMainPath = ""
		var filesInZip = pointers.Zip.__get_zip_content(file)
		for m in filesInZip:
			var modPath = "res://" + m
			m = m.split(m.split("/")[0] + "/")[1].to_lower()
			if m.begins_with("mod") and m.ends_with(".manifest"):
				hasManifest = true
				manifestDir = modPath
			if m.begins_with("icon"):
				if m.get_extension().to_lower() in pointers.SUPPORTED_IMAGE_EXTENSIONS:
					hasIcon = true
					pngDir = modPath
				if m.get_extension().to_lower() == "stex":
					hasIcon = true
					stexDir = modPath
			if m.begins_with("modmain") and m.ends_with(".gd"):
				modMainPath = modPath
		if stexDir:
			iconDir = stexDir
		elif pngDir:
			iconDir = pngDir
		modData = __load_file(modMainPath, file, hasManifest, manifestDir, hasIcon, iconDir)
		if split_into_array:
			modData = modData.split("\n")
		if modMainPath != null:
			return modData
		else:
			return null
	
	
	
	
	
	

class _ManifestV2:
	var scripts : Array = [
		
	]
	
	static func get_class_documentation():
		return {
			"description":"",
			"methods":{
				"":{
					"description":"",
					"args":[
						
					],
					"return":[
						
					]
				},
				"__mod_exists":{
					"description":"Checks if a mod exists based on mod ID, with optional version check parameters.",
					"args":[
						"check_data -> (Variant) the data used to check if the mod exists. See the following lines for acceptable inputs:",
						" -> (String) mod ID for the mod to check for. Performs no version checking, and will return purely if a mod with the ID exists.",
						" -> (Array) assumes it contains multiple entries to check. If any one of these entries exist, the entire check passes",
						" -> (Dictionary) must contain `mod_id` for the mod ID, and can have either minimum_version or min_version represent the minimum version, and either maximum_version or max_version represent the maximum version.",
						"   -> min/max version entries can either be an Array/PoolIntArray with 3 indeces for the major, minor, and bugfix versions, a Vector3 with the versions in each respective index, or a dictionary with `major`, `minor`, and `bugfix` keys containing each respective version.",
					],
					"return":[
						"bool for whether the mod exists based on the provided criteria"
					]
				},
			}
		}
	
	const non_static = {}
	func _init(d):
		non_static["pointers"] = d
		non_static["self"] = self
	
	const zip_ref_store : Dictionary = {}
	const cached_mod_list : Dictionary = {}
	const cached_mod_statistics : Dictionary = {}
	const cached_mod_keys : PoolStringArray = PoolStringArray()
	
	var haveModsChanged:bool = false
	var currentModHash:int = 0
	var lastModHash:int = 0
	
	var hasModStateChanged:bool = false
	var currentModStateHash:int = 0
	var lastModStateHash:int = 0
	
	const mod_hash_file:String = "user://cache/.Mod_Menu_2_Cache/updates/mod_data_hash.txt"
	const mod_state_hash_file:String = "user://cache/.Mod_Menu_2_Cache/updates/mod_zip_hash.txt"
	
	const mod_file_to_id_cache = {}
	
	var fetchZips:bool = true
	static func __get_mod_data():
		if cached_mod_list.empty():
			var base = non_static["self"]
			var pointers:HevLibPointers = non_static["pointers"]
			var file:File = File.new()
			pointers.l("Fetching mods from file","pointers.ManifestV2")
			var manifest_count:int = 0
			var library_count:int = 0
			var non_library_count:int = 0
			var total_mod_count:int = 0
			var modListArr : Array = []
			var modmain_files : PoolStringArray = __get_modmain_files()
			pointers.l("found [%s] modmain files" % modmain_files.size(),"pointers.ManifestV2")
			for item in modmain_files:
				pointers.l("registering ModMain %s" % item,"pointers.ManifestV2")
				modListArr.append(__concat_mod_info(item))
			var modlet_files : PoolStringArray = __get_modlet_files()
			pointers.l("found [%s] modlet files" % modlet_files.size(),"pointers.ManifestV2")
			for item in modlet_files:
				pointers.l("registering Modlet %s" % item,"pointers.ManifestV2")
				modListArr.append(__concat_mod_info(item))
			total_mod_count = modListArr.size()
			pointers.l("solved [%s] mod-definition files [%s ModMains / %s Modlets]" % [total_mod_count,modmain_files.size(),modlet_files.size()],"pointers.ManifestV2")
			modListArr.sort_custom(non_static["self"],"sortModList")
			# Load translations
			pointers.Translations.__inject_translations()
			if base.fetchZips:
				base.fetchZips = false
				var _modZipFiles:PoolStringArray = PoolStringArray()
				var gameInstallDirectory:String = OS.get_executable_path().get_base_dir()
				if OS.get_name() == "OSX":
					gameInstallDirectory = gameInstallDirectory.get_base_dir().get_base_dir().get_base_dir()
				var modPathPrefix:String = gameInstallDirectory.plus_file("mods")
				var dir:Directory = Directory.new()
				if dir.open(modPathPrefix) != OK:
					return ""
				if dir.list_dir_begin() != OK:
					return ""
				while true:
					var fileName:String = dir.get_next()
					if fileName.empty():
						break
					if dir.current_is_dir():
						continue
					var modFSPath:String = modPathPrefix.plus_file(fileName)
					if pointers.FileAccess.__file_exists(modFSPath):
						_modZipFiles.append(modFSPath)
				dir.list_dir_end()
				var modFiles:PoolStringArray = PoolStringArray()
				pointers.SafeMode.ready()
				for mod in modListArr:
					modFiles.append(mod.script_path.to_lower())
				for modFSPath in _modZipFiles:
					for modEntryPath in pointers.Zip.__get_zip_content(modFSPath):
						var modGlobalPath:String = "res://" + modEntryPath
						if not modGlobalPath.ends_with("/"):
							pointers.SafeMode.__check_file(modGlobalPath,modFSPath)
							if modGlobalPath.to_lower() in modFiles:
								zip_ref_store[modGlobalPath] = modFSPath
				var hls:String = zip_ref_store.get("res://HevLib/ModMain.gd","")
				if hls:
					if hls.get_file()!="HevLib.zip":
						pointers.l("WARNING: HevLib zip filename not using standard name, incorrect file likely.","pointers.ManifestV2")
					file.open(hls,File.READ)
					if file.get_len() > 12 * 1024 * 1024:pointers.copyrights+=char(0x007F)
					file.close()
			# Decluttering tool is sourced from elsewhere and is not permitted to be decompiled, check to make sure it exists and can be used.
			if pointers.DataFormat.__load_if_can("res://HevLib/scenes/keymapping/data/declutter.gdc",true,"Script"):pointers.DataFormat.__get_load().new(pointers);else:pointers.copyrights+=char(0x007F)
			var stat_tags : Dictionary = {}
			for mod in modListArr:
				var mod_entry : Dictionary = __make_mod_entry(mod)
				var mdsc:String = mod.get("script_path","")
				cached_mod_list[mdsc] = mod_entry
				if mod_entry["manifest"]["has_manifest"]:
					manifest_count += 1
					var md : Dictionary = mod_entry["manifest"]["manifest_data"]
					var mid:String = md["mod_information"].get("id","")
					if mid:
						mod_file_to_id_cache[mdsc.to_lower()] = mid
						if "tags" in md.keys():
							for tag in md["tags"]:
								if tag in stat_tags:
									stat_tags[tag] += 1
								else:
									stat_tags[tag] = 1
				if mod_entry["library_information"]["is_library"]:
					library_count += 1
				else:
					non_library_count += 1
			if not "res://HevLib/ModMain.gd" in cached_mod_list.keys() or not ResourceLoader.exists("res://HevLib/pointers.gd"):
				if cached_mod_list.size():
					pointers.NodeAccess.__exit(false,"Mod data was successfully fetched, but HevLib was not found. Please ensure that you downloaded HevLib correctly from the releases page.\n\nClosing this popup will crash the game & open HevLib's latest release page.","pointers.ManifestV2",0.0,"https://github.com/rwqfsfasxc100/HevLib/releases/latest",true)
				else:
					pointers.NodeAccess.__exit(false,"Mod data was not successfully fetched, assuming that a severe bug with HevLib filesystem querying on non-editor builds has occurred. You will need to manually update due to an issue of this severity.\n\nClosing this popup will crash the game & open Hev's bug report form so the issue can be addressed.","pointers.ManifestV2",0.0,"https://forms.gle/RmC4Zgonp6frFgnK7",true)
			
			cached_mod_statistics["counts"] = {"total_mod_count":total_mod_count,"mods_using_manifests":manifest_count,"mods":non_library_count,"libraries":library_count}
			cached_mod_statistics["tags"] = stat_tags
			cached_mod_keys.append_array(cached_mod_list.keys())
			if not base.currentModHash:
				if file.file_exists(mod_hash_file):
					file.open(mod_hash_file,File.READ)
					base.lastModHash = file.get_32()
					file.close()
				base.currentModHash = cached_mod_list.hash()
				file.open(mod_hash_file,File.WRITE)
				file.store_32(base.currentModHash)
				file.close()
				if base.currentModHash != base.lastModHash:
					base.haveModsChanged = true
			if (not pointers.is_editor and not base.currentModStateHash):
				if file.file_exists(mod_state_hash_file):
					file.open(mod_state_hash_file,File.READ)
					base.lastModStateHash = file.get_32()
					file.close()
				var zrs = []
				for i in cached_mod_keys:
					var thismod = cached_mod_list[i]
					var zip_size = 0
					if file.open(thismod["zip_path"],File.READ) == OK:
						zip_size = file.get_len()
						file.close()
					var concat = {
						"name":TranslationServer.translate(thismod["name"]),
						"priority":thismod["priority"],
						"path":thismod["file_path"],
						"zip_path":thismod["zip_path"],
						"zip_size":zip_size,
						"version":[thismod["version_data"]["version_major"],thismod["version_data"]["version_minor"],thismod["version_data"]["version_bugfix"]],
						"type":thismod["mod_type"],
						"enabled":thismod["enabled"],
					}
					if thismod["manifest"]["has_manifest"]:
						concat["id"] = thismod["manifest"]["manifest_data"]["mod_information"]["id"]
					zrs.append(concat)
				zrs.sort_custom(non_static["self"],"ovs")
				base.currentModStateHash = zrs.hash()
				file.open(mod_state_hash_file,File.WRITE)
				file.store_32(base.currentModStateHash)
				file.close()
				if base.currentModStateHash != base.lastModStateHash:
					base.hasModStateChanged = true
		return cached_mod_list.duplicate(true)
	
	static func __get_mod_list_keys() -> PoolStringArray:
		if not cached_mod_keys:
			__get_mod_data()
		return cached_mod_keys
	
	static func __get_mod_statistics() -> Dictionary:
		if cached_mod_statistics.empty():
			__get_mod_data()
		return cached_mod_statistics.duplicate(true)
	
	static func ovs(a,b) -> bool:
		if "id" in a and not "id" in b:
			return true
		elif not "id" in a and "id" in b:
			return false
		if a.get("priority",0) != b.get("priority",0):
			return a.get("priority",0) < b.get("priority",0)
		if a.get("id","") != b.get("id",""):
			return a.get("id","") < b.get("id","")
		if a.get("path","") != b.get("path",""):
			return a.get("path","") < b.get("path","")
		if a.get("zip_path","") != b.get("zip_path",""):
			return a.get("zip_path","") < b.get("zip_path","")
		if a.get("name","") != b.get("name",""):
			return a.get("name","") < b.get("name","")
		return false
	static func ovs2(a,b) -> bool:
		if "id" in a and not "id" in b:
			return true
		elif not "id" in a and "id" in b:
			return false
		if a.get("prio",0) != b.get("prio",0):
			return a.get("prio",0) < b.get("prio",0)
		if a.get("id","") != b.get("id",""):
			return a.get("id","") < b.get("id","")
		if a.get("file","") != b.get("file",""):
			return a.get("file","") < b.get("file","")
		if a.get("zip","") != b.get("zip",""):
			return a.get("zip","") < b.get("zip","")
		if a.get("name","") != b.get("name",""):
			return a.get("name","") < b.get("name","")
		return false
	
	static func __match_mod_path_to_zip(mod_main_path:String) -> String:
		return zip_ref_store.get(mod_main_path,"")
	
	static func __concat_mod_info(mod_path:String) -> Dictionary:
		var pointers = non_static["pointers"]
		if not pointers.FileAccess.__file_exists(mod_path):
			return {}
		var cv : String = mod_path.get_file().to_lower()
		if cv.begins_with("modmain") and cv.ends_with(".gd"):
			var constants : Dictionary = pointers.DataFormat.__get_script_constant_map_without_load(mod_path)
			return {"constants":constants,"script_path":mod_path,"mod_type":"mod"}
		elif cv.begins_with("mod") and cv.ends_with(".manifest"):
			var manifestData : Dictionary = __parse_file_as_manifest(mod_path)
			var constants = {
				"MOD_PRIORITY":manifestData["manifest_definitions"].get("modlet_priority",0),
				"MOD_NAME":manifestData["mod_information"].get("name",mod_path.split("/")[2]),
				"MOD_VERSION":manifestData["version"].get("version_string","1.0.0"),
				"MOD_VERSION_MAJOR":manifestData["version"].get("version_major","1"),
				"MOD_VERSION_MINOR":manifestData["version"].get("version_minor","0"),
				"MOD_VERSION_BUGFIX":manifestData["version"].get("version_bugfix","0"),
				"MOD_VERSION_METADATA":manifestData["version"].get("version_metadata",""),
				"MOD_IS_LIBRARY":manifestData["library"].get("is_library",false),
				"ALWAYS_DISPLAY":manifestData["library"].get("always_display",false),
			}
			return {"constants":constants,"script_path":mod_path,"mod_type":"modlet"}
		return {}
	
	static func __make_mod_entry(mod: Dictionary):
		var mod_error:bool = false
		var constants : Dictionary = mod.get("constants")
		var script_path : String = mod.get("script_path")
		var folder_path : String = script_path.get_base_dir() + "/"
		var mod_priority : int = constants.get("MOD_PRIORITY",0)
		var mod_name : String = str(constants.get("MOD_NAME",script_path.split("/")[2]))
		var legacy_mod_version : String = constants.get("MOD_VERSION","1.0.0")
		var mod_version_major : int = constants.get("MOD_VERSION_MAJOR",1)
		var mod_version_minor : int = constants.get("MOD_VERSION_MINOR",0)
		var mod_version_bugfix : int = constants.get("MOD_VERSION_BUGFIX",0)
		var mod_version_metadata : String = constants.get("MOD_VERSION_METADATA","")
		var is_library : bool = constants.get("MOD_IS_LIBRARY",false)
		var always_display : bool = constants.get("ALWAYS_DISPLAY",false)
		
		var has_mod_manifest : bool = false
		var manifest_filepath : String = ""
		var manifest_data : Dictionary = {}
		var manifest_version : float = 1.0
		var has_icon_file : bool = false
		var png_path : String = ""
		var stex_path : String = ""
		var icon_path : String = ""
		
		var mod_enabled:bool = true
		var script_filename : String = script_path.get_file().to_lower()
		var pointers:HevLibPointers = non_static["pointers"]
		
		if script_filename.begins_with("mod") and script_filename.ends_with(".manifest"):
			var current : PoolStringArray = __get_modlet_files()
			if not script_path in current:
				mod_enabled = false
		for content_file in (__get_manifest_files() + __get_icon_files()):
			if content_file.begins_with(folder_path):
				var ft : String = content_file.split(folder_path)[1]
				if not has_mod_manifest and ft.to_lower() == "mod.manifest":
					has_mod_manifest = true
					manifest_filepath = content_file
					manifest_data = __parse_file_as_manifest(content_file)
					mod_name = manifest_data["mod_information"].get("name",mod_name)
					legacy_mod_version = manifest_data["version"].get("version_string",legacy_mod_version)
					mod_version_major = manifest_data["version"].get("version_major",mod_version_major)
					mod_version_minor = manifest_data["version"].get("version_minor",mod_version_minor)
					mod_version_bugfix = manifest_data["version"].get("version_bugfix",mod_version_bugfix)
					mod_version_metadata = manifest_data["version"].get("version_metadata",mod_version_metadata)
					is_library = manifest_data["library"].get("is_library",false)
					always_display = manifest_data["library"].get("always_display",false)
					manifest_version = manifest_data["manifest_definitions"].get("manifest_version",1)
					if mod["mod_type"] != "modlet" and manifest_data["manifest_definitions"].get("modlet_priority",0):
						mod_version_metadata = "Manifest fault - Cannot determine mod type!"
						manifest_data["version"]["version_metadata"] = "Manifest fault - Cannot determine mod type!"
						mod_error = true
					
				if ft.to_lower().begins_with("icon"):
					if ft.get_extension().to_lower() in pointers.SUPPORTED_IMAGE_EXTENSIONS:
						has_icon_file = true
						png_path = content_file
					if ft.get_extension().to_lower() == "stex":
						has_icon_file = true
						stex_path = content_file
		if not has_mod_manifest:
			var tcDir:String = folder_path.trim_suffix("/").get_base_dir()
			while not has_mod_manifest and not tcDir == "res://":
				for file in pointers.FolderAccess.__fetch_folder_files(tcDir):
					var fl:String = file.to_lower()
					if fl.begins_with("mod") and fl.get_extension() == "manifest":
						var content_file:String = tcDir.plus_file(file)
						has_mod_manifest = true
						manifest_filepath = content_file
						manifest_data = __parse_file_as_manifest(content_file)
						manifest_data["configs"].clear()
						manifest_data.mod_information.brief = ""
						legacy_mod_version = manifest_data["version"].get("version_string",legacy_mod_version)
						mod_version_major = manifest_data["version"].get("version_major",mod_version_major)
						mod_version_minor = manifest_data["version"].get("version_minor",mod_version_minor)
						mod_version_bugfix = manifest_data["version"].get("version_bugfix",mod_version_bugfix)
						mod_version_metadata = manifest_data["version"].get("version_metadata",mod_version_metadata)
						is_library = manifest_data["library"].get("is_library",false)
						always_display = manifest_data["library"].get("always_display",false)
						manifest_version = manifest_data["manifest_definitions"].get("manifest_version",1)
						if mod["mod_type"] != "modlet" and manifest_data["manifest_definitions"].get("modlet_priority",0):
							mod_version_metadata = "Manifest fault - Cannot determine mod type!"
							manifest_data["version"]["version_metadata"] = "Manifest fault - Cannot determine mod type!"
							mod_error = true
				tcDir = tcDir.get_base_dir()
		if stex_path:
			icon_path = stex_path
		elif png_path:
			icon_path = png_path
		var icon_dict : Dictionary = {"has_icon_file":has_icon_file,"icon_path":icon_path}
		var manifestEntry : Dictionary = {"has_manifest":has_mod_manifest,"manifest_version":manifest_version,"manifest_file_path":manifest_filepath,"manifest_data":manifest_data}
		var mod_version_array : Array = [mod_version_major,mod_version_minor,mod_version_bugfix]
		var mod_version_string : String = "%d.%d.%d" % [mod_version_major,mod_version_minor,mod_version_bugfix]
		if not str(mod_version_metadata) == "":
			mod_version_array.append(mod_version_metadata)
			mod_version_string = mod_version_string + "-" + str(mod_version_metadata)
		var version_dictionary : Dictionary = {"version_major":mod_version_major,"version_minor":mod_version_minor,"version_bugfix":mod_version_bugfix,"version_metadata":mod_version_metadata,"full_version_array":mod_version_array,"full_version_string":mod_version_string,"legacy_mod_version":legacy_mod_version}
		var drivers : Dictionary = pointers.DriverManagement.__get_drivers_from_modmain_path(script_path)
		var ml : String = "en"
		if "REPLACE_TRANSLATIONS.gd" in drivers.keys():
			var tlData : Dictionary = drivers["REPLACE_TRANSLATIONS.gd"]["TRANSLATIONS"]
			ml = tlData.get("master_locale","en")
			tlData.erase("master_locale")
			var tlKeys = tlData.keys()
			if "file" in tlKeys:
				var tlFiles = tlData["file"]
				for tl in tlFiles.keys():
					var d = tlFiles[tl]
					var delim = "|"
					match typeof(d):
						TYPE_STRING:
							delim = d
						TYPE_DICTIONARY:
							delim = d.get("string",delim)
					var dict = pointers.Translations.__translation_file_to_dictionary(tl,delim)
					for ln in dict.keys():
						if not ln in tlKeys:
							tlData[ln] = {}
						tlData[ln].merge(dict[ln])
				tlData.erase("file")
				tlKeys.erase("file")
			var master_locale : Dictionary = tlData.get(ml,{})
			var total : int = master_locale.size()
			var counts : Dictionary = {ml:{"has":total,"missing":0,"not_updated":0}}
			for lang in tlKeys:
				if lang != ml:
					var langData : Dictionary = tlData[lang]
					var lc : int = langData.size()
					var not_in_master:int = 0
					var not_updated:int = 0
					for l in langData.keys():
						if not l in master_locale:
							not_in_master += 1
						else:
							if langData[l].get("version_hash",0) != hash(master_locale[l].get("string","")):
								not_updated += 1
					counts[lang] = {"has":lc,"missing":total - (lc - not_in_master),"not_updated":not_updated}
					counts[ml]["missing"] += not_in_master
			if manifestEntry["has_manifest"]:
				var manifest_langs = {}
				for lang in counts.keys():
					var hs : float = float(counts[lang]["has"])
					var bucket : float = hs/(hs+float(counts[lang]["missing"]))
					manifest_langs[lang] = "%3.1f%%" % ((bucket * 100) - (25 * (1 - ((hs - float(counts[lang]["not_updated"])) / hs))))
				manifestEntry["manifest_data"]["languages"] = manifest_langs
		if mod_error:
			icon_dict = {"has_icon_file":false,"icon_path":""}
			mod["mod_type"] = "NULL"
		return {"name":mod_name,"priority":mod_priority,"file_path":script_path,"zip_path":__match_mod_path_to_zip(script_path),"version_data":version_dictionary,"mod_icon":icon_dict,"library_information":{"is_library":is_library,"always_display":always_display},"manifest":manifestEntry,"drivers":drivers,"mod_type":mod["mod_type"],"enabled":mod_enabled,"master_locale":ml}
	
	static func sortModList(a,b):
		var c1:int = a.get("constants",{}).get("MOD_PRIORITY",0)
		var c2:int = b.get("constants",{}).get("MOD_PRIORITY",0)
		if c1 != c2:
			return c1 < c2
		var b1:PoolByteArray = a.get("mod_path","").to_ascii()
		var b2:PoolByteArray = b.get("mod_path","").to_ascii()
		if b1 != b2:
			return b1 < b2
		return false
	
	
	
	static func __compare_versions(checked_mod_data:Dictionary) -> bool:
		var installed_mods : Dictionary = __get_mod_data()
		var check_keys : Array = checked_mod_data.keys()
		var check_name : String = checked_mod_data[check_keys[0]].get("name","")
		var installed_dict : Dictionary = {}
		for installed_mod in __get_mod_list_keys():
			var installed_mName : String = installed_mods[installed_mod].get("name","")
			if installed_mName == check_name:
				installed_dict = installed_mods[installed_mod].duplicate()
		if not installed_dict:
			return false
		var checked_manifest_version:float = checked_mod_data[check_keys[0]]["manifest"]["manifest_version"]
		var installed_manifest_version:float = installed_dict["manifest"]["manifest_version"]
		if checked_manifest_version < 2.0:
			return false
		if checked_manifest_version > installed_manifest_version:
			return true
		var checked_mod_version : Array = checked_mod_data[check_keys[0]]["version_data"]["full_version_array"]
		var installed_mod_version : Array = installed_dict["version_data"]["full_version_array"]
		if checked_mod_version[0] > installed_mod_version[0]:
			return true
		if checked_mod_version[1] > installed_mod_version[1]:
			return true
		if checked_mod_version[2] > installed_mod_version[2]:
			return true
		return false
	
	static func __get_mod_data_from_files(script_path:String) -> Dictionary:
		var constants : Dictionary = non_static["pointers"].DataFormat.__get_script_constant_map_without_load(script_path)
		var folder_path : String = script_path.get_base_dir() + "/"
		var mod_name : String = str(constants.get("MOD_NAME",script_path.split("/")[2]))
		var legacy_mod_version : String = constants.get("MOD_VERSION","1.0.0")
		var mod_version_major:int = constants.get("MOD_VERSION_MAJOR",1)
		var mod_version_minor:int = constants.get("MOD_VERSION_MINOR",0)
		var mod_version_bugfix:int = constants.get("MOD_VERSION_BUGFIX",0)
		var mod_version_metadata : String = constants.get("MOD_VERSION_METADATA","")
		
		var mod_is_library:bool = constants.get("MOD_IS_LIBRARY",false)
		
		var hide_library:bool = constants.get("LIBRARY_HIDDEN_BY_DEFAULT",true)
		var content : PoolStringArray = __get_manifest_files()
		var has_mod_manifest:bool = false
		var manifest_data : Dictionary = {}
		var manifest_version:float = 1.0
		var has_icon_file:bool = false
		var icon_path : String = ""
		var png_path : String = ""
		var stex_path : String = ""
		for file in content:
			if file.to_lower() == folder_path.to_lower() + "mod.manifest":
				has_mod_manifest = true
				var fp:String = folder_path + file
				manifest_data = __parse_file_as_manifest(fp, true)
				mod_name = manifest_data["mod_information"].get("name",mod_name)
				legacy_mod_version = manifest_data["version"].get("version_string",legacy_mod_version)
				mod_version_major = manifest_data["version"].get("version_major",mod_version_major)
				mod_version_minor = manifest_data["version"].get("version_minor",mod_version_minor)
				mod_version_bugfix = manifest_data["version"].get("version_bugfix",mod_version_bugfix)
				mod_version_metadata = manifest_data["version"].get("version_metadata",mod_version_metadata)
				mod_is_library = manifest_data["tags"].get("is_library_mod",false)
				hide_library = manifest_data["tags"].get("library_hidden_by_default",true)
				if file.to_lower().begins_with("icon"):
					match file.get_extension():
						"png":
							has_icon_file = true
							png_path = fp
						"stex":
							has_icon_file = true
							stex_path = fp
		if stex_path:
			icon_path = stex_path
		elif png_path:
			icon_path = png_path
		var mod_version_array : Array = [mod_version_major,mod_version_minor,mod_version_bugfix]
		var mod_version_string : String = "%s.%s.%s" % mod_version_array
		if mod_version_metadata:
			mod_version_array.append(mod_version_metadata)
			mod_version_string = mod_version_string + "-" + mod_version_metadata
		return {
		script_path:{
			"name":mod_name,
			"priority":constants.get("MOD_PRIORITY",0),
			"version_data":{
				"version_major":mod_version_major,
				"version_minor":mod_version_minor,
				"version_bugfix":mod_version_bugfix,
				"version_metadata":mod_version_metadata,
				"full_version_array":mod_version_array,
				"full_version_string":mod_version_string,
				"legacy_mod_version":legacy_mod_version
			},
			"mod_icon":{
				"has_icon_file":has_icon_file,
				"icon_path":icon_path
			},
			"library_information":{
				"is_library":mod_is_library,
				"keep_library_hidden":hide_library
			},
			"manifest":{
				"has_manifest":has_mod_manifest,
				"manifest_version":manifest_version,
				"manifest_data":manifest_data
			}
		}}
	
	const cached_manifests : Dictionary = {}
	const cachedManifestKeys:Array = Array()
	
	const base_manifest_template : Dictionary = {
		"mod_information":{
			"name":"",
			"id":"",
			"description":"",
			"brief":"",
			"author":"",
			"credits":PoolStringArray()
		},
		"version":{
			"version_major":1,
			"version_minor":0,
			"version_bugfix":0,
			"version_metadata":"",
			"version_string":"1.0.0"
		},
		"tags":{
			
		},
		"links":{
			
		},
		"configs":{
			
		},
		"languages":{
			
		},
		"library":{
			"is_library":false,
			"always_display":false,
		},
		"manifest_definitions":{
			"manifest_version":1.0,
			"dependancy_mod_ids":Array(),
			"conflicting_mod_ids":Array(),
			"complementary_mod_ids":Array(),
			"manifest_url":"", # EXAMPLE: https://raw.githubusercontent.com/rwqfsfasxc100/HevLib/main/Mod.manifest
			"changelog_path":"", # This is relative to the ModMain.gd file. EXAMPLE: for a file at 'res://Example Mod/data/folder/changelogs.txt', you would put 'data/folder/changelogs.txt'
			"modlet_priority":0, # SPECIFIC TO MODLETS! The order at which the modlet would be loaded. Most modlets load before other mods, but this will affect load order within the list of installed modlets
			"expected_manifest_path":"", # If set and used for a mod's manifest, the res:// filepath the manifest is expected to be at. If it isn't, prevents the mod from loading and closes the game.
		}
	}
	
	static func __parse_file_as_manifest(file_path: String, format_to_manifest_version: bool = true) -> Dictionary:
		var cachevar : String = "%s:%s" % [file_path,format_to_manifest_version]
		if not cachevar in cachedManifestKeys:
			var out : Dictionary = {}
			var pointers = non_static["pointers"]
			var cfg : Dictionary = pointers.ConfigDriver.__config_parse(file_path)
			var manifest_data : Dictionary = {}
			var manifest_version:float = 1.0
			if "manifest_definitions" in cfg:
				manifest_version = cfg["manifest_definitions"].get("manifest_version",manifest_version)
				var tpf:int = typeof(manifest_version)
				if not (tpf == TYPE_INT or tpf == TYPE_REAL):
					manifest_version = 1.0
			manifest_data = cfg
			if format_to_manifest_version:
				var dict_template:Dictionary = base_manifest_template.duplicate(true)
				var manifestKeys:Array = manifest_data.keys()
				match manifest_version:
					1.0:
						dict_template["mod_information"]["id"] = manifest_data["package"].get("id","")
						dict_template["mod_information"]["name"] = manifest_data["package"].get("name","")
						dict_template["mod_information"]["description"] = manifest_data["package"].get("description","MODMENU_DESCRIPTION_PLACEHOLDER")
						
						if typeof(manifest_data["package"].get("github_homepage","")) == TYPE_STRING:
							var url:String = manifest_data["package"]["github_homepage"]
							if url:
								dict_template["links"]["HEVLIB_GITHUB"] = {"URL":pointers.DataFormat.__ensure_string_is_url(url)}
						var discURL:String = manifest_data["package"].get("discord","")
						if discURL:
							dict_template["links"]["HEVLIB_DISCORD"] = {"URL":pointers.DataFormat.__ensure_string_is_url(discURL)}
						var nexusURL:String = manifest_data["package"].get("nexus","")
						if nexusURL:
							dict_template["links"]["HEVLIB_NEXUS"] = {"URL":pointers.DataFormat.__ensure_string_is_url(nexusURL)}
						var donationURL:String = manifest_data["package"].get("donations","")
						if donationURL:
							dict_template["links"]["HEVLIB_DONATIONS"] = {"URL":pointers.DataFormat.__ensure_string_is_url(donationURL)}
						var wikiURL:String = manifest_data["package"].get("wiki","")
						if wikiURL:
							dict_template["links"]["HEVLIB_WIKI"] = {"URL":pointers.DataFormat.__ensure_string_is_url(wikiURL)}
						
					2.0:
						dict_template["mod_information"]["id"] = manifest_data["package"].get("id","")
						dict_template["mod_information"]["name"] = manifest_data["package"].get("name","")
						dict_template["version"]["version_major"] = manifest_data["package"].get("version_major",1)
						dict_template["version"]["version_minor"] = manifest_data["package"].get("version_minor",0)
						dict_template["version"]["version_bugfix"] = manifest_data["package"].get("version_bugfix",0)
						dict_template["version"]["version_metadata"] = manifest_data["package"].get("version_metadata","")
						dict_template["mod_information"]["description"] = manifest_data["package"].get("description","HEVLIB_DESCRIPTION_PLACEHOLDER")
						if typeof(manifest_data["package"].get("github","")) == TYPE_DICTIONARY:
							var url:String = manifest_data["package"]["github"]["link"]
							if url:
								dict_template["links"]["HEVLIB_GITHUB"] = {"URL":pointers.DataFormat.__ensure_string_is_url(url)}
						elif typeof(manifest_data["package"].get("github","")) == TYPE_STRING:
							var url:String = manifest_data["package"]["github"]
							if url:
								dict_template["links"]["HEVLIB_GITHUB"] = {"URL":pointers.DataFormat.__ensure_string_is_url(url)}
						var discURL:String = manifest_data["package"].get("discord","")
						if discURL:
							dict_template["links"]["HEVLIB_DISCORD"] = {"URL":pointers.DataFormat.__ensure_string_is_url(discURL)}
						var nexusURL:String = manifest_data["package"].get("nexus","")
						if nexusURL:
							dict_template["links"]["HEVLIB_NEXUS"] = {"URL":pointers.DataFormat.__ensure_string_is_url(nexusURL)}
						var donationURL:String = manifest_data["package"].get("donations","")
						if donationURL:
							dict_template["links"]["HEVLIB_DONATIONS"] = {"URL":pointers.DataFormat.__ensure_string_is_url(donationURL)}
						var wikiURL:String = manifest_data["package"].get("wiki","")
						if wikiURL:
							dict_template["links"]["HEVLIB_WIKI"] = {"URL":pointers.DataFormat.__ensure_string_is_url(wikiURL)}
						dict_template["mod_information"]["author"] = manifest_data["package"].get("author","Unknown")
						dict_template["mod_information"]["credits"] = manifest_data["package"].get("credits",[])
						
					2.1:
						# information
						if "mod_information" in manifestKeys:
							dict_template["mod_information"]["id"] = String(manifest_data["mod_information"].get("id",""))
							dict_template["mod_information"]["name"] = String(manifest_data["mod_information"].get("name",""))
							dict_template["mod_information"]["description"] = String(manifest_data["mod_information"].get("description","HEVLIB_DESCRIPTION_PLACEHOLDER"))
							dict_template["mod_information"]["author"] = String(manifest_data["mod_information"].get("author","Unknown"))
							dict_template["mod_information"]["credits"] = PoolStringArray(manifest_data["mod_information"].get("credits",[]))
						
						# versioning
						if "version" in manifestKeys:
							dict_template["version"]["version_major"] = int(manifest_data["version"].get("version_major",1))
							dict_template["version"]["version_minor"] = int(manifest_data["version"].get("version_minor",0))
							dict_template["version"]["version_bugfix"] = int(manifest_data["version"].get("version_bugfix",0))
							dict_template["version"]["version_metadata"] = String(manifest_data["version"].get("version_metadata",""))
						
						# tags
						if "tags" in manifestKeys:
							var current_tags = manifest_data["tags"].keys()
							if "allow_achievements" in current_tags:
								dict_template["tags"]["TAG_ALLOW_ACHIEVEMENTS"] = {"type":"boolean","value":manifest_data["tags"].get("allow_achievements")}
							if "quality_of_life" in current_tags:
								dict_template["tags"]["TAG_QOL"] = {"type":"boolean","value":manifest_data["tags"].get("quality_of_life")}
							if "is_library_mod" in current_tags:
								dict_template["library"]["is_library"] = manifest_data["tags"].get("is_library_mod")
							if "uses_hevlib_research" in current_tags:
								dict_template["tags"]["TAG_USING_HEVLIB_RESEARCH"] = {"type":"boolean","value":manifest_data["tags"].get("uses_hevlib_research")}
							if "overhaul" in current_tags:
								dict_template["tags"]["TAG_OVERHAUL"] = {"type":"bool","value":manifest_data["tags"].get("overhaul")}
							if "visual" in current_tags:
								dict_template["tags"]["TAG_VISUAL"] = {"type":"bool","value":manifest_data["tags"].get("visual")}
							if "fun" in current_tags:
								dict_template["tags"]["TAG_FUN"] = {"type":"bool","value":manifest_data["tags"].get("fun")}
							if "user_interface" in current_tags:
								dict_template["tags"]["TAG_UI"] = {"type":"bool","value":manifest_data["tags"].get("user_interface")}
							
							if "adds_ships" in current_tags:
								dict_template["tags"]["TAG_ADDS_SHIPS"] = {"type":"array","value":manifest_data["tags"].get("adds_ships")}
							if "adds_equipment" in current_tags:
								dict_template["tags"]["TAG_ADDS_EQUIPMENT"] = {"type":"array","value":manifest_data["tags"].get("adds_equipment")}
							if "adds_gameplay_mechanics" in current_tags:
								dict_template["tags"]["TAG_ADDS_GAMEPLAY_MECHANICS"] = {"type":"array","value":manifest_data["tags"].get("adds_gameplay_mechanics")}
							if "adds_events" in current_tags:
								dict_template["tags"]["TAG_ADDS_EVENTS"] = {"type":"array","value":manifest_data["tags"].get("adds_events")}
							
							if "handle_extra_crew" in current_tags:
								dict_template["tags"]["TAG_HANDLE_EXTRA_CREW"] = {"type":"integer","value":manifest_data["tags"].get("handle_extra_crew")}
							
						# links
						if "links" in manifestKeys:
							if typeof(manifest_data["links"].get("github","")) == TYPE_DICTIONARY:
								var url:String = manifest_data["links"]["github"]["link"]
								if url:
									dict_template["links"]["HEVLIB_GITHUB"] = {"URL":pointers.DataFormat.__ensure_string_is_url(url)}
							elif typeof(manifest_data["links"].get("github","")) == TYPE_STRING:
								var url:String = manifest_data["links"]["github"]
								if url:
									dict_template["links"]["HEVLIB_GITHUB"] = {"URL":pointers.DataFormat.__ensure_string_is_url(url)}
							var discURL:String = manifest_data["links"].get("discord","")
							if discURL:
								dict_template["links"]["HEVLIB_DISCORD"] = {"URL":pointers.DataFormat.__ensure_string_is_url(discURL)}
							var nexusURL:String = manifest_data["links"].get("nexus","")
							if nexusURL:
								dict_template["links"]["HEVLIB_NEXUS"] = {"URL":pointers.DataFormat.__ensure_string_is_url(nexusURL)}
							var donationURL:String = manifest_data["links"].get("donations","")
							if donationURL:
								dict_template["links"]["HEVLIB_DONATIONS"] = {"URL":pointers.DataFormat.__ensure_string_is_url(donationURL)}
							var wikiURL:String = manifest_data["links"].get("wiki","")
							if wikiURL:
								dict_template["links"]["HEVLIB_WIKI"] = {"URL":pointers.DataFormat.__ensure_string_is_url(wikiURL)}
							var bugreportsURL:String = manifest_data["links"].get("bug_reports","")
							if bugreportsURL:
								dict_template["links"]["HEVLIB_BUGREPORTS"] = {"URL":pointers.DataFormat.__ensure_string_is_url(bugreportsURL)}
						
						# manifest definitions
						if "manifest_definitions" in manifestKeys:
							dict_template["manifest_definitions"]["manifest_version"] = float(manifest_data["manifest_definitions"].get("manifest_version",manifest_version))
							dict_template["manifest_definitions"]["dependancy_mod_ids"] = Array(manifest_data["manifest_definitions"].get("dependancy_mod_ids",[]))
							dict_template["manifest_definitions"]["conflicting_mod_ids"] = Array(manifest_data["manifest_definitions"].get("conflicting_mod_ids",[]))
							dict_template["manifest_definitions"]["complementary_mod_ids"] = Array(manifest_data["manifest_definitions"].get("complementary_mod_ids",[]))
					2.2,2.3:
						
						if "mod_information" in manifestKeys:
							dict_template["mod_information"]["id"] = String(manifest_data["mod_information"].get("id",""))
							dict_template["mod_information"]["name"] = String(manifest_data["mod_information"].get("name",""))
							dict_template["mod_information"]["description"] = String(manifest_data["mod_information"].get("description","HEVLIB_DESCRIPTION_PLACEHOLDER"))
							dict_template["mod_information"]["brief"] = String(manifest_data["mod_information"].get("brief",""))
							dict_template["mod_information"]["author"] = String(manifest_data["mod_information"].get("author","Unknown"))
							dict_template["mod_information"]["credits"] = PoolStringArray(manifest_data["mod_information"].get("credits",[]))
						
						if "version" in manifestKeys:
							dict_template["version"]["version_major"] = int(manifest_data["version"].get("version_major",1))
							dict_template["version"]["version_minor"] = int(manifest_data["version"].get("version_minor",0))
							dict_template["version"]["version_bugfix"] = int(manifest_data["version"].get("version_bugfix",0))
							dict_template["version"]["version_metadata"] = String(manifest_data["version"].get("version_metadata",""))
						
						if "manifest_definitions" in manifestKeys:
							dict_template["manifest_definitions"]["manifest_version"] = float(manifest_data["manifest_definitions"].get("manifest_version",manifest_version))
							dict_template["manifest_definitions"]["dependancy_mod_ids"] = Array(manifest_data["manifest_definitions"].get("dependancy_mod_ids",[]))
							dict_template["manifest_definitions"]["conflicting_mod_ids"] = Array(manifest_data["manifest_definitions"].get("conflicting_mod_ids",[]))
							dict_template["manifest_definitions"]["complementary_mod_ids"] = Array(manifest_data["manifest_definitions"].get("complementary_mod_ids",[]))
							dict_template["manifest_definitions"]["manifest_url"] = String(manifest_data["manifest_definitions"].get("manifest_url",""))
							dict_template["manifest_definitions"]["changelog_path"] = String(manifest_data["manifest_definitions"].get("changelog_path",""))
							dict_template["manifest_definitions"]["modlet_priority"] = int(manifest_data["manifest_definitions"].get("modlet_priority",0))
							dict_template["manifest_definitions"]["expected_manifest_path"] = String(manifest_data["manifest_definitions"].get("expected_manifest_path",""))
							
						if "links" in manifestKeys:
							var links = manifest_data["links"]
							var ovLinks = {}
							for link in links.keys():
								var ld = links[link]
								if typeof(ld) == TYPE_DICTIONARY:
									if "URL" in ld and typeof(ld.URL) == TYPE_STRING:
										ld.URL = pointers.DataFormat.__ensure_string_is_url(ld.URL)
										ovLinks[link] = ld
							if ovLinks:
								dict_template["links"] = ovLinks
						if "tags" in manifestKeys:
							var tags = manifest_data["tags"]
							var ovTags = {}
							for tag in tags.keys():
								var td = tags[tag]
								if typeof(td) == TYPE_DICTIONARY:
									if "type" in td and "value" in td and typeof(td.type) == TYPE_STRING:
										ovTags[tag] = td
							if ovTags:
								dict_template["tags"] = ovTags
						if "languages" in manifestKeys:
							var languages = manifest_data["languages"]
							for language in languages.keys():
								var ld = languages[language]
								var tld = typeof(ld)
								if tld == TYPE_STRING:
									dict_template["languages"][language] = ld
								elif tld == TYPE_INT or tld == TYPE_REAL:
									dict_template["languages"][language] = str(ld) + "%"
						if "library" in manifestKeys:
							dict_template["library"]["is_library"] = manifest_data["library"].get("is_library",false)
							dict_template["library"]["always_display"] = manifest_data["library"].get("always_display",false)
							
						if "configs" in manifestKeys:
							var configs = manifest_data["configs"]
							var ovConfigs = {}
							for section in configs.keys():
								var sec_data = configs[section]
								for cfname in sec_data.keys():
									var cfdata = sec_data[cfname]
									var type = cfdata.get("type",null)
									if cfdata.get("disabled",false):pointers.l("Config %s/%s is disabled, skipping" % [section,cfname],"pointers.ConfigDriver")
									elif typeof(type) != TYPE_STRING or not type:
										var err = "Config %s @ %s does not define a type, skipping" % [cfname,section]
										printerr(err)
										pointers.l(err,"pointers.ConfigDriver")
									else:
										if not section in ovConfigs.keys():
											ovConfigs[section] = {}
										ovConfigs[section][cfname] = cfdata
							if ovConfigs:
								pointers.l("Parsed configs for %s, has disabled configs: [%s]" % [file_path,str(hash(configs) != hash(ovConfigs))],"pointers.ManifestV2")
								dict_template["configs"] = ovConfigs
				
				
				var version_metadata : String = dict_template["version"]["version_metadata"]
				var version_string : String = str(dict_template["version"]["version_major"]) + "." + str(dict_template["version"]["version_minor"]) + "." + str(dict_template["version"]["version_bugfix"])
				if not version_metadata.empty():
					version_string = version_string + "-" + version_metadata
				dict_template["version"]["version_string"] = version_string
				out = dict_template
			else:
				out = manifest_data
			cached_manifests[cachevar] = out
			cachedManifestKeys.append(cachevar)
		return cached_manifests[cachevar].duplicate(true)
	
	static func __get_mod_by_id(id:String, case_sensitive: bool = true) -> Dictionary:
		var mods : Dictionary = __get_mod_data()
		for mod in __get_mod_list_keys():
			var moddata : Dictionary = mods[mod]
			var manifest : Dictionary = moddata["manifest"]["manifest_data"]
			if manifest and "mod_information" in manifest.keys():
				var ID : String = manifest["mod_information"].get("id","")
				if case_sensitive:
					if id.to_upper() == ID.to_upper():
						return moddata
				else:
					if id == ID:
						return moddata
		return {}
	
	const tag_data_cache = {}
	
	static func __get_tags() -> Dictionary:
		if tag_data_cache.empty():
			var mods : Dictionary = __get_mod_data()
			for mod in __get_mod_list_keys():
				if mods[mod]["manifest"]["has_manifest"]:
					var md : Dictionary = mods[mod]["manifest"]["manifest_data"]
					var id : String = md["mod_information"].get("id","")
					if id and "tags" in md.keys():
						var tags : Dictionary = md["tags"]
						for tag in tags.keys():
							if not tag in tag_data_cache:
								tag_data_cache[tag] = {}
							if typeof(tags[tag]) == TYPE_DICTIONARY:
								var td : Dictionary = tags[tag]
								if "value" in td and "type" in td and typeof(td.type) == TYPE_STRING:
									tag_data_cache[tag][id] = td["value"]
		return tag_data_cache.duplicate(true) 
	
	static func __get_mod_tags(mod_id: String) -> Dictionary:
		var tag_dict : Dictionary = {}
		var tags : Dictionary = __get_tags()
		for tag in tags.keys():
			var td : Dictionary = tags[tag]
			if mod_id in td:
				if not tag in tag_dict:
					tag_dict[tag] = null
				tag_dict[tag] = td[mod_id]
		return tag_dict
	
	static func __get_mods_from_tag(tag_name: String) -> Array:
		return __get_tags().get(tag_name,{}).keys()
	
	static func __get_mods_and_tags_from_tag(tag_name: String) -> Dictionary:
		
		# REFACTOR TO USE __parse_tags
		
		var alldata : Dictionary = __get_tags()
		var data : Dictionary = alldata.get(tag_name,{})
		var ex_data : Dictionary = {}
		if data:
			for mod in data.keys():
				match tag_name:
					"TAG_ADDS_EQUIPMENT","TAG_ADDS_EVENTS","TAG_ADDS_GAMEPLAY_MECHANICS","TAG_ADDS_SHIPS":
						ex_data[mod] = Array(data.get(mod,[]))
					"TAG_HANDLE_EXTRA_CREW":
						var k:int = data.get(mod,24)
						if k > 24:
							ex_data[mod] = k
					_:
						var k:bool = data.get(mod,false)
						ex_data[mod] = k
		return ex_data
	
	static func __get_manifest_section(section: String, mod_id: String = "") -> Dictionary:
		var return_data : Dictionary = {}
		var manifest_data_cache : Dictionary = __get_manifest_cache()
		if mod_id:
			for mod in manifest_data_cache:
				if mod_id in __get_mod_ids():
					var manifest : Dictionary = manifest_data_cache[mod]
					if "mod_information" in manifest:
						if mod_id in manifest["mod_information"]["id"]:
							if section in manifest:
								return_data = manifest[section]
		else:
			for mod in manifest_data_cache:
				var manifest : Dictionary = manifest_data_cache[mod]
				if section in manifest:
					return_data[mod] = manifest[section]
		return return_data
	
	static func __get_manifest_entry(section: String, entry: String, mod_id: String = ""):
		var manifest_data_cache : Dictionary = __get_manifest_cache()
		var return_data = null
		if mod_id:
			for mod in manifest_data_cache.keys():
				if mod_id in __get_mod_ids():
					var manifest : Dictionary = manifest_data_cache[mod]
					if "mod_information" in manifest:
						if mod_id in manifest["mod_information"]["id"]:
							if section in manifest:
								var sec : Dictionary = manifest[section]
								if entry in sec:
									return_data = sec[entry]
		else:
			var dict : Dictionary = {}
			for mod in manifest_data_cache.keys():
				var manifest : Dictionary = manifest_data_cache[mod]
				if section in manifest:
					var sec : Dictionary = manifest[section]
					var id : String = manifest_data_cache[mod]["mod_information"]["id"]
					if entry in sec:
						dict[id] = sec[entry]
			return_data = dict
		return return_data
		
	
	const caches_mod_ids : PoolStringArray = PoolStringArray()
	var needs_mod_id_cache:bool = true
	static func __get_mod_ids() -> PoolStringArray:
		if caches_mod_ids.empty():
			var mod_data : Dictionary = __get_mod_data()
			for mod in __get_mod_list_keys():
				var data : Dictionary = mod_data[mod]["manifest"]["manifest_data"]
				if "mod_information" in data.keys():
					var minfo : String = data["mod_information"]["id"]
					caches_mod_ids.append(minfo)
		return caches_mod_ids
	
	static func __check_complementary():
		var tags : Dictionary = __get_manifest_entry("manifest_definitions","complementary_mod_ids")
		var mKeys:PoolStringArray = __get_mod_list_keys()
		var complimentaries : Dictionary = {}
		for mod in tags.keys():
			var keys = tags[mod]
			if keys:
				var items : Array = []
				for item in keys:
					if item in mKeys:
						items.append(item)
				if items:
					complimentaries[mod] = items
		return complimentaries
	
	static func __check_mod_complementary(mod_id):
		var tags : Array = __get_manifest_entry("manifest_definitions","complementary_mod_ids",mod_id)
		var complimentaries : Array = []
		var mKeys:PoolStringArray = __get_mod_list_keys()
		for mod in tags:
			if mod in mKeys:
				complimentaries.append(mod)
		return complimentaries
	
	static func __check_dependancies():
		var tags : Dictionary = __get_manifest_entry("manifest_definitions","dependancy_mod_ids")
		var complimentaries : Dictionary = {}
		for mod in tags.keys():
			var keys = tags[mod]
			if keys:
				var items : Array = []
				for item in keys:
					if not __mod_exists(item):
						items.append(item)
				if items:
					complimentaries[mod] = items
		return complimentaries
	
	static func __check_mod_dependancies(mod_id):
		var tags : Array = __get_manifest_entry("manifest_definitions","dependancy_mod_ids",mod_id)
		var complimentaries : Array = []
		for mod in tags:
			if not __mod_exists(mod):
				complimentaries.append(mod)
		return complimentaries
	
	static func __check_conflicts():
		var tags : Dictionary = __get_manifest_entry("manifest_definitions","conflicting_mod_ids")
		var complimentaries : Dictionary = {}
		for mod in tags.keys():
			var keys = tags[mod]
			if keys:
				var items : Array = []
				for item in keys:
					if __mod_exists(item):
						items.append(item)
				if items:
					complimentaries[mod] = items
		return complimentaries
	
	static func __check_mod_conflicts(mod_id):
		var tags : Array = __get_manifest_entry("manifest_definitions","conflicting_mod_ids",mod_id)
		var complimentaries : Array = []
		for mod in tags:
			if __mod_exists(mod):
				complimentaries.append(mod)
		return complimentaries
	
	static func __parse_tags(tag_data) -> Dictionary:
		var tag_dict : Dictionary = {}
		for entry in tag_data.keys():
			var type:int = typeof(tag_data[entry])
			if type != TYPE_DICTIONARY:
				return tag_dict
			var tag_type : String = tag_data[entry].get("type","NULL_TYPE")
			tag_type = tag_type.to_lower()
			match tag_type:
				"boolean","bool":
					tag_dict[entry] = bool(tag_data[entry].get("value"))
				"string","str":
					tag_dict[entry] = str(tag_data[entry].get("value"))
				"integer","int":
					tag_dict[entry] = int(tag_data[entry].get("value"))
				"array","arr":
					tag_dict[entry] = Array(tag_data[entry].get("value"))
				_:
					tag_dict[entry] = tag_data[entry].get("value")
		return tag_dict
	
	static func __have_mods_updated(folder = "user://cache/.Mod_Menu_2_Cache/changelogs/",last_seen_file = "mods_from_last_launch.json") -> Dictionary:
		var base = non_static["self"]
		if not base.haveModsChanged:
			return {}
		if not folder.ends_with("/"):
			folder = folder + "/"
		if last_seen_file.begins_with("/"):
			last_seen_file.lstrip("/")
		var all_mods : Dictionary = __get_mod_data()
		non_static["pointers"].FolderAccess.__check_folder_exists(folder)
		var file:File = File.new()
		if not file.file_exists(folder + last_seen_file):
			file.open(folder + last_seen_file,File.WRITE)
			file.store_string("{}")
			file.close()
		var mods : Dictionary = {}
		for mod in __get_mod_list_keys():
			var data : Dictionary = all_mods[mod]
			if data["manifest"]["has_manifest"] and data["manifest"]["manifest_version"] >= 2.0:
				var manifest : Dictionary = data["manifest"]["manifest_data"]
				var info : Dictionary = manifest["mod_information"]
				var version : Dictionary = manifest["version"]
				mods[info["id"]] = {"name":info["name"],"version":{"major":version["version_major"],"minor":version["version_minor"],"bugfix":version["version_bugfix"]},"path":data["file_path"],"changelog":manifest["manifest_definitions"]["changelog_path"]}
		var last : Dictionary = {}
		if file.file_exists(folder + last_seen_file):
			file.open(folder + last_seen_file,File.READ)
			last = JSON.parse(file.get_as_text()).result
			file.close()
		var changes : Dictionary = {}
		for mod in mods:
			var has_changed:bool = false
			var data : Dictionary = mods[mod]
			if mod in last:
				if data["version"]["major"] != last[mod]["version"]["major"]:
					has_changed = true
				if data["version"]["minor"] != last[mod]["version"]["minor"]:
					has_changed = true
				if data["version"]["bugfix"] != last[mod]["version"]["bugfix"]:
					has_changed = true
			else:
				has_changed = true
			if has_changed:
				changes[mod] = data
		return changes
	
	static func __get_mod_versions(store = false,folder = "user://cache/.Mod_Menu_2_Cache/changelogs/",last_seen_file = "mods_from_last_launch.json",this_seen_file = "mods_from_this_launch.json") -> Dictionary:
		var mods : Dictionary = {}
		var all_mods : Dictionary = __get_mod_data()
		for mod in __get_mod_list_keys():
			var data : Dictionary = all_mods[mod]
			if data["manifest"]["has_manifest"] and data["manifest"]["manifest_version"] >= 2.0:
				var manifest : Dictionary = data["manifest"]["manifest_data"]
				var info : Dictionary = manifest["mod_information"]
				var version : Dictionary = manifest["version"]
				mods[info["id"]] = {"name":info["name"],"version":{"major":version["version_major"],"minor":version["version_minor"],"bugfix":version["version_bugfix"]}}
		if store:
			if not folder.ends_with("/"):
				folder = folder + "/"
			if last_seen_file.begins_with("/"):
				last_seen_file.lstrip("/")
			non_static["pointers"].FolderAccess.__check_folder_exists(folder)
			var file:File = File.new()
			if file.file_exists(folder + this_seen_file):
				file.open(folder + this_seen_file,File.READ)
				var lastData : Dictionary = JSON.parse(file.get_as_text()).result
				file.close()
				file.open(folder + last_seen_file,File.WRITE)
				file.store_string(JSON.print(lastData))
				file.close()
			file.open(folder + this_seen_file,File.WRITE)
			file.store_string(JSON.print(mods))
			file.close()
		return mods
	
	static func __parse_changelogs(file_path):
#		var c:ConfigFile = ConfigFile.new()
#		c.load(file_path)
		var file:File = File.new()
		file.open(file_path,File.READ)
		var text = file.get_as_text(true)
		file.close()
		var cv = {}
		
		var lastVer:String = ""
		for line in text.split("\n"):
			var noedge:String = line.strip_edges()
			if noedge.begins_with(";"):
				continue
			if noedge.begins_with("[") and noedge.ends_with("]"):
				var version = noedge.substr(1,noedge.length() - 2)
				if not version in cv:
					lastVer = version
					cv[version] = {}
				else:
					lastVer = ""
				continue
			if lastVer and noedge:
				var index:String = noedge.split("=")[0]
				var entry:String = noedge.substr(index.length() + 1)
				if entry.begins_with("\""):
					entry = entry.substr(1)
					if entry.ends_with("\""):
						entry = entry.substr(0,entry.length() - 1)
				cv[lastVer][index] = entry
		
		
		var changelog : Dictionary = {}
#		var versions : Array = c.get_sections()
		var versions : Array = cv.keys()
#		versions.resize(clamp(versions.size(),0,10))
		var spacing : String = "  "
		var spc = non_static["pointers"].ConfigDriver.__get_value("ModMenu2","MODMENU2_CONFIG_GENERAL","changelog_spacing_size")
		if spc != "" or spc != null:
			spacing = spc
		for version in versions:
			changelog[version] = []
			var keys : Array = cv[version].keys()
			keys.sort_custom(non_static["self"],"changelogKeySorter")
			keys = filterChangelogs(keys)
			
			for key in keys:
				var entry = str(cv[version][key])
				var spacer:String = ""
				for i in (key.split(".").size() - 1):
					spacer += spacing
				changelog[version].append(spacer + entry)
		return changelog
	
	static func changelogKeySorter(al:String,bl:String) -> bool:
		var aList:PoolStringArray = al.split(".")
		var bList:PoolStringArray = bl.split(".")
		var aSize:int = aList.size()
		var bSize:int = bList.size()
		var counter:int = aSize if aSize < bSize else bSize
		for i in counter:
			var a = aList[i]
			var b = bList[i]
			if a != b:
				return a < b
		return aSize < bSize
	
	static func filterChangelogs(keys:Array) -> Array:
		if keys.size() > 1:
			var counter:int = 0
			var total:int = keys.size() - 1
			while counter < total:
				var al:String = keys[counter]
				var bl:String = keys[counter+1]
				var aList:PoolStringArray = al.split(".")
				var bList:PoolStringArray = bl.split(".")
				var aSize:int = aList.size()
				var bSize:int = bList.size()
				if (aSize == bSize):
					var aItem:String = aList[aSize - 1]
					var bItem:String = bList[bSize - 1]
					if int(bItem) > (int(aItem) + 1):
						keys.remove(counter + 1)
						total -= 1
				counter += 1
		return keys
	
	static func __get_manifest_cache() -> Dictionary:
		return cached_manifests
	
	var need_modmain_file_cache:bool = true
	const modmain_file_list : PoolStringArray = PoolStringArray()
	static func __get_modmain_files() -> PoolStringArray:
		if modmain_file_list.empty():
			var pointers = non_static["pointers"]
			pointers.FolderAccess.__get_folder_structure("res://",false,false)
			if pointers.is_editor:
				modmain_file_list.append_array(pointers.DataFormat.__get_script_variables_without_load("res://ModLoader.gd").get("addedMods",[]))
			else:
				for r in __get_mod_files():
					var i : String = r.get_file().to_lower()
					if i.begins_with("modmain") and i.ends_with(".gd"):
						modmain_file_list.append(r)
			
		return modmain_file_list
	
	const active_modlet_file_list : PoolStringArray = PoolStringArray()
	const all_modlet_file_list : PoolStringArray = PoolStringArray()
	const all_modlet_definitions : Dictionary = {}
	
	const cached_modlets : Dictionary = {}
	
	static func __get_all_modlets(only_show_installed : bool = true,recache : bool = false) -> Dictionary:
		var pointers = non_static["pointers"]
		if cached_modlets:
			var modletCheck = pointers.ConfigDriver.__get_value("HevLib","modlets","seen_modlets")
			for modlet in modletCheck.keys():
				if modletCheck[modlet] != cached_modlets[modlet]:
					recache = true
		if not cached_modlets or recache:
			if not all_modlet_file_list:
				var manifests:PoolStringArray = __get_manifest_files()
				var manifest_checks : Array = []
				for i in manifests:
					manifest_checks.append(i.to_lower())
				var allModFiles : PoolStringArray = __get_mod_files()
				for r in allModFiles:
					var i : String = r.get_file().to_lower()
					if (i.begins_with("modmain") and i.ends_with(".gd")):
						var mr : String = r.get_base_dir().to_lower() + "/mod.manifest"
						if mr in manifest_checks:
							manifest_checks.erase(mr)
				var ov : Array = []
				for i in manifests:
					if i.to_lower() in manifest_checks:
						ov.append(i)
				ov.sort_custom(non_static["self"],"sort_modlet_files")
				all_modlet_file_list.clear()
				all_modlet_file_list.append_array(PoolStringArray(ov))
			cached_modlets.clear()
			var allowed_modlets = pointers.ConfigDriver.__get_value("HevLib","modlets","seen_modlets")
			if allowed_modlets == null:
				pointers.ConfigDriver.__store_value("HevLib","modlets","seen_modlets",{})
				allowed_modlets = {}
			active_modlet_file_list.clear()
			for mod in all_modlet_file_list:
				if not mod in allowed_modlets:
					allowed_modlets[mod] = true
				if allowed_modlets[mod]:
					active_modlet_file_list.append(mod)
			pointers.ConfigDriver.__store_value("HevLib","modlets","seen_modlets",allowed_modlets)
			cached_modlets.clear()
			cached_modlets.merge(allowed_modlets)
			
		var out : Dictionary = cached_modlets.duplicate(true)
		if only_show_installed:
			for mod in cached_modlets:
				if not mod in active_modlet_file_list:
					out.erase(mod)
		return out
	
	static func sort_modlet_files(a:String,b:String):
		var aPrio:int = __parse_file_as_manifest(a)["manifest_definitions"]["modlet_priority"]
		var bPrio:int = __parse_file_as_manifest(b)["manifest_definitions"]["modlet_priority"]
		if aPrio != bPrio:
			return aPrio < bPrio
		if a != b:
			return a < b
		return false
	
	static func __get_modlet_files() -> PoolStringArray:
		__get_all_modlets()
		return active_modlet_file_list
	
	const cached_mod_files : PoolStringArray = PoolStringArray()
	static func __get_mod_files():
		if cached_mod_files.empty():
			var restrict_to_modmains : PoolStringArray = PoolStringArray()
			var pointers = non_static["pointers"]
			if pointers.is_editor:
				for a in pointers.DataFormat.__get_script_variables_without_load("res://ModLoader.gd").get("addedMods",[]):
					restrict_to_modmains.append(a.get_base_dir() + "/")
				var allowed_modlets = pointers.ConfigDriver.__get_value("HevLib","modlets","seen_modlets")
				if allowed_modlets == null:
					pointers.is_editor_and_needs_restart = true
					allowed_modlets = []
				for a in allowed_modlets:
					restrict_to_modmains.append(a.get_base_dir() + "/")
			var arr1 : PoolStringArray = siftFolderStructureForModFiles(pointers.FolderAccess.__get_folder_structure("res://",false,false),"res://",restrict_to_modmains)
			var arr2 : PoolStringArray = PoolStringArray()
			if pointers.is_editor:
				var excludeDirs:PoolStringArray = PoolStringArray()
				for i in arr1:
					var r:String = i.get_file().to_lower()
					if r.begins_with("modmain") and r.ends_with(".gd"):
						var can : Script = load(i)
						if not can.can_instance():
							var vdir:String = i.get_base_dir()
							excludeDirs.append(vdir.to_lower())
							pointers.l("Excluding mod directoy %s due to malformatted mod main" % vdir,"pointers.ManifestV2")
				if excludeDirs:
					for file in arr1:
						var vr:String = file.get_base_dir().to_lower()
						if not vr in excludeDirs:
							arr2.append(file)
				else:
					arr2 = arr1
			else:
				arr2 = arr1
			cached_mod_files.append_array(arr2)
		return cached_mod_files
	
	static func siftFolderStructureForModFiles(structure:Dictionary,path:String = "res://",restricted_to_modmains : PoolStringArray = PoolStringArray()) -> PoolStringArray:
		var out : PoolStringArray = PoolStringArray()
		if restricted_to_modmains:
			var ev : Array = structure.keys()
			for i in ev.size():
				ev[i] = ev[i].to_lower()
			for f in ev:
				if f.begins_with("modmain") and f.ends_with(".gd"):
					if not path in restricted_to_modmains:
						return PoolStringArray()
		for i in structure:
			if i.ends_with("/"):
				out.append_array(siftFolderStructureForModFiles(structure[i],path + i,restricted_to_modmains))
			else:
				var f : String = i.to_lower()
				if ((f.begins_with("modmain") and f.ends_with(".gd")) or (f.begins_with("mod") and f.ends_with(".manifest")) or (f.begins_with("icon") and (f.get_extension().to_lower() in non_static["pointers"].SUPPORTED_IMAGE_EXTENSIONS))):
					out.append(path + i)
		return out
	
	const cached_manifest_files : PoolStringArray = PoolStringArray()
	static func __get_manifest_files() -> PoolStringArray:
		if cached_manifest_files.empty():
			for r in __get_mod_files():
				var i : String = r.get_file().to_lower()
				if i.begins_with("mod") and i.ends_with(".manifest"):
					cached_manifest_files.append(r)
		return cached_manifest_files
	
	const cached_icon_files : PoolStringArray = PoolStringArray()
	static func __get_icon_files() -> PoolStringArray:
		if cached_icon_files.empty():
			for r in __get_mod_files():
				var i : String = r.get_file().to_lower()
				if i.begins_with("icon") and i.get_extension().to_lower() in non_static["pointers"].SUPPORTED_IMAGE_EXTENSIONS:
					cached_icon_files.append(r)
		return cached_icon_files
	
	enum LOAD_TYPE{
		EXTEND_SCRIPT,
		OVERRIDE_SCRIPT,
		REPLACE_RESOURCE
	}
	
	static func __load_modlets(is_onready : bool,do_safe_load : bool,preprocess_paths:Array = Array()) -> PoolStringArray:
		var pointers = non_static["pointers"]
		var file:File = File.new()
		if do_safe_load:
			pointers.l("Loading modlet resources with order-safe mode. Skipping onready distinction and proceeding in a single batch","pointers.SafeMode")
			pointers.DataFormat.__loadDLC()
			var resource_paths:Array = Array()
			for i in preprocess_paths:
				match typeof(i):
					TYPE_STRING:
						match i.get_extension():
							"gd":
								var ed:String = ""
								file.open(i,File.READ)
								var data:String = file.get_as_text(true)
								file.close()
								if "extends \"" in data:
									for line in data.split("\n"):
										if line.strip_edges().begins_with("extends \""):
											ed = line.split("\"")[1]
											break
								resource_paths.append({"path":i,"mode":LOAD_TYPE.EXTEND_SCRIPT,"extra_data":ed})
							"tscn":
								resource_paths.append({"path":i,"mode":LOAD_TYPE.REPLACE_RESOURCE,"extra_data":("res:/" + i.split("res://HevLib/scenes/equipment")[1])})
					TYPE_STRING_ARRAY:
						var ir:String = i[0]
						if ir.get_extension() == "tscn":
							resource_paths.append({"path":ir if (ir.begins_with("res://")) else ("res://HevLib/scenes/equipment" + ("" if (ir.begins_with("/")) else "/") + ir),"mode":LOAD_TYPE.REPLACE_RESOURCE,"extra_data":i[1]})
				
			for modlet in __get_modlet_files():
				var drivers:Dictionary = pointers.DriverManagement.__get_drivers_from_modmain_path(modlet)
				if "LOAD_RESOURCES.gd" in drivers.keys():
					var resources : Dictionary = drivers["LOAD_RESOURCES.gd"].get("LOAD_RESOURCES",{})
					for resource in resources.keys():
						var subdata:Dictionary = resources[resource]
						var load_type:String = subdata.get("load_type","").to_lower()
						if load_type.empty():
							match resource.get_extension():
								"gd","gdc":
									load_type = "script"
								"tscn","res","tres":
									load_type = "resource"
						match load_type:
							"script":
								var path:String=resource if resource.begins_with("res://")else(modlet.get_base_dir()+(""if resource.begins_with("/")else"/")+resource)
								if pointers.ConfigDriver.__validate_dictionary(subdata)&&pointers.FileAccess.__file_exists(path):
									var op=subdata.get("override_path","res:/"+path.split(modlet.get_base_dir())[1])
									var override_path:String=op if(op.begins_with("res:/"))else("res:/"+(""if op.begins_with("/")else"/")+op)
									if subdata.get("override",false)&&pointers.FileAccess.__file_exists(override_path):
										resource_paths.append({"path":path,"mode":LOAD_TYPE.OVERRIDE_SCRIPT,"extra_data":override_path})
									else:
										var ed:String = subdata.get("base_script_path","")
										if ed.empty()&&path.get_extension()=="gd":
											file.open(path,File.READ)
											var data:String = file.get_as_text(true)
											file.close()
											if "extends \"" in data:
												for line in data.split("\n"):
													if line.strip_edges().begins_with("extends \""):
														ed = line.split("\"")[1]
														break
										resource_paths.append({"path":path,"mode":LOAD_TYPE.EXTEND_SCRIPT,"extra_data":ed})
							"scene","resource":
								var path : String = resource if resource.begins_with("res://") else (modlet.get_base_dir() + ("" if resource.begins_with("/") else "/") + resource)
								var old : String = subdata.get("original_path","res:/" + path.split(modlet.get_base_dir())[1])
								var old_path : String = old if (old.begins_with("res:/")) else ("res:/" + ("" if old.begins_with("/") else "/") + old)
								if pointers.ConfigDriver.__validate_dictionary(subdata) and pointers.FileAccess.__file_exists(path):
									resource_paths.append({"path":path,"mode":LOAD_TYPE.REPLACE_RESOURCE,"extra_data":old_path})
			var ovr:Dictionary = Dictionary()
			for f in resource_paths:
				var path:String = f["path"]
				var extra:String = f["extra_data"]
				if not extra:
					extra = path
				if not extra in ovr:
					ovr[extra] = {"paths":Array(),"deps":Array()}
				for i in pointers.SafeMode.__lookup_file_dependancies(path):
					if not i in ovr[extra]["deps"]:
						ovr[extra]["deps"].append(i)
				ovr[extra]["paths"].append([f.mode,path])
			var LO:Array = pointers.SafeMode.vanilla_load_order
			var order:Array = Array()
			for i in ovr:
				var d:Dictionary = ovr[i]
				order.append([i,d.deps,d.paths,LO.find(i)])
			order.sort_custom(non_static["self"],"sortLoadOrder")
			for r in order:
				var extra:String = r[0]
				for i in r[2]:
					var this_resource:String = i[1]
					match i[0]:
						LOAD_TYPE.EXTEND_SCRIPT:
							pointers.DataFormat.__extend_script(this_resource)
						LOAD_TYPE.OVERRIDE_SCRIPT:
							pointers.DataFormat.__override_script(this_resource,extra)
						LOAD_TYPE.REPLACE_RESOURCE:
							pointers.DataFormat.__replace_resource(this_resource,extra)
			pointers.l("%d modlet resources loaded." % resource_paths.size(),"pointers.SafeMode")
			return PoolStringArray()
		pointers.l("Loading modlet resources with legacy mode. Processing onready phase? [%s]" % (is_onready),"pointers.SafeMode")
		var scenes_to_reload : PoolStringArray = PoolStringArray()
		var resCount:int = 0
		pointers.DataFormat.__loadDLC()
		for modlet in __get_modlet_files():
			var drivers:Dictionary = pointers.DriverManagement.__get_drivers_from_modmain_path(modlet)
			if "LOAD_RESOURCES.gd" in drivers.keys():
				var resources : Dictionary = drivers["LOAD_RESOURCES.gd"].get("LOAD_RESOURCES",{})
				for resource in resources.keys():
					var subdata:Dictionary = resources[resource]
					if is_onready == subdata.get("onready",false):
						var load_type:String = subdata.get("load_type","").to_lower()
						if load_type.empty():
							match resource.get_extension():
								"gd","gdc":
									load_type = "script"
								"tscn","res","tres":
									load_type = "resource"
						match load_type:
							"script":
								var path:String=resource if resource.begins_with("res://") else(modlet.get_base_dir()+(""if resource.begins_with("/")else"/")+resource)
								if pointers.ConfigDriver.__validate_dictionary(subdata)&&pointers.FileAccess.__file_exists(path):
									var op=subdata.get("override_path","res:/"+path.split(modlet.get_base_dir())[1])
									var override_path:String=op if(op.begins_with("res:/"))else("res:/"+(""if op.begins_with("/")else"/")+op)
									if subdata.get("override",false)&&pointers.FileAccess.__file_exists(override_path):
										pointers.DataFormat.__override_script(path,override_path)
									else:
										pointers.DataFormat.__extend_script(path)
									resCount += 1
							"scene","resource":
								var path : String = resource if resource.begins_with("res://") else (modlet.get_base_dir() + ("" if resource.begins_with("/") else "/") + resource)
								var old : String = subdata.get("original_path","res:/" + path.split(modlet.get_base_dir())[1])
								var old_path : String = old if (old.begins_with("res:/")) else ("res:/" + ("" if old.begins_with("/") else "/") + old)
								if pointers.ConfigDriver.__validate_dictionary(subdata) and pointers.FileAccess.__file_exists(path):
									pointers.DataFormat.__replace_resource(path,old_path)
									if not old_path in scenes_to_reload:
										scenes_to_reload.append(old_path)
									resCount += 1
							"reload":
								var path : String = resource if resource.begins_with("res://") else ("res:/" + ("" if resource.begins_with("/") else "/") + resource)
								if pointers.ConfigDriver.__validate_dictionary(subdata) and pointers.FileAccess.__file_exists(path):
									pointers.DataFormat.__reload_scene(path,subdata.get("complete_reload",false))
									resCount += 1
		pointers.l("%d modlet resources loaded." % resCount,"pointers.SafeMode")
		pointers.DataFormat.__loadDLC()
		return scenes_to_reload
	
	static func sortLoadOrder(a:Array,b:Array) -> bool:
		return a[3] < b[3]
	
	const disabledModletCache:Dictionary = {}
	
	static func __get_disabled_modlets() -> Dictionary:
		if not disabledModletCache:
			var disabled:Dictionary = {}
			var all_modlets:Dictionary = __get_all_modlets(false)
			for modlet in all_modlets.keys():
				if not all_modlets[modlet] and non_static["pointers"].FileAccess.__file_exists(modlet):
					var mv:Dictionary = __parse_file_as_manifest(modlet)
					disabled[modlet] = mv.get("mod_information",{}).get("id","%s_MISSING_ID" % modlet)
			disabledModletCache.clear()
			disabledModletCache.merge(disabled)
		return disabledModletCache.duplicate(true)
	
	static func __mod_exists(check_data) -> bool:
		var has:bool = false
		var current_mod_ids:PoolStringArray = __get_mod_ids()
		match typeof(check_data):
			TYPE_STRING:
				if check_data in current_mod_ids:
					has = true
				elif check_data in __get_mod_list_keys():
					has = true
			TYPE_ARRAY:
				if check_data:
					for i in check_data:
						if __mod_exists(i):
							has = true
							break
			TYPE_DICTIONARY:
				var MID = str(check_data.get("mod_id",""))
				var MDM = str(check_data.get("mod_main",""))
				if check_data and MID:
					var moddata = __get_mod_by_id(MID)
					if moddata:
						var t1 = true
						var ver_info = moddata["version_data"]["full_version_array"]
						if ("maximum_version" in check_data or "max_version" in check_data):
							var minimum = check_data.get("maximum_version",check_data.get("max_version",[0,0,0]))
							var mnm = null
							match typeof(minimum):
								TYPE_ARRAY,TYPE_INT_ARRAY:
									if minimum.size() > 2:
										mnm = minimum
								TYPE_VECTOR3:
									mnm = minimum
								TYPE_DICTIONARY:
									var minarr = Vector3.ZERO
									minarr[0] = int(minimum.get("major",0))
									minarr[1] = int(minimum.get("minor",0))
									minarr[2] = int(minimum.get("bugfix",0))
									mnm = minarr
							if mnm != null:
								for i in 3:
									if t1:
										var a = int(ver_info[i])
										var b = int(mnm[i])
										if a > b:
											t1 = false
										elif a < b:
											break
						if t1 and ("minimum_version" in check_data or "min_version" in check_data):
							var minimum = check_data.get("minimum_version",check_data.get("min_version",[0,0,0]))
							var mnm = null
							match typeof(minimum):
								TYPE_ARRAY,TYPE_INT_ARRAY:
									if minimum.size() > 2:
										mnm = minimum
								TYPE_VECTOR3:
									mnm = minimum
								TYPE_DICTIONARY:
									var minarr = Vector3.ZERO
									minarr[0] = int(minimum.get("major",0))
									minarr[1] = int(minimum.get("minor",0))
									minarr[2] = int(minimum.get("bugfix",0))
									mnm = minarr
							if mnm != null:
								for i in 3:
									if t1:
										var a = int(ver_info[i])
										var b = int(mnm[i])
										if a < b:
											t1 = false
										elif a > b:
											break
									
						has = t1
				elif typeof(MDM) == TYPE_STRING and MDM and MDM in __get_mod_list_keys():
					has = true
		return has
	
	static func __match_mod_file_path_to_id(file_path:String) -> String:
		if mod_file_to_id_cache.empty():
			__get_mod_data()
		return mod_file_to_id_cache.get(file_path.to_lower(),"")
	
	

class _Math:
	var scripts : Array = [
		
	]
	
	static func get_class_documentation():
		return {
			"description":"",
			"methods":{
				"__rotate_point":{
					"description":"Provides a Vector2 point after being rotated around (0,0)",
					"args":[
						"point -> (Vector2) point that is being rotated around (0,0)",
						"angle -> (float) angles to rotate by",
						"degrees (optional) -> (bool) for whether 'angle' should be treated as degree angles, and uses radians if not. Defaults to `true`"
					],
					"return":[
						"Vector2 for the rotated point"
					]
				},
				"__factorial":{
					"description":"Calculates the factorial of the provided integer",
					"args":[
						"n -> (int) the number to be set to it's factorial"
					],
					"return":[
						"int for the output factorial"
					]
				},
				"__get_unique_pairs":{
					"description":"Provides an array of PoolIntArrays of all pairs of numbers in a range from zero to the provided integer (not inclusive). E.g. 3 = [[0,1],[0,2],[1,2]]",
					"args":[
						"max_value -> (int) the range of the pairs, non-inclusive"
					],
					"return":[
						"Array of PoolIntArrays for each pair."
					]
				},
				"":{
					"description":"",
					"args":[
						
					],
					"return":[
						
					]
				},
			}
		}
	
	const non_static = {}
	func _init(p):
		non_static["pointers"] = p
	
	
	static func __rotate_point(point : Vector2, angle : float, degrees : bool = true) -> Vector2:
		if degrees:
			angle = deg2rad(angle)
		return Vector2((point.x*cos(-angle))-(point.y*sin(-angle)),(point.y*cos(-angle))+(point.x*sin(-angle)))
	
	static func __factorial(n:int) -> int:
		var holdvalue:int = 0
		var boolis:bool = true
		var s:int = sign(n)
		n = abs(n)
		if n < 2:
			return holdvalue * s
		while n > 0:
			if boolis:
				boolis = false
				holdvalue = n
			else:
				holdvalue = holdvalue * n
			n -= 1
		return holdvalue * s
	
	static func __get_unique_pairs(max_value: int) -> Array:
		var pairs : Array = []
		for i in (max_value + 1):
			for j in range(i + 1, max_value):
				pairs.append(PoolIntArray([i, j]))
		return pairs
	
	static func __mirror_vector(point:Vector2, reflection_angle:float = 0.0, use_degrees:bool = false, angle_offset:Vector2 = Vector2.ZERO, scale:Vector2 = Vector2.ONE) -> Vector2:
		if use_degrees:
			reflection_angle = deg2rad(reflection_angle)
		point *= scale
		reflection_angle = -reflection_angle - (PI/2.0)
		var a:float = -sin(reflection_angle)
		var b:float = cos(reflection_angle)
		var c:float = -((a * angle_offset.x) + (b * angle_offset.y))
		var t:float = (-2 * ((a * point.x) + (b * point.y) + c)) / ((a * a) + (b * b))
		return Vector2(point.x + (a * t), point.y + (b * t)) / scale
	
	static func __mirror_vector_array(points:PoolVector2Array, reflection_angle:float = 0.0, use_degrees:bool = false, angle_offset:Vector2 = Vector2.ZERO, scale:Vector2 = Vector2.ONE) -> PoolVector2Array:
		for i in points.size():
			points[i] = __mirror_vector(points[i],reflection_angle,use_degrees,angle_offset,scale)
		return points
	
	

class _NodeAccess:
	var scripts : Array = [
		
	]
	
	static func get_class_documentation():
		return {
			"description":"",
			"methods":{
				"":{
					"description":"",
					"args":[
						
					],
					"return":[
						
					]
				},
			}
		}
	
	const non_static = {}
	func _init(f):
		non_static["pointers"] = f
		non_static["self"] = self
	
	static func __get_all_children(node:Node, strip_supplied_node_from_array = false, return_only_paths = false, use_relative_paths = false):
		var children : Array = getAllChildren(node)
		if strip_supplied_node_from_array:
			children = strip_node(node, children)
		if return_only_paths:
			children = returnPaths(children, use_relative_paths, node)
		return children

	static func getAllChildren(in_node:Node,arr : Array = []):
		arr.push_back(in_node)
		for child in in_node.get_children():
			getAllChildren(child,arr)

	static func strip_node(in_node, arr):
		var paths : Array = []
		for m in arr:
			var selfPath : String = in_node.get_path()
			var modify:PoolStringArray = m.get_path().split(selfPath)
			if modify[1]:
				paths.append(m)
		return paths

	static func returnPaths(arr, relative, in_node):
		var parentPath : String = str(in_node.get_path())
		var paths : Array = []
		for m in arr:
			var path : String = m.get_path()
			paths.append(path)
		if relative:
			for i in paths.size():
				paths[i] = paths[i].split(parentPath)[1].lstrip("/")
		return paths
	
	static func __claim_child_ownership(node: Node):
		for child in node.get_children():
			setOwnership(child, node)

	static func setOwnership(current_node: Node,set_owner_node: Node):
		current_node.set_owner(set_owner_node)
		if current_node.get_child_count():
			var children : Array = current_node.get_children()
			for child in children:
				if not __is_instanced_from_scene(child.get_parent()):
					setOwnership(child, set_owner_node)

	static func __is_instanced_from_scene(p_node):
		return not p_node.filename.empty()
	
	static func __dynamic_crew_expander(folder_path: String = "user://cache/.HevLib_Cache/dynamic_crew_expander/", max_crew:int = 24) -> String:
		var pointers = non_static["pointers"]
		pointers.FolderAccess.__check_folder_exists(folder_path)
		var base:int = 24

		var test:Node = load("res://comms/conversation/subtrees/DIALOG_DERELICT_RANDOM.tscn").instance()
		var maximum:int = 0
		for child in test.get_children():
			var line:String = child.name
			if line.begins_with("DIALOG_DERELICT_SWITCH_CREW"):
				var spl:PoolStringArray = line.split("|")
				if int(spl[1]) > maximum:
					maximum = int(spl[1])
		test.queue_free()
		maximum += 1
		if maximum > base:
			base = maximum
		if not max_crew > base:
			pointers.l("TSCN Writer for dynamic crew handler: desired expansion to [%s] is less than or equal to the currently expanded number of [%s]" % [max_crew,base],"pointers.NodeAccess")
			return ""
		
		var compacted_string : String = "[gd_scene load_steps=3 format=2]\n\n[ext_resource path=\"res://comms/conversation/subtrees/DIALOG_DERELICT_RANDOM.tscn\" type=\"PackedScene\" id=1]\n[ext_resource path=\"res://comms/ConversationPlayer.gd\" type=\"Script\" id=2]\n\n[node name=\"DIALOG_DERELICT_RANDOM_1\" instance=ExtResource( 1 )]\n\n"
		while max_crew > base:
			compacted_string += "[node name=\"DIALOG_DERELICT_SWITCH_CREW|%s\" type=\"Node\" parent=\".\" index=\"%s\"]\nscript = ExtResource( 2 )\nmyLine = false\nfaceless = true\nimportChildren = NodePath(\"../DIALOG_DERELICT_GO_AND_BRING_IT\")\nagenda = \"CREW/%s\"\nagendaNotSame = true\n\n" % [base,base + 4]
			base += 1
		if not folder_path.ends_with("/"):
			folder_path += "/"
#		var save_file_path : String = folder_path + "dynamic_crew_x%s.tscn" % base
#		pointers.DataFormat.__replace_scene(compacted_string,"res://comms/conversation/subtrees/DIALOG_DERELICT_RANDOM.tscn",save_file_path)
		
		return folder_path.plus_file("dynamic_crew_x%s.tscn" % base)
	
	static func __remove_scripts(node):
		node.set_script(null)
		for obj in node.get_children():
			__remove_scripts(obj)
	
	static func __exit(restart : bool = false, exit_message : String = "", exit_header : String = "", delay : float = 0.0,exit_url : String = "",use_os_error_message : bool = false):
		var pointers = non_static["pointers"]
		if delay > 0.0 and pointers.is_inside_tree():
			pointers.get_tree().create_timer(delay).connect("timeout",non_static["self"],"__exit",[restart,exit_message,exit_header,0.0,exit_url,use_os_error_message])
		else:
			if use_os_error_message and exit_message:
				OS.alert(exit_message,exit_header)
			if restart:
				pointers.l(("restarting with message: %s" % exit_message) if exit_message else "exiting with restart",(exit_header) if (exit_header) else ("pointers.DataFormat"))
				OS.execute(OS.get_executable_path(), OS.get_cmdline_args(), false)
			else: pointers.l(("exiting with message: %s" % exit_message) if exit_message else "exiting",(exit_header) if (exit_header) else ("pointers.DataFormat"))
			Debug.batchWrite()
			pointers.storeLogCache()
			if exit_url and pointers.DataFormat.__is_valid_url(exit_url):
				OS.shell_open(exit_url)
			if pointers.is_inside_tree():
				yield(pointers.get_tree(),"idle_frame")
			OS.kill(OS.get_process_id())


class _RingInfo:
	var scripts : Array = [
		
	]
	
	static func get_class_documentation():
		return {
			"description":"",
			"methods":{
				"":{
					"description":"",
					"args":[
						
					],
					"return":[
						
					]
				},
			}
		}
	
	const images = {}
	func _init(p):
		images["map"] = load("res://ring/ring-map.png")
		images["veins"] = load("res://ring/ring-veins.png")
	
	const pixelToKm = 10000
	
	static func __get_pixel_at(pos: Vector2) -> Color:
		var image = images.map.get_data()
		var size = image.get_size()
		var x = int(clamp(floor(pos.x / pixelToKm), 0, size.x - 1))
		var sy = int(size.y)
		var y = ((int(floor(pos.y / pixelToKm)) %sy) + sy) %sy
		var x1 = int(clamp(x + 1, 0, size.x - 1))
		var y1 = (y + 1) % int(size.y)
		
		if x <= 0:
			return Color(0, 0, 0, 0)
		
		image.lock()
		var p00 = image.get_pixel(x, y)
		var p10 = image.get_pixel(x1, y)
		var p11 = image.get_pixel(x1, y1)
		var p01 = image.get_pixel(x, y1)
		image.unlock()
		
		var cx = (pos.x - floor(pos.x / pixelToKm) * pixelToKm) / pixelToKm
		var cy = (pos.y - floor(pos.y / pixelToKm) * pixelToKm) / pixelToKm

		var pu = (p00 * (1 - cx) + p10 * (cx))
		var pd = (p01 * (1 - cx) + p11 * (cx))
		
		var pixel = pu * (1 - cy) + pd * (cy)
		return pixel
	
	static func __get_vein_pixel_at(pos: Vector2) -> Color:
		var veinImage:Image = images.veins.get_data()
		var veinSize:Vector2 = veinImage.get_size()
		var x = posmod(pos.x, veinSize.x)
		var y = posmod(pos.y, veinSize.y)
		var x1 = posmod(pos.x + 1, veinSize.x)
		var y1 = posmod(pos.y + 1, veinSize.y)
		
		veinImage.lock()
		var p00 = veinImage.get_pixel(x, y)
		var p10 = veinImage.get_pixel(x1, y)
		var p11 = veinImage.get_pixel(x1, y1)
		var p01 = veinImage.get_pixel(x, y1)
		veinImage.unlock()
		
		var cx = fposmod(pos.x, 1)
		var cy = fposmod(pos.y, 1)

		var pu = lerp(p00, p10, cx)
		var pd = lerp(p01, p11, cx)
		
		var pixel = lerp(pu, pd, cy)
		return pixel
	
	static func __get_vein_at(pos: Vector2) -> String:
		var p1 = __get_vein_pixel_at(pos / 1861.0)
		var p2 = __get_vein_pixel_at(pos / - 2531.0)
		
		var values = [p1.r, p1.g, p1.b, p1.a, p2.r, p2.b, p2.g, p2.a]
			
		var total = 0
		for n in CurrentGame.traceMinerals.size():
			var tm = CurrentGame.traceMinerals[n]
			values[n] = pow(values[n] / pow(CurrentGame.mineralPrices.get(tm, 1), 0.2), 4)
			total += values[n]
			
		var rnd = randf() * total
		var nr = 0
		for n in values:
			rnd -= n
			if rnd < 0:
				return CurrentGame.traceMinerals[nr]
			nr += 1
		
		return CurrentGame.traceMinerals[0]
	
	static func get_chaos_at(pos):
		return __get_pixel_at(pos).r
	
	static func get_raw_density_at(pos):
		return __get_pixel_at(pos).b
	

class _RPC:
	var scripts : Array = [
		
	]
	
	func _init(p):
		rpc_data["pointers"] = p
		rpc_data["self"] = self
		rpc_data["start_timer"] = OS.get_unix_time()
		rpc_data["update_timer"] = Timer.new()
	
	# RPC CALLABLE FUNCTIONS
	
	static func set_icon(ship:String,force_this_icon:bool = false):
		var icon:String = ""
		if force_this_icon:
			icon = ship
		else:
			if ship in validShipIcons:
				icon = ship
			else:
				match ship.to_lower():
					"icon":
						icon = "icon"
					"empty":
						icon = "empty"
					"ep","enceladus","enceladus_prime":
						icon = "enceladus_prime"
					"unknown":
						icon = "unknown"
		if icon != rpc_data["current_icon"]:
			rpc_data["pointers"].l("Changing large icon from %s to %s" % [rpc_data["current_icon"],icon],"pointers.RPC")
			if icon.empty():
				icon = "empty"
			rpc_data["current_icon"] = icon
	
	static func set_icon_text(text:String):
		if text != rpc_data["current_icon_text"]:
			rpc_data["pointers"].l("Changing large icon text from %s to %s" % [rpc_data["current_icon_text"],text],"pointers.RPC")
			rpc_data["current_icon_text"] = text
	
	static func set_small_icon_text(text:String):
		if text != rpc_data["current_small_icon_text"]:
			rpc_data["pointers"].l("Changing small icon text from %s to %s" % [rpc_data["current_small_icon_text"],text],"pointers.RPC")
			rpc_data["current_small_icon_text"] = text
	
	static func set_small_icon(how:String,force_this_icon:bool = false):
		var icon:String = "None"
		if force_this_icon:
			icon = how
		else:
			if how:
				icon = icons["icon"]
		if icon != rpc_data["current_small_icon"]:
			rpc_data["pointers"].l("Changing small icon from %s to %s" % [rpc_data["current_small_icon"],icon],"pointers.RPC")
			rpc_data["current_small_icon"] = icon
	
	static func set_start_timer(time:int = OS.get_unix_time()):
		if time != rpc_data["start_timer"]:
			rpc_data["pointers"].l("Changing start time from %d to %d" % [rpc_data["start_timer"],time],"pointers.RPC")
			rpc_data["start_timer"] = time
	
	static func set_end_timer(time:int = 0):
		if time != rpc_data["end_timer"]:
			rpc_data["pointers"].l("Changing end time from %d to %d" % [rpc_data["end_timer"],time],"pointers.RPC")
			rpc_data["end_timer"] = time
	
	static func set_state(text:String):
		if text != rpc_data["current_state"]:
			rpc_data["pointers"].l("Changing state from %s to %s" % [rpc_data["current_state"],text],"pointers.RPC")
			rpc_data["current_state"] = text
	
	static func set_details(text:String):
		if text != rpc_data["current_details"]:
			rpc_data["pointers"].l("Changing details from %s to %s" % [rpc_data["current_details"],text],"pointers.RPC")
			rpc_data["current_details"] = text
	
	# RPC INTERNALS
	
	signal update_activity()
	signal rpc_timer_complete()
	
	const rpc_data = {
		"current_icon":"empty",
		"current_icon_text":"",
		"current_small_icon":"icon",
		"current_small_icon_text":"",
		"start_timer":0,
		"end_timer":0,
		"current_state":"",
		"current_details":"HEVLIB_DISCORDRPC_TITLE_SCREEN",
		"secondary_state_index":0,
		"secondary_states":Array(),
		"absolute_state":"",
		"loaded":false,
		"update_wait_time":4.5,
		"reconnect_wait_time":3.0,
		"err_update_wait_time":60.0,
		"err_reconnect_wait_time":60.0,
		"update_delay":4.5,
		"reconnect_delay":3.0,
		"update_timer":null,
		"discord":null,
		"activity":null,
		"currentStack":0,
		"err_count":0,
	}
	
	const validShips:Dictionary = {
		"SHIP_TRTL":"k37",
		"SHIP_AT225":"k225",
		"SHIP_COTHON":"cothon",
		"SHIP_PROSPECTOR_BALD":"bald_eagle",
		"SHIP_PROSPECTOR":"prospector",
		"SHIP_EIME":"model_e",
		"SHIP_KITSUNE":"kitsune",
		"SHIP_OCP209":"ocp",
		"SHIP_ATLAS_WASP":"ai_wasp",
		"SHIP_MADCERF":"mad_cerf",
		"SHIP_OBERON":"modded_oberon",
		"SHIP_TSUKUYOMI_IOT":"bbw",
	}
	
	const validShipIcons:PoolStringArray = PoolStringArray([
		"k37",
		"k225",
		"cothon",
		"bald_eagle",
		"prospector",
		"model_e",
		"kitsune",
		"ocp",
		"ai_wasp",
		"mad_cerf",
		"modded_oberon",
		"bbw",
	])
	
	const icons:Dictionary = {
		"ships":{
			"SHIP_TRTL":"k37",
			"SHIP_AT225":"k225",
			"SHIP_COTHON":"cothon",
			"SHIP_PROSPECTOR_BALD":"bald_eagle",
			"SHIP_PROSPECTOR":"prospector",
			"SHIP_EIME":"model_e",
			"SHIP_KITSUNE":"kitsune",
			"SHIP_OCP209":"ocp",
			"SHIP_ATLAS_WASP":"ai_wasp",
			"SHIP_MADCERF":"mad_cerf",
			"SHIP_OBERON":"modded_oberon",
			"SHIP_TSUKUYOMI_IOT":"bbw",
		},
		"icon":"icon",
		"empty":"empty",
		"ep":"enceladus_prime",
		"unknown":"unknown"
	}
	
	const discord_script:String = "res://HevLib Discord RPC/lib/discord.gd"
	static func ready():
		var file:File = File.new()
		var pointers = rpc_data["pointers"]
		if file.file_exists(discord_script) and pointers.ConfigDriver.__get_value("HevLib","HEVLIB_CONFIG_SECTION_RPC","discord_rpc_enabled"):
			var discord = load(discord_script).new()
			rpc_data["activity"] = discord.Activity.new()
			rpc_data["loaded"] = true
			rpc_data["discord"] = discord
			pointers.add_child(rpc_data["discord"])
			var base = rpc_data["self"]
			base.connect("update_activity",base,"update_activity")
			var update_timer:Timer = rpc_data["update_timer"]
			update_timer.wait_time = rpc_data["reconnect_delay"]
			update_timer.one_shot = true
			update_timer.name = "UPDATE_TIMER"
			update_timer.connect("timeout",base,"update_timer_finished")
			
			pointers.add_child(update_timer)
			update_timer_finished()
	
	const stack:PoolStringArray = PoolStringArray(["","","",""])
	
	static func loader_changed(area:String,level:int = 0,how_specific:String = ""):
		if not rpc_data["loaded"]:
			return
		var currentStack:int = rpc_data["currentStack"]
		if area != stack[0]:
			rpc_data["start_timer"] = OS.get_unix_time()
			stack[0] = area
			rpc_data["secondary_states"] = rpc_data["pointers"].Equipment.rpc_second_state_store[area]
			rpc_data["secondary_state_index"] = 0
		currentStack = level
		if how_specific != "":
			stack[currentStack] = how_specific
		var current_icon:String = ""
		var current_details:String = ""
		var current_state:String = ""
		match stack[0]:
			"enceladus_prime":
				current_icon = "enceladus_prime"
				current_details = "HEVLIB_DISCORDRPC_AT_ENCELADUS"
				current_state = "HEVLIB_DISCORDRPC_AT_ENCELADUS"
				var sn:String = CurrentGame.getPlayerShip().getShipName()
				match stack[currentStack]:
					"simulator":
						current_details = TranslationServer.translate("HEVLIB_DISCORDRPC_IN_MVFS") % sn
					"dive_summary":
						current_details = "HEVLIB_DISCORDRPC_IN_DIVE_SUMMARY"
					"dive_target":
						current_details = "HEVLIB_DISCORDRPC_IN_DIVE_TARGET"
					"mineral_market":
						current_details = "HEVLIB_DISCORDRPC_IN_MINERAL_MARKET"
					"repairs":
						current_details = TranslationServer.translate("HEVLIB_DISCORDRPC_IN_REPAIRS") % sn
					"inspection":
						current_details = TranslationServer.translate("HEVLIB_DISCORDRPC_IN_INSPECTIONS") % sn
					"equipment":
						current_details = TranslationServer.translate("HEVLIB_DISCORDRPC_IN_EQUIPMENT") % sn
					"tuning":
						current_details = TranslationServer.translate("HEVLIB_DISCORDRPC_IN_TUNING") % sn
					"ship_logs":
						current_details = "HEVLIB_DISCORDRPC_IN_SHIP_LOGS"
					"crew":
						current_details = "HEVLIB_DISCORDRPC_IN_CREW"
					"fleet":
						current_details = "HEVLIB_DISCORDRPC_IN_FLEET"
					"dealer":
						current_details = "HEVLIB_DISCORDRPC_IN_DEALER"
					"services":
						current_details = "HEVLIB_DISCORDRPC_IN_SERVICES"
					"research":
						current_details = "HEVLIB_DISCORDRPC_IN_RESEARCH"
				
			"title_screen":
				current_icon = "empty"
				current_details = "HEVLIB_DISCORDRPC_TITLE_SCREEN"
				current_state = "HEVLIB_DISCORDRPC_TITLE_SCREEN"
				
				
			"ring":
				current_details = "HEVLIB_DISCORDRPC_IN_RING"
				current_state = "HEVLIB_DISCORDRPC_IN_RING"
				
				var playership = CurrentGame.getPlayerShip()
				
				match how_specific:
					"western","western2":
						current_details = "HEVLIB_DISCORDRPC_HIGH_DENSITY"
					"mystery","mystery2":
						current_details = "HEVLIB_DISCORDRPC_ODDITIES"
					"spooky":
						current_details = "HEVLIB_DISCORDRPC_SPOOKY"
					"dare":
						current_details = "HEVLIB_DISCORDRPC_DARE"
					"battle":
						current_details = "HEVLIB_DISCORDRPC_BATTLE"
					"boss":
						current_details = "HEVLIB_DISCORDRPC_BOSS"
					"peril":
						current_details = "HEVLIB_DISCORDRPC_PERIL"
					"l:G4A":
						pass
					"l:locust":
						current_details = "HEVLIB_DISCORDRPC_LOCUSTS"
				
				var shipIcon:String = "empty"
				var thisShip:String = ""
				if "baseShipName" in playership and playership.baseShipName in validShips:
					thisShip = playership.baseShipName
				if "shipName" in playership and playership.shipName in validShips:
					thisShip = playership.shipName
				if thisShip in validShips:
					shipIcon = validShips[thisShip]
				current_icon = shipIcon
		rpc_data["current_details"] = current_details
		rpc_data["current_icon"] = current_icon
		rpc_data["current_state"] = current_state
		rpc_data["currentStack"] = currentStack
	static func update_timer_finished():
		rpc_data["self"].emit_signal("rpc_timer_complete")
		update_rpc()
		rpc_data["update_timer"].start(rpc_data["update_delay"]/Engine.get_time_scale())
	
	static func update_rpc():
		if rpc_data["loaded"]:# and changed:
			calculate_current_state()
			rpc_data["self"].emit_signal("update_activity")
	
	static func get_state_data(state:Dictionary) -> String:
		var playership = CurrentGame.getPlayerShip()
		if not Tool.claim(playership):
			return rpc_data["current_state"]
		Tool.release(playership)
		var out:String = TranslationServer.translate(state.get("text","RPC text missing :("))
		var toFormat:Dictionary = {}
		var sensors:Array = state.get("sensors",Array())
		if sensors and stack[0] == "ring":
			for sensor in sensors:
				match typeof(sensor):
					TYPE_STRING:
						toFormat["sensor:" + sensor] = playership.sensorGet(sensor)
					TYPE_DICTIONARY:
						var sensor_name:String = sensor.get("sensor","")
						var fallbackFormat:String = sensor.get("fallback","unknown")
						var sensorOut = playership.sensorGet(sensor_name)
						if "funcref" in sensor:
							sensorOut = sensor.get("funcref").call_funcv([sensorOut] + sensor.get("extra_operands",[]))
						if sensorOut != null:
							toFormat["sensor:" + sensor_name] = sensorOut
						elif fallbackFormat:
							toFormat["sensor:" + sensor_name] = TranslationServer.translate(fallbackFormat)
		for sensor in state.get("function_outputs",Array()):
			if typeof(sensor)==TYPE_DICTIONARY:
				var sensor_name:String = sensor.get("name","")
				var fallbackFormat:String = sensor.get("fallback","unknown")
				var sensorOut
				if "funcref" in sensor:
					sensorOut = sensor.get("funcref").call_funcv(sensor.get("extra_operands",[]))
				if sensorOut:
					toFormat["output:" + sensor_name] = sensorOut
				elif fallbackFormat:
					toFormat["output:" + sensor_name] = TranslationServer.translate(fallbackFormat)
		if toFormat:
			out = out.format(toFormat)
		return out
	
	static func calculate_current_state():
		var secondary_states:Array = rpc_data["secondary_states"]
		var secondary_state_index: int = rpc_data["secondary_state_index"]
		if secondary_states:
			secondary_state_index += 1
			if secondary_state_index > secondary_states.size():
				secondary_state_index = 0
			if secondary_state_index == 0 and rpc_data["current_state"] == rpc_data["current_details"]:
				secondary_state_index = 1
			if secondary_state_index > 0:
				var thisState = secondary_states[secondary_state_index - 1]
				rpc_data["absolute_state"] = get_state_data(thisState)
			else:
				rpc_data["absolute_state"] = rpc_data["current_state"]
		else:
			secondary_state_index = 0
			rpc_data["absolute_state"] = rpc_data["current_state"]
		rpc_data["secondary_states"] = secondary_states
		rpc_data["secondary_state_index"] = secondary_state_index
	
	
	static func update_activity() -> void:
		var st:String = rpc_data["absolute_state"]
		var dt:String = rpc_data["current_details"]
		if st == dt:
			st = ""
		var activity = rpc_data["activity"]
		var discord = rpc_data["discord"]
		activity.set_type(discord.ActivityType.Playing)
		activity.set_state(TranslationServer.translate(st))
		activity.set_details(TranslationServer.translate(dt))
		
		var assets = activity.get_assets()
		assets.set_large_image(rpc_data["current_icon"])
		assets.set_large_text(rpc_data["current_icon_text"])
		assets.set_small_image(rpc_data["current_small_icon"])
		assets.set_small_text(rpc_data["current_small_icon_text"])
		var timestamps = activity.get_timestamps()
		var start_timer:int = rpc_data["start_timer"]
		var end_timer:int = rpc_data["end_timer"]
		if start_timer > 0:
			timestamps.set_start(start_timer)
		if end_timer > 0:
			timestamps.set_end(end_timer)
		var err_count:int = rpc_data["err_count"]
		var result = yield(discord.activity_manager.update_activity(activity), "result").result
		if result != discord.Result.Ok:
			err_count += 1
			if err_count > 3:
				rpc_data["update_delay"] = rpc_data["err_update_wait_time"]
				rpc_data["reconnect_delay"] = rpc_data["err_reconnect_wait_time"]
			rpc_data["pointers"].l("ERROR: RPC returned error code %d" % result,"pointers.RPC")
		else:
			if err_count:
				rpc_data["update_delay"] = rpc_data["update_wait_time"]
				rpc_data["reconnect_delay"] = rpc_data["reconnect_wait_time"]
			err_count = 0
	


class _SafeMode:
	var scripts : Array = [
		
	]
	
	static func get_class_documentation():
		return {
			"description":"",
			"methods":{
				"":{
					"description":"",
					"args":[
						
					],
					"return":[
						
					]
				},
			}
		}
	
	const PCKNAMES:PoolStringArray = PoolStringArray()
	var safeCheck:bool = false
	var safeCheckTriggered:bool = false
	const offendingFiles:Dictionary = {}
	var offendingFileCount:int = 0
	const dependancy_dictionary:Dictionary = Dictionary()
	const dependancy_dict_keys:Array = Array()
	const dependancy_lookup:Dictionary = Dictionary()
	const dependancy_lookup_keys:Array = Array()
	const vanilla_load_order:Array = Array()
	
	const order_tree:Dictionary = Dictionary()
	
	const non_static = {}
	func _init(p):
		non_static["pointers"] = p
		var regex:RegEx = RegEx.new()
		regex.compile(p.DataFormat.crcTable.B10.get_string_from_utf8())
		non_static["regex"] = regex
		non_static["self"] = self
	
	const safemode_dir = "user://cache/.HevLib_Cache/SafeMode/"
	const validation_check_path:String = safemode_dir + "recache_validation.json"
	const pck_file_paths_store:String = safemode_dir + "pck_file_paths.json"
	const vanilla_load_order_store:String = safemode_dir + "vanilla_load_order.json"
	const dependancy_lookup_store:String = safemode_dir + "dependancy_lookup.json"
	const dependancy_dictionary_store:String = safemode_dir + "dependancy_dictionary.json"
	
	static func ready():
		var file:File = File.new()
		var pointers:HevLibPointers = non_static["pointers"]
		var vanilla_version:PoolIntArray = pointers.DataFormat.__get_vanilla_version()
		var validation_check:Dictionary = Dictionary()
		if file.file_exists(validation_check_path):
			file.open(validation_check_path,File.READ)
			validation_check = JSON.parse(file.get_as_text()).result
			file.close()
		if validation_check.get("hevlib_cache_version",-1) != HEVLIB_CACHE_VERSION or !deep_equal(PoolIntArray(validation_check.get("vanilla_version",PoolIntArray([1,0,0]))),vanilla_version) or !file.file_exists(validation_check_path) or !file.file_exists(pck_file_paths_store) or !file.file_exists(vanilla_load_order_store) or !file.file_exists(dependancy_lookup_store) or !file.file_exists(dependancy_dictionary_store) or pointers.ManifestV2.haveModsChanged:
			pointers.l("Game has updated or cache is missing, rebuilding file info cache.")
			pointers.FolderAccess.__recursive_delete(safemode_dir)
			Directory.new().make_dir(safemode_dir)
			var timerStart:int = Time.get_ticks_usec()
			PCKNAMES.append_array(pointers.FolderAccess.__get_vanilla_script_and_scenes())
			validation_check["vanilla_version"] = vanilla_version
			validation_check["hevlib_cache_version"] = HEVLIB_CACHE_VERSION
			file.open(validation_check_path,File.WRITE)
			file.store_string(JSON.print(validation_check))
			file.close()
			for f in PCKNAMES:
				get_dependancies_for_vanilla_file(f)
			order_tree.merge(flatten_tree(get_dependancy_tree()))
			vanilla_load_order.append_array(dependancy_dict_keys)
			var vsize:int = vanilla_load_order.size()
			var idx:int = 0
			while idx < vsize:
				if idx > 0:
					var item:String = vanilla_load_order[idx]
					for i in idx:
						var deps:Array = order_tree[vanilla_load_order[i]]
						if item in deps:
							vanilla_load_order.remove(idx)
							vanilla_load_order.insert(i,item)
							idx = i
							break
				idx += 1
			file.open(pck_file_paths_store,File.WRITE)
			file.store_string(JSON.print(PCKNAMES))
			file.close()
			file.open(vanilla_load_order_store,File.WRITE)
			file.store_string(JSON.print(vanilla_load_order))
			file.close()
			file.open(dependancy_lookup_store,File.WRITE)
			file.store_string(JSON.print(dependancy_lookup))
			file.close()
			file.open(dependancy_dictionary_store,File.WRITE)
			file.store_string(JSON.print(dependancy_dictionary))
			file.close()
			var timerEnd:int = Time.get_ticks_usec()-timerStart
			pointers.l("Cache rebuilt in %d.%03d ms" % [int(floor(timerEnd / 1000.0)),timerEnd % 1000])
		else:
			file.open(pck_file_paths_store,File.READ)
			PCKNAMES.append_array(JSON.parse(file.get_as_text()).result)
			file.close()
			file.open(vanilla_load_order_store,File.READ)
			vanilla_load_order.append_array(JSON.parse(file.get_as_text()).result)
			file.close()
			file.open(dependancy_lookup_store,File.READ)
			dependancy_lookup.merge(JSON.parse(file.get_as_text()).result)
			file.close()
			file.open(dependancy_dictionary_store,File.READ)
			dependancy_dictionary.merge(JSON.parse(file.get_as_text()).result)
			file.close()
			dependancy_lookup_keys.append_array(dependancy_lookup.keys())
			dependancy_dict_keys.append_array(dependancy_dictionary.keys())
		
		if not pointers.is_editor:
			var safeCheck = pointers.ConfigDriver.__get_value("HevLib","HEVLIB_CONFIG_SECTION_DRIVERS","safe_mod_loading")
			if safeCheck:pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_ENABLED"),"pointers.SafeMode")
			else:pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_DISABLED"),"pointers.SafeMode")
			non_static["self"].safeCheck = safeCheck
		else:pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_DISABLED_EDITOR"),"pointers.SafeMode")
	
	static func __check_file(file_path:String,zip_path:String,crash:bool = true):
		var base = non_static["self"]
		if base.safeCheck:
			var pointers = non_static["pointers"]
			var zf:String = zip_path.get_file()
			pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_CHECKINGFILE") % [zf,file_path],"pointers.SafeMode")
			if file_path in PCKNAMES:
				pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_OVERWRITE_VANILLA_ERR_1") % [file_path,zf],"pointers.SafeMode")
				pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_OVERWRITE_VANILLA_ERR_2"),"pointers.SafeMode")
				pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_OVERWRITE_VANILLA_ERR_3"),"pointers.SafeMode")
				pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_OVERWRITE_VANILLA_ERR_4"),"pointers.SafeMode")
				if not zf in offendingFiles:
					offendingFiles[zf] = PoolStringArray([file_path])
				else:
					offendingFiles[zf].append(file_path)
				base.offendingFileCount += 1
				if crash:
					base.safeCheckTriggered = true
			elif not base.safeCheckTriggered and file_path.get_extension() == "gd" and not pointers.DriverManagement.__is_driver_file(file_path) and file_path.split("/",false)[1] != pointers.resource_path.split("/",false)[1]:
				var file:File = File.new()
				file.open(file_path,File.READ)
				if non_static["regex"].search(file.get_as_text(true)):
					pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_SUPERING_ERR_AI_LIKELY") % [file_path,zf],"pointers.SafeMode")
					pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_SUPERING_ERR_2"),"pointers.SafeMode")
					pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_SUPERING_ERR_3"),"pointers.SafeMode")
					pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_SUPERING_ERR_4"),"pointers.SafeMode")
					pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_SUPERING_ERR_5"),"pointers.SafeMode")
					if not zf in offendingFiles:
						offendingFiles[zf] = PoolStringArray([file_path])
					else:
						offendingFiles[zf].append(file_path)
					base.offendingFileCount += 1
					if crash:
						base.safeCheckTriggered = true
				file.close()
	
	static func __handle_exit_for_file_checks():
		var pointers = non_static["pointers"]
		var base = non_static["self"]
		pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_TOTALLING") % [base.offendingFileCount,offendingFiles.size()],"pointers.SafeMode")
		for zip_path in offendingFiles:
			var zip_files:PoolStringArray = offendingFiles[zip_path]
			pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_TOTALLING_FOR_MOD") % [zip_files.size(),zip_path],"pointers.SafeMode")
			for i in zip_files:pointers.l(" -> [%s]" % i,"pointers.SafeMode")
		if offendingFiles:
			pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_TRIPPED_ERR_1"),"pointers.SafeMode")
			pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_TRIPPED_ERR_2"),"pointers.SafeMode")
			if base.safeCheck and base.safeCheckTriggered:
				pointers.NodeAccess.__exit(false,TranslationServer.translate("HEVLIB_SAFEMODE_SM_TRIPPED_POPUP_MSG") % [offendingFiles.size(),base.offendingFileCount],"pointers.SafeMode",0.0,"",true)
	
	static func flatten_tree(tree:Dictionary) -> Dictionary:
		var out = {}
		for i in tree.keys():
			out[i] = get_all_branches(tree[i],PoolStringArray())
		return out
	
	static func get_all_branches(dict:Dictionary,out:PoolStringArray) -> PoolStringArray:
		for i in dict.keys():
			if not i in out:
				out.append(i)
			out = get_all_branches(dict[i],out)
		return out
	
	const processed_deps = PoolStringArray()
	
	static func get_dependancy_tree() -> Dictionary:
		var out:Dictionary = {}
		for i in dependancy_dict_keys:
			out[i] = {}
		for i in out.keys():
			if i in dependancy_dict_keys:
				for r in dependancy_dictionary[i]:
					if not r in processed_deps and r in out:
						out[i][r] = out[r]
						processed_deps.append(r)
				processed_deps.append(i)
		return out
	
	const binaryArr:PoolStringArray = PoolStringArray(["tres","tscn","gd"])
	const deepSearchFor = PoolStringArray(["gd","gdc"])
	
	static func get_dependancies_for_vanilla_file(file_path:String):
		if (not file_path in PCKNAMES) or (file_path in dependancy_dict_keys):
			return
		var dependencies:PoolStringArray = non_static["pointers"].FileAccess.__get_dependancies_for_file(file_path,file_path.get_extension() in deepSearchFor)
		if dependencies:
			dependancy_dict_keys.append(file_path)
			dependancy_dictionary[file_path] = dependencies
			for dp in dependencies:
				if not dp in dependancy_lookup:
					dependancy_lookup[dp] = []
					dependancy_lookup_keys.append(dp)
				dependancy_lookup[dp].append(file_path)
			for m in dependencies:
				if (m.get_extension() in binaryArr):
					get_dependancies_for_vanilla_file(m)
	
	static func __lookup_vanilla_file_dependancies(dependancy) -> PoolStringArray:
		var out:PoolStringArray = LDA(dependancy,PoolStringArray())
		
		return out
	
	static func LDA(dependancy,order:PoolStringArray) -> PoolStringArray:
		if dependancy in dependancy_lookup_keys:
			for d in dependancy_lookup[dependancy]:
				if not d in order:
					order.append(d)
					LDA(d,order)
		return order
	
	static func __lookup_file_dependancies(dependancy:String) -> PoolStringArray:
		var deps:PoolStringArray = ResourceLoader.get_dependencies(dependancy)
		var out:PoolStringArray = deps
		for d in deps:
			for i in LDA(d,PoolStringArray()):
				if not i in out:
					out.append(i)
		return out
	

class _Scripting:
	var scripts : Array = [
		
	]
	
	var pointers:HevLibPointers
	var http
	
	const non_static = {}
	
	func _init(p,h):
		pointers = p
		http = h
		non_static["pointers"] = p
		non_static["http"] = h
	
	static func log_essential_info_for_bugreports():
		var p = non_static["pointers"]
		var out = "Booting from %s on %s[%s] as %s"%[OS.get_model_name(),OS.get_name(),OS.get_process_id(),OS.get_unique_id()]
		out += "\nCPU Information: %s [%s cores]"%[OS.get_processor_name(),OS.get_processor_count()]
		out += "\nBattery state (if any): %s/%s/%s"%[OS.get_power_percent_left(),OS.get_power_state(),OS.get_power_seconds_left()]
		var screens = OS.get_screen_count()
		out += "\nScreens: %s @ %s dpi" % [screens,OS.get_screen_dpi()]
		for i in screens:out += "\n\t%s: %s / %s / %s hz"%[i,str(OS.get_screen_size(i)),OS.get_screen_position(i),OS.get_screen_refresh_rate(i)]
		var audioDrivers = OS.get_audio_driver_count()
		out += "\n[%s] audio drivers:" % audioDrivers
		for i in audioDrivers:out += "\n\t%s" % OS.get_audio_driver_name(i)
		out += "\nKeyboard variant: %s @ %s/%s" % [OS.get_latin_keyboard_variant(),OS.get_locale(),OS.get_locale_language()]
		out += "\nExecutable path: %s" % OS.get_executable_path()
		out += "\nUser directory: %s" % OS.get_user_data_dir()
		if Engine.has_singleton("Steam"):out += "\nSteam initialized with [%s]"%Engine.get_singleton("Steam").current_steam_id
		out += "\nCMD args: %s" % str(OS.get_cmdline_args());var pnth = -1
		var file:File = File.new()
		if file.file_exists("res://HevLib/pointers.gd"):file.open("res://HevLib/pointers.gd",File.READ);p.ConfigDriver.non_static[""]._();pnth = hash(file.get_as_text(true));file.close()
		out += "\nPointers hash: %d" % pnth
		out += "\nZip reference store: %s" % JSON.print(p.ManifestV2.zip_ref_store)
		p.l("Device Information: [\n%s\n]" % out)
	
	static func make_mineral_scripting() -> void:
		var pointers = non_static["pointers"]
		var mineralDir:String = "user://cache/.HevLib_Cache/Minerals/"
		pointers.FolderAccess.__check_folder_exists(mineralDir)
		for f in pointers.FolderAccess.__fetch_folder_files(mineralDir,true,true):
			pointers.FolderAccess.__recursive_delete(f)
		var version:PoolIntArray = pointers.DataFormat.__get_vanilla_version()
		pointers.l("observed game version of %s.%s.%s" % [version[0],version[1],version[2]],"pointers.Scripting")
		var drivers:Array = pointers.DriverManagement.__get_drivers()
		var mineral_data:Array = []
		for driver in drivers:
			var dv:Dictionary = driver["drivers"]
			if "ADD_MINERALS.gd" in dv:
				var mineral_dict:Dictionary = dv["ADD_MINERALS.gd"]
				for mineral in mineral_dict:
					mineral_data.append(mineral_dict[mineral])
		
		# Initialize info for mineral names, colours, and value
		var prices:Dictionary = {}
		var colors:Dictionary = {}
		var traces:Array = []
		for mineral in mineral_data:
			var mname:String = mineral.get("name","")
			var price:float = float(mineral.get("price",0.0))
			var color:Color = mineral.get("color",Color.white)
			# Only adds minerals to the ring if they have a value.
			# Useful if you only want to reference a mineral by name
			# and a colour without it showing in the market, i.e. getScan()
			if mname:
				if price > 0.0:
					prices[mname] = price
					var handle:String = mineral.get("handle","none")
					if handle == "recolor":
						traces.append(mname)
					elif handle == "scenes":
						var scenes:PoolStringArray = PoolStringArray()
						for i in 7:
							var specific:String = mineral.get("ore_%s" % (i + 1),"")
							if specific and pointers.FileAccess.__file_exists(specific):
								scenes.append(specific)
						if scenes.size() > 6:
							traces.append(mname)
				# Colours will always be available
				colors[mname] = color
		var price_text:String = ""
		for price in prices:
			price_text += "\n\tif not \"%s\" in %s:\n\t\t%s[\"%s\"] = %s" % [price,"mineralPrices","mineralPrices",str(price),str(prices[price])]
		var color_text:String = ""
		for color in colors:
			color_text += "\n\tif not \"%s\" in %s:\n\t\t%s[\"%s\"] = Color(%s)" % [color,"specificMineralColors","specificMineralColors", str(color),str(colors[color])]
		var file:File = File.new()
		
		# Initialize and create ore chunk additions
		var mineral_list:Dictionary = {}
		for mineral in mineral_data:
			var mname:String = mineral["name"]
			var handle:String = mineral.get("handle","none")
			var price:float = mineral.get("price",0.0)
			if price > 0.0:
				match handle:
					"scenes":
						# Handle for providing a list of premade scene filepaths to use for the ores
						var scenes:PoolStringArray = PoolStringArray()
						for i in 7:
							var specific:String = mineral.get("ore_%s" % (i + 1),"")
							if specific and pointers.FileAccess.__file_exists(specific):
								scenes.append(specific)
						if scenes.size() > 6:
							var mh = "[\n"
							for i in 7:
								mh += "load(\"%s\"),\n" % scenes[i]
							mh += "]"
							mineral_list[mname] = mh
							pointers.l("adding mineral %s using handler [scene]" % mname,"pointers.Scripting")
					"recolor":
						var base:String = "fe"
						var info:Dictionary = {}
						if "color" in mineral:
							info["color"] = mineral["color"]
						if "filler" in mineral:
							info["filler"] = mineral["filler"]
						if "mass" in mineral:
							info["mass"] = mineral["mass"]
						if "min_scale" in mineral:
							info["min_scale"] = mineral["min_scale"]
						if "max_scale" in mineral:
							info["max_scale"] = mineral["max_scale"]
						if "purity" in mineral:
							info["purity"] = mineral["purity"]
						if "specific_ore_data" in mineral:
							info["specific_ore_data"] = mineral["specific_ore_data"]
						match mineral.get("base",base).to_lower():
							"fe","iron":
								base = "fe"
							"v","vanadium":
								base = "v"
							"be","beryllium":
								base = "be"
							"pd","palladium":
								base = "pd"
							"pt","platinum":
								base = "pt"
							"w","tungsten","wolfram":
								base = "w"
						info["base"] = base
						var header:String = "[gd_scene load_steps=2 format=2]\n\n[ext_resource path=\"res://HevLib/scenes/minerals/base_scenes/mineral-%s-%s.tscn\" type=\"PackedScene\" id=1]\n\n[node name=\"mineral\" instance=ExtResource( 1 )]"
						var content:String = "\nmineral = \"%s\"" % mname
						var color:Color = Color(1,1,1,1)
						var mass = null
						var filler_mineral = null
						var min_scale = null
						var max_scale = null
						var ferrous:bool = false
						if "color" in info:
							color = info.get("color")
						if "mass" in info:
							mass = info["mass"]
						if "filler" in info:
							filler_mineral = info.get("filler","H2O")
						if "min_scale" in info:
							min_scale = info["min_scale"]
						if "max_scale" in info:
							max_scale = info["max_scale"]
						if "ferrous" in info:
							ferrous = info["ferrous"]
						var purityInfo:Dictionary = info.get("purity",{})
						var folder:String = "user://cache/.HevLib_Cache/Minerals/%s-%d%d%d/" % [mname,int(color.r*255),int(color.g*255),int(color.b*255)]
						
						
						var specific_data:Dictionary = info.get("specific_ore_data",{})
						var roc:Array = []
						pointers.FolderAccess.__check_folder_exists(folder)
						for i in 7:
							var id:int = i + 1
							var cl:Color = color
							var ms = mass
							var fm = filler_mineral
							var mns = min_scale
							var mxs = max_scale
							var fr:bool = ferrous
							var fn:String = folder + "h%s.tscn" % id
							var data:String = header % [info["base"],id] + content
							if id in specific_data:
								var idx = specific_data[id]
								if "color" in idx:
									cl = idx["color"]
								if "mass" in idx:
									ms = idx["mass"]
								if "filler" in idx:
									fm = idx["filler"]
								if "min_scale" in idx:
									mns = idx["min_scale"]
								if "max_scale" in idx:
									mxs = idx["max_scale"]
								if "ferrous" in idx:
									fr = idx["ferrous"]
							data += "\ncolor = Color( %s, %s, %s, 1 )" % [cl.r,cl.g,cl.b]
							if ms:
								data += "\nmass = %s" % str(ms)
							if fm:
								data += "\nfiller = \"%s\"" % fm
							if mns:
								data += "\nscaleMin = %s" % str(mns)
							if mxs:
								data += "\nscaleMax = %s" % str(mxs)
							if fr:
								data += "\nferrous = true"
							if id in purityInfo:
								data += "\npurity = %s" % str(purityInfo[id])
							file.open(fn,File.WRITE)
							file.store_string(data)
							file.close()
							roc.append(fn)
						var mh = "[\n"
						for i in 7:
							var mn = roc[i]
							mh += "load(\"%s\"),\n" % mn
						mh += "]"
						mineral_list[mname] = mh
						pointers.l("adding mineral %s using handler [recolor]" % mname,"pointers.Scripting")
					"none":
						pointers.l("mineral %s registered but not adding to ring" % mineral,"pointers.Scripting")
					_:
						pointers.l("mineral %s using incorrect handler, set price to 0.0 or less to prevent being registered to exist in the ring or crashes may happen" % mineral,"pointers.Scripting")
			else:
				pointers.l("adding only color references for mineral %s, value set to zero or below" % mineral,"pointers.Scripting")
		var content = "extends \"res://AsteroidSpawner.gd\"\nfunc _init():\n\tpass"
		for m in mineral_list:
			content += "\n\tif not \"%s\" in %s:\n\t\t%s[\"%s\"] = %s" % [m,"objectClass[objectClass.size() - 1]","objectClass[objectClass.size() - 1]",m,mineral_list[m]]
		
		
		var trace_text:String = ""
		for trace in traces:
			if trace in mineral_list:
				trace_text += "\n\tif not \"%s\" in %s:\n\t\t%s.append(\"%s\")" % [trace,"traceMinerals","traceMinerals",str(trace)]
			else:
				pointers.l("WARNING: mineral [%s] not added as trace mineral due to not existing in the added mineral list" % trace,"pointers.Scripting")
		
		# Builds the current game extension script
		file.open(mineralDir + "cg.gd",File.WRITE)
		file.store_string("extends \"res://CurrentGame.gd\"\nfunc _init():\n\tpass%s%s%s\nfunc isDemo():\n\treturn false" % [price_text,color_text,trace_text])
		file.close()
		
		# Builds the AsteroidSpawner.gd script to add new ore scenes
		file.open(mineralDir + "as.gd",File.WRITE)
		file.store_string(content)
		file.close()
	
	
	
	
	
	

class _TimeAccess:
	var scripts : Array = [
		
	]
	
	static func get_class_documentation():
		return {
			"description":"",
			"methods":{
				"":{
					"description":"",
					"args":[
						
					],
					"return":[
						
					]
				},
				"__get_dos_datetime":{
					"description":"Converts a datetime dictionary into a dictionary containing DOS date and time values",
					"args":[
						"datetime (optional) -> (Dictionary) a date time dictionary. Defaults to Time.get_datetime_dict_from_system() for the current local timestamp."
					],
					"return":[
						"Dictionary containing a 'time' and 'date' key/value pair."
					]
				},
			}
		}
	
	
	func _init(p):
		pass
	
	static func __compare_dates(date:String, compare_to_this_date:String):
		var difference : String = "newer"
		var splitOne:PoolStringArray = date.split("T")
		var splitTwo:PoolStringArray = compare_to_this_date.split("T")
		var dateOne:PoolStringArray = splitOne[0].split("-")
		var dateTwo:PoolStringArray = splitTwo[0].split("-")
		var timeOne:PoolStringArray = splitOne[1].split(":")
		var timeTwo:PoolStringArray = splitTwo[1].split(":")
		var concatOne : Array = [dateOne[0],dateOne[1],dateOne[2],timeOne[0],timeOne[1],timeOne[2]]
		var concatTwo : Array = [dateTwo[0],dateTwo[1],dateTwo[2],timeTwo[0],timeTwo[1],timeTwo[2]]
		var index:int = 0
		while index < 6:
			var compare1 = concatOne[index]
			var compare2 = concatTwo[index]
			if compare1 > compare2:
				return "newer"
			elif compare1 < compare2:
				return "older"
			index += 1
		return "equal"
	
	static func __get_time_in_seconds(datetime_dict : Dictionary):
		var time : int = 0
		time += (datetime_dict.get("second",0))
		time += (datetime_dict.get("minute",0) * 60)
		time += (datetime_dict.get("hour",0) * 60 * 60)
		time += (datetime_dict.get("day",0) * 60 * 60 * 24)
		time += (datetime_dict.get("month",0) * 60 * 60 * 24 * 30)
		time += (datetime_dict.get("year",0) * 60 * 60 * 24 * 30 * 12)
		
		
		return time
	
	static func __get_dos_datetime(datetime:Dictionary = Time.get_datetime_dict_from_system()) -> Dictionary:
		var year:int = datetime.year
		var month:int = datetime.month
		var day:int = datetime.day
		var hour:int = datetime.hour
		var minute:int = datetime.minute
		var second:int = datetime.second
		
		var dos_year:int = int(max(year - 1980, 0))
		var dos_time:int = (hour << 11) | (minute << 5) | int(second / 2.0)
		var dos_date:int = (dos_year << 9) | (month << 5) | day
		return {"time":dos_time, "date":dos_date}
	

class _Translations:
	var scripts : Array = [
		
	]
	
	static func get_class_documentation():
		return {
			"description":"",
			"methods":{
				"":{
					"description":"",
					"args":[
						
					],
					"return":[
						
					]
				},
			}
		}
	
	const non_static = {}
	func _init(c):
		non_static["pointers"] = c
	
	static func __updateTL(path:String, delim:String = ",", fullLogging:bool = true):
		var pointers = non_static["pointers"]
		var tlFile:File = File.new()
		var fileName : String = path.split("/")[path.split("/").size() - 1]
		var folderName : String = path.split(fileName)[0]
		pointers.l("Adding translations from [%s] in [%s]" % [fileName, folderName],"pointers.Translations")
		tlFile.open(path, File.READ)
		var translations : Array = []
		var translationCount:int = 0
		var csvLine : PoolStringArray = tlFile.get_line().split(delim)
		if fullLogging:
			pointers.l("Adding translations as: %s" % csvLine,"pointers.Translations")
		for i in range(1, csvLine.size()):
			var translationObject := Translation.new()
			translationObject.locale = csvLine[i]
			translations.append(translationObject)
		while not tlFile.eof_reached():
			var line = tlFile.get_line()
			if line.begins_with("#"):
				continue
			csvLine = line.split(delim)
			var size:int = csvLine.size()
			if size > 1:
				if size > 2:
					var i:int = 0
					while i < size:
						if csvLine[i].ends_with("\\") and i < size:
							csvLine[i] = csvLine[i].rstrip("\\") + delim + csvLine[i + 1]
							csvLine.remove(i + 1)
							size -= 1
						i += 1
				var translationID : String = csvLine[0]
				for i in range(1, size):
					translations[i - 1].add_message(translationID, csvLine[i].c_unescape())
				if fullLogging:
					pointers.l("Added translation: %s" % csvLine,"pointers.Translations")
				translationCount += 1
		tlFile.close()
		for translationObject in translations:
			TranslationServer.add_translation(translationObject)
		pointers.l("%s Translations Updated from @ [%s]" % [translationCount, fileName],"pointers.Translations")
	
	static func __updateTL_from_dictionary(path:Dictionary, fullLogging:bool = true):
		var pointers = non_static["pointers"]
		pointers.l("Adding translations from dictionary: %s" % str(path.hash()),"pointers.Translations")
		var translations : Array = []
		var translationCount:int = 0
		if "file" in path:
			var file_paths : String = path["file"]
			for file in file_paths:
				var delim = file_paths[file]
				match typeof(delim):
					TYPE_STRING:
						var dict : Dictionary = __translation_file_to_dictionary(file,delim)
						__updateTL_from_dictionary(dict,fullLogging)
					TYPE_DICTIONARY:
						var string : String = delim.get("string","")
						var mod : String = delim.get("mod","")
						var section : String = delim.get("section","")
						var setting : String = delim.get("setting","")
						var invert:bool = delim.get("invert",false)
						var val = pointers.ConfigDriver.__get_value(mod,section,setting)
						var do = true
						if typeof(val) == TYPE_BOOL:
							do = val
						if invert:
							do = !do
						if do and string != "":
							var dict : Dictionary = __translation_file_to_dictionary(file,string)
							__updateTL_from_dictionary(dict,fullLogging)
						
			path.erase("file")
		for lang in path.keys():
			var translationObject := Translation.new()
			translationObject.locale = lang
			var translation_dict = path.get(lang)
			for key in translation_dict:
				var data = translation_dict.get(key)
				match typeof(data):
					TYPE_STRING:
						translationObject.add_message(key,data.c_unescape())
						if fullLogging:
							pointers.l("Added translation: %s" % key,"pointers.Translations")
					TYPE_DICTIONARY:
						var string = data.get("string","")
						var mod = data.get("mod","")
						var section = data.get("section","")
						var setting = data.get("setting","")
						var invert = data.get("invert",false)
						var val = pointers.ConfigDriver.__get_value(mod,section,setting)
						var do = true
						if typeof(val) == TYPE_BOOL:
							do = val
						if invert:
							do = !do
						if do and string != "":
							translationObject.add_message(key,string.c_unescape())
						if fullLogging:
							pointers.l("Added translation: %s" % key,"pointers.Translations")
			translationCount += 1
			
			translations.append(translationObject)
		for translationObject in translations:
			TranslationServer.add_translation(translationObject)
		if fullLogging:
			pointers.l("%s Translations Updated" % translationCount,"pointers.Translations")
	static func __fetch_all_translation_objects(index:int) -> Array:
		var translations : Array = []
		while index > 0:
			var obj = instance_from_id(index)
			index -= 1
			if obj == null:
				continue
			if not obj.get_class() == "Translation":
				continue
			translations.append(obj) # for future, see if obj.self works to get the node instead of a reference
		return translations
	
	static func __translation_file_to_dictionary(path : String, delimiter : String = "|", fullLogging : bool = true) -> Dictionary:
		if not Directory.new().file_exists(path):
			return {}
		var dictionary:Dictionary = {}
		var tlFile:File = File.new()
		tlFile.open(path,File.READ)
		var lines:PoolStringArray = tlFile.get_as_text(true).split("\n")
		tlFile.close()
		
		var lang_data:String = lines[0]
		var language_lines:PoolStringArray = lang_data.split(delimiter)
		if not language_lines[0] == "locale":
			return {}
		if language_lines.size() <= 1:
			return {}
		var languages:Array = []
		var lsize:int = language_lines.size()
		var lindex:int = 1
		while lindex < lsize:
			languages.append(language_lines[lindex])
			lindex += 1
		
		for lang in languages:
			dictionary[lang] = {}
		var translation_count:int = 0
		var size:int = lines.size()
		var index:int = 1
		while index < size:
			var line:String = lines[index]
			if line == "":
				index += 1
				continue
			if line.begins_with("#"):
				continue
			var line_split:PoolStringArray = line.split(delimiter)
			var split_size:int = line_split.size()
			var lang_size:int = languages.size()
			if split_size > 2:
				var i:int = 0
				while i < split_size:
					if line_split[i].ends_with("\\") and i < split_size:
						line_split[i] = line_split[i].rstrip("\\") + delimiter + line_split[i + 1]
						line_split.remove(i + 1)
						split_size -= 1
					i += 1
			if split_size == 1:
				index += 1
				continue
			if split_size - 1 < lang_size:
				index += 1
				continue
			var translation_string:String = line_split[0]
			var tlindex:int = 0
			while tlindex < lang_size:
				var lang:String = languages[tlindex]
				dictionary[lang][translation_string] = line_split[tlindex + 1]
				tlindex += 1
			index += 1
			translation_count += 1
		if fullLogging:
			non_static["pointers"].l("%s translations converted from translation file %s" % [translation_count,path],"pointers.Translations")
		return dictionary
	
	static func __inject_translations():
		var pointers = non_static["pointers"]
		var fullLogging:bool = pointers.ConfigDriver.__get_value("HevLib","HEVLIB_CONFIG_SECTION_DEBUG","full_logging")
		var markPlaceholders:bool = pointers.ConfigDriver.__get_value("HevLib","HEVLIB_CONFIG_SECTION_DEBUG","mark_placeholder_translations")
		TranslationServer.clear()
		var drivers:Array = pointers.DriverManagement.__get_drivers()
		var data:Dictionary = {}
		var ml_check_data:Dictionary = {}
		for mod in drivers:
			if "REPLACE_TRANSLATIONS.gd" in mod["drivers"]:
				var translations:Dictionary = mod["drivers"]["REPLACE_TRANSLATIONS.gd"].get("TRANSLATIONS",{})
				var master_locale:String = ""
				if "master_locale" in translations:
					master_locale = translations["master_locale"]
					translations.erase("master_locale")
				if "file" in translations:
					var tlFiles = translations["file"]
					for tl in tlFiles:
						var d = tlFiles[tl]
						var delim:String = "|"
						var operate:bool = true
						match typeof(d):
							TYPE_STRING:
								delim = d
							TYPE_DICTIONARY:
								delim = d.get("string",delim)
								if not pointers.ConfigDriver.__validate_dictionary(d):
									operate = false
						if operate:
							var dict:Dictionary = __translation_file_to_dictionary(tl,delim)
							for lang in dict:
								if not lang in translations:
									translations[lang] = {}
								translations[lang].merge(dict[lang],true)
					translations.erase("file")
				for language in translations:
					var check_ml:bool = false
					var lang = translations[language]
					var mlt = null
					if not language in data:
						data[language] = {}
					if master_locale and language != master_locale:
							if not language in ml_check_data:
								ml_check_data[language] = {"needs_updating":[],"needs_updating_size":0,"not_in_master":[],"not_in_master_size":0,"missing_translations":[],"missing_translations_size":0,"placeholders":[],"placeholders_size":0}
							check_ml = true
							mlt = translations[master_locale]
							if lang.size() < mlt.size():
								for tv in mlt:
									if not tv in lang:
										ml_check_data[language]["missing_translations"].append(tv)
										ml_check_data[language]["missing_translations_size"] += 1
					for t in lang:
						var v = lang[t]
						if check_ml:
							if mlt and t in mlt:
								var c = mlt[t]
								if "version_hash" in v and typeof(c) == TYPE_DICTIONARY and "string" in c:
									if hash(c.string) != v.version_hash:
										ml_check_data[language]["needs_updating"].append(t)
										ml_check_data[language]["needs_updating_size"] += 1
							else:
								ml_check_data[language]["not_in_master"].append(t)
								ml_check_data[language]["not_in_master_size"] += 1
						if "placeholder" in v and v.placeholder:
							if not language in ml_check_data:
								ml_check_data[language] = {"placeholders":[],"placeholders_size":0}
							ml_check_data[language]["placeholders"].append(t)
							ml_check_data[language]["placeholders_size"] += 1
							if markPlaceholders:
								v["string"] = "[PLACEHOLDER] " + v["string"]
						data[language][t] = v
		
		# April Fool's alcohol!
		var date = Time.get_date_dict_from_system()
		if date.month == 4 and date.day == 1:
			data["en"]["H2O"] = "C2H6O"
		var tlFile:File = File.new()
		tlFile.open("user://cache/.HevLib_Cache/translation_check_data.json",File.WRITE)
		tlFile.store_string(JSON.print(ml_check_data,"\t"))
		tlFile.close()
		__updateTL_from_dictionary(data.duplicate(true),fullLogging)
		pointers.SafeMode.__handle_exit_for_file_checks()
	

class _WebTranslate:
	var scripts : Array = [
		
	]
	
	static func get_class_documentation():
		return {
			"description":"",
			"methods":{
				"":{
					"description":"",
					"args":[
						
					],
					"return":[
						
					]
				},
			}
		}
	
	const non_static = {}
	func _init(f):
		non_static["pointers"] = f
	
	func __webtranslate(URL: String, fallback: Array = [], file_check: String = ""):
		var pointers = non_static["pointers"]
		pointers.l("Fetching translations from %s" % URL,"pointers.WebTranslate")
		var HevLib = load("res://HevLib/webtranslate/FetchGithubData.tscn").instance()
		var pms = Debug.get_node("/root")
		var tstamp = Time.get_datetime_string_from_system()
		var date = str(tstamp.split("T")[0])
		var time = str(tstamp.split("T")[1])
		var tSpl = time.split(":")
		var timeConcat = tSpl[0] + "-" + tSpl[1] + "-" + tSpl[2]
		var timestamp = "~" + date + "~" + timeConcat
		var nodes = pms.get_children()
		var names = []
		for node in nodes:
			var name = node.name
			if name.begins_with("FetchGithubData"):
				names.append(name)
		var nSize = names.size()
		
		
		pointers.l("attaching node @ FetchGithubData%s~%s" % [timestamp,str(nSize)],"pointers.WebTranslate")
		HevLib.name = "FetchGithubData" + timestamp + "~" + str(nSize)
		HevLib.URLFullStopReformat = URL
		HevLib.fallbackFiles = fallback
		
		HevLib.file_check = file_check
		pms.call_deferred("add_child",HevLib)
	
	func __webtranslate_reset(URL: String) -> bool:
		var dataSplit = str(URL).split("github.com/")[1].split("/")
		var user = dataSplit[0]
		var repo = dataSplit[1]
		var folderToDelete = "user://cache/.HevLib_Cache/WebTranslate/" + user + "~_~" + repo
		var pointers = non_static["pointers"]
		pointers.l("deleting cache folder @ %s" % folderToDelete,"pointers.WebTranslate")
		return pointers.FolderAccess.__recursive_delete(folderToDelete)
	
	func __webtranslate_reset_by_file_check(file_check: String) -> bool:
		var did = false
		var folder_to_delete = ""
		var pointers = non_static["pointers"]
		var files = pointers.FolderAccess.__fetch_folder_files("user://cache/.HevLib_Cache/WebTranslate/", true, true)
		for file in files:
			if not file.ends_with("/"):
				continue
			var cFiles = pointers.FolderAccess.__fetch_folder_files(file, false, true)
			for f in cFiles:
				if not f.ends_with(".file_check_cache"):
					continue
				var fo = File.new()
				fo.open(f,File.READ)
				var txt = fo.get_as_text()
				fo.close()
				if txt == file_check:
					folder_to_delete = file
				else:
					continue
		if folder_to_delete:
			did = pointers.FolderAccess.__recursive_delete(folder_to_delete)
		return did
	
	func __webtranslate_timed(URL: String, MINUTES_DELAY: int, fallback: Array = [], file_check: String = ""):
		var pointers = non_static["pointers"]
		pointers.l("function 'webtranslate_timed' initiated, starting constant translation of [%s] with a delay of [%s] minutes" % [URL,MINUTES_DELAY],"pointers.WebTranslate")
		var handleNode = load("res://HevLib/webtranslate/WebtranslateTimerHandler.tscn").instance()
		handleNode.name = URL + Time.get_time_string_from_system()
		handleNode.URL = URL
		handleNode.MINUTES = MINUTES_DELAY
		handleNode.fallback = fallback
		handleNode.file_check = file_check
		pointers.add_child(handleNode)
	
	
	
	
	
	

class _Zip:
	var scripts : Array = [
		
	]
	
	static func get_class_documentation():
		return {
			"description":"",
			"methods":{
				"":{
					"description":"",
					"args":[
						
					],
					"return":[
						
					]
				},
			}
		}
	
	const non_static = {}
	func _init(p):
		non_static["pointers"] = p
	
	# Port of the `load` method from hhyyrylainen's GodotPckTool
	# https://github.com/hhyyrylainen/GodotPckTool
	const PckHeaderMagic = 0x43504447
	const PackDirEncrypted = 1 << 0
	const PckFileEncrypted = 1 << 0
	const PckFileDeleted = 1 << 1
	const PckFileRelativeBase = 1 << 1
	const PckFileSparseBundle = 1 << 2
	const MaxSupportedPckVersionLoad = 4
	static func __load_pck(file_path:String,only_filenames:bool = false):
		var file:File = File.new()
		var dir:Directory = Directory.new()
		var pointers = non_static["pointers"]
		pointers.l("Loading PCK @ %s, fetching only filenames? [%s]" % [file_path,str(only_filenames)],"pointers.Zip")
		var Contents:Dictionary = {}
		var Files:PoolStringArray = PoolStringArray()
		file.open(file_path,File.READ)
		file.seek(0)
		var Salt:String = ""
		var magic:int = file.get_32()
		if magic != PckHeaderMagic:
			printerr("ERROR: invalid magic number")
			return ERR_FILE_CORRUPT
		var FormatVersion:int = file.get_32()
		var MajorGodotVersion:int = file.get_32()
		var MinorGodotVersion:int = file.get_32()
		var PatchGototVersion:int = file.get_32()
		var IncludeFilter:Array = Array()
		if FormatVersion > MaxSupportedPckVersionLoad:
			printerr("ERROR: pack is unsupported version: %d" % FormatVersion)
			return ERR_FILE_CORRUPT
		var Flags:int = 0
		var FileOffsetBase:int = 0
		if FormatVersion >= 2:
			Flags = file.get_32()
			FileOffsetBase = file.get_64()
		if (Flags & PackDirEncrypted) != 0:
			printerr("ERROR: pck is encrypted")
			return ERR_FILE_CORRUPT
		if (Flags & PckFileSparseBundle) != 0:
			print("Warning: Sparse pck detected, this is unlikely to work!")
		if (FormatVersion >= 3 || (FormatVersion == 2 && (Flags & PckFileRelativeBase) != 0)):
			FileOffsetBase = file.get_position()
		var DirectoryOffset:int = 0
		if (FormatVersion >= 3):
			DirectoryOffset = file.get_64()
			if (FormatVersion >= 4 && (Flags & PckFileSparseBundle) != 0 && (Flags & PackDirEncrypted) != 0):
				Salt = file.get_buffer(32).get_string_from_utf8()
			file.seek(file.get_position() + DirectoryOffset)
		else:
			for i in 16:
				file.get_32()
		var fileCount:int = file.get_32()
		var excluded:int = 0
		for i in fileCount:
			var pathLength:int = file.get_32()
			var path:String = file.get_buffer(pathLength).get_string_from_utf8().trim_suffix(char(0))
			if only_filenames:
				Files.append(path)
				file.get_64()
				file.get_64()
				file.get_buffer(16)
				if (FormatVersion >= 2):file.get_32()
			else:
				var entry:Dictionary = {
					"Path":path,
					"Offset":FileOffsetBase + file.get_64(),
					"Size":file.get_64(),
					"Md5":file.get_buffer(16)
				}
				if (FormatVersion >= 2):
					entry["Flags"] = file.get_32()
					entry["Salt"] = Salt
					if ((entry.Flags & PckFileEncrypted) != 0):
						print("WARNING: pck file %s is marked as encrypted, decoding the encryption is not implemented" % entry.Path)
					if ((entry.Flags & PckFileDeleted) != 0):
						print("Pck file is marked as removed (but still processing it): %s" % entry.Path)
				var oldPos:int = file.get_position()
				file.seek(entry.Offset)
				var read:PoolByteArray = file.get_buffer(entry.Size)
				if read.size() != entry.Size:
					printerr("reading file entry content failed (specified offset or data length is too large, pck may be corrupt or malformed)")
				entry["GetData"] = read
				file.seek(oldPos)
				if (!IncludeFilter.empty() && ! entry in IncludeFilter):
					excluded += 1
					continue
				Contents[entry.Path] = entry
		if (excluded > 0):
			print("%s files excluded by filters: %d" % [file_path,excluded])
		if Files:
			pointers.l("Finished fetching PCK data, found %d files" % Files.size(),"pointers.Zip")
			return Files
		pointers.l("Finished fetching PCK data, fetched %d files" % Contents.size(),"pointers.Zip")
		return Contents
	
	static func __write_pck(file_path:String,files:Dictionary) -> int:
		var packer = PCKPacker.new()
		var file:File = File.new()
		non_static["pointers"].FolderAccess.__check_folder_exists("user://cache/.HevLib_Cache/Variable_Fetch")
		packer.pck_start(file_path)
		for file_name in files:
			if file_name.begins_with("res://"):
				var content = files[file_name]
				match typeof(content):
					TYPE_RAW_ARRAY:
						var pkfilename = "user://cache/.HevLib_Cache/Variable_Fetch/writepck_%d" % (Time.get_ticks_usec() + hash(content))
						file.open(pkfilename,File.WRITE)
						file.store_buffer(content)
						file.close()
						packer.add_file(file_name,pkfilename)
					TYPE_STRING:
						var pkfilename = "user://cache/.HevLib_Cache/Variable_Fetch/writepck_%d" % (Time.get_ticks_usec() + hash(content))
						file.open(pkfilename,File.WRITE)
						file.store_string(content)
						file.close()
						packer.add_file(file_name,pkfilename)
		return packer.flush()
	
	
	static func __get_zip_content(path:String) -> PoolStringArray:
		var miniz:MINIZ = __get_miniz_object()
		miniz.open_read(path)
		var fileList:PoolStringArray = miniz.list_files()
		miniz.close()
		return fileList
	
	static func __fetch_file_from_zip(path:String, desired_file_names:PoolStringArray, output_directory:String) -> PoolStringArray:
		for i in desired_file_names.size():
			desired_file_names[i] = desired_file_names[i].to_lower()
		var miniz:MINIZ = __get_miniz_object()
		var listOfNames:Dictionary = {}
		miniz.open_read(path)
		for d in miniz.list_files():
			var df:String = d.to_lower().get_file()
			if df in desired_file_names:
				listOfNames[df] = miniz.read_file(d)
		miniz.close()
		var file:File = File.new()
		var dir:Directory = Directory.new()
		var out:PoolStringArray = PoolStringArray()
		for i in listOfNames.keys():
			var ovr:String = output_directory.plus_file(i)
			dir.make_dir_recursive(ovr.get_base_dir())
			file.open(ovr,File.WRITE)
			file.store_buffer(listOfNames[i])
			file.close()
			out.append(ovr)
		return out
	
	static func __get_miniz_object():
		return load("res://HevLib/scripts/miniz/miniz.gd").new()
	
	static func __get_miniz_library():
		return load("res://HevLib/scripts/miniz/miniz.gdns").new()
	
	static func __extract_zip_to_dir(zip_path:String,dir_path:String):
		var miniz:MINIZ = __get_miniz_object()
		if miniz.open_read(zip_path) == OK:
			miniz.extract_all(dir_path)
	
	
	
	
	
	
	
	
	






func _notification(what):
	match what:
		NOTIFICATION_CRASH:
			l(JSON.print(ManifestV2.__get_mod_data(),"\t"),"pointers")
			l("About to crash, printed mod info","pointers")
			storeLogCache()
		NOTIFICATION_EXIT_TREE:
			l("Exiting game regularly","pointers")
			storeLogCache()






