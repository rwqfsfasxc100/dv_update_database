# This translation file is generated automatically
# Do not modify anything directly, as this will cause the file to break for translators
# Please use Translation Tracker to modify these yourself, and contact the mod author to implement them
# https://github.com/rwqfsfasxc100/TranslationTracker/releases/latest

# [license]
# 3-Clause BSD NON-AI License
# 
# Copyright 2026 __hev (Benjamin Buckhurst)
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

const TRANSLATIONS = {
	"master_locale": "en",
	"en": {
		"HEVLIB_MOD_BRIEF": {
			"string": "Library mod containing several common functions created by __hev",
			"version_hash": 504726156,
			"placeholder": false
		},
		"HEVLIB_MOD_DESCRIPTION": {
			"string": "A library providing several functional parts:\\n\\n * Common functionality provided through 'pointer' files.\\n * Handling of mod manifest files via versioning to create a unified medium to fetch information from them.\\n * EquipmentDriver - Add & manage equipment items, slots, and more...\\n * WeaponSlotDriver - Add and modify equipment added to ship hardpoints.\\n\\nThis library also aims to keep a consistent method to make modding easier. Compatability with mods is also a primary focus of the functionality provided.\\n\\nFor more information, please check this mod's wiki. If you have any suggestons or ideas, please leave them in the Discord or a GitHub issue.",
			"version_hash": 1185923833
		},
		"HEVLIB_MOD_ERROR_HEADER": {
			"string": "%s MOD ISSUES",
			"version_hash": 3377428377
		},
		"HEVLIB_MOD_ERROR_DEPENDANCY_DIALOGUE_BOX": {
			"string": "There are currently %s unmet mod dependancies. Please satisfy these requirements or remove the mods that need them: %s",
			"version_hash": 368204025
		},
		"HEVLIB_GENERIC_ERROR_DIALOGUE_BOX": {
			"string": "Something has gone wrong. Please restart the game!",
			"version_hash": 605763982
		},
		"EVENTDRIVER_MENU": {
			"string": "EventDriver Debug Menu",
			"version_hash": 451113391
		},
		"EVENTDRIVER_EVENTS": {
			"string": "Selected Event",
			"version_hash": 3337649328
		},
		"EVENTDRIVER_TIMER": {
			"string": "Storyteller Event Timer",
			"version_hash": 3794017585
		},
		"EVENTDRIVER_SPAWNNOW": {
			"string": "Force event spawn using selected event",
			"version_hash": 2944227280
		},
		"EVENTDRIVER_EVENT_SELECTOR": {
			"string": "Event Selector",
			"version_hash": 2551222664
		},
		"EVENTDRIVER_CLEAREVENT": {
			"string": "Clear selected event(s)",
			"version_hash": 579909883
		},
		"HEVLIB_MISSING_DOCUMENTATION_1": {
			"string": "!!!!! No documentation for this feature was provided!",
			"version_hash": 3595625429
		},
		"HEVLIB_MISSING_DOCUMENTATION_2": {
			"string": "!!!!! Please bring this to my (__hev) attention ASAP, as documentation is key for libraries such as this one for proper maintenance!",
			"version_hash": 3771196171
		},
		"HEVLIB_DESCRIPTION_PLACEHOLDER": {
			"string": "This mod does not have a description. \\n\\nPlease check the webpage or thread where you obtained this mod for info, or ask the creator for a description.",
			"version_hash": 3310358705
		},
		"HEVLIB_SELF_CHECK_ERROR_MESSAGE": {
			"string": "HevLib was not installed correctly. Please double check the download source, and make sure that the root folder looks as follows: HevLib.zip/HevLib/\\n\\nPressing OK will exit the game and open the latest release page in your browser.",
			"version_hash": 3685656617
		},
		"HEVLIB_SELF_CHECK_ERROR_HEADER": {
			"string": "HEVLIB LOAD ERROR!",
			"version_hash": 1761231146
		},
		"HEVLIB_INCORRECT_SHIP": {
			"string": "(ERROR!) Missing ship type: '%s'\\nThis save cannot be opened as the active ship isn't available!\\nTo load this save, please reinstall the mod containing the ship type!",
			"version_hash": 3862475614
		},
		"HEVLIB_SLOT": {
			"string": "Slot",
			"version_hash": 2089577767
		},
		"HEVLIB_MOD_MENU": {
			"string": "Mod Menu",
			"version_hash": 3618868698
		},
		"HEVLIB_MISSING_MOD_NAME": {
			"string": "Mod Name Unavailable :(",
			"version_hash": 132557580
		},
		"HEVLIB_MISSING_DESCRIPTION": {
			"string": "This mod does not have a description :( \\n\\nPlease check the webpage or thread where you obtained this mod for info, or ask the creator for a description.",
			"version_hash": 3469973573
		},
		"HEVLIB_AUTHOR": {
			"string": "Author:",
			"version_hash": 2829231346
		},
		"HEVLIB_CREDITS": {
			"string": "Credits:",
			"version_hash": 2336438541
		},
		"HEVLIB_UNKNOWN": {
			"string": "Unknown",
			"version_hash": 2604381749
		},
		"HEVLIB_MM_TOOLTIP_HEADER": {
			"string": "Mod Information:",
			"version_hash": 2393777861
		},
		"HEVLIB_MM_TOOLTIP_ID": {
			"string": "Mod ID: %s",
			"version_hash": 2265364772
		},
		"HEVLIB_MM_TOOLTIP_MV": {
			"string": "Manifest Version: %s",
			"version_hash": 2561429428
		},
		"HEVLIB_MM_TOOLTIP_ZIP": {
			"string": "Zip File: %s",
			"version_hash": 3308902826
		},
		"HEVLIB_MM_TOOLTIP_LIBRARY": {
			"string": "Library: %s \\ Always Display: %s",
			"version_hash": 1617363745
		},
		"HEVLIB_MM_BUTTON_TOOLTIP_GITHUB": {
			"string": "Mod Github Page",
			"version_hash": 60488389
		},
		"HEVLIB_MM_BUTTON_TOOLTIP_DISCORD": {
			"string": "Mod Discord Thread",
			"version_hash": 87679173
		},
		"HEVLIB_MM_BUTTON_TOOLTIP_NEXUS": {
			"string": "Nexus mods page",
			"version_hash": 3775372648
		},
		"HEVLIB_MM_BUTTON_TOOLTIP_DONATIONS": {
			"string": "Donate to the project",
			"version_hash": 362649787
		},
		"HEVLIB_MM_BUTTON_TOOLTIP_WIKI": {
			"string": "Mod wiki page",
			"version_hash": 1350544086
		},
		"HEVLIB_MM_BUTTON_TOOLTIP_BUGREPORTS": {
			"string": "Report a bug",
			"version_hash": 1392941888
		},
		"HEVLIB_MM_BUTTON_TOOLTIP_CUSTOM": {
			"string": "More...",
			"version_hash": 909612738
		},
		"HEVLIB_VANILLA_DESCRIPTION": {
			"string": "A physics-based mining sim, set in the thickest debris field in Sol. Every action has a reaction, lasers are invisible without a medium, and your thrust is a potent weapon. Find trade, adapt your equipment to your playstyle, hire a crew to help. Unravel the mysteries of the rings, or just get rich.",
			"version_hash": 3302886100
		},
		"HEVLIB_VANILLA_BRIEF": {
			"string": "The vanilla game",
			"version_hash": 108259687
		},
		"HEVLIB_MODMENU_MODS": {
			"string": "Mods",
			"version_hash": 2089365048
		},
		"HEVLIB_MODMENU_OK": {
			"string": "Ok",
			"version_hash": 5862623
		},
		"HEVLIB_MODMENU_CLOSE": {
			"string": "Close",
			"version_hash": 217614907
		},
		"HEVLIB_MODMENU_OPENFOLDER": {
			"string": "Open Mods Folder",
			"version_hash": 1431776550
		},
		"HEVLIB_MODMENU_MODS_VISIBLE": {
			"string": "Showing %d mods",
			"version_hash": 2827411840
		},
		"HEVLIB_DROP_FILES_TO_ADD_MODS": {
			"string": "Drag and drop files into this window to add mods.\\nIdentical mod file names will be overwritten",
			"version_hash": 1054825256
		},
		"HEVLIB_MODMENU_VER_AND_PRIO": {
			"string": "Version: v%s / Priority: %s",
			"version_hash": 2055836630
		},
		"HEVLIB_MODMENU_PRIO": {
			"string": "Priority: %s",
			"version_hash": 293290073
		},
		"HEVLIB_MODMENU_VERSION": {
			"string": "Version: v%s",
			"version_hash": 3570940819
		},
		"HEVLIB_MODMENU_PRIO_MID_HEADER": {
			"string": "Mod ID and Priority",
			"version_hash": 3551428199
		},
		"HEVLIB_GITHUB": {
			"string": "GitHub",
			"version_hash": 3039441928
		},
		"HEVLIB_DISCORD": {
			"string": "Discord",
			"version_hash": 1937677677
		},
		"HEVLIB_NEXUS": {
			"string": "Nexusmods",
			"version_hash": 3566644875
		},
		"HEVLIB_DONATIONS": {
			"string": "Make a Donation",
			"version_hash": 2458561600
		},
		"HEVLIB_WIKI": {
			"string": "Wiki",
			"version_hash": 2089718105
		},
		"HEVLIB_BUGREPORTS": {
			"string": "Report a bug",
			"version_hash": 1392941888
		},
		"HEVLIB_GITHUB_TOOLTIP": {
			"string": "GitHub repository for the project",
			"version_hash": 1410097863
		},
		"HEVLIB_DISCORD_TOOLTIP": {
			"string": "Discord thread/channel/server for the project",
			"version_hash": 281037778
		},
		"HEVLIB_NEXUS_TOOLTIP": {
			"string": "Nexusmods page for the project",
			"version_hash": 2831875367
		},
		"HEVLIB_DONATIONS_TOOLTIP": {
			"string": "Donate to the project",
			"version_hash": 362649787
		},
		"HEVLIB_WIKI_TOOLTIP": {
			"string": "Wiki page(s) for the project",
			"version_hash": 1482974745
		},
		"HEVLIB_BUGREPORTS_TOOLTIP": {
			"string": "Report a bug via the project's reports link",
			"version_hash": 4054124463
		},
		"HEVLIB_FILTER_BY_TAGS": {
			"string": "Filter mods by tags",
			"version_hash": 464171496
		},
		"HEVLIB_SETTINGS_BUTTON_TOOLTIP": {
			"string": "Open the configuration menu",
			"version_hash": 4289380645
		},
		"HEVLIB_LINKS_BUTTON": {
			"string": "Links",
			"version_hash": 228179046
		},
		"HEVLIB_BUGREPORTS_BUTTON": {
			"string": "Bug reports",
			"version_hash": 3349318290
		},
		"HEVLIB_LINKS_TOOLTIP": {
			"string": "Display the project's links",
			"version_hash": 466114574
		},
		"TAG_ALLOW_ACHIEVEMENTS": {
			"string": "Allows achievements",
			"version_hash": 1786747123
		},
		"TAG_QOL": {
			"string": "Quality of life",
			"version_hash": 2157051683
		},
		"TAG_VISUAL": {
			"string": "Visual",
			"version_hash": 3626485241
		},
		"TAG_FUN": {
			"string": "Fun",
			"version_hash": 193457198
		},
		"TAG_UI": {
			"string": "User interface (UI)",
			"version_hash": 1251064324
		},
		"TAG_ADDS_SHIPS": {
			"string": "Adds new ships",
			"version_hash": 10555442
		},
		"TAG_ADDS_EQUIPMENT": {
			"string": "Adds new equipment",
			"version_hash": 153230275
		},
		"TAG_ADDS_GAMEPLAY_MECHANICS": {
			"string": "Adds new gameplay mechanics",
			"version_hash": 1112044006
		},
		"TAG_ADDS_EVENTS": {
			"string": "Adds new ring events",
			"version_hash": 1474324656
		},
		"TAG_HANDLE_EXTRA_CREW": {
			"string": "Handles extra crew",
			"version_hash": 1697697785
		},
		"HEVLIB_TAG_FILTER": {
			"string": "Filter mods by tag",
			"version_hash": 1706022613
		},
		"HEVLIB_VANILLA_STEAM_STORE": {
			"string": "Steam",
			"version_hash": 236865663
		},
		"HEVLIB_VANILLA_STEAM_STORE_TOOLTIP": {
			"string": "Opens the Steam page for the game",
			"version_hash": 3542265316
		},
		"HEVLIB_VANILLA_ITCH_STORE": {
			"string": "itch.io",
			"version_hash": 2888975475
		},
		"HEVLIB_VANILLA_ITCH_STORE_TOOLTIP": {
			"string": "Opens the itch.io page for the game",
			"version_hash": 2978883672
		},
		"HEVLIB_VANILLA_EPIC_STORE": {
			"string": "Epic Games",
			"version_hash": 1050618451
		},
		"HEVLIB_VANILLA_EPIC_STORE_TOOLTIP": {
			"string": "Opens the Epic Games page for the game",
			"version_hash": 2631198840
		},
		"HEVLIB_VANILLA_GOG_STORE": {
			"string": "GOG",
			"version_hash": 193456994
		},
		"HEVLIB_VANILLA_GOG_STORE_TOOLTIP": {
			"string": "Opens the GOG page for the game",
			"version_hash": 3604779527
		},
		"HEVLIB_CONFIG_SORT_BY_PRICE": {
			"string": "Sort equipment by price",
			"version_hash": 3049697875
		},
		"HEVLIB_CONFIG_SORT_BY_PRICE_TOOLTIP": {
			"string": "Forces equipment to be sorted by price. Will break AUX unit sorting by type, but\nprevents issues with modded equipment.",
			"version_hash": 825779431
		},
		"HEVLIB_CONFIG_SORT_SLOT_BY_TYPE": {
			"string": "Sort slots by type",
			"version_hash": 2003290207
		},
		"HEVLIB_CONFIG_SORT_SLOT_BY_TYPE_TOOLTIP": {
			"string": "Sorts slots by similarity. Prevents arbritrary sorting by modded slots.",
			"version_hash": 820864655
		},
		"HEVLIB_CONFIG_USE_LEGACY_EQUIPMENT_HANDLING": {
			"string": "Use legacy equipment handling",
			"version_hash": 1321146980
		},
		"HEVLIB_CONFIG_USE_LEGACY_EQUIPMENT_HANDLING_TOOLTIP": {
			"string": "Enables pre-1.7 equipment handling. Only use for old mods that don't work with the newer system. Don't expect this to work for most mods.",
			"version_hash": 1725865707
		},
		"HEVLIB_CONFIG_WRITE_EVENTS": {
			"string": "Write event names",
			"version_hash": 924663846
		},
		"HEVLIB_CONFIG_WRITE_EVENTS_TOOLTIP": {
			"string": "Writes events to a cache file located at 'user://cache/.HevLib_Cache/current_events.txt'\n\nThis contains all events loaded by the game at the time the rings are loaded.",
			"version_hash": 2763919336
		},
		"HEVLIB_CONFIG_SHOW_HIDDEN_LIBRARIES": {
			"string": "Show hidden libraries",
			"version_hash": 342727087
		},
		"HEVLIB_CONFIG_SHOW_HIDDEN_LIBRARIES_TOOLTIP": {
			"string": "Makes any library without the always display tag visible.",
			"version_hash": 3751304199
		},
		"HEVLIB_CONFIG_INPUT_DEBUGGER": {
			"string": "Input debugger",
			"version_hash": 1682321818
		},
		"HEVLIB_CONFIG_INPUT_DEBUGGER_TOOLTIP": {
			"string": "Displays debug information about current inputs.",
			"version_hash": 688163626
		},
		"HEVLIB_CONFIG_EVENT_DEBUGGER": {
			"string": "Event debugger",
			"version_hash": 843030316
		},
		"HEVLIB_CONFIG_EVENT_DEBUGGER_TOOLTIP": {
			"string": "Exposes key events and displays if they're active or inactive.",
			"version_hash": 297150667
		},
		"HEVLIB_CONFIG_POSITION_DATA_DEBUGGER": {
			"string": "Position data debugger",
			"version_hash": 710020793
		},
		"HEVLIB_CONFIG_POSITION_DATA_DEBUGGER_TOOLTIP": {
			"string": "Displays the current chaos and an estimated number of event possibilities while on a dive.",
			"version_hash": 3508993106
		},
		"HEVLIB_CONFIG_SHOW_ACCURATE_EVENTS": {
			"string": "Show accurate events",
			"version_hash": 179893315
		},
		"HEVLIB_CONFIG_SHOW_ACCURATE_EVENTS_TOOLTIP": {
			"string": "Used in conjunction with Position data debugger. Displays an actual count of events in the area.\nDue to the way this setting works, it will decrease performance by a significant enough amount,\nand will generate thousands of logs per minute.\n\nUSE OF THIS SETTING IS COMPLETELY UNSUPPORTED AND WILL INVALIDATE ALL BUG REPORTS!\nYOU HAVE BEEN WARNED!",
			"version_hash": 1287925013
		},
		"HEVLIB_CONFIG_OPEN_DEBUG_EVENT_MENU": {
			"string": "Debug event menu",
			"version_hash": 1572595843
		},
		"HEVLIB_CONFIG_OPEN_DEBUG_EVENT_MENU_TOOLTIP": {
			"string": "Keys used to open the event debugger menu.",
			"version_hash": 1644117010
		},
		"HEVLIB_CONFIG_OPEN_DEBUGGER": {
			"string": "Toggle debug display",
			"version_hash": 3629985732
		},
		"HEVLIB_CONFIG_OPEN_DEBUGGER_TOOLTIP": {
			"string": "Toggles visibility of the --debug-console display without the need for the command line.",
			"version_hash": 2762277725
		},
		"HEVLIB_CONFIG_TOGGLE_DEBUG_MENUS": {
			"string": "HevLib debugger menus",
			"version_hash": 2934186220
		},
		"HEVLIB_CONFIG_TOGGLE_DEBUG_MENUS_TOOLTIP": {
			"string": "Toggles visibility of the input debugger and event debugger if they are enabled",
			"version_hash": 392008755
		},
		"HEVLIB_CONFIG_LINEEDIT_PLACEHOLDER": {
			"string": "Insert text",
			"version_hash": 2446160991
		},
		"HEVLIB_CONFIG_SECTION_EQUIPMENT": {
			"string": "Equipment",
			"version_hash": 3425279869
		},
		"HEVLIB_CONFIG_SECTION_EVENTS": {
			"string": "Events",
			"version_hash": 2976090426
		},
		"HEVLIB_CONFIG_SECTION_DRIVERS": {
			"string": "Drivers",
			"version_hash": 2278708932
		},
		"HEVLIB_CONFIG_SECTION_DEBUG": {
			"string": "Debug",
			"version_hash": 218535180
		},
		"HEVLIB_CONFIG_SECTION_INPUT": {
			"string": "Binds",
			"version_hash": 216319605
		},
		"HEVLIB_NOTIFICATIONS": {
			"string": "Mod Notifications",
			"version_hash": 2627580863
		},
		"HEVLIB_UPDATE_COUNT": {
			"string": "%s mod(s) are in need of updates!",
			"version_hash": 4074946392
		},
		"HEVLIB_DEPENDANCY_COUNT": {
			"string": "%s mod(s) are missing dependancies!",
			"version_hash": 4185942359
		},
		"HEVLIB_CONFLICT_COUNT": {
			"string": "%s mod(s) are in conflict!",
			"version_hash": 3441683171
		},
		"HEVLIB_UPDATE_INFO_HEADER": {
			"string": "This mod has pending updates!",
			"version_hash": 189982677
		},
		"HEVLIB_DEPENDANCY_INFO_HEADER": {
			"string": "This mod has missing dependancies!",
			"version_hash": 4142743351
		},
		"HEVLIB_CONFLICT_INFO_HEADER": {
			"string": "This mod is currently in conflict!",
			"version_hash": 3275554923
		},
		"HEVLIB_UPDATE_INFO_BODY": {
			"string": "Update this mod from version [%s] to version [%s]?",
			"version_hash": 3420349538
		},
		"HEVLIB_DEPENDANCY_INFO_BODY": {
			"string": "This mod requires the following mods, which are missing:\n\n%s\n\nDo not expect this mod to operate as intended!",
			"version_hash": 1224371477
		},
		"HEVLIB_CONFLICT_INFO_BODY": {
			"string": "This mod is in conflict with other installed mods. Please install a compatable version of the following mods:\n\n%s\n\nDo not expect this mod to operate as intended!",
			"version_hash": 2530687101
		},
		"HEVLIB_CONFIG_RANDOMIZE_MINERALS": {
			"string": "Randomize mineral seed",
			"version_hash": 161105527
		},
		"HEVLIB_CONFIG_RANDOMIZE_MINERALS_TOOLTIP": {
			"string": "Randomizes the mineral seeds upon every game launch. \\n\\nIf false, uses a predetermined array of constants for mineral seeds",
			"version_hash": 2736477669
		},
		"HEVLIB_UPDATE_CENTER": {
			"string": "Mod Update Center",
			"version_hash": 3293317673
		},
		"HEVLIB_UPDATE_CENTER_DESC": {
			"string": "The following mods have updates",
			"version_hash": 1583276900
		},
		"HEVLIB_UPDATE_ALL": {
			"string": "Update all mods",
			"version_hash": 3690503988
		},
		"HEVLIB_IGNORE_ALL": {
			"string": "Ignore all mods",
			"version_hash": 3685319509
		},
		"HEVLIB_IGNORE_UPDATE": {
			"string": "Ignore update",
			"version_hash": 2636390252
		},
		"HEVLIB_UPDATE_MOD": {
			"string": "Update mod",
			"version_hash": 234302216
		},
		"HEVLIB_CONFIRMATION_DIALOGUE_UPDATE_MOD": {
			"string": "Update the selected mod [%s] from version [%s] to version [%s]? \n\nThis may take a while, depending on the size of the mod.",
			"version_hash": 3712115181
		},
		"HEVLIB_CONFIRMATION_DIALOGUE_IGNORE_MOD_UPDATE": {
			"string": "Ignore the update for mod [%s] to version [%s]? \\n\\nThis decision can be reset in the mod menu config.",
			"version_hash": 173309219
		},
		"HEVLIB_CONFIRMATION_DIALOGUE_UPDATE_MODS": {
			"string": "Update all mods displayed in this menu? \\n\\nThis may take a while, depending on the number and size of the mods.",
			"version_hash": 3399667694
		},
		"HEVLIB_CONFIRMATION_DIALOGUE_IGNORE_MODS": {
			"string": "Ignore all mod updates displayed in this menu? \\n\\nThis decision can be reset in the mod menu config.",
			"version_hash": 719742785
		},
		"HEVLIB_ICON_TOOLTIP_CONFLICT": {
			"string": "This mod conflicts with the following mods:%s",
			"version_hash": 100480821
		},
		"HEVLIB_ICON_TOOLTIP_DEPENDANCIES": {
			"string": "This mod is missing the following mod dependancies:%s",
			"version_hash": 1674753562
		},
		"HEVLIB_ICON_TOOLTIP_COMPLEMENTARY": {
			"string": "This mod complements the following mods:%s",
			"version_hash": 420583035
		},
		"HEVLIB_ICON_TOOLTIP_UPDATES": {
			"string": "This mod has an update! \\nVersion [%s] -> Version [%s]",
			"version_hash": 2631682861
		},
		"HEVLIB_MODMENU_UPDATE_NOTIFIER": {
			"string": "There are updates for your mods. \\n\\nDo you want to open the update menu?",
			"version_hash": 3676459949
		},
		"HEVLIB_PLEASE_WAIT": {
			"string": "Please wait...",
			"version_hash": 3842636830
		},
		"HEVLIB_RESTART": {
			"string": "Restart game",
			"version_hash": 448851172
		},
		"HEVLIB_EXIT_INSTEAD": {
			"string": "Exit game instead",
			"version_hash": 2376159649
		},
		"HEVLIB_RESTART_BECAUSE_NEW_MODS": {
			"string": "The game needs to restart to apply changes to mods. \\n\\nAlternatively, you can close the game, or close this window to continue playing to allow you to save.",
			"version_hash": 688430703
		},
		"HEVLIB_WAIT_TO_UPDATE_ALL": {
			"string": "Please wait... \\n\\nDownloading mod %02d of %02d \\n%s [%s] version [%s]",
			"version_hash": 4167406587
		},
		"HEVLIB_TITLE_IGNORE_MOD": {
			"string": "Ignore mod?",
			"version_hash": 1185318888
		},
		"HEVLIB_TITLE_UPDATE_MOD": {
			"string": "Update mod?",
			"version_hash": 3437005895
		},
		"HEVLIB_TITLE_IGNORE_MODS": {
			"string": "Ignore mods?",
			"version_hash": 460819419
		},
		"HEVLIB_TITLE_UPDATE_MODS": {
			"string": "Update mods?",
			"version_hash": 1752046618
		},
		"HEVLIB_DLCLIST_DLC_HEADER": {
			"string": "------- DLC ------",
			"version_hash": 245182049
		},
		"HEVLIB_DLCLIST_MODS_HEADER": {
			"string": "------ MODS ------",
			"version_hash": 1346064212
		},
		"HEVLIB_CONFIG_SHOW_ALWAYS_LIBRARIES_IN_DLCLIST": {
			"string": "Show always displayed libraries in DLC list",
			"version_hash": 2439027097
		},
		"HEVLIB_CONFIG_SHOW_ALWAYS_LIBRARIES_IN_DLCLIST_TOOLTIP": {
			"string": "Allows libraries with the 'always_display' tag (such as HevLib) to appear\nin the DLC list mods section",
			"version_hash": 4096856680
		},
		"HEVLIB_CONFIG_SHOW_ALL_LIBRARIES_IN_DLCLIST": {
			"string": "Show all libraries in DLC list",
			"version_hash": 3753868258
		},
		"HEVLIB_CONFIG_SHOW_ALL_LIBRARIES_IN_DLCLIST_TOOLTIP": {
			"string": "Allows all libraries to appear in the DLC list mods section. This can cause the list\nto get very large with libraries that have a lot of mod main files\nfor sub processes.",
			"version_hash": 691199143
		},
		"HEVLIB_CONFIG_DLCLIST_SORT_ORDER": {
			"string": "DLC list mod sort order",
			"version_hash": 2104835928
		},
		"HEVLIB_CONFIG_DLCLIST_SORT_ORDER_TOOLTIP": {
			"string": "If and how the DLC list mod section should be sorted.",
			"version_hash": 3524220335
		},
		"HEVLIB_RESEARCH": {
			"string": "Research",
			"version_hash": 2602532946
		},
		"HEVLIB_RESEARCH_CURRENT": {
			"string": "Current Research",
			"version_hash": 1810057685
		},
		"HEVLIB_CURRENT_PROJECTS": {
			"string": "Active Research Projects",
			"version_hash": 2308505464
		},
		"HEVLIB_RESEARCH_STATS": {
			"string": "All Project Stats",
			"version_hash": 3481155716
		},
		"HEVLIB_RESEARCH_AVAILABLE": {
			"string": "Available Projects",
			"version_hash": 2078505552
		},
		"HEVLIB_CONFIG_TOGGLE_UI_SCROLL_LEFT": {
			"string": "UI Scroll Left",
			"version_hash": 239484797
		},
		"HEVLIB_CONFIG_TOGGLE_UI_SCROLL_LEFT_TOOLTIP": {
			"string": "Primary left scroll input for horizontal-only scroll menus",
			"version_hash": 2459810666
		},
		"HEVLIB_CONFIG_TOGGLE_UI_SCROLL_RIGHT": {
			"string": "UI Scroll Right",
			"version_hash": 3615291088
		},
		"HEVLIB_CONFIG_TOGGLE_UI_SCROLL_RIGHT_TOOLTIP": {
			"string": "Primary right scroll input for horizontal-only scroll menus",
			"version_hash": 1217894109
		},
		"HEVLIB_CONFIG_TOGGLE_UI_SCROLL_LEFT2": {
			"string": "UI Scroll Left (alt)",
			"version_hash": 2744720591
		},
		"HEVLIB_CONFIG_TOGGLE_UI_SCROLL_LEFT2_TOOLTIP": {
			"string": "Alternate left scroll input for horizontal-only scroll menus",
			"version_hash": 4207006566
		},
		"HEVLIB_CONFIG_TOGGLE_UI_SCROLL_RIGHT2": {
			"string": "UI Scroll Right (alt)",
			"version_hash": 3554592354
		},
		"HEVLIB_CONFIG_TOGGLE_UI_SCROLL_RIGHT2_TOOLTIP": {
			"string": "Alternate right scroll input for horizontal-only scroll menus",
			"version_hash": 3040783961
		},
		"SYSTEM_HEVLIB_INTERNALS_NODE": {
			"string": "Internal System Mod Handle",
			"version_hash": 3379743283
		},
		"NOTIFICATION_NAME_PLACEHOLDER": {
			"string": "{Notification Body Missing}",
			"version_hash": 1693706220
		},
		"NOTIFICATION_TITLE_PLACEHOLDER": {
			"string": "{Notification Name Missing}",
			"version_hash": 3481814879
		},
		"HEVLIB_AVAILABLE_RESEARCH": {
			"string": "Available Research Projects",
			"version_hash": 318053917
		},
		"HEVLIB_RESEARCH_TOTAL_TOOLTIP": {
			"string": "Total progress towards this project",
			"version_hash": 1598981297
		},
		"DLC_ANDROID": {
			"string": "Android face pack",
			"version_hash": 3806021908
		},
		"HEVLIB_CONFIG_LIMIT_NANODRONE_OUTPUT": {
			"string": "Limit nanodrone storage output",
			"version_hash": 3207490862
		},
		"HEVLIB_CONFIG_LIMIT_NANODRONE_OUTPUT_TOOLTIP": {
			"string": "Prevents nanodrones from being used if the consumption rate exceeds that of\nthe installed storage medium. \n\nNote: this likely will never be met with vanilla equipment outside of\nvery specific configurations.",
			"version_hash": 4102208437
		},
		"HEVLIB_CONFIG_DISPLAY_CURRENTLY_PLAYING": {
			"string": "Display current player count",
			"version_hash": 507597972
		},
		"HEVLIB_CONFIG_DISPLAY_CURRENTLY_PLAYING_TOOLTIP": {
			"string": "Whether to display the number of concurrent players on Steam clients.\\nNote that numbers are separate between full game and demo.",
			"version_hash": 4192055013
		},
		"HEVLIB_CLEAR_LEADERBOARDS": {
			"string": "Clear leaderboard stats",
			"version_hash": 1094632464
		},
		"HEVLIB_CLEAR_LEADERBOARDS_TOOLTIP": {
			"string": "Opens a menu that lets you reset individual leaderboard stats.\\n\\nNOTE: Steam releases only",
			"version_hash": 790679608
		},
		"HEVLIB_OPEN_MENU": {
			"string": "Open menu",
			"version_hash": 2736950124
		},
		"STEAMSTAT_best_haul": {
			"string": "Best haul (complete)",
			"version_hash": 1718163207
		},
		"STEAMSTAT_best_ore": {
			"string": "Best haul (ore)",
			"version_hash": 474342196
		},
		"STEAMSTAT_longest_dive": {
			"string": "Longest dive (including astrogation)",
			"version_hash": 2842100834
		},
		"STEAMSTAT_longest_dive_realtime": {
			"string": "Longest dive (pilot time)",
			"version_hash": 2971453009
		},
		"STEAMSTAT_money_per_day": {
			"string": "Average income per day",
			"version_hash": 2616976832
		},
		"STEAMSTAT_time": {
			"string": "Days working in the rings",
			"version_hash": 1752709682
		},
		"STEAMSTAT_total_money": {
			"string": "Wealth",
			"version_hash": 3660220906
		},
		"STEAMSTAT_CLEAR_STAT": {
			"string": "Clear stat",
			"version_hash": 3593190152
		},
		"HEVLIB_CONFIRM": {
			"string": "Confirm Action",
			"version_hash": 2178666097
		},
		"HEVLIB_WIPE_STAT_ARE_YOU_SURE": {
			"string": "Are you sure you want to wipe the stat %s?",
			"version_hash": 698846716
		},
		"HEVLIB_NOSTEAM": {
			"string": "This menu only works on Steam builds.",
			"version_hash": 3802738386
		},
		"HEVLIB_OPT_PROFILES": {
			"string": "Settings Profiles",
			"version_hash": 2144737018
		},
		"HEVLIB_PROFILE_SELECT": {
			"string": "Select Profile",
			"version_hash": 3621498966
		},
		"HEVLIB_ADD_PROFILE": {
			"string": "Add profile",
			"version_hash": 610551423
		},
		"HEVLIB_RENAME_PROFILE": {
			"string": "Rename profile",
			"version_hash": 3715498190
		},
		"HEVLIB_DELETE_PROFILE": {
			"string": "Delete profile",
			"version_hash": 1875438633
		},
		"HEVLIB_PROFILENAME_ADD": {
			"string": "Add profile",
			"version_hash": 610551423
		},
		"HEVLIB_PROFILENAME_RENAME": {
			"string": "Rename profile",
			"version_hash": 3715498190
		},
		"HEVLIB_PROFILE_DELETE": {
			"string": "Delete profile",
			"version_hash": 1875438633
		},
		"HEVLIB_PROFILE_DELETE_ARE_YOU_SURE": {
			"string": "Are you sure you want to delete this profile?",
			"version_hash": 3461730766
		},
		"HEVLIB_CHANGELOGS": {
			"string": "Changelogs",
			"version_hash": 656124416
		},
		"HEVLIB_CHANGELOGS_NEW": {
			"string": "New Changelogs",
			"version_hash": 3365610410
		},
		"HEVLIB_CONFIG_MULTIPLE_MINERALS_PER_CHUNK": {
			"string": "Multiple minerals per chunk",
			"version_hash": 3451211596
		},
		"HEVLIB_CONFIG_MULTIPLE_MINERALS_PER_CHUNK_TOOLTIP": {
			"string": "Adds functionality that permits multiple ores to exist within the same ore chunk. \\n\\nCredit: Za'krin for the original implementation this adapts and improves from.",
			"version_hash": 3231012828
		},
		"HEVLIB_TRANSIT_TIP_1": {
			"string": "Having multiple crew with the same profession can let them work in tandem.",
			"version_hash": 3778788784
		},
		"HEVLIB_TRANSIT_TIP_2": {
			"string": "Unlike the autopilot, your thrusters can still operate by using manual input, without needing your computer or HUD to be online. ",
			"version_hash": 769325838
		},
		"HEVLIB_TRANSIT_TIP_3": {
			"string": "When rescuing a lifepod, an unused cradle arm can let you get a secure hold on it without clogging your cargo bay.",
			"version_hash": 1685575029
		},
		"HEVLIB_TRANSIT_TIP_4": {
			"string": "Broadcasting a claim can bring more attention to the area.",
			"version_hash": 2111589941
		},
		"HEVLIB_TRANSIT_TIP_5": {
			"string": "Your geologist can restrict what your equipment can see. Being more restrictive on the filters can help prevent your ship's systems from being overwhelmed.",
			"version_hash": 46062683
		},
		"HEVLIB_TRANSIT_TIP_6": {
			"string": "If you need more insurance and you aren't getting enough from Jameson's monthly allowance, hit up Search and Rescue vessels in the rings.",
			"version_hash": 2741005409
		},
		"HEVLIB_TRANSIT_TIP_7": {
			"string": "A happy crew will work a little harder, and an unhappy crew will feel less motivated to work.",
			"version_hash": 294913161
		},
		"HEVLIB_TRANSIT_TIP_8": {
			"string": "If selecting an object with the autopilot, microseismic drones will scan the target object, otherwise they will scan whatever is beneath the mouse.",
			"version_hash": 4239360766
		},
		"HEVLIB_TRANSIT_TIP_9": {
			"string": "Habitats will always pay at least a small premium over the market value of a mineral.",
			"version_hash": 1249715321
		},
		"HEVLIB_TRANSIT_TIP_10": {
			"string": "Using too many nanodrones catching worthless ores? Configure your geologist's filters to catch only what you want and save on drones too.",
			"version_hash": 4012124347
		},
		"HEVLIB_TRANSIT_TIP_11": {
			"string": "Having problems with your mods? Submit a report on the site you obtained them from, or join the Discord for realtime support.",
			"version_hash": 3402302455
		},
		"HEVLIB_TRANSIT_TIP_12": {
			"string": "Got a suggestion for a mod? Join the Discord and feel free to ask.",
			"version_hash": 3184450777
		},
		"HEVLIB_TRANSIT_TIP_13": {
			"string": "Want to find more mods? Check out the entire collection at 'https://delta-v.kodera.pl/index.php/Mod_List'",
			"version_hash": 3141819234
		},
		"HEVLIB_TRANSIT_TIP_14": {
			"string": "Keep in mind that anything that can break apart rocks can also damage other ships by some means.",
			"version_hash": 635357464
		},
		"HEVLIB_TRANSIT_TIP_15": {
			"string": "Autonomous systems do work as intended, however you may need to be patient to let them work.",
			"version_hash": 3043623550
		},
		"HEVLIB_TRANSIT_TIP_16": {
			"string": "Enjoying the mods you're using? Consider supporting their authors!",
			"version_hash": 79152977
		},
		"HEVLIB_TRANSIT_TIP_17": {
			"string": "Mods behaving slightly differently after an update? Check any recent changelogs or ask the author.",
			"version_hash": 2422128719
		},
		"MODMENU2_MOD_DESCRIPTION": {
			"string": "An advanced mod menu that allows almost complete control over how you view your mods.\\n\\nFeatures:\\n\\n* Basic mod viewing - will display any mod installed, whether it has modern manifest information or is a basic mod, as well as displaying info for the vanilla game.\\n* Config modifications - allows the user to customise any mods that provide a set of configs in the manifest.\\n* Update checking - any mod that supplies appropriate updater information will have any updates scanned at launch. Updates can be downloaded individually, as a group, or ignored for the version.\\n* Conflict and dependancy checks - any mod that provides mod IDs for mods that are required or don't work with will show a warning on the title screen. NOTE: This only works for mods with manifests.\\n* Tag & search filters - lets you filter the displayed mods by keyword or mod ID, or choose from a set of tags contained with mods to display only mods using a specific set of tags",
			"version_hash": 3441621910
		},
		"MODMENU2_MOD_BRIEF": {
			"string": "An advanced mod menu",
			"version_hash": 175259935
		},
		"MODMENU2_CONFIG_GENERAL": {
			"string": "General",
			"version_hash": 1354717699
		},
		"MODMENU2_CLEAR_IGNORED_UPDATES": {
			"string": "Clear ignored updates",
			"version_hash": 22297130
		},
		"MODMENU2_CLEAR_IGNORED_UPDATES_TOOLTIP": {
			"string": "Clears the list of updates which you chose to ignore",
			"version_hash": 3834391056
		},
		"MODMENU2_CLEAR_IGNORED_UPDATES_BUTTON": {
			"string": "Clear",
			"version_hash": 217603436
		},
		"TAG_OVERHAUL": {
			"string": "Overhaul",
			"version_hash": 3544097003
		},
		"HEVLIB_GITHUB_PROGRESS_WAITING_ON_RESPONSE": {
			"string": "Waiting for response from server.",
			"version_hash": 1988119143
		},
		"HEVLIB_GITHUB_PROGRESS_ZIP_FOUND_AND_REQUESTING": {
			"string": "Response received. Requesting file.",
			"version_hash": 1619856286
		},
		"HEVLIB_GITHUB_PROGRESS_DOWNLOADING": {
			"string": "Downloading file | %06.2f%%\\n\\n%0.2f %s downloaded of %0.2f %s",
			"version_hash": 812004994
		},
		"HEVLIB_GITHUB_PROGRESS_DOWNLOADING_ONLY_BYTES": {
			"string": "Downloading file.\\n\\n%0.2f %s downloaded",
			"version_hash": 2232387281
		},
		"HEVLIB_GITHUB_PROGRESS_DOWNLOADED_FILE": {
			"string": "Download finished.",
			"version_hash": 249088469
		},
		"HEVLIB_SIZE_LABEL_BYTES": {
			"string": "bytes",
			"version_hash": 254850636
		},
		"HEVLIB_SIZE_LABEL_KILOBYTES": {
			"string": "kilobytes",
			"version_hash": 214961083
		},
		"HEVLIB_SIZE_LABEL_MEGABYTES": {
			"string": "megabytes",
			"version_hash": 2738237862
		},
		"HEVLIB_NO_DOWNLOAD_HEADER": {
			"string": "NO PROVIDED LINK!",
			"version_hash": 3291089198
		},
		"HEVLIB_NO_DOWNLOAD_CONTENT": {
			"string": "NOTICE: mod [%s] has no valid download link provided, and has not been downloaded. \\n\\nPlease refer to the source of this mod for any updates, and please inform the mod's author.",
			"version_hash": 2446599643
		},
		"HEVLIB_SAVEOPT_FIX_CORRUPTED_CARGO": {
			"string": "Fix corrupted cargo crash",
			"version_hash": 802028065
		},
		"HEVLIB_SAVEOPT_FIX_CORRUPTED_CARGO_TOOLTIP": {
			"string": "Use this to fix a save if it does not load due to having brought back invalid cargo during the previous dive. \\n\\nTelltale signs of this would be the second to last line of the engine_log.txt file showing: \\n'ERROR: No loader found for resource: res://.' after crashing on return from the rings / loading the save.",
			"version_hash": 885117514
		},
		"HEVLIB_CONFIG_MAX_MODDED_DEALERSHIP_POOLS": {
			"string": "Maximum modded dealership entries",
			"version_hash": 1666179083
		},
		"HEVLIB_CONFIG_MAX_MODDED_DEALERSHIP_POOLS_TOOLTIP": {
			"string": "The maximum number of modded ship pools added to the dealership's used ship list.\n\nThis only handles ships added through ShipDriver, with the number not\nincreasing if there are fewer ships added than this number.",
			"version_hash": 3536264146
		},
		"HEVLIB_SAVEOPT_CLEAR_SOLD_SHIPS": {
			"string": "Clear sold ship cache",
			"version_hash": 4176761126
		},
		"HEVLIB_SAVEOPT_CLEAR_SOLD_SHIPS_TOOLTIP": {
			"string": "Clears any data stored about sold ships. This is used to fix issues with sold modded ships having a persistent ghost ship left in the dealership forever.",
			"version_hash": 713581652
		},
		"HEVLIB_CONFIG_INPUT_VIRTUALIZATION": {
			"string": "Input virtualization (WIP)",
			"version_hash": 1330041627
		},
		"HEVLIB_CONFIG_INPUT_VIRTUALIZATION_TOOLTIP": {
			"string": "Uses a software-based system to handle inputs instead of the game. Permits use of multi-key bind actions.",
			"version_hash": 4158244573
		},
		"HEVLIB_CONFIG_INPUT_VIRTUALIZATION_OVERRIDE_BUILTIN": {
			"string": "Ignore built-in binds",
			"version_hash": 1598156349
		},
		"HEVLIB_CONFIG_INPUT_VIRTUALIZATION_OVERRIDE_BUILTIN_TOOLTIP": {
			"string": "Whether Input Virtualization should not handle engine built-in keybinds, even those not intended to be rebound.",
			"version_hash": 4016249648
		},
		"HEVLIB_OPT_MODPACKS": {
			"string": "Modpacks",
			"version_hash": 3714458839
		},
		"HEVLIB_MODPACKS IMPORT": {
			"string": "Import modpacks",
			"version_hash": 126074482
		},
		"HEVLIB_MODPACKS EXPORT": {
			"string": "Export modpacks",
			"version_hash": 103317849
		},
		"HEVLIB_APPLICABLE_MODS": {
			"string": "Modpack-compatable mods",
			"version_hash": 476877116
		},
		"HEVLIB_SAVE_MODPACK": {
			"string": "Save Modpack",
			"version_hash": 1264474579
		},
		"HEVLIB_OPEN_MODPACK": {
			"string": "Open Modpack",
			"version_hash": 732682486
		},
		"HEVLIB_MODPACK_LIMITATIONS": {
			"string": "Modpacks cannot include mods without a manifest formatted to at least MV2.2, and have both a link to the GitHub repository and manifest URL.",
			"version_hash": 2148121562
		},
		"HEVLIB_MODPACK_TOGGLE": {
			"string": "Include this mod in the exported modpack?",
			"version_hash": 909574562
		},
		"HEVLIB_MODPACK_DOWNLOADING": {
			"string": "Please wait... \\n\\nDownloading mod %02d of %02d \\n%s [%s]\\n\\n(%s mods skipped.)",
			"version_hash": 640450355
		},
		"HEVLIB_CONFIG_CARGO_SCANNER_DISPLAY_LIMIT": {
			"string": "Cargo scanner mineral display limit",
			"version_hash": 3554924120
		},
		"HEVLIB_CONFIG_CARGO_SCANNER_DISPLAY_LIMIT_TOOLTIP": {
			"string": "How many mineral entries are allowed to appear in any raw mineral scanner list.\nThis only includes minerals, and will skip empty space, equipment,\nand unidentified entries.",
			"version_hash": 886148855
		},
		"TAG_ADD_TRANSIT_TIPS": {
			"string": "Adds transit tips",
			"version_hash": 3276505670
		},
		"EVENTDRIVER_ENABLE_ALL": {
			"string": "Enable all events",
			"version_hash": 987521466
		},
		"EVENTDRIVER_DISABLE_ALL": {
			"string": "Disable all events",
			"version_hash": 1138158759
		},
		"HEVLIB_GITHUBMODS_TITLE": {
			"string": "Available mods",
			"version_hash": 2637865945
		},
		"HEVLIB_GITHUBMODS_COUNT": {
			"string": "%d available",
			"version_hash": 913247151
		},
		"HEVLIB_CONFIG_PROCESSED_MINERAL_DISPLAY_LIMIT": {
			"string": "Processed cargo mineral display limit",
			"version_hash": 2547578582
		},
		"HEVLIB_CONFIG_PROCESSED_MINERAL_DISPLAY_LIMIT_TOOLTIP": {
			"string": "How many mineral entries are allowed to appear at any time within the processed ore list.\nThis display cycles through 'pages' once the limit is exceeded so all minerals can be shown.",
			"version_hash": 1369356988
		},
		"HEVLIB_TRANSIT_TIP_18": {
			"string": "Want to see multiple ores in a single mineral chunk or configure other mineral settings? Check the Drivers tab within the HevLib config.",
			"version_hash": 2874849155
		},
		"HEVLIB_TRANSIT_TIP_19": {
			"string": "Want to configure how likely modded ships appear in the dealer? Check the Drivers tab within the HevLib config.",
			"version_hash": 809628308
		},
		"HEVLIB_TRANSIT_TIP_20": {
			"string": "Want to control certain equipment changes like slot sorting or mineral scanner limits? Check the Equipment section within the HevLib config.",
			"version_hash": 186912265
		},
		"HEVLIB_TRANSIT_TIP_21": {
			"string": "Having issues with the handling of a ship? Consider swapping out thrusters or the autopilot, and tune thrust output and autopilot parameters!",
			"version_hash": 841163575
		},
		"HEVLIB_TRANSIT_TIP_22": {
			"string": "Specific equipment may only work out-of-the-box on their intended vessels. If you're having issues with a specific equipment item, maybe try their intended ship?",
			"version_hash": 2483296260
		},
		"HEVLIB_TRANSIT_TIP_23": {
			"string": "You can sort the order of any mods displayed inside the DLC list within Drivers section within HevLib.",
			"version_hash": 1367355062
		},
		"HEVLIB_TRANSIT_TIP_24": {
			"string": "Sick of mining? There are numerous ways to make money through other means.",
			"version_hash": 3573113157
		},
		"HEVLIB_TRANSIT_TIP_25": {
			"string": "Mass driver magazines and nanodrone components are limited by their storage's delivery speed.",
			"version_hash": 2903300490
		},
		"HEVLIB_TRANSIT_TIP_26": {
			"string": "A scroll bar is provided by the Geologist tab to help with long equipment names and/or mineral lists.",
			"version_hash": 1092699375
		},
		"EVENTDRIVER_LEGACY": {
			"string": "Use legacy spawn handler?",
			"version_hash": 2630802733
		},
		"EVENTDRIVER_INJECT": {
			"string": "Inject oddity?",
			"version_hash": 548009294
		},
		"EVENTDRIVER_SPAWNER_CONTROLS": {
			"string": "Spawn event controls",
			"version_hash": 383031684
		},
		"EVENTDRIVER_CLEARER_CONTROLS": {
			"string": "Clear event controls",
			"version_hash": 3681275490
		},
		"EVENTDRIVER_CLEAR_POI": {
			"string": "Clear related POI",
			"version_hash": 3673548405
		},
		"EVENTDRIVER_CLEAR_POI_TOOLTIP": {
			"string": "POI-based events create a location inside the astrogation cache, and will respawn when cleared normally. \n\nThis toggle will remove a POI for the event if it is nearby.",
			"version_hash": 2980544907
		},
		"EVENTDRIVER_CLEAR_CARGO": {
			"string": "Clear in cargo?",
			"version_hash": 3991202254
		},
		"EVENTDRIVER_EVENTS_TOOLTIP": {
			"string": "The desired event to spawn/clear\n\"none\" - spawn random event / clear all events",
			"version_hash": 2910940133
		},
		"EVENTDRIVER_TIMER_TOOLTIP": {
			"string": "The time between event spawns in seconds",
			"version_hash": 1166419779
		},
		"EVENTDRIVER_SPAWNNOW_TOOLTIP": {
			"string": "Spawns the selected event.\nIf \"none\" selected, spawns random event",
			"version_hash": 2314890076
		},
		"EVENTDRIVER_LEGACY_TOOLTIP": {
			"string": "Use a very old system using testSpecificStoryElement to spawn the event",
			"version_hash": 555589987
		},
		"EVENTDRIVER_INJECT_TOOLTIP": {
			"string": "Have the event's objects placed directly into the ring. \nThis bypasses regular event spawning mechanics, and may cause irregularities",
			"version_hash": 324336902
		},
		"EVENTDRIVER_CLEAREVENT_TOOLTIP": {
			"string": "Clears all events of the selected type.\nIf \"none\" selected, clears all events",
			"version_hash": 30519526
		},
		"EVENTDRIVER_CLEAR_CARGO_TOOLTIP": {
			"string": "If selected, also clears all oddities directly spawned by an event that are inside your cargo bay.",
			"version_hash": 917771176
		},
		"HEVLIB_DOWNLOAD_MOD": {
			"string": "Download mod!",
			"version_hash": 570592894
		},
		"MODMENU_MOD_UNAVAILABLE": {
			"string": "This mod is currently unavailable. This could be due to multiple reasons, including but not limited to:\n\n- GitHub has been rate limited (likely too many requests)\n- Internet connectivity problems\n- Mod does not have a proper download setup",
			"version_hash": 3639564067
		},
		"HEVLIB_CONFIG_FULL_LOGGING": {
			"string": "Full logging",
			"version_hash": 2478639519
		},
		"HEVLIB_CONFIG_FULL_LOGGING_TOOLTIP": {
			"string": "Whether any potentially verbose HevLib functions should produce extra logs",
			"version_hash": 3570790396
		},
		"MODMENU_GET_NEW_MODS": {
			"string": "Get new mods from GitHub",
			"version_hash": 2573811993
		},
		"HEVLIB_MM_TOOLTIP_LANGUAGE_ENTRY": {
			"string": "%s: %s",
			"version_hash": 1718567247
		},
		"HEVLIB_SUPPORTED_LANGUAGES": {
			"string": "Supported languages / completion %:",
			"version_hash": 31187306
		},
		"HEVLIB_CONFIG_SECTION_KEYMAPPING": {
			"string": "Keymapping",
			"version_hash": 3052849914
		},
		"HEVLIB_MODMENU_CANNOT_RESTART": {
			"string": "Currently in-rings.\nPlease restart manually.",
			"version_hash": 3242006044
		},
		"HEVLIB_CONFIG_UNRESTRICTED_AMMO_OUTPUT": {
			"string": "Remove ammunition delivery limits",
			"version_hash": 537716554
		},
		"HEVLIB_CONFIG_UNRESTRICTED_AMMO_OUTPUT_TOOLTIP": {
			"string": "Reverts ammunition magazine behaviour to prior to 1.64.14,\nwith no restrictions to how fast ammunition could be delivered\nto equipment.",
			"version_hash": 1708599757
		},
		"HEVLIB_SETTING_REQUIRES_RESTART": {
			"string": "NOTICE: This setting requires a restart after changing it.",
			"version_hash": 1236302953
		},
		"HEVLIB_MODMENU_MODNAME_DISABLED": {
			"string": "(disabled)",
			"version_hash": 3167290830
		},
		"HEVLIB_MODLET_ENABLED": {
			"string": "Enabled?",
			"version_hash": 644251567
		},
		"HEVLIB_MODMENU_MODNAME_ENABLED_NEEDS_RESTART": {
			"string": "(enabled, needs restart)",
			"version_hash": 1899921857
		},
		"HEVLIB_MODMENU_MODNAME_DISABLED_NEEDS_RESTART": {
			"string": "(disabled, needs restart)",
			"version_hash": 2601371502
		},
		"MODMENU2_TRANSIT_TIP_1": {
			"string": "Modpacks can make sharing mods easy! Create or import them within the Mod Menu.",
			"version_hash": 2128454254
		},
		"MODMENU2_TRANSIT_TIP_2": {
			"string": "Want to try some new configs without messing with your current setup? Creat a new config profile to easily swap to your preferred settings.",
			"version_hash": 331405958
		},
		"MODMENU2_TRANSIT_TIP_3": {
			"string": "Want some new mods and don't want to search online? Check the GitHub downloader menu!",
			"version_hash": 2668803293
		},
		"HEVLIB_MODMENU_MODLET_TOGGLE_TOOLTIP": {
			"string": "Toggles whether this modlet is enabled.\n\n(requires game restart)",
			"version_hash": 3820371863
		},
		"HEVLIB_MODMENU_MODLET_TOGGLE_MM2FALLBACK": {
			"string": "Cannot toggle ModMenu2.\n\nZip has to be manually removed or\ntoggled in the config file directly.",
			"version_hash": 915722318
		},
		"MODMENU2_CHANGELOG_SPACING_SIZE": {
			"string": "Changelog spacing size",
			"version_hash": 3748345741
		},
		"MODMENU2_CHANGELOG_SPACING_SIZE_TOOLTIP": {
			"string": "Spaces placed as each indent for a changelog's subsection",
			"version_hash": 1698732061
		},
		"HEVLIB_CONFIG_POINTER_LOGGING_FRAME_INTERVAL": {
			"string": "Pointer logging interval (phys frames)",
			"version_hash": 346203813
		},
		"HEVLIB_CONFIG_POINTER_LOGGING_FRAME_INTERVAL_TOOLTIP": {
			"string": "The number of physics frames between automatic writes to the pointer log\n(i.e. information logged specifically by mods to the cache)\n\nThis is dependant on your current physics framerate.",
			"version_hash": 515481480
		},
		"HEVLIB_CONFIG_EXTEND_DIVIDED_STORAGE_MULTIPLIER": {
			"string": "Extend storage multiplier of divided holds",
			"version_hash": 3830358193
		},
		"HEVLIB_CONFIG_EXTEND_DIVIDED_STORAGE_MULTIPLIER_TOOLTIP": {
			"string": "Whether the processed storage added by equipment using the MODIFY_INTERNALS\ndriver should dynamically adjust based on the number of minerals that can\nbe found in the ring.\n\nIf disabled, defaults to use just Vanilla's 6 ores.",
			"version_hash": 759404083
		},
		"HEVLIB_CONFIG_MAX_DEALERSHIP_MODIFICATION_ROLLS": {
			"string": "Maximum rolls for new ship loadout adjustments",
			"version_hash": 3469313118
		},
		"HEVLIB_CONFIG_MAX_DEALERSHIP_MODIFICATION_ROLLS_TOOLTIP": {
			"string": "The number of times a new ship may have modifications to it's base loadout made.\n\nThe maximum will depend on the number added by other mods with MODIFY_SHIP_BUILDS.gd.",
			"version_hash": 2944029967
		},
		"HEVLIB_CONFIG_DEALERSHIP_MODIFICATION_ROLL_CHANCE_SCALE": {
			"string": "Ship modification chance adjustment",
			"version_hash": 2832891408
		},
		"HEVLIB_CONFIG_DEALERSHIP_MODIFICATION_ROLL_CHANCE_SCALE_TOOLTIP": {
			"string": "Scale for how likely a ship will have modifications to it's config, with\nthe chance being for each modification.",
			"version_hash": 543789100
		},
		"HEVLIB_CREDITS_CONTRIBUTORS_HEADER": {
			"string": "   --- Contributors ---   ",
			"version_hash": 3641455841
		},
		"HEVLIB_CREDITS_CONTRIBUTORS_ZAKRIN": {
			"string": "Za'krin - Mod Main design, original implementation of updateTL, original load order processing from ZKYLoader",
			"version_hash": 710854217
		},
		"HEVLIB_CREDITS_CONTRIBUTORS_SPDX": {
			"string": "spaceDOTexe - Manifest design, UpgradeGroup ship limiting logic",
			"version_hash": 4113957048
		},
		"HEVLIB_CREDITS_CONTRIBUTORS_1WT1": {
			"string": "WT - Configs for SHIP_NODE_MODIFY",
			"version_hash": 4219071341
		},
		"HEVLIB_CREDITS_SUPPORTERS_HEADER": {
			"string": "   --- Supporters ---   ",
			"version_hash": 1704348250
		},
		"HEVLIB_CREDITS_SUPPORTERS_KOFI_GAZI": {
			"string": "GAZI - supporter (ko-fi)",
			"version_hash": 4085861848
		},
		"HEVLIB_CREDITS_SUPPORTERS_KOFI_BAGGERDUDE": {
			"string": "Bagger dude - supporter (ko-fi)",
			"version_hash": 2887391095
		},
		"HEVLIB_CREDITS_SUPPORTERS_KOFI_1WT1": {
			"string": "WT - supporter (ko-fi)",
			"version_hash": 3531547864
		},
		"HEVLIB_DEV_PUSH": {
			"string": "Push mod updates",
			"version_hash": 4122676635
		},
		"HEVLIB_DEV_PUSH_CONFIRM": {
			"string": "Are you sure that you want to push updates for your mods?",
			"version_hash": 3051814466
		},
		"HEVLIB_CONFIG_DEV_ALWAYS_SEND_NEW_MODS": {
			"string": "Send new mod info on Editor builds",
			"version_hash": 3525213644
		},
		"HEVLIB_CONFIG_DEV_ALWAYS_SEND_NEW_MODS_TOOLTIP": {
			"string": "Whether the UpdateDB should receive info on mods it's not aware of on editor builds.\n\nThis option is intended for mod developers. It does nothing on release builds of the game.",
			"version_hash": 113417870
		},
		"HEVLIB_CONFIG_SHOW_RINGMAP_OVERLAY": {
			"string": "Show ring map overlay",
			"version_hash": 2186846390
		},
		"HEVLIB_CONFIG_SHOW_RINGMAP_OVERLAY_TOOLTIP": {
			"string": "Toggles the visibility of the ring map overlay.",
			"version_hash": 1321643511
		},
		"HEVLIB_CONFIG_RINGMAP_HEATMAP": {
			"string": "Convert ring map overlay data to heatmap",
			"version_hash": 2108586739
		},
		"HEVLIB_CONFIG_RINGMAP_HEATMAP_TOOLTIP": {
			"string": "Whether the ring map overlay should use an HSV heatmap instead of\ndisplaying the raw pixel data.\n\nRaw data contains the specific channel/index for the respective\ngetPixelAt() or getTargetDensityAt() method.",
			"version_hash": 3398779976
		},
		"HEVLIB_CONFIG_RINGMAP_HEATMAP_CLAMP": {
			"string": "Stepify ring map overlay colouring",
			"version_hash": 4564075
		},
		"HEVLIB_CONFIG_RINGMAP_HEATMAP_CLAMP_TOOLTIP": {
			"string": "Whether to clamp the output colour of the ring map to steps of 1/20, rounding down.\n\nThis happens specifically to the raw value before visualizing, and is best used for knowing\nwhen specific values have been reached.",
			"version_hash": 3469990629
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_MIN_VALUE": {
			"string": "Minimum ring map value",
			"version_hash": 2811375820
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_MIN_VALUE_TOOLTIP": {
			"string": "The minimum value that must be reached to show the display in full brightness.\n\nAreas that fail this check have the out of bounds opacity multiplied to it's current opacity.",
			"version_hash": 3861393134
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_MAX_VALUE": {
			"string": "Maximum ring map value",
			"version_hash": 414329998
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_MAX_VALUE_TOOLTIP": {
			"string": "The maximum value that must be reached to show the display in full brightness.\n\nAreas that fail this check have the out of bounds opacity multiplied to it's current opacity.",
			"version_hash": 2602012528
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_OPACITY": {
			"string": "Ring map opacity",
			"version_hash": 1582996684
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_OPACITY_TOOLTIP": {
			"string": "Base opacity of the ring map overlay.",
			"version_hash": 4040631661
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_OOB_OPACITY": {
			"string": "Ring map out of bounds opacity",
			"version_hash": 2317746276
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_OOB_OPACITY_TOOLTIP": {
			"string": "Opacity multiplier for any values on the overlay that are outside the set\nminimum and maximum value.",
			"version_hash": 1226795897
		},
		"HEVLIB_CONFIG_RINGMAP_DISPLAY_MODE": {
			"string": "Ring map overlay display mode",
			"version_hash": 2985551792
		},
		"HEVLIB_CONFIG_RINGMAP_DISPLAY_MODE_TOOLTIP": {
			"string": "Which visualizer the ring map is using currently.\n\n* Chaos - displays the ring chaos value. (getPixelAt() red channel)\n* Size bias - displays the ringroid size bias value. (getPixelAt() green channel)\n* Raw density - displays the raw density value. (getPixelAt() blue channel)\n* Class 1 density - displays the density of C1 (largest) ringroids. (getTargetDensityAt() index 0)\n* Class 2 density - displays the density of C2 ringroids. (getTargetDensityAt() index 1)\n* Class 3 density - displays the density of C3 ringroids. (getTargetDensityAt() index 2)\n* Class 4 density - displays the density of C4 ringroids. (getTargetDensityAt() index 3)\n* Class 5 density - displays the density of C6 (smallest) ringroids. (getTargetDensityAt() index 4)\n* Most prevalent ringroid size - displays the most prevalent ringroid size of an area.\n   The brighter the area, the larger the 'roid prevalence.",
			"version_hash": 869282124
		},
		"HEVLIB_CONFIG_RINGMAP_DISPLAY_MODE_CHAOS": {
			"string": "Chaos",
			"version_hash": 217455795
		},
		"HEVLIB_CONFIG_RINGMAP_DISPLAY_MODE_BIAS": {
			"string": "Size bias",
			"version_hash": 986321567
		},
		"HEVLIB_CONFIG_RINGMAP_DISPLAY_MODE_RAWDENSITY": {
			"string": "Raw density",
			"version_hash": 3733987279
		},
		"HEVLIB_CONFIG_RINGMAP_DISPLAY_MODE_DENSITY_C1": {
			"string": "Class 1 density",
			"version_hash": 2812853740
		},
		"HEVLIB_CONFIG_RINGMAP_DISPLAY_MODE_DENSITY_C2": {
			"string": "Class 2 density",
			"version_hash": 472198893
		},
		"HEVLIB_CONFIG_RINGMAP_DISPLAY_MODE_DENSITY_C3": {
			"string": "Class 3 density",
			"version_hash": 2426511342
		},
		"HEVLIB_CONFIG_RINGMAP_DISPLAY_MODE_DENSITY_C4": {
			"string": "Class 4 density",
			"version_hash": 85856495
		},
		"HEVLIB_CONFIG_RINGMAP_DISPLAY_MODE_DENSITY_C5": {
			"string": "Class 5 density",
			"version_hash": 2040168944
		},
		"HEVLIB_CONFIG_RINGMAP_DISPLAY_MODE_DENSITY_MOST_PREVALENT": {
			"string": "Most prevalent ringroid size",
			"version_hash": 609523250
		},
		"HEVLIB_CONFIG_TOGGLE_RINGMAP_OVERLAY": {
			"string": "Toggle ring map overlay",
			"version_hash": 2000092087
		},
		"HEVLIB_CONFIG_TOGGLE_RINGMAP_OVERLAY_TOOLTIP": {
			"string": "Keys used to toggle the ring map overlay.",
			"version_hash": 4280819030
		},
		"HEVLIB_CONFIG_TOGGLE_RINGMAP_OVERLAY_HEATMAP": {
			"string": "Toggle show ring map heatmap",
			"version_hash": 2570144278
		},
		"HEVLIB_CONFIG_TOGGLE_RINGMAP_OVERLAY_HEATMAP_TOOLTIP": {
			"string": "Keys used to toggle whether the ring map uses a heatmap.",
			"version_hash": 3603998316
		},
		"HEVLIB_CONFIG_TOGGLE_RINGMAP_OVERLAY_HEATMAP_CLAMP": {
			"string": "Toggle ring map heatmap value stepping",
			"version_hash": 459047484
		},
		"HEVLIB_CONFIG_TOGGLE_RINGMAP_OVERLAY_HEATMAP_CLAMP_TOOLTIP": {
			"string": "Keys used to toggle whether the ring map heatmap has clamped values.",
			"version_hash": 2375962285
		},
		"HEVLIB_CONFIG_CYCLE_RINGMAP_OVERLAY_MODE": {
			"string": "Cycle ring map overlay mode",
			"version_hash": 3781027242
		},
		"HEVLIB_CONFIG_CYCLE_RINGMAP_OVERLAY_MODE_TOOLTIP": {
			"string": "Keys used to cycle through the ring map overlay modes.\n\nCheck Debug/Ring map overlay display mode for which modes do what.",
			"version_hash": 2873646839
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_MIN_VALUE_UP": {
			"string": "Increase ring map overlay minimum value",
			"version_hash": 2310825944
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_MIN_VALUE_UP_TOOLTIP": {
			"string": "Keys used to increase the minimum value for the ring map overlay.",
			"version_hash": 1532744479
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_MIN_VALUE_DOWN": {
			"string": "Decrease ring map overlay minimum value",
			"version_hash": 380670570
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_MIN_VALUE_DOWN_TOOLTIP": {
			"string": "Keys used to decrease the minimum value for the ring map overlay.",
			"version_hash": 2833586929
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_MAX_VALUE_UP": {
			"string": "Increase ring map overlay maximum value",
			"version_hash": 935367002
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_MAX_VALUE_UP_TOOLTIP": {
			"string": "Keys used to increase the maximum value for the ring map overlay.",
			"version_hash": 781650721
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_MAX_VALUE_DOWN": {
			"string": "Decrease ring map overlay maximum value",
			"version_hash": 3300178924
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_MAX_VALUE_DOWN_TOOLTIP": {
			"string": "Keys used to decrease the maximum value for the ring map overlay.",
			"version_hash": 2082493171
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_OPACITY_UP": {
			"string": "Increase ring map opacity",
			"version_hash": 1968471254
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_OPACITY_UP_TOOLTIP": {
			"string": "Keys used to increase the opacity of the ring map overlay.",
			"version_hash": 1962015821
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_OPACITY_DOWN": {
			"string": "Decrease ring map opacity",
			"version_hash": 3534073832
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_OPACITY_DOWN_TOOLTIP": {
			"string": "Keys used to decrease the opacity of the ring map overlay.",
			"version_hash": 3717483615
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_OOB_OPACITY_UP": {
			"string": "Increase ring map out of bounds opacity",
			"version_hash": 3249678830
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_OOB_OPACITY_UP_TOOLTIP": {
			"string": "Keys used to increase the out of bounds opacity of the ring map overlay.",
			"version_hash": 15580581
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_OOB_OPACITY_DOWN": {
			"string": "Decrease ring map out of bounds opacity",
			"version_hash": 1319523456
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_OOB_OPACITY_DOWN_TOOLTIP": {
			"string": "Keys used to decrease the out of bounds opacity of the ring map overlay.",
			"version_hash": 2858534199
		},
		"HEVLIB_CONFIG_SAFE_MOD_LOADING": {
			"string": "Safe Mod Loading",
			"version_hash": 1714521282
		},
		"HEVLIB_CONFIG_SAFE_MOD_LOADING_TOOLTIP": {
			"string": "Prevents the game from being loaded if a mod performs unsafe operations (such as overriding vanilla files directly.)\n\nRecommended to keep this enabled to prevent issues with vanilla and/or other mods. Note: I will dismiss bug reports that have disabled SafeMode due to the probable cause of the issue being related to it needing this disabled..",
			"version_hash": 2729983956
		},
		"HEVLIB_CREDITS_SUPPORTERS_KOFI_TESSIER": {
			"string": "Tessier-Ashpool S.A. - supporter (ko-fi)",
			"version_hash": 2705946943
		},
		"HEVLIB_CREDITS_SOFTWARE_HEADER": {
			"string": "   --- Software ---   ",
			"version_hash": 2827177182
		},
		"HEVLIB_CREDITS_SOFTWARE_JELLE": {
			"string": "jelle - GDUNZIP implementation",
			"version_hash": 784233189
		},
		"HEVLIB_CREDITS_TRANSLATORS_HEADER": {
			"string": "   --- Translators ---   ",
			"version_hash": 3211741168
		},
		"HEVLIB_CREDITS_TRANSLATORS_1WT1": {
			"string": "WT - Ukranian translations",
			"version_hash": 1851458392
		},
		"HEVLIB_CREDITS_TRANSLATORS_HEDRAUTA": {
			"string": "Hedrauta - German translations",
			"version_hash": 1012571612
		},
		"HEVLIB_CREDITS_TRANSLATORS_NEKO!!": {
			"string": "NeKo!! - Chinese translations",
			"version_hash": 3552644866
		},
		"HEVLIB_CREDITS_TRANSLATORS_TESSIER": {
			"string": "Tessier-Ashpool S.A. - Chinese translations",
			"version_hash": 2709571237
		},
		"HEVLIB_ERRORCHECK_MISSING_TRANSLATIONS": {
			"string": "HevLib's translations could not load. This indicates that a severe issue has occurred, and there's a high likelihood that your mods will not work.\n\nClosing this popup will open the mod's bug report form. Please fill this out to the best of your ability. You will need to manually install the update once it has been released.",
			"version_hash": 655551688
		},
		"HEVLIB_ERRORCHECK_MISSING_VANILLA_LOCALES": {
			"string": "Exiting game due to a non-initialized TranslationServer. This is likely caused by a severe issue with any mods you have installed and/or Vanilla's .PCK file is corrupted.",
			"version_hash": 4154468583
		},
		"HEVLIB_FINISH_RESEARCH": {
			"string": "Complete Research!",
			"version_hash": 2793565484
		},
		"HEVLIB_START_RESEARCH": {
			"string": "Start research!",
			"version_hash": 3449780673
		},
		"HEVLIB_RESEARCH_ACTIVE_PROJECTS": {
			"string": "Active Projects",
			"version_hash": 3390722379
		},
		"HEVLIB_RESEARCH_COMPLETED_PROJECTS": {
			"string": "Completed Projects",
			"version_hash": 1653704780
		},
		"HEVLIB_SHOW_COMPLETED_PROJECTS": {
			"string": "Show completed projects",
			"version_hash": 633182925
		},
		"HEVLIB_COMPLETED_PROJECTS": {
			"string": "Completed Projects",
			"version_hash": 1653704780
		},
		"HEVLIB_RESEARCH_TOGGLE_COMPLETED_VISIBILITY": {
			"string": "Whether the list of completed research projects should be displayed",
			"version_hash": 4158265463
		},
		"HEVLIB_RESEARCH_TOGGLE_COMPLETED_VISIBILITY_DISABLED": {
			"string": "No completed projects can be shown",
			"version_hash": 3880024785
		},
		"HEVLIB_TRANSIT_TIP_27": {
			"string": "Want to assist with translating mods and have them integrated directly within them? Check out TranslationTracker & its wiki to get started at 'https://github.com/rwqfsfasxc100/TranslationTracker/wiki'",
			"version_hash": 3021212995
		},
		"HEVLIB_INSUFFICIENT_FUNDS_TOOLTIP": {
			"string": "Insufficient funds",
			"version_hash": 2943580940
		},
		"HEVLIB_SAFEMODE_SM_TRIPPED_POPUP_MSG": {
			"string": "Safe mode tripped! %d mods attempted to overwrite the behaviour of a total of %d Vanilla resource file(s) in a manner that would likely be unstable.\n\nIf you are looking to extend/overwrite a Vanilla resource, please use DataFormat.__extend_script() or DataFormat.__override_script() for extending/overwriting scripts respectively, DataFormat.__replace_resource() for scenes/resources, or any equivalent method within your ModMain/LOAD_RESOURCES script(s).\n\nCheck the game logs for verbose details regarding the offending mod(s).",
			"version_hash": 44561853
		},
		"HEVLIB_SAFEMODE_SM_TRIPPED_ERR_1": {
			"string": "Make sure to check the specific line where each script was checked, as it will provide more information regarding the specific issue.",
			"version_hash": 1565839805
		},
		"HEVLIB_SAFEMODE_SM_TRIPPED_ERR_2": {
			"string": "If you are having problems fixing these issues, you may also ask for help regarding it in the Discord at [https://discord.gg/dv], where both myself and others are willing to help.",
			"version_hash": 1444952411
		},
		"HEVLIB_SAFEMODE_SM_TOTALLING": {
			"string": "Found %d offending files loaded between %d mods.",
			"version_hash": 1066159722
		},
		"HEVLIB_SAFEMODE_SM_TOTALLING_FOR_MOD": {
			"string": "[%d] offending files for mod [%s]:",
			"version_hash": 3656929850
		},
		"HEVLIB_SAFEMODE_SM_SUPERING_ERR_AI_LIKELY": {
			"string": "ERROR: file %s @ %s is not properly compiled and likely runs recursive code. Do not expect this script to run as intended.",
			"version_hash": 2471823957
		},
		"HEVLIB_SAFEMODE_SM_SUPERING_ERR_2": {
			"string": " -> This is likely due to a signature of incorrectly supering a virtual method, and is not permitted to be ran while it is installed and running SafeMode checks.",
			"version_hash": 2353006025
		},
		"HEVLIB_SAFEMODE_SM_SUPERING_ERR_3": {
			"string": " -> It is unsupported behaviour due to it being in best-case scenario terrible for performance and has historically resulted in frequent crashes. As a result is not supported to be run through HevLib.",
			"version_hash": 1451242435
		},
		"HEVLIB_SAFEMODE_SM_SUPERING_ERR_4": {
			"string": " -> If for whatever reason you require this functionality, I would recommend to instead refactor to not require the use of HevLib, completely overwrite the script that's being extended with the appropriate tools, or disable SafeMode's checks. (NOTE: Disabling SafeMode voids your ability to make bug reports, please be cautious with this.)",
			"version_hash": 707209201
		},
		"HEVLIB_SAFEMODE_SM_SUPERING_ERR_5": {
			"string": " -> Otherwise, if you are unable to find a suitable solution, you may also ask for help regarding it in the Discord at [https://discord.gg/dv].",
			"version_hash": 4132048125
		},
		"HEVLIB_SAFEMODE_SM_OVERWRITE_VANILLA_ERR_1": {
			"string": "WARNING: file %s @ %s overwrites a Vanilla resource file.",
			"version_hash": 1478591741
		},
		"HEVLIB_SAFEMODE_SM_OVERWRITE_VANILLA_ERR_2": {
			"string": " -> File should use a unique directory as to ensure the Vanilla file can be accessed at all times.",
			"version_hash": 1822456348
		},
		"HEVLIB_SAFEMODE_SM_OVERWRITE_VANILLA_ERR_3": {
			"string": " -> If you need to completely overwrite a script, use DataFormat.__override_script() or use an equivalent within the ModMain.gd script",
			"version_hash": 642916197
		},
		"HEVLIB_SAFEMODE_SM_OVERWRITE_VANILLA_ERR_4": {
			"string": " -> If you are unable to find a suitable solution, you may also ask for help regarding it in the Discord at [https://discord.gg/dv].",
			"version_hash": 2592290551
		},
		"HEVLIB_SAFEMODE_SM_CHECKINGFILE": {
			"string": "checking file %s:%s",
			"version_hash": 3109389835
		},
		"HEVLIB_SAFEMODE_SM_DISABLED_EDITOR": {
			"string": "Running from the editor, safe mode disabled by default as it cannot fail.",
			"version_hash": 3077477960
		},
		"HEVLIB_SAFEMODE_SM_DISABLED": {
			"string": "Safe mode disabled! NOTE: this will automatically assume that whatever you're doing that requires it to be disabled is the cause of the issue, so please keep that in mind! If you still need help, join the Discord at [https://discord.gg/dv], where myself and others are willing to help.",
			"version_hash": 3377736353
		},
		"HEVLIB_SAFEMODE_SM_ENABLED": {
			"string": "Safe mode enabled.",
			"version_hash": 1554000514
		},
		"HEVLIB_CONFIG_MARK_PLACEHOLDER_TRANSLATIONS": {
			"string": "Mark placeholder translations",
			"version_hash": 3783987957,
			"placeholder": false
		},
		"HEVLIB_CONFIG_MARK_PLACEHOLDER_TRANSLATIONS_DESC": {
			"string": "Any translation that is marked as a placeholder within its respective\ndriver will be made obvious it is with a [placeholder] prefix.",
			"version_hash": 685449490
		},
		"HEVLIB_CONFIG_SAFE_MODLET_LOADING": {
			"string": "Resolve modlet load conflicts",
			"version_hash": 2972641615
		},
		"HEVLIB_CONFIG_SAFE_MODLET_LOADING_DESC": {
			"string": "Uses a presumed Vanilla load order heuristic to ensure that modifications made through LOAD_RESOURCES.gd are load-safe.\n\nNOTICE: May cause issues with mods loading during and after the onready phase.",
			"version_hash": 2218953947
		}
	},
	"de": {
		"HEVLIB_MOD_BRIEF": {
			"string": "Mod-Bibliothek für die meistgenutzten Funktionen erstellt von __hev",
			"version_hash": 0
		},
		"HEVLIB_MOD_DESCRIPTION": {
			"string": "Eine Programmbibliothek beitet eine Reihe von Funktionen für andere Mods duch 'Pointer'-Dateien. \\n * Umgang mit Mod-Manifest-Dateien mittels Versionierung, um ein einheitliches Medium zur Abfrage von Informationen daraus zu schaffen.\\n * EquipmentTreiber - Hinzufügen und verwalten von Ausrüstungs-Items\\\\-Plätzen und mehr...\\n * WaffenPlatzTreiber - Hinzufügen und verwalten von Ausrüstung für die Befestigungen.\\n\\nDiese Bibliothek verfolgt außerdem das Ziel, eine konsistente Vorgehensweise beizubehalten, um Modding zu erleichtern. Die Kompatibilität mit Mods ist ebenfalls ein zentraler Schwerpunkt der bereitgestellten Funktionalität.\\n\\nWeitere Informationen findest du im Wiki dieses Mods. Wenn du Vorschläge oder Ideen hast, hinterlasse sie bitte im Discord oder als GitHub-Issue.",
			"version_hash": 0
		},
		"HEVLIB_MOD_ERROR_HEADER": {
			"string": "%s MOD ISSUES",
			"version_hash": 0
		},
		"HEVLIB_MOD_ERROR_DEPENDANCY_DIALOGUE_BOX": {
			"string": "Es gibt aktuell %s ubefriedigte Mod-Abhängigkeiten. Stelle sicher dass die Vorraussetzungen vorhanden sind, oder entferne die Mods: %s",
			"version_hash": 0
		},
		"HEVLIB_GENERIC_ERROR_DIALOGUE_BOX": {
			"string": "Etwas ist schief gelaufen. Bitte das Spiel neustarten!",
			"version_hash": 0
		},
		"EVENTDRIVER_MENU": {
			"string": "EventDriver Debug Menü",
			"version_hash": 0
		},
		"EVENTDRIVER_EVENTS": {
			"string": "Ausgewähltes Event",
			"version_hash": 0
		},
		"EVENTDRIVER_TIMER": {
			"string": "Storyteller Event Timer",
			"version_hash": 0
		},
		"EVENTDRIVER_SPAWNNOW": {
			"string": "Erzwinge aktuell gewähltes Event zu starten",
			"version_hash": 0
		},
		"EVENTDRIVER_EVENT_SELECTOR": {
			"string": "Event Selektor",
			"version_hash": 0
		},
		"EVENTDRIVER_CLEAREVENT": {
			"string": "Ausgewählte(s) Event(s) bereinigen",
			"version_hash": 0
		},
		"HEVLIB_MISSING_DOCUMENTATION_1": {
			"string": "!!!!! Für dieses Feature wurde keine Dokumentation bereitgestellt!",
			"version_hash": 0
		},
		"HEVLIB_MISSING_DOCUMENTATION_2": {
			"string": "!!!!! Bitte teile es mir (__hev) ASAP mit, da Dokumentationen der Schlüssel für Bibliotheken wie diese sind, um Instandhaltung zu wahren!",
			"version_hash": 0
		},
		"HEVLIB_DESCRIPTION_PLACEHOLDER": {
			"string": "Dieser Mods hat keine Beschreibung. \\n\\nÜberprüfe die Webseite, wo du den Mod erhalten hast oder frage beim Ersteller nach einer Beschreibung.",
			"version_hash": 0
		},
		"HEVLIB_SELF_CHECK_ERROR_MESSAGE": {
			"string": "HevLib wurde nicht korrekt installiert. Überprüfe deine Quelle und stelle sicher, dass es wie folgt aussieht: HevLib.zip/HevLib/\\n\\nMit OK wird das Spiel beendet und du es werden die aktuellsten Releases im Browser geöffnet.",
			"version_hash": 0
		},
		"HEVLIB_SELF_CHECK_ERROR_HEADER": {
			"string": "HEVLIB LOAD ERROR!",
			"version_hash": 0
		},
		"HEVLIB_INCORRECT_SHIP": {
			"string": "(ERROR!) Fehlender Schiffs-Typ: '%s'\\nDas Save kann nicht geladen werden, da das aktive Schiff nicht verügbar ist!\\nUm das Save zu laden, installiere bitte den Mod erneut, der diesen Schiffs-Typ enthält!",
			"version_hash": 0
		},
		"HEVLIB_SLOT": {
			"string": "Slot",
			"version_hash": 0
		},
		"HEVLIB_MOD_MENU": {
			"string": "Mod Menü",
			"version_hash": 0
		},
		"HEVLIB_MISSING_MOD_NAME": {
			"string": "Mod Name nicht verfügbar :(",
			"version_hash": 0
		},
		"HEVLIB_MISSING_DESCRIPTION": {
			"string": "Dieser Mods hat keine Beschreibung. :( \\n\\nÜberprüfe die Webseite, wo du den Mod erhalten hast oder frage beim Ersteller nach einer Beschreibung.",
			"version_hash": 0
		},
		"HEVLIB_AUTHOR": {
			"string": "Ersteller:",
			"version_hash": 0
		},
		"HEVLIB_CREDITS": {
			"string": "Danksagung:",
			"version_hash": 0
		},
		"HEVLIB_UNKNOWN": {
			"string": "Unbekannt",
			"version_hash": 0
		},
		"HEVLIB_MM_TOOLTIP_HEADER": {
			"string": "Mod Information:",
			"version_hash": 0
		},
		"HEVLIB_MM_TOOLTIP_ID": {
			"string": "Mod ID: %s",
			"version_hash": 0
		},
		"HEVLIB_MM_TOOLTIP_MV": {
			"string": "Manifest Version: %s",
			"version_hash": 0
		},
		"HEVLIB_MM_TOOLTIP_ZIP": {
			"string": "Zip File: %s",
			"version_hash": 0
		},
		"HEVLIB_MM_TOOLTIP_LIBRARY": {
			"string": "Bibliothek: %s \\ Immer zeigen: %s",
			"version_hash": 0
		},
		"HEVLIB_MM_BUTTON_TOOLTIP_GITHUB": {
			"string": "Mod Github Seite",
			"version_hash": 0
		},
		"HEVLIB_MM_BUTTON_TOOLTIP_DISCORD": {
			"string": "Mod Discord Thread",
			"version_hash": 0
		},
		"HEVLIB_MM_BUTTON_TOOLTIP_NEXUS": {
			"string": "Nexus Mods Seite",
			"version_hash": 0
		},
		"HEVLIB_MM_BUTTON_TOOLTIP_DONATIONS": {
			"string": "Spenden ans Projekt",
			"version_hash": 0
		},
		"HEVLIB_MM_BUTTON_TOOLTIP_WIKI": {
			"string": "Mod Wiki Seite",
			"version_hash": 0
		},
		"HEVLIB_MM_BUTTON_TOOLTIP_BUGREPORTS": {
			"string": "Einen Fehler melden",
			"version_hash": 0
		},
		"HEVLIB_MM_BUTTON_TOOLTIP_CUSTOM": {
			"string": "Mehr...",
			"version_hash": 0
		},
		"HEVLIB_VANILLA_DESCRIPTION": {
			"string": "Eine physikbasierte Bergbau-Simulation, angesiedelt im dichtesten Trümmerfeld des Sonnensystems. Jede Aktion hat eine Reaktion, Laser sind ohne ein Medium unsichtbar, und dein Schub ist eine mächtige Waffe. Finde Handelspartner, passe deine Ausrüstung an deinen Spielstil an und heuere eine Crew zur Unterstützung an. Lüfte die Geheimnisse der Ringe – oder werde einfach nur reich.",
			"version_hash": 0
		},
		"HEVLIB_VANILLA_BRIEF": {
			"string": "Das Basis Spiel",
			"version_hash": 0
		},
		"HEVLIB_MODMENU_MODS": {
			"string": "Mods",
			"version_hash": 0
		},
		"HEVLIB_MODMENU_OK": {
			"string": "Ok",
			"version_hash": 0
		},
		"HEVLIB_MODMENU_CLOSE": {
			"string": "Schließen",
			"version_hash": 0
		},
		"HEVLIB_MODMENU_OPENFOLDER": {
			"string": "Öffne Mod-Ordner",
			"version_hash": 0
		},
		"HEVLIB_MODMENU_MODS_VISIBLE": {
			"string": "Zeige %d Mods",
			"version_hash": 0
		},
		"HEVLIB_DROP_FILES_TO_ADD_MODS": {
			"string": "Ziehe Dateien per Drag-and-drop in dieses Fenster, um Mods hinzuzufügen.\\nMod-Dateien mit identischem Namen werden überschrieben.",
			"version_hash": 0
		},
		"HEVLIB_MODMENU_VER_AND_PRIO": {
			"string": "Version: v%s / Priorität: %s",
			"version_hash": 0
		},
		"HEVLIB_MODMENU_PRIO": {
			"string": "Priorität: %s",
			"version_hash": 0
		},
		"HEVLIB_MODMENU_VERSION": {
			"string": "Version: v%s",
			"version_hash": 0
		},
		"HEVLIB_MODMENU_PRIO_MID_HEADER": {
			"string": "Mod ID und Priorität",
			"version_hash": 0
		},
		"HEVLIB_GITHUB": {
			"string": "GitHub",
			"version_hash": 0
		},
		"HEVLIB_DISCORD": {
			"string": "Discord",
			"version_hash": 0
		},
		"HEVLIB_NEXUS": {
			"string": "Nexusmods",
			"version_hash": 0
		},
		"HEVLIB_DONATIONS": {
			"string": "Eine Spende machen",
			"version_hash": 0
		},
		"HEVLIB_WIKI": {
			"string": "Wiki",
			"version_hash": 0
		},
		"HEVLIB_BUGREPORTS": {
			"string": "Melde einen Fehler",
			"version_hash": 0
		},
		"HEVLIB_GITHUB_TOOLTIP": {
			"string": "GitHub repository für das Projekt",
			"version_hash": 0
		},
		"HEVLIB_DISCORD_TOOLTIP": {
			"string": "Discord thread/channel/server für das Projekt",
			"version_hash": 0
		},
		"HEVLIB_NEXUS_TOOLTIP": {
			"string": "Nexusmods Seite für das Projekt",
			"version_hash": 0
		},
		"HEVLIB_DONATIONS_TOOLTIP": {
			"string": "Spende an das Projekt",
			"version_hash": 0
		},
		"HEVLIB_WIKI_TOOLTIP": {
			"string": "Wiki Seite(n) für das Projekt",
			"version_hash": 0
		},
		"HEVLIB_BUGREPORTS_TOOLTIP": {
			"string": "Melde Fehler über des Projekt's Melde-Link",
			"version_hash": 0
		},
		"HEVLIB_FILTER_BY_TAGS": {
			"string": "Filter Mods bei Schlagwort",
			"version_hash": 0
		},
		"HEVLIB_SETTINGS_BUTTON_TOOLTIP": {
			"string": "Öffne das Einstellungen-Menü",
			"version_hash": 0
		},
		"HEVLIB_LINKS_BUTTON": {
			"string": "Links",
			"version_hash": 0
		},
		"HEVLIB_BUGREPORTS_BUTTON": {
			"string": "Fehlermeldungen",
			"version_hash": 0
		},
		"HEVLIB_LINKS_TOOLTIP": {
			"string": "Links des Projekts zeigen",
			"version_hash": 0
		},
		"TAG_ALLOW_ACHIEVEMENTS": {
			"string": "Erlaube Errungenschaften",
			"version_hash": 0
		},
		"TAG_QOL": {
			"string": "Quality of life",
			"version_hash": 0
		},
		"TAG_VISUAL": {
			"string": "Visuell",
			"version_hash": 0
		},
		"TAG_FUN": {
			"string": "Spaß",
			"version_hash": 0
		},
		"TAG_UI": {
			"string": "User interface (UI)",
			"version_hash": 0
		},
		"TAG_ADDS_SHIPS": {
			"string": "Fügt neue Schiffe hinzu",
			"version_hash": 0
		},
		"TAG_ADDS_EQUIPMENT": {
			"string": "Fügt neue Ausrüstung hinzu",
			"version_hash": 0
		},
		"TAG_ADDS_GAMEPLAY_MECHANICS": {
			"string": "Fügt neue Gamplay-Mechaniken hinzu",
			"version_hash": 0
		},
		"TAG_ADDS_EVENTS": {
			"string": "Fügt neue Ring-Events hinzu",
			"version_hash": 0
		},
		"TAG_HANDLE_EXTRA_CREW": {
			"string": "Handhabt extra Besatzung",
			"version_hash": 0
		},
		"HEVLIB_TAG_FILTER": {
			"string": "Filter Mods durch Schlagwort",
			"version_hash": 0
		},
		"HEVLIB_VANILLA_STEAM_STORE": {
			"string": "Steam",
			"version_hash": 0
		},
		"HEVLIB_VANILLA_STEAM_STORE_TOOLTIP": {
			"string": "Öffnet die Steam-Store-Seite für das Spiel",
			"version_hash": 0
		},
		"HEVLIB_VANILLA_ITCH_STORE": {
			"string": "itch.io",
			"version_hash": 0
		},
		"HEVLIB_VANILLA_ITCH_STORE_TOOLTIP": {
			"string": "Öffnet die itch.io-Seite für das Spiel",
			"version_hash": 0
		},
		"HEVLIB_VANILLA_EPIC_STORE": {
			"string": "Epic Games",
			"version_hash": 0
		},
		"HEVLIB_VANILLA_EPIC_STORE_TOOLTIP": {
			"string": "Öffnet die Epic Games-Seite für das Spiel",
			"version_hash": 0
		},
		"HEVLIB_VANILLA_GOG_STORE": {
			"string": "GOG",
			"version_hash": 0
		},
		"HEVLIB_VANILLA_GOG_STORE_TOOLTIP": {
			"string": "Öffnet die GOG-Seite für das Spiel",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_SORT_BY_PRICE": {
			"string": "Ausrüstung nach Preis sortieren",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_SORT_BY_PRICE_TOOLTIP": {
			"string": "Zwingt die Ausrüstung nach Preis zu sortieren.\t\\nDies zerstört zwar die Hilfsenergieeinheit, aber beugt Fehler mit gemoddeter Ausrüstung vor. ",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_SORT_SLOT_BY_TYPE": {
			"string": "Sortiere Plätze nach Typ",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_SORT_SLOT_BY_TYPE_TOOLTIP": {
			"string": "Sortiert Plätze nach Typ. Verhindert das willkürliche Versetzen von gemoddeten Plätzen.",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_USE_LEGACY_EQUIPMENT_HANDLING": {
			"string": "Veraltetes System für Ausrüstung verwenden",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_USE_LEGACY_EQUIPMENT_HANDLING_TOOLTIP": {
			"string": "Verwendet das Ausrüstungssystem von vor v1.7\\nSollte nur für ältere Mods verwendet werden.\\nFunktionalität wird nicht garantiert.",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_WRITE_EVENTS": {
			"string": "Events aufzeichnen",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_WRITE_EVENTS_TOOLTIP": {
			"string": "Schreibt in eine Datei unter user://cache/.HevLib_Cache/current_events.txt, welche alle Events beinhaltet, die bei Spielstart geladen werden.",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_SHOW_HIDDEN_LIBRARIES": {
			"string": "Zeige verstecke Bibliotheken",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_SHOW_HIDDEN_LIBRARIES_TOOLTIP": {
			"string": "Zeigt alle Bibliotheken, welche nicht dauerhaft angezeigt.",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_INPUT_DEBUGGER": {
			"string": "Input debugger",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_INPUT_DEBUGGER_TOOLTIP": {
			"string": "Zeigt Debug-Informationen über deine aktuellen Eingaben.",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_EVENT_DEBUGGER": {
			"string": "Event debugger",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_EVENT_DEBUGGER_TOOLTIP": {
			"string": "Zeigt Schlüsselereignisse und ob diese in-/aktiv sind.",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_POSITION_DATA_DEBUGGER": {
			"string": "Position data debugger",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_POSITION_DATA_DEBUGGER_TOOLTIP": {
			"string": "Zeigt das aktuelle Chaos und die erwartete Anzahl an möglichen Ereignissen währen eines Tauchvorganges",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_SHOW_ACCURATE_EVENTS": {
			"string": "Zeige genaue Events",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_SHOW_ACCURATE_EVENTS_TOOLTIP": {
			"string": "Wird im Zusammenhang mit dem Position data debugger verwendet. Zeigt einen Zähler für alle vorhandene Events Im Bereich.\\nBasierend darauf, wie wie diese Einstellung funktioniert, wird die Performance stark beeinträchtigt und es werden tausende Zeilen Logs geschrieben.\\n\\nDIE NUTZUNG WIRD NICHT UNTERSTÜTZT UND INVALIDIERT ALLE FEHLERMELDUNGEN! DU WURDEST GEWARNT!",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_OPEN_DEBUG_EVENT_MENU": {
			"string": "Debug event Menü",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_OPEN_DEBUG_EVENT_MENU_TOOLTIP": {
			"string": "Welche Taste öffnet das Event debugger Menü.",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_OPEN_DEBUGGER": {
			"string": "Debug display umschalten",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_OPEN_DEBUGGER_TOOLTIP": {
			"string": "Schaltet die Sichtbarkeit der --debug-console Anzeige, welches normalerweise ein Argument benötigt.",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_TOGGLE_DEBUG_MENUS": {
			"string": "HevLib debugger Menüs",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_TOGGLE_DEBUG_MENUS_TOOLTIP": {
			"string": "Wenn aktiviert, zeigt es den Input debugger sowie Event debugger",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_LINEEDIT_PLACEHOLDER": {
			"string": "Text einfügen",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_SECTION_EQUIPMENT": {
			"string": "Ausrüstung",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_SECTION_EVENTS": {
			"string": "Events",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_SECTION_DRIVERS": {
			"string": "Treiber",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_SECTION_DEBUG": {
			"string": "Debug",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_SECTION_INPUT": {
			"string": "Tasten",
			"version_hash": 0
		},
		"HEVLIB_NOTIFICATIONS": {
			"string": "Mod Benachrichtigungen",
			"version_hash": 0
		},
		"HEVLIB_UPDATE_COUNT": {
			"string": "Neue Updates: %s Mod(s)!",
			"version_hash": 0
		},
		"HEVLIB_DEPENDANCY_COUNT": {
			"string": "Fehlende Abhängigkeiten: %s Mod(s)!",
			"version_hash": 0
		},
		"HEVLIB_CONFLICT_COUNT": {
			"string": "%s mod(s) konfligieren!",
			"version_hash": 0
		},
		"HEVLIB_UPDATE_INFO_HEADER": {
			"string": "Dieser Mod hat ausstehende Updates!",
			"version_hash": 0
		},
		"HEVLIB_DEPENDANCY_INFO_HEADER": {
			"string": "Diesem Mod fehlen Abhängigkeiten!",
			"version_hash": 0
		},
		"HEVLIB_CONFLICT_INFO_HEADER": {
			"string": "Dieser Mod steht im Konflikt!",
			"version_hash": 0
		},
		"HEVLIB_UPDATE_INFO_BODY": {
			"string": "Den Mod von Version [%s] auf Version [%s] upgraden?",
			"version_hash": 0
		},
		"HEVLIB_DEPENDANCY_INFO_BODY": {
			"string": "Diesem Mod fehlen folgende Abhängigkeiten:\\n%s\\n\\n\\n\\Erwarte nicht, dass der Mods wie erwartet funktioniert!",
			"version_hash": 0
		},
		"HEVLIB_CONFLICT_INFO_BODY": {
			"string": "Dieser Mod steht in Konflikt mit anderen Mods. Bitte nutze eine kompatiblere Version für die folgenden Mods:\\n%s\\n\\n\\n\\Erwarte nicht, dass der Mods wie erwartet funktioniert!",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_RANDOMIZE_MINERALS": {
			"string": "Zufälliger Mineral-Seed",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_RANDOMIZE_MINERALS_TOOLTIP": {
			"string": "Erstellt bei Spielstart immer einen zufälligen Seed für die Mineralien. \\n\\nWenn deaktiviert, wird ein vorrausbestimmte Liste an Konstanten für die Seeds verwendet.",
			"version_hash": 0
		},
		"HEVLIB_UPDATE_CENTER": {
			"string": "Mod Update Center",
			"version_hash": 0
		},
		"HEVLIB_UPDATE_CENTER_DESC": {
			"string": "Die folgenden Mods haben Updates",
			"version_hash": 0
		},
		"HEVLIB_UPDATE_ALL": {
			"string": "Update alle Mods",
			"version_hash": 0
		},
		"HEVLIB_IGNORE_ALL": {
			"string": "Ignorier alle Mods",
			"version_hash": 0
		},
		"HEVLIB_IGNORE_UPDATE": {
			"string": "Update ignorieren",
			"version_hash": 0
		},
		"HEVLIB_UPDATE_MOD": {
			"string": "Mod updaten",
			"version_hash": 0
		},
		"HEVLIB_CONFIRMATION_DIALOGUE_UPDATE_MOD": {
			"string": "Den Mod von Version [%s v%s] auf [%s] updaten? \\n\\nJe nach Größe des Mods kann dies etwas dauern.",
			"version_hash": 0
		},
		"HEVLIB_CONFIRMATION_DIALOGUE_IGNORE_MOD_UPDATE": {
			"string": "Das Update des Mods von Version [%s] auf [%s] ignorieren? \\n\\nDiese Entscheidung kann im Mod-Menü zurückgesetzt werden.",
			"version_hash": 0
		},
		"HEVLIB_CONFIRMATION_DIALOGUE_UPDATE_MODS": {
			"string": "Alle Mods updaten? \\n\\nJe nach Größe und Anzahl der Mods kann dies etwas dauern.",
			"version_hash": 0
		},
		"HEVLIB_CONFIRMATION_DIALOGUE_IGNORE_MODS": {
			"string": "Alle Mod-Updates ignorieren? \\n\\nDiese Entscheidung kann im Mod-Menü zurückgesetzt werden.",
			"version_hash": 0
		},
		"HEVLIB_ICON_TOOLTIP_CONFLICT": {
			"string": "Dieser Mods steht in Konflikt mit folgenden Mods:%s",
			"version_hash": 0
		},
		"HEVLIB_ICON_TOOLTIP_DEPENDANCIES": {
			"string": "Diesem Mod fehlen folgende Abhängigkeiten:%s",
			"version_hash": 0
		},
		"HEVLIB_ICON_TOOLTIP_COMPLEMENTARY": {
			"string": "Dieser Mod ergänzt die folgenden Mods:%s",
			"version_hash": 0
		},
		"HEVLIB_ICON_TOOLTIP_UPDATES": {
			"string": "Dieser Mod hat ein Update! \\nVersion [%s] -> Version [%s]",
			"version_hash": 0
		},
		"HEVLIB_MODMENU_UPDATE_NOTIFIER": {
			"string": "Es sind Mod-Updates verfügbar. \\n\\nWillst du das Update-Menü öffnen?",
			"version_hash": 0
		},
		"HEVLIB_PLEASE_WAIT": {
			"string": "Bitte warte...",
			"version_hash": 0
		},
		"HEVLIB_RESTART": {
			"string": "Spiel neustarten",
			"version_hash": 0
		},
		"HEVLIB_EXIT_INSTEAD": {
			"string": "Spiel beenden",
			"version_hash": 0
		},
		"HEVLIB_RESTART_BECAUSE_NEW_MODS": {
			"string": "Ein Neustart wird benötigt. \\n\\nAlternativ kann dieses Fenster geschlossen werden, damit du noch vorher speichern kannst.",
			"version_hash": 0
		},
		"HEVLIB_WAIT_TO_UPDATE_ALL": {
			"string": "Bitte warte... \\n\\nDownloade Mod %02d von %02d \\n%s [%s] Version [%s]",
			"version_hash": 0
		},
		"HEVLIB_TITLE_IGNORE_MOD": {
			"string": "Mod ignorieren?",
			"version_hash": 0
		},
		"HEVLIB_TITLE_UPDATE_MOD": {
			"string": "Mod updaten?",
			"version_hash": 0
		},
		"HEVLIB_TITLE_IGNORE_MODS": {
			"string": "Mods ignorieren?",
			"version_hash": 0
		},
		"HEVLIB_TITLE_UPDATE_MODS": {
			"string": "Mods updaten?",
			"version_hash": 0
		},
		"HEVLIB_DLCLIST_DLC_HEADER": {
			"string": "------- DLC ------",
			"version_hash": 0
		},
		"HEVLIB_DLCLIST_MODS_HEADER": {
			"string": "------ MODS ------",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_SHOW_ALWAYS_LIBRARIES_IN_DLCLIST": {
			"string": "Bibliotheken mit \"Immer zeigen\" in der DLC-Liste auflisten",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_SHOW_ALWAYS_LIBRARIES_IN_DLCLIST_TOOLTIP": {
			"string": "Bibliotheken mit dem 'Immer Zeigen' tag (so wie HevLib) erlauben, in der DLC-Mod-Liste zu erscheinen.",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_SHOW_ALL_LIBRARIES_IN_DLCLIST": {
			"string": "Alle Bibliotheken auflisten",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_SHOW_ALL_LIBRARIES_IN_DLCLIST_TOOLTIP": {
			"string": "Alle Bibliotheken in der DLC-Mod-Liste auflisten. Die Liste kann durch Mods mit vielen Sub-Prozessen sehr lang werden.",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_DLCLIST_SORT_ORDER": {
			"string": "DLC-Mod-Liste Sortierung",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_DLCLIST_SORT_ORDER_TOOLTIP": {
			"string": "Ob und wie die Liste sortiert werden soll.",
			"version_hash": 0
		},
		"HEVLIB_RESEARCH": {
			"string": "Forschung",
			"version_hash": 0
		},
		"HEVLIB_RESEARCH_CURRENT": {
			"string": "Aktuelle Forschung",
			"version_hash": 0
		},
		"HEVLIB_CURRENT_PROJECTS": {
			"string": "Aktive Forschungsprojekte",
			"version_hash": 0
		},
		"HEVLIB_RESEARCH_STATS": {
			"string": "Alle Projektstatistiken",
			"version_hash": 0
		},
		"HEVLIB_RESEARCH_AVAILABLE": {
			"string": "Verfügbare Projekte",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_TOGGLE_UI_SCROLL_LEFT": {
			"string": "UI links scrollen",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_TOGGLE_UI_SCROLL_LEFT_TOOLTIP": {
			"string": "Primäre Taste für horizontale Bildlaufmenüs",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_TOGGLE_UI_SCROLL_RIGHT": {
			"string": "UI rechts scrollen",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_TOGGLE_UI_SCROLL_RIGHT_TOOLTIP": {
			"string": "Primäre Taste für horizontale Bildlaufmenüs",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_TOGGLE_UI_SCROLL_LEFT2": {
			"string": "UI links scrollen (alt)",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_TOGGLE_UI_SCROLL_LEFT2_TOOLTIP": {
			"string": "Alternative Taste für horizontale Bildlaufmenüs",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_TOGGLE_UI_SCROLL_RIGHT2": {
			"string": "UI rechts scrollen (alt)",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_TOGGLE_UI_SCROLL_RIGHT2_TOOLTIP": {
			"string": "Alternative Alternative Taste für horizontale Bildlaufmenüs",
			"version_hash": 0
		},
		"SYSTEM_HEVLIB_INTERNALS_NODE": {
			"string": "Interne System Mod Laufzeit",
			"version_hash": 0
		},
		"NOTIFICATION_NAME_PLACEHOLDER": {
			"string": "{Benachrichtigungskörper fehlt}",
			"version_hash": 0
		},
		"NOTIFICATION_TITLE_PLACEHOLDER": {
			"string": "{Benachrichtigungsname fehlt}",
			"version_hash": 0
		},
		"HEVLIB_AVAILABLE_RESEARCH": {
			"string": "Verfügbare Forschungsprojekte",
			"version_hash": 0
		},
		"HEVLIB_RESEARCH_TOTAL_TOOLTIP": {
			"string": "Gesammter Forschungsstand für das Projekt",
			"version_hash": 0
		},
		"DLC_ANDROID": {
			"string": "Android face pack",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_LIMIT_NANODRONE_OUTPUT": {
			"string": "Limitiere Nanodrohnenlagerarbeitsleistung",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_LIMIT_NANODRONE_OUTPUT_TOOLTIP": {
			"string": "Verhindert, dass Nanodrohnen mehr als das vom installiertem Medium bereitgestellten Rate nutzen können. \\nNotiz: Dies wird nur in speziellen Konfigurationen passieren.",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_DISPLAY_CURRENTLY_PLAYING": {
			"string": "Zeige aktuelle Spieleranzahl",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_DISPLAY_CURRENTLY_PLAYING_TOOLTIP": {
			"string": "Zeigt die Anzahl aller Steam-Clienten in der oberen linken Bildschirmecke.\\nDieser Zähler unterscheidet zwischen Vollversion und Demo.",
			"version_hash": 0
		},
		"HEVLIB_CLEAR_LEADERBOARDS": {
			"string": "Leaderboardstatistiken resetten",
			"version_hash": 0
		},
		"HEVLIB_CLEAR_LEADERBOARDS_TOOLTIP": {
			"string": "Öffnet ein Menü, in welchem man individuelle Statistiken zurücksetzen kann. \\n\\nNOTIZ: Nur für Steam-Versionen",
			"version_hash": 0
		},
		"HEVLIB_OPEN_MENU": {
			"string": "Öffne Menü",
			"version_hash": 0
		},
		"STEAMSTAT_best_haul": {
			"string": "Beste Ausbeute (komplett)",
			"version_hash": 0
		},
		"STEAMSTAT_best_ore": {
			"string": "Beste Ausbeute (Erz)",
			"version_hash": 0
		},
		"STEAMSTAT_longest_dive": {
			"string": "Längster Tauchgang (mit Astrogation)",
			"version_hash": 0
		},
		"STEAMSTAT_longest_dive_realtime": {
			"string": "Längster Tauchgang (Steuerzeit)",
			"version_hash": 0
		},
		"STEAMSTAT_money_per_day": {
			"string": "Durchschnittliche Einnahmen pro Tag",
			"version_hash": 0
		},
		"STEAMSTAT_time": {
			"string": "Tage in den Ringen",
			"version_hash": 0
		},
		"STEAMSTAT_total_money": {
			"string": "Vermögen",
			"version_hash": 0
		},
		"STEAMSTAT_CLEAR_STAT": {
			"string": "Statistik reinigen",
			"version_hash": 0
		},
		"HEVLIB_CONFIRM": {
			"string": "Aktion bestätigen",
			"version_hash": 0
		},
		"HEVLIB_WIPE_STAT_ARE_YOU_SURE": {
			"string": "Bist du dir sicher, dass du %s ausradieren willst?",
			"version_hash": 0
		},
		"HEVLIB_NOSTEAM": {
			"string": "Dieses Menü funktioniert auf Steam.",
			"version_hash": 0
		},
		"HEVLIB_OPT_PROFILES": {
			"string": "Einstellungsprofile",
			"version_hash": 0
		},
		"HEVLIB_PROFILE_SELECT": {
			"string": "Profil wählen",
			"version_hash": 0
		},
		"HEVLIB_ADD_PROFILE": {
			"string": "Profil hinzufügen",
			"version_hash": 0
		},
		"HEVLIB_RENAME_PROFILE": {
			"string": "Profil umbenennen",
			"version_hash": 0
		},
		"HEVLIB_DELETE_PROFILE": {
			"string": "Profil löschen",
			"version_hash": 0
		},
		"HEVLIB_PROFILENAME_ADD": {
			"string": "Profil hinzufügen",
			"version_hash": 0
		},
		"HEVLIB_PROFILENAME_RENAME": {
			"string": "Profil umbenennen",
			"version_hash": 0
		},
		"HEVLIB_PROFILE_DELETE": {
			"string": "Profil löschen",
			"version_hash": 0
		},
		"HEVLIB_PROFILE_DELETE_ARE_YOU_SURE": {
			"string": "Bist du dir sicher, dass du das Profil löschen willst?",
			"version_hash": 0
		},
		"HEVLIB_CHANGELOGS": {
			"string": "Änderungsprotokoll",
			"version_hash": 0
		},
		"HEVLIB_CHANGELOGS_NEW": {
			"string": "Neues Änderungsprotokoll",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_MULTIPLE_MINERALS_PER_CHUNK": {
			"string": "Multiple Mineralien pro Brocken",
			"version_hash": 0
		},
		"HEVLIB_CONFIG_MULTIPLE_MINERALS_PER_CHUNK_TOOLTIP": {
			"string": "Verbietet, dass multiple Mineralien sich auf einen Erz-Brocken sammeln. \\n\\nDank an Za'krin für die ursprüngliche Implementierung. Diese Version adaptiert und verbessert sie.",
			"version_hash": 0
		},
		"HEVLIB_TRANSIT_TIP_1": {
			"string": "Mehr Besatzung des gleichen Berufes lässt diese zusammen arbeiten.",
			"version_hash": 0
		},
		"HEVLIB_TRANSIT_TIP_2": {
			"string": "Abgesehen vom Autopiloten können deine Triebwerke immer noch angesteuert werden, auch wenn Bordcomputer oder HUD nicht mehr online sind.",
			"version_hash": 0
		},
		"HEVLIB_TRANSIT_TIP_3": {
			"string": "Beim bergen einer Rettungskapsel kann ein freier Halterungsarm diese sicher halten, während dein Frachtraum nicht zugemüllt wird.",
			"version_hash": 0
		},
		"HEVLIB_TRANSIT_TIP_4": {
			"string": "Eine Beanspruchungsbake kann mehr Aufmerksamkeit erzeugen.",
			"version_hash": 0
		},
		"HEVLIB_TRANSIT_TIP_5": {
			"string": "Dein Geologe kann einschränken, was deine Ausrüstung erkennen kan. Je strenger die Filter sind, desto weniger werden die Systeme überfordert.",
			"version_hash": 0
		},
		"HEVLIB_TRANSIT_TIP_6": {
			"string": "Wenn dir Jameson's monatlicher Satz zu wenig ist, kannst du im Ring ein Search-and-Rescue-Schiff aufsuchen, um mehr Versicherung zu erhalten.",
			"version_hash": 0
		},
		"HEVLIB_TRANSIT_TIP_7": {
			"string": "Eine glückliche Besatzung arbeitet weniger hart und unglücklich fühlen sie sich weniger motiviert.",
			"version_hash": 0
		},
		"HEVLIB_TRANSIT_TIP_8": {
			"string": "Wenn ein object mit dem Autopiloten auswählt wurde, können mikroseismische Drohnen das Zielobjekt scannen, ansonsten wird das Objekt gescannt, was sich unter der Maus befindet",
			"version_hash": 0
		},
		"HEVLIB_TRANSIT_TIP_9": {
			"string": "Habitate zahlen immer bessere Preise als den aktuellen  Marktpreis.",
			"version_hash": 0
		},
		"HEVLIB_TRANSIT_TIP_10": {
			"string": "Zu viele Nanodrohnen genutzt, die unnützes Erz sammeln? Richte deinen Filter im Geologen ein, um nur das zu erhalten, was du möchtest und spare dabei an Drohnen.",
			"version_hash": 0
		},
		"HEVLIB_TRANSIT_TIP_11": {
			"string": "Probleme mit Mods? Melde es dort, wo du sie herbekommen hast, oder versuche es im Discord für zeitnahen Support. ",
			"version_hash": 0
		},
		"HEVLIB_TRANSIT_TIP_12": {
			"string": "Hast du einen Vorschlag für einen mods? Betritt den Discord und frage freundlich nach.",
			"version_hash": 0
		},
		"HEVLIB_TRANSIT_TIP_13": {
			"string": "Möchtest du mehr mods? Schau die dir hier die ganze Liste an: 'https://delta-v.kodera.pl/index.php/Mod_List'",
			"version_hash": 0
		},
		"HEVLIB_TRANSIT_TIP_14": {
			"string": "Behalte im Hinterkopf, das alles, was Steine zerstören kann, auch andere Schiffe beschädigen kann.",
			"version_hash": 0
		},
		"HEVLIB_TRANSIT_TIP_15": {
			"string": "Autonome Systeme arbeiten wie vorgesehen, jedoch braucht es Geduld, damit sie arbeiten.",
			"version_hash": 0
		},
		"HEVLIB_TRANSIT_TIP_16": {
			"string": "Gefallen dir die Mods, die du nutzt? Unterstütze doch die Schöpfer!",
			"version_hash": 0
		},
		"HEVLIB_TRANSIT_TIP_17": {
			"string": "Mods verhalten sich nach einem Update anders? Schau in das Änderungsprotokoll oder frag den Verfasser.",
			"version_hash": 0
		},
		"MODMENU2_MOD_DESCRIPTION": {
			"string": "Ein erweitertes Mod-Menü, welches beinahe eine komplette Kontrolle darüber hat, wie du deine Mods siehst.\\n\\nBesonderheiten:\\n\\n* Einfache Mod-Ansicht - zeigt, welche Mods installiert sind, egal ob sie ein modernes Manifest haben, oder einfach nur simple Mods sind, aber auch aber Infos über das Hauptspiel.\\n* Mod Einstellungen - Erlaubt dem Nutzer Mods einzustellen, ohne dass er die Manifest-Datei bearbeiten muss.\\n* Update Kontrolle - Jeder Mod, der die benötigten Informationen liefert, kann auf Updates beim Spielstart kontrolliert werden. Updates können individuell oder im ganzen heruntergeladen, oder auch ignoriert werden.\\n* Konflikt- und Abhängigkeitsprüfungen – jede Mod, die Mod-IDs für erforderliche Mods oder für inkompatible Mods angibt, zeigt eine Warnung auf dem Startbildschirm an. Hinweis: Dies funktioniert nur bei Mods mit Manifest-Dateien.\\n* Tag- & Suchfilter – ermöglichen es, die angezeigten Mods nach Schlüsselwort oder Mod-ID zu filtern oder aus einer Menge von in den Mods enthaltenen Schlüsselwörtern auszuwählen, um nur Mods anzuzeigen, die ein bestimmtes Schlüsselwort verwenden.",
			"version_hash": 0
		},
		"MODMENU2_MOD_BRIEF": {
			"string": "Ein erweitertes Mod-Menü",
			"version_hash": 0
		},
		"MODMENU2_CONFIG_GENERAL": {
			"string": "Allgemein",
			"version_hash": 0
		},
		"MODMENU2_CLEAR_IGNORED_UPDATES": {
			"string": "Ignorierte Updates zurücksetzen",
			"version_hash": 0
		},
		"MODMENU2_CLEAR_IGNORED_UPDATES_TOOLTIP": {
			"string": "Setzt die Liste der Mods, die beim updaten ignoriert werden, zurück",
			"version_hash": 0
		},
		"MODMENU2_CLEAR_IGNORED_UPDATES_BUTTON": {
			"string": "Zurücksetzen",
			"version_hash": 0
		},
		"TAG_OVERHAUL": {
			"string": "Капитальный ремонт",
			"version_hash": 3544097003
		},
		"HEVLIB_GITHUB_PROGRESS_WAITING_ON_RESPONSE": {
			"string": "Ожидание ответа от сервера.",
			"version_hash": 1988119143
		},
		"HEVLIB_GITHUB_PROGRESS_ZIP_FOUND_AND_REQUESTING": {
			"string": "Ответ получен. Запрос файла.",
			"version_hash": 1619856286
		},
		"HEVLIB_GITHUB_PROGRESS_DOWNLOADING": {
			"string": "Загрузка файла | %06.2f%%\\n\\n%0.2f %s загружено из %0.2f %s",
			"version_hash": 812004994
		},
		"HEVLIB_GITHUB_PROGRESS_DOWNLOADING_ONLY_BYTES": {
			"string": "Загрузка file.\\n\\n%0.2f %s загружен",
			"version_hash": 2232387281
		},
		"HEVLIB_GITHUB_PROGRESS_DOWNLOADED_FILE": {
			"string": "Загрузка завершена.",
			"version_hash": 249088469
		},
		"HEVLIB_SIZE_LABEL_BYTES": {
			"string": "байт",
			"version_hash": 254850636
		},
		"HEVLIB_SIZE_LABEL_KILOBYTES": {
			"string": "килобайт",
			"version_hash": 214961083
		},
		"HEVLIB_SIZE_LABEL_MEGABYTES": {
			"string": "мегабайт",
			"version_hash": 2738237862
		},
		"HEVLIB_NO_DOWNLOAD_HEADER": {
			"string": "ССЫЛКА НЕ УКАЗАНА!",
			"version_hash": 3291089198
		},
		"HEVLIB_NO_DOWNLOAD_CONTENT": {
			"string": "NOTICE: мод [%s] не имеет действующей ссылки для скачивания и не был загружен. \\n\\nПожалуйста, обращайтесь к источнику этого мода для получения любых обновлений и сообщите об этом автору мода.",
			"version_hash": 2446599643
		},
		"HEVLIB_SAVEOPT_FIX_CORRUPTED_CARGO": {
			"string": "Исправить поврежденный груз.",
			"version_hash": 802028065
		},
		"HEVLIB_SAVEOPT_FIX_CORRUPTED_CARGO_TOOLTIP": {
			"string": "Используйте эту функцию, если сохранение не загружается из-за некорректного груза, доставленного в предыдущем рейсе. \\n\\nХарактерный признак — предпоследняя строка файла engine_log.txt: \\n'ERROR: No loader found for resource: res://.' после вылета при возвращении из колец или загрузке сохранения.",
			"version_hash": 885117514
		},
		"HEVLIB_CONFIG_MAX_MODDED_DEALERSHIP_POOLS": {
			"string": "Максимальное количество записей модифицированного дилерского центра",
			"version_hash": 1666179083
		},
		"HEVLIB_CONFIG_MAX_MODDED_DEALERSHIP_POOLS_TOOLTIP": {
			"string": "Максимальное количество пулов модифицированных кораблей, добавленных в список используемых кораблей дилерского центра.\\n\\nЭто обрабатывает только корабли, добавленные через ShipDriver, причем число не\\n увеличивается, если добавлено меньше кораблей, чем это число.",
			"version_hash": 3536264146
		},
		"HEVLIB_SAVEOPT_CLEAR_SOLD_SHIPS": {
			"string": "Очистить кэш проданных кораблей",
			"version_hash": 4176761126
		},
		"HEVLIB_SAVEOPT_CLEAR_SOLD_SHIPS_TOOLTIP": {
			"string": "Очищает все данные, хранящиеся о проданных кораблях. Это используется для исправления проблем с проданными модифицированными кораблями, в которых постоянный корабль-призрак навсегда остается в дилерском центре.",
			"version_hash": 713581652
		},
		"HEVLIB_CONFIG_INPUT_VIRTUALIZATION": {
			"string": "Виртуализация ввода (WIP)",
			"version_hash": 1330041627
		},
		"HEVLIB_CONFIG_INPUT_VIRTUALIZATION_TOOLTIP": {
			"string": "Использует программную систему для обработки ввода вместо игры. Разрешает использование действий привязки нескольких клавиш.",
			"version_hash": 4158244573
		},
		"HEVLIB_CONFIG_INPUT_VIRTUALIZATION_OVERRIDE_BUILTIN": {
			"string": "Игнорировать встроенные привязки",
			"version_hash": 1598156349
		},
		"HEVLIB_CONFIG_INPUT_VIRTUALIZATION_OVERRIDE_BUILTIN_TOOLTIP": {
			"string": "Должна ли виртуализация ввода обрабатывать встроенные в механизм привязки клавиш, даже те, которые не предназначены для повторного привязки.",
			"version_hash": 4016249648
		},
		"HEVLIB_OPT_MODPACKS": {
			"string": "Модпаки",
			"version_hash": 3714458839
		},
		"HEVLIB_MODPACKS IMPORT": {
			"string": "Импорт модпаков",
			"version_hash": 126074482
		},
		"HEVLIB_MODPACKS EXPORT": {
			"string": "Экспорт модпаков",
			"version_hash": 103317849
		},
		"HEVLIB_APPLICABLE_MODS": {
			"string": "Модпаки, совместимые с модпаками",
			"version_hash": 476877116
		},
		"HEVLIB_SAVE_MODPACK": {
			"string": "Сохранить модпак",
			"version_hash": 1264474579
		},
		"HEVLIB_OPEN_MODPACK": {
			"string": "Открыть модпак",
			"version_hash": 732682486
		},
		"HEVLIB_MODPACK_LIMITATIONS": {
			"string": "Модпаки не могут включать моды без манифеста, отформатированного как минимум до MV2.2 и иметь как ссылку на репозиторий GitHub, так и манифест URL.",
			"version_hash": 2148121562
		},
		"HEVLIB_MODPACK_TOGGLE": {
			"string": "Включить этот мод в экспортированный пакет модов?",
			"version_hash": 909574562
		},
		"HEVLIB_MODPACK_DOWNLOADING": {
			"string": "Пожалуйста, подождите... \\n\\nЗагрузка мода %02d из %02d \\n%s [%s]\\n\\n(%s моды пропущены.)",
			"version_hash": 640450355
		},
		"HEVLIB_CONFIG_CARGO_SCANNER_DISPLAY_LIMIT": {
			"string": "Ограничение отображения минералов в сканере груза",
			"version_hash": 3554924120
		},
		"HEVLIB_CONFIG_CARGO_SCANNER_DISPLAY_LIMIT_TOOLTIP": {
			"string": "Сколько записей о минералах разрешено отображать в любом списке сканера необработанных минералов.\\nЭто включает только минералы и пропускает пустое пространство, оборудование, \\n и неопознанные записи.",
			"version_hash": 886148855
		},
		"TAG_ADD_TRANSIT_TIPS": {
			"string": "Добавляет подсказки по транзиту",
			"version_hash": 3276505670
		},
		"EVENTDRIVER_ENABLE_ALL": {
			"string": "Включить все события",
			"version_hash": 987521466
		},
		"EVENTDRIVER_DISABLE_ALL": {
			"string": "Отключить все события",
			"version_hash": 1138158759
		},
		"HEVLIB_GITHUBMODS_TITLE": {
			"string": "Доступные моды",
			"version_hash": 2637865945
		},
		"HEVLIB_GITHUBMODS_COUNT": {
			"string": "%d доступны",
			"version_hash": 913247151
		},
		"HEVLIB_CONFIG_PROCESSED_MINERAL_DISPLAY_LIMIT": {
			"string": "Предел отображения полезных ископаемых переработанного груза",
			"version_hash": 2547578582
		},
		"HEVLIB_CONFIG_PROCESSED_MINERAL_DISPLAY_LIMIT_TOOLTIP": {
			"string": "Сколько записей о минералах может появиться в любое время в списке обработанной руды.\\nЭтот дисплей циклически переключается по страницам после превышения лимита, поэтому могут быть показаны все минералы.",
			"version_hash": 1369356988
		},
		"HEVLIB_TRANSIT_TIP_18": {
			"string": "Хотите увидеть несколько руд в одном куске минерала или настроить другие параметры минерала? Проверьте вкладку «Драйверы» в конфигурации HevLib.",
			"version_hash": 2874849155
		},
		"HEVLIB_TRANSIT_TIP_19": {
			"string": "Хотите настроить вероятность появления модифицированных кораблей у дилера? Проверьте вкладку «Драйверы» в конфигурации HevLib.",
			"version_hash": 809628308
		},
		"HEVLIB_TRANSIT_TIP_20": {
			"string": "Хотите контролировать определенные изменения в оборудовании, например сортировку слотов или ограничения сканера минералов? Проверьте раздел «Оборудование» в конфигурации HevLib.",
			"version_hash": 186912265
		},
		"HEVLIB_TRANSIT_TIP_21": {
			"string": "Возникли проблемы с управлением кораблем? Рассмотрите возможность замены двигателей или автопилота, а также настройте мощность тяги и параметры автопилота!",
			"version_hash": 841163575
		},
		"HEVLIB_TRANSIT_TIP_22": {
			"string": "Определенное оборудование может работать без дополнительной настройки только на предназначенных для него судах. Если у вас возникли проблемы с конкретным элементом оборудования, возможно, попробуйте соответствующий корабль?",
			"version_hash": 2483296260
		},
		"HEVLIB_TRANSIT_TIP_23": {
			"string": "Вы можете отсортировать порядок любых модов, отображаемых в списке DLC в разделе «Драйверы» в HevLib.",
			"version_hash": 1367355062
		},
		"HEVLIB_TRANSIT_TIP_24": {
			"string": "Устали от майнинга? Есть множество способов заработать деньги другими способами.",
			"version_hash": 3573113157
		},
		"HEVLIB_TRANSIT_TIP_25": {
			"string": "Магазины массовых драйверов и компоненты нанодронов ограничены скоростью доставки в их хранилище.",
			"version_hash": 2903300490
		},
		"HEVLIB_TRANSIT_TIP_26": {
			"string": "На вкладке «Геолог» предусмотрена полоса прокрутки, которая помогает просматривать длинные названия оборудования и/или списки полезных ископаемых.",
			"version_hash": 1092699375
		},
		"EVENTDRIVER_LEGACY": {
			"string": "Использовать устаревший обработчик появления?",
			"version_hash": 2630802733
		},
		"EVENTDRIVER_INJECT": {
			"string": "Внести странность?",
			"version_hash": 548009294
		},
		"EVENTDRIVER_SPAWNER_CONTROLS": {
			"string": "Создать элементы управления событиями",
			"version_hash": 383031684
		},
		"EVENTDRIVER_CLEARER_CONTROLS": {
			"string": "Очистить элементы управления событиями",
			"version_hash": 3681275490
		},
		"EVENTDRIVER_CLEAR_POI": {
			"string": "Очистить связанные POI",
			"version_hash": 3673548405
		},
		"EVENTDRIVER_CLEAR_POI_TOOLTIP": {
			"string": "POI- события создают местоположение внутри кэша астронавигации и возобновятся при нормальной очистке. \\n\\nЭтот переключатель удалит POI для события, если оно находится поблизости.",
			"version_hash": 2980544907
		},
		"EVENTDRIVER_CLEAR_CARGO": {
			"string": "Освободили груз?",
			"version_hash": 3991202254
		},
		"EVENTDRIVER_EVENTS_TOOLTIP": {
			"string": "Желаемое событие для создания/очистки\\n\\\"none\\\" - создать случайное событие/очистить все события",
			"version_hash": 2910940133
		},
		"EVENTDRIVER_TIMER_TOOLTIP": {
			"string": "Время между появлением событий в секундах.",
			"version_hash": 1166419779
		},
		"EVENTDRIVER_SPAWNNOW_TOOLTIP": {
			"string": "Создает выбранное событие.\\nЕсли выбрано \\\"none\\\", порождает случайное событие",
			"version_hash": 2314890076
		},
		"EVENTDRIVER_LEGACY_TOOLTIP": {
			"string": "Используйте очень старую систему с использованием testSpecificStoryElement для создания события",
			"version_hash": 555589987
		},
		"EVENTDRIVER_INJECT_TOOLTIP": {
			"string": "Размещайте объекты события непосредственно в кольце. \\nЭто обходит стандартный механизм создания событий и может вызвать сбои",
			"version_hash": 324336902
		},
		"EVENTDRIVER_CLEAREVENT_TOOLTIP": {
			"string": "Удаляет все события выбранного типа.\\nЕсли выбрано \\\"none\\\", очищаются все события",
			"version_hash": 30519526
		},
		"EVENTDRIVER_CLEAR_CARGO_TOOLTIP": {
			"string": "Если выбрано, также удаляются все странности, непосредственно порожденные событием, которые находятся внутри вашего груза бухта.",
			"version_hash": 917771176
		},
		"HEVLIB_DOWNLOAD_MOD": {
			"string": "Скачать мод!",
			"version_hash": 570592894
		},
		"MODMENU_MOD_UNAVAILABLE": {
			"string": "Этот мод в настоящее время недоступен. Это может быть связано с несколькими причинами, включая, помимо прочего: \\n\\n- GitHub была ограничена по скорости (вероятно, слишком много запросов)\\n- Проблемы с подключением к Интернету\\n- Мод не имеет правильной настройки загрузки",
			"version_hash": 3639564067
		},
		"HEVLIB_CONFIG_FULL_LOGGING": {
			"string": "Полное журналирование",
			"version_hash": 2478639519
		},
		"HEVLIB_CONFIG_FULL_LOGGING_TOOLTIP": {
			"string": "Есть ли потенциально многословная информация Функции HevLib должны создавать дополнительные журналы",
			"version_hash": 3570790396
		},
		"MODMENU_GET_NEW_MODS": {
			"string": "Получить новые моды из GitHub",
			"version_hash": 2573811993
		},
		"HEVLIB_MM_TOOLTIP_LANGUAGE_ENTRY": {
			"string": "%s: %s",
			"version_hash": 1718567247
		},
		"HEVLIB_SUPPORTED_LANGUAGES": {
			"string": "Поддерживаемые языки/завершение %:",
			"version_hash": 31187306
		},
		"HEVLIB_CONFIG_SECTION_KEYMAPPING": {
			"string": "Раскладка клавиш",
			"version_hash": 3052849914
		},
		"HEVLIB_MODMENU_CANNOT_RESTART": {
			"string": "В настоящее время в кольцах.\\nПерезапустите вручную.",
			"version_hash": 3242006044
		},
		"HEVLIB_CONFIG_UNRESTRICTED_AMMO_OUTPUT": {
			"string": "Удаляет ограничения на доставку боеприпасов.",
			"version_hash": 537716554
		},
		"HEVLIB_CONFIG_UNRESTRICTED_AMMO_OUTPUT_TOOLTIP": {
			"string": "Возвращает поведение магазина боеприпасов до версии 1.64.14,\\n, без ограничений на скорость доставки боеприпасов\\n к оборудованию.",
			"version_hash": 1708599757
		},
		"HEVLIB_SETTING_REQUIRES_RESTART": {
			"string": "NOTICE: после изменения этого параметра требуется перезагрузка.",
			"version_hash": 1236302953
		},
		"HEVLIB_MODMENU_MODNAME_DISABLED": {
			"string": "(отключено)",
			"version_hash": 3167290830
		},
		"HEVLIB_MODLET_ENABLED": {
			"string": "Включено?",
			"version_hash": 644251567
		},
		"HEVLIB_MODMENU_MODNAME_ENABLED_NEEDS_RESTART": {
			"string": "(включено, требуется перезагрузка)",
			"version_hash": 1899921857
		},
		"HEVLIB_MODMENU_MODNAME_DISABLED_NEEDS_RESTART": {
			"string": "(отключено, требуется перезагрузка)",
			"version_hash": 2601371502
		},
		"MODMENU2_TRANSIT_TIP_1": {
			"string": "Пакеты модов упрощают обмен модами! Создайте или импортируйте их в меню модов.",
			"version_hash": 2128454254
		},
		"MODMENU2_TRANSIT_TIP_2": {
			"string": "Хотите попробовать новые конфигурации, не меняя текущие настройки? Создайте новый профиль конфигурации, чтобы легко переключаться на предпочитаемые вами настройки.",
			"version_hash": 331405958
		},
		"MODMENU2_TRANSIT_TIP_3": {
			"string": "Хотите новые моды и не хотите искать их в Интернете? Проверьте меню загрузчика GitHub!",
			"version_hash": 2668803293
		},
		"HEVLIB_MODMENU_MODLET_TOGGLE_TOOLTIP": {
			"string": "Переключает, включен ли этот модлет.\\n\\n (требуется перезапуск игры)",
			"version_hash": 3820371863
		},
		"HEVLIB_MODMENU_MODLET_TOGGLE_MM2FALLBACK": {
			"string": "Невозможно переключить ModMenu2.\\n\\nZip необходимо удалить вручную или \\nпереключить непосредственно в файле конфигурации.",
			"version_hash": 915722318
		},
		"MODMENU2_CHANGELOG_SPACING_SIZE": {
			"string": "Размер интервала журнала изменений",
			"version_hash": 3748345741
		},
		"MODMENU2_CHANGELOG_SPACING_SIZE_TOOLTIP": {
			"string": "Пробелы, размещаемые в каждом отступе для подраздела журнала изменений",
			"version_hash": 1698732061
		},
		"HEVLIB_CONFIG_POINTER_LOGGING_FRAME_INTERVAL": {
			"string": "Интервал регистрации указателя (физические кадры)",
			"version_hash": 346203813
		},
		"HEVLIB_CONFIG_POINTER_LOGGING_FRAME_INTERVAL_TOOLTIP": {
			"string": "Количество физических кадров между автоматическими записями в журнал указателя\\n (т. е. информация, регистрируемая специально модами в кэш)\\n\\nЭто зависит от вашей текущей частоты кадров в физике",
			"version_hash": 515481480
		},
		"HEVLIB_CONFIG_EXTEND_DIVIDED_STORAGE_MULTIPLIER": {
			"string": "Увеличить вместимость секционных хранилищ",
			"version_hash": 3830358193
		},
		"HEVLIB_CONFIG_EXTEND_DIVIDED_STORAGE_MULTIPLIER_TOOLTIP": {
			"string": "Определяет, должна ли вместимость переработанного груза, добавляемая оборудованием через драйвер MODIFY_INTERNALS, автоматически меняться в зависимости от количества видов минералов в кольцах.\\n\\nЕсли параметр отключён, расчёт выполняется для шести минералов из основной игры.",
			"version_hash": 759404083
		},
		"HEVLIB_CONFIG_MAX_DEALERSHIP_MODIFICATION_ROLLS": {
			"string": "Максимальное количество бросков для корректировки снаряжения нового корабля",
			"version_hash": 3469313118
		},
		"HEVLIB_CONFIG_MAX_DEALERSHIP_MODIFICATION_ROLLS_TOOLTIP": {
			"string": "Сколько раз новый корабль может иметь изменения в своей базовой комплектации.\\n\\nМаксимум будет зависеть от количества, добавленного другими модами с MODIFY_SHIP_BUILDS.gd.",
			"version_hash": 2944029967
		},
		"HEVLIB_CONFIG_DEALERSHIP_MODIFICATION_ROLL_CHANCE_SCALE": {
			"string": "Корректировка шанса модификации корабля",
			"version_hash": 2832891408
		},
		"HEVLIB_CONFIG_DEALERSHIP_MODIFICATION_ROLL_CHANCE_SCALE_TOOLTIP": {
			"string": "Масштабируйте вероятность внесения изменений в конфигурацию корабля с вероятностью \\n для каждой модификации.",
			"version_hash": 543789100
		},
		"HEVLIB_CREDITS_CONTRIBUTORS_HEADER": {
			"string": "   --- Участники ---   ",
			"version_hash": 3641455841
		},
		"HEVLIB_CREDITS_CONTRIBUTORS_ZAKRIN": {
			"string": "Za'krin - Основной дизайн мода, оригинальная реализация updateTL",
			"version_hash": 3828627238
		},
		"HEVLIB_CREDITS_CONTRIBUTORS_SPDX": {
			"string": "spaceDOTexe - Дизайн манифеста, логика ограничения корабля UpgradeGroup",
			"version_hash": 4113957048
		},
		"HEVLIB_CREDITS_CONTRIBUTORS_1WT1": {
			"string": "WT - Конфигурации для SHIP_NODE_MODIFY",
			"version_hash": 4219071341
		},
		"HEVLIB_CREDITS_SUPPORTERS_HEADER": {
			"string": "   --- Сторонники ---   ",
			"version_hash": 1704348250
		},
		"HEVLIB_CREDITS_SUPPORTERS_KOFI_GAZI": {
			"string": "GAZI - сторонник (ко-фи)",
			"version_hash": 4085861848
		},
		"HEVLIB_CREDITS_SUPPORTERS_KOFI_BAGGERDUDE": {
			"string": "Bagger dude - сторонник (ко-фи)",
			"version_hash": 2887391095
		},
		"HEVLIB_CREDITS_SUPPORTERS_KOFI_1WT1": {
			"string": "WT - сторонник (ко-фи)",
			"version_hash": 3531547864
		},
		"HEVLIB_DEV_PUSH": {
			"string": "Опубликовать обновления модов",
			"version_hash": 4122676635
		},
		"HEVLIB_DEV_PUSH_CONFIRM": {
			"string": "Вы уверены, что хотите выпускать обновления для своих модов?",
			"version_hash": 3051814466
		},
		"HEVLIB_CONFIG_DEV_ALWAYS_SEND_NEW_MODS": {
			"string": "Отправлять новую информацию о модах в сборках редактора.",
			"version_hash": 3525213644
		},
		"HEVLIB_CONFIG_DEV_ALWAYS_SEND_NEW_MODS_TOOLTIP": {
			"string": "Должен ли UpdateDB получать информацию о модах, о которых он не знает, в сборках редактора.\\n\\nЭта опция предназначена для разработчиков модов. В релизных сборках игры он ничего не делает.",
			"version_hash": 113417870
		},
		"HEVLIB_CONFIG_SHOW_RINGMAP_OVERLAY": {
			"string": "Показать наложение карты кольца",
			"version_hash": 2186846390
		},
		"HEVLIB_CONFIG_SHOW_RINGMAP_OVERLAY_TOOLTIP": {
			"string": "Переключает видимость наложения карты кольца",
			"version_hash": 1321643511
		},
		"HEVLIB_CONFIG_RINGMAP_HEATMAP": {
			"string": "Преобразовать данные наложения карты кольца в тепловую карту",
			"version_hash": 2108586739
		},
		"HEVLIB_CONFIG_RINGMAP_HEATMAP_TOOLTIP": {
			"string": "Должен ли наложение карты кольца использовать тепловую карту HSV вместо \\n отображения необработанных данных пикселей.\\n\\nНеобработанные данные содержат конкретный канал/индекс для соответствующий метод \\ngetPixelAt() или getTargetDensityAt().",
			"version_hash": 3398779976
		},
		"HEVLIB_CONFIG_RINGMAP_HEATMAP_CLAMP": {
			"string": "Степификация цвета наложения карты кольца",
			"version_hash": 4564075
		},
		"HEVLIB_CONFIG_RINGMAP_HEATMAP_CLAMP_TOOLTIP": {
			"string": "Следует ли ограничивать выходной цвет карты кольца шагом 1/20, округляя вниз.\\n\\nЭто происходит конкретно с необработанным значением перед визуализацией, и его лучше всего использовать для определения\\n, когда были достигнуты определенные значения.",
			"version_hash": 3469990629
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_MIN_VALUE": {
			"string": "Минимальное значение карты кольца",
			"version_hash": 2811375820
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_MIN_VALUE_TOOLTIP": {
			"string": "Минимальное значение, которое должно быть достигнуто, чтобы дисплей отображался с полной яркостью.\\n\\nОбласти, которые не прошли проверку, имеют непрозрачность за пределами границ, умноженную на ее текущую непрозрачность.",
			"version_hash": 3861393134
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_MAX_VALUE": {
			"string": "Максимальное значение карты кольца",
			"version_hash": 414329998
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_MAX_VALUE_TOOLTIP": {
			"string": "Максимальное значение, которое должно быть достигнуто, чтобы отобразить дисплей с полной яркостью.\\n\\nОбласти, которые не прошли проверку, имеют непрозрачность за пределами границ, умноженную на ее текущую непрозрачность",
			"version_hash": 2602012528
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_OPACITY": {
			"string": "Непрозрачность карты кольца",
			"version_hash": 1582996684
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_OPACITY_TOOLTIP": {
			"string": "Базовая непрозрачность наложения карты кольца",
			"version_hash": 4040631661
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_OOB_OPACITY": {
			"string": "Карта кольца выходит за пределы непрозрачности",
			"version_hash": 2317746276
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_OOB_OPACITY_TOOLTIP": {
			"string": "Множитель непрозрачности для любых значений наложения, выходящих за пределы заданного \\nминимального и максимального значения",
			"version_hash": 1226795897
		},
		"HEVLIB_CONFIG_RINGMAP_DISPLAY_MODE": {
			"string": "Режим отображения наложения карты кольца",
			"version_hash": 2985551792
		},
		"HEVLIB_CONFIG_RINGMAP_DISPLAY_MODE_TOOLTIP": {
			"string": "Какой визуализатор в настоящее время использует карта кольца.\\n\\n* Хаос — отображает значение хаоса кольца. (красный канал getPixelAt())\\n* Смещение размера — отображает значение смещения размера рингроида. (зелёный канал getPixelAt())\\n* Необработанная плотность — отображает необработанное значение плотности. (синий канал getPixelAt())\\n* Плотность класса 1 — отображает плотность C1 (самых крупных) рингроидов. (getTargetDensityAt() индекс 0)\\n* Плотность класса 2 — отображает плотность рингроидов C2. (getTargetDensityAt() индекс 1)\\n* Плотность класса 3 — отображает плотность рингроидов C3. (getTargetDensityAt() index 2)\\n* Плотность класса 4 — отображает плотность рингроидов C4. (getTargetDensityAt() index 3)\\n* Плотность класса 5 — отображает плотность C6 (наименьших) рингроидов. (индекс getTargetDensityAt() 4)\\n* Самый распространенный размер рингроида — отображает наиболее распространенный размер рингроида в области.\\n Чем ярче область, тем больше распространенность рингроида.",
			"version_hash": 869282124
		},
		"HEVLIB_CONFIG_RINGMAP_DISPLAY_MODE_CHAOS": {
			"string": "Хаос",
			"version_hash": 217455795
		},
		"HEVLIB_CONFIG_RINGMAP_DISPLAY_MODE_BIAS": {
			"string": "Смещение размера",
			"version_hash": 986321567
		},
		"HEVLIB_CONFIG_RINGMAP_DISPLAY_MODE_RAWDENSITY": {
			"string": "Чистая плотность",
			"version_hash": 3733987279
		},
		"HEVLIB_CONFIG_RINGMAP_DISPLAY_MODE_DENSITY_C1": {
			"string": "Плотность класса 1",
			"version_hash": 2812853740
		},
		"HEVLIB_CONFIG_RINGMAP_DISPLAY_MODE_DENSITY_C2": {
			"string": "Плотность класса 2",
			"version_hash": 472198893
		},
		"HEVLIB_CONFIG_RINGMAP_DISPLAY_MODE_DENSITY_C3": {
			"string": "Плотность класса 3",
			"version_hash": 2426511342
		},
		"HEVLIB_CONFIG_RINGMAP_DISPLAY_MODE_DENSITY_C4": {
			"string": "Плотность класса 4",
			"version_hash": 85856495
		},
		"HEVLIB_CONFIG_RINGMAP_DISPLAY_MODE_DENSITY_C5": {
			"string": "Плотность класса 5",
			"version_hash": 2040168944
		},
		"HEVLIB_CONFIG_RINGMAP_DISPLAY_MODE_DENSITY_MOST_PREVALENT": {
			"string": "Наиболее распространенный размер рингроида",
			"version_hash": 609523250
		},
		"HEVLIB_CONFIG_TOGGLE_RINGMAP_OVERLAY": {
			"string": "Переключение наложения карты кольца",
			"version_hash": 2000092087
		},
		"HEVLIB_CONFIG_TOGGLE_RINGMAP_OVERLAY_TOOLTIP": {
			"string": "Клавиши, используемые для переключения наложения карты кольца",
			"version_hash": 4280819030
		},
		"HEVLIB_CONFIG_TOGGLE_RINGMAP_OVERLAY_HEATMAP": {
			"string": "Переключить отображение тепловой карты карты кольца",
			"version_hash": 2570144278
		},
		"HEVLIB_CONFIG_TOGGLE_RINGMAP_OVERLAY_HEATMAP_TOOLTIP": {
			"string": "Клавиши, используемые для переключения того, использует ли карта кольца тепловую карту",
			"version_hash": 3603998316
		},
		"HEVLIB_CONFIG_TOGGLE_RINGMAP_OVERLAY_HEATMAP_CLAMP": {
			"string": "Переключение шага значений тепловой карты кольцевой карты",
			"version_hash": 459047484
		},
		"HEVLIB_CONFIG_TOGGLE_RINGMAP_OVERLAY_HEATMAP_CLAMP_TOOLTIP": {
			"string": "Клавиши, используемые для переключения того, имеет ли тепловая карта кольцевой карты фиксированные значения.",
			"version_hash": 2375962285
		},
		"HEVLIB_CONFIG_CYCLE_RINGMAP_OVERLAY_MODE": {
			"string": "Циклический режим наложения карты кольца",
			"version_hash": 3781027242
		},
		"HEVLIB_CONFIG_CYCLE_RINGMAP_OVERLAY_MODE_TOOLTIP": {
			"string": "Клавиши, используемые для переключения между режимами наложения карты кольца. \\n\\nПроверьте режим отображения наложения карты отладки/кольца, какие режимы что делают.",
			"version_hash": 2873646839
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_MIN_VALUE_UP": {
			"string": "Увеличение минимального значения наложения карты кольца.",
			"version_hash": 2310825944
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_MIN_VALUE_UP_TOOLTIP": {
			"string": "Клавиши, используемые для увеличения минимального значения наложения карты кольца.",
			"version_hash": 1532744479
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_MIN_VALUE_DOWN": {
			"string": "Уменьшить минимальное значение наложения карты кольца.",
			"version_hash": 380670570
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_MIN_VALUE_DOWN_TOOLTIP": {
			"string": "Клавиши, используемые для уменьшения минимального значения наложения карты кольца.",
			"version_hash": 2833586929
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_MAX_VALUE_UP": {
			"string": "Увеличение максимального значения наложения карты кольца",
			"version_hash": 935367002
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_MAX_VALUE_UP_TOOLTIP": {
			"string": "Клавиши, используемые для увеличения максимального значения наложения карты кольца",
			"version_hash": 781650721
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_MAX_VALUE_DOWN": {
			"string": "Уменьшить максимальное значение наложения карты кольца",
			"version_hash": 3300178924
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_MAX_VALUE_DOWN_TOOLTIP": {
			"string": "Клавиши, используемые для уменьшения максимального значения наложения карты кольца",
			"version_hash": 2082493171
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_OPACITY_UP": {
			"string": "Увеличьте непрозрачность карты кольца",
			"version_hash": 1968471254
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_OPACITY_UP_TOOLTIP": {
			"string": "Клавиши, используемые для увеличения непрозрачности наложения карты кольца",
			"version_hash": 1962015821
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_OPACITY_DOWN": {
			"string": "Уменьшить непрозрачность карты кольца",
			"version_hash": 3534073832
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_OPACITY_DOWN_TOOLTIP": {
			"string": "Клавиши, используемые для уменьшения непрозрачности наложения карты кольца",
			"version_hash": 3717483615
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_OOB_OPACITY_UP": {
			"string": "Увеличить непрозрачность карты кольца за пределами границ",
			"version_hash": 3249678830
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_OOB_OPACITY_UP_TOOLTIP": {
			"string": "Клавиши, используемые для увеличения непрозрачности наложения карты кольца за пределами границ",
			"version_hash": 15580581
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_OOB_OPACITY_DOWN": {
			"string": "Уменьшить непрозрачность карты кольца за пределами границ",
			"version_hash": 1319523456
		},
		"HEVLIB_CONFIG_RINGMAP_OVERLAY_OOB_OPACITY_DOWN_TOOLTIP": {
			"string": "Клавиши, используемые для уменьшения непрозрачности за пределами наложения карты кольца",
			"version_hash": 2858534199
		},
		"HEVLIB_CONFIG_SAFE_MOD_LOADING": {
			"string": "Безопасная загрузка модов",
			"version_hash": 1714521282
		},
		"HEVLIB_CONFIG_SAFE_MOD_LOADING_TOOLTIP": {
			"string": "Предотвращает загрузку игры, если мод выполняет небезопасные операции (например, напрямую переопределяет ванильные файлы).\\n\\nРекомендуется оставить эту опцию включенной, чтобы предотвратить проблемы с ванильными и/или другими модами. Примечание. Я буду отклонять отчеты об ошибках, в которых отключен безопасный режим, поскольку вероятная причина проблемы связана с необходимостью его отключения.",
			"version_hash": 2729983956
		},
		"HEVLIB_CREDITS_SUPPORTERS_KOFI_TESSIER": {
			"string": "Tessier-Ashpool SA - сторонник (ко-фи)",
			"version_hash": 2705946943
		},
		"HEVLIB_CREDITS_SOFTWARE_HEADER": {
			"string": "   --- Программное обеспечение ---   ",
			"version_hash": 2827177182
		},
		"HEVLIB_CREDITS_SOFTWARE_JELLE": {
			"string": "jelle — реализация GDUNZIP",
			"version_hash": 784233189
		},
		"HEVLIB_CREDITS_TRANSLATORS_HEADER": {
			"string": "   --- Переводчики ---   ",
			"version_hash": 3211741168
		},
		"HEVLIB_CREDITS_TRANSLATORS_1WT1": {
			"string": "WT - украинские переводы",
			"version_hash": 1851458392
		},
		"HEVLIB_CREDITS_TRANSLATORS_HEDRAUTA": {
			"string": "Хедраута - переводы на немецкий язык",
			"version_hash": 1012571612
		},
		"HEVLIB_CREDITS_TRANSLATORS_NEKO!!": {
			"string": "НеКо!! - Китайские переводы",
			"version_hash": 3552644866
		},
		"HEVLIB_CREDITS_TRANSLATORS_TESSIER": {
			"string": "Tessier-Ashpool S.A. - переводы на китайский язык",
			"version_hash": 2709571237
		},
		"HEVLIB_ERRORCHECK_MISSING_TRANSLATIONS": {
			"string": "Не удалось загрузить переводы HevLib. Это указывает на то, что возникла серьезная проблема, и существует высокая вероятность того, что ваши моды не будут работать.\\n\\nЗакрытие этого всплывающего окна откроет форму отчета об ошибках мода. Пожалуйста, заполните это как можно лучше. Вам нужно будет вручную установить обновление после его выпуска.",
			"version_hash": 655551688
		},
		"HEVLIB_ERRORCHECK_MISSING_VANILLA_LOCALES": {
			"string": "Выход из игры из-за неинициализированного сервера перевода. Вероятно, это вызвано серьезной проблемой с любыми установленными вами модами и/или повреждением файла .PCK Vanilla.",
			"version_hash": 4154468583
		},
		"HEVLIB_FINISH_RESEARCH": {
			"string": "Завершите исследование!",
			"version_hash": 2793565484
		}
	},
	"uk_UA": {
		"HEVLIB_MOD_BRIEF": {
			"string": "Мод-бібліотека, що містить кілька загальних функцій, створених __hev",
			"version_hash": 504726156
		},
		"HEVLIB_MOD_DESCRIPTION": {
			"string": "Бібліотека, що надає кілька функціональних частин:\\n\\n * Загальний функціонал через 'pointer' файли.\\n * Обробка файлів маніфесту модів через версіонування для створення єдиного середовища отримання інформації з них.\\n * EquipmentDriver - Додавання та управління предметами обладнання, слотами тощо...\\n * WeaponSlotDriver - Додавання та модифікація обладнання, що додається до кріплень корабля.\\n\\nЦя бібліотека також має на меті зберегти послідовний метод для полегшення створення модів. Сумісність з модами також є основним фокусом наданого функціоналу.\\n\\nДля отримання додаткової інформації, будь ласка, перевірте вікі цього мода. Якщо у вас є пропозиції чи ідеї, будь ласка, залиште їх у Discord або як issue на GitHub.",
			"version_hash": 1185923833
		},
		"HEVLIB_MOD_ERROR_HEADER": {
			"string": "ПРОБЛЕМИ З МОДОМ %s",
			"version_hash": 3377428377
		},
		"HEVLIB_MOD_ERROR_DEPENDANCY_DIALOGUE_BOX": {
			"string": "Наразі виявлено %s невиконаних залежностей модів. Будь ласка, задовольніть ці вимоги або видаліть моди, які їх потребують: %s",
			"version_hash": 368204025
		},
		"HEVLIB_GENERIC_ERROR_DIALOGUE_BOX": {
			"string": "Щось пішло не так. Будь ласка, перезапустіть гру!",
			"version_hash": 605763982
		},
		"EVENTDRIVER_MENU": {
			"string": "Меню налагодження EventDriver",
			"version_hash": 451113391
		},
		"EVENTDRIVER_EVENTS": {
			"string": "Обрана подія",
			"version_hash": 3337649328
		},
		"EVENTDRIVER_TIMER": {
			"string": "Таймер подій Storyteller",
			"version_hash": 3794017585
		},
		"EVENTDRIVER_SPAWNNOW": {
			"string": "Примусовий спаун події з використанням обраної події",
			"version_hash": 2944227280
		},
		"EVENTDRIVER_EVENT_SELECTOR": {
			"string": "Вибір події",
			"version_hash": 2551222664
		},
		"EVENTDRIVER_CLEAREVENT": {
			"string": "Очистити обрану подію/події",
			"version_hash": 579909883
		},
		"HEVLIB_MISSING_DOCUMENTATION_1": {
			"string": "!!!!! Для цієї функції не надано документації!",
			"version_hash": 3595625429
		},
		"HEVLIB_MISSING_DOCUMENTATION_2": {
			"string": "!!!!! Будь ласка, повідомте мене (__hev) про це ЯКОМОГА ШВИДШЕ, оскільки документація є ключовою для таких бібліотек, як ця, для належної підтримки!",
			"version_hash": 3771196171
		},
		"HEVLIB_DESCRIPTION_PLACEHOLDER": {
			"string": "Цей мод не має опису. \\n\\nБудь ласка, перевірте веб-сторінку або гілку форуму, де ви отримали цей мод, для інформації, або запитайте опис у автора.",
			"version_hash": 3310358705
		},
		"HEVLIB_SELF_CHECK_ERROR_MESSAGE": {
			"string": "HevLib встановлено неправильно. Будь ласка, перевірте джерело завантаження та переконайтеся, що коренева папка виглядає наступним чином: HevLib.zip/HevLib/\\n\\nНатискання OK закриє гру та відкриє сторінку останнього релізу у вашому браузері.",
			"version_hash": 3685656617
		},
		"HEVLIB_SELF_CHECK_ERROR_HEADER": {
			"string": "ПОМИЛКА ЗАВАНТАЖЕННЯ HEVLIB!",
			"version_hash": 1761231146
		},
		"HEVLIB_INCORRECT_SHIP": {
			"string": "(ПОМИЛКА!) Відсутній тип судна: '%s'\\nЦе збереження не може бути відкрито, оскільки активне судно недоступне!\\nЩоб завантажити це збереження, будь ласка, перевстановіть мод, що містить цей тип судна!",
			"version_hash": 3862475614
		},
		"HEVLIB_SLOT": {
			"string": "Слот",
			"version_hash": 2089577767
		},
		"HEVLIB_MOD_MENU": {
			"string": "Меню модів",
			"version_hash": 3618868698
		},
		"HEVLIB_MISSING_MOD_NAME": {
			"string": "Назва мода недоступна :(",
			"version_hash": 132557580
		},
		"HEVLIB_MISSING_DESCRIPTION": {
			"string": "Цей мод не має опису :( \\n\\nБудь ласка, перевірте веб-сторінку або гілку форуму, де ви отримали цей мод, для інформації, або запитайте опис у автора.",
			"version_hash": 3469973573
		},
		"HEVLIB_AUTHOR": {
			"string": "Автор:",
			"version_hash": 2829231346
		},
		"HEVLIB_CREDITS": {
			"string": "Подяки:",
			"version_hash": 2336438541
		},
		"HEVLIB_UNKNOWN": {
			"string": "Невідомо",
			"version_hash": 2604381749
		},
		"HEVLIB_MM_TOOLTIP_HEADER": {
			"string": "Інформація про мод:",
			"version_hash": 2393777861
		},
		"HEVLIB_MM_TOOLTIP_ID": {
			"string": "ID мода: %s",
			"version_hash": 2265364772
		},
		"HEVLIB_MM_TOOLTIP_MV": {
			"string": "Версія маніфесту: %s",
			"version_hash": 2561429428
		},
		"HEVLIB_MM_TOOLTIP_ZIP": {
			"string": "Zip-файл: %s",
			"version_hash": 3308902826
		},
		"HEVLIB_MM_TOOLTIP_LIBRARY": {
			"string": "Бібліотека: %s \\ Завжди відображати: %s",
			"version_hash": 1617363745
		},
		"HEVLIB_MM_BUTTON_TOOLTIP_GITHUB": {
			"string": "Сторінка мода на Github",
			"version_hash": 60488389
		},
		"HEVLIB_MM_BUTTON_TOOLTIP_DISCORD": {
			"string": "Гілка мода в Discord",
			"version_hash": 87679173
		},
		"HEVLIB_MM_BUTTON_TOOLTIP_NEXUS": {
			"string": "Сторінка Nexus mods",
			"version_hash": 3775372648
		},
		"HEVLIB_MM_BUTTON_TOOLTIP_DONATIONS": {
			"string": "Пожертвувати проекту",
			"version_hash": 362649787
		},
		"HEVLIB_MM_BUTTON_TOOLTIP_WIKI": {
			"string": "Вікі-сторінка мода",
			"version_hash": 1350544086
		},
		"HEVLIB_MM_BUTTON_TOOLTIP_BUGREPORTS": {
			"string": "Повідомити про помилку",
			"version_hash": 1392941888
		},
		"HEVLIB_MM_BUTTON_TOOLTIP_CUSTOM": {
			"string": "Більше...",
			"version_hash": 909612738
		},
		"HEVLIB_VANILLA_DESCRIPTION": {
			"string": "Симулятор видобутку на основі фізики, дія якого відбувається в найгустішому полі уламків у Сонячній системі. Кожна дія має протидію, лазери невидимі без середовища, а ваша тяга є потужною зброєю. Знаходьте торгівлю, адаптуйте обладнання до свого стилю гри, наймайте екіпаж для допомоги. Розкривайте таємниці кілець або просто багатійте.",
			"version_hash": 3302886100
		},
		"HEVLIB_VANILLA_BRIEF": {
			"string": "Оригінальна гра",
			"version_hash": 108259687
		},
		"HEVLIB_MODMENU_MODS": {
			"string": "Моди",
			"version_hash": 2089365048
		},
		"HEVLIB_MODMENU_OK": {
			"string": "Гаразд",
			"version_hash": 5862623
		},
		"HEVLIB_MODMENU_CLOSE": {
			"string": "Закрити",
			"version_hash": 217614907
		},
		"HEVLIB_MODMENU_OPENFOLDER": {
			"string": "Відкрити папку модів",
			"version_hash": 1431776550
		},
		"HEVLIB_MODMENU_MODS_VISIBLE": {
			"string": "Відображається %d модів",
			"version_hash": 2827411840
		},
		"HEVLIB_DROP_FILES_TO_ADD_MODS": {
			"string": "Перетягніть файли у це вікно, щоб додати моди.\\nФайли з однаковими назвами будуть перезаписані",
			"version_hash": 1054825256
		},
		"HEVLIB_MODMENU_VER_AND_PRIO": {
			"string": "Версія: v%s / Пріоритет: %s",
			"version_hash": 2055836630
		},
		"HEVLIB_MODMENU_PRIO": {
			"string": "Пріоритет: %s",
			"version_hash": 293290073
		},
		"HEVLIB_MODMENU_VERSION": {
			"string": "Версія: v%s",
			"version_hash": 3570940819
		},
		"HEVLIB_MODMENU_PRIO_MID_HEADER": {
			"string": "ID та пріоритет мода",
			"version_hash": 3551428199
		},
		"HEVLIB_GITHUB": {
			"string": "GitHub",
			"version_hash": 3039441928
		},
		"HEVLIB_DISCORD": {
			"string": "Discord",
			"version_hash": 1937677677
		},
		"HEVLIB_NEXUS": {
			"string": "Nexusmods",
			"version_hash": 3566644875
		},
		"HEVLIB_DONATIONS": {
			"string": "Зробити пожертву",
			"version_hash": 2458561600
		},
		"HEVLIB_WIKI": {
			"string": "Вікі",
			"version_hash": 2089718105
		},
		"HEVLIB_BUGREPORTS": {
			"string": "Повідомити про помилку",
			"version_hash": 1392941888
		},
		"HEVLIB_GITHUB_TOOLTIP": {
			"string": "Репозиторій GitHub для цього проекту",
			"version_hash": 1410097863
		},
		"HEVLIB_DISCORD_TOOLTIP": {
			"string": "Гілка/канал/сервер Discord для цього проекту",
			"version_hash": 281037778
		},
		"HEVLIB_NEXUS_TOOLTIP": {
			"string": "Сторінка Nexusmods для цього проекту",
			"version_hash": 2831875367
		},
		"HEVLIB_DONATIONS_TOOLTIP": {
			"string": "Пожертвувати цьому проекту",
			"version_hash": 362649787
		},
		"HEVLIB_WIKI_TOOLTIP": {
			"string": "Вікі-сторінка(и) для цього проекту",
			"version_hash": 1482974745
		},
		"HEVLIB_BUGREPORTS_TOOLTIP": {
			"string": "Повідомити про помилку через посилання проекту на звіти",
			"version_hash": 4054124463
		},
		"HEVLIB_FILTER_BY_TAGS": {
			"string": "Фільтрувати моди за тегами",
			"version_hash": 464171496
		},
		"HEVLIB_SETTINGS_BUTTON_TOOLTIP": {
			"string": "Відкрити меню налаштувань",
			"version_hash": 4289380645
		},
		"HEVLIB_LINKS_BUTTON": {
			"string": "Посилання",
			"version_hash": 228179046
		},
		"HEVLIB_BUGREPORTS_BUTTON": {
			"string": "Звіти про помилки",
			"version_hash": 3349318290
		},
		"HEVLIB_LINKS_TOOLTIP": {
			"string": "Відобразити посилання проекту",
			"version_hash": 466114574
		},
		"TAG_ALLOW_ACHIEVEMENTS": {
			"string": "Дозволяє досягнення",
			"version_hash": 1786747123
		},
		"TAG_QOL": {
			"string": "QoL",
			"version_hash": 2157051683
		},
		"TAG_VISUAL": {
			"string": "Візуальні",
			"version_hash": 3626485241
		},
		"TAG_FUN": {
			"string": "Розважальні",
			"version_hash": 193457198
		},
		"TAG_UI": {
			"string": "Інтерфейс користувача (UI)",
			"version_hash": 1251064324
		},
		"TAG_ADDS_SHIPS": {
			"string": "Додає нові кораблі",
			"version_hash": 10555442
		},
		"TAG_ADDS_EQUIPMENT": {
			"string": "Додає нове обладнання",
			"version_hash": 153230275
		},
		"TAG_ADDS_GAMEPLAY_MECHANICS": {
			"string": "Додає нові ігрові механіки",
			"version_hash": 1112044006
		},
		"TAG_ADDS_EVENTS": {
			"string": "Додає нові події в кільцях",
			"version_hash": 1474324656
		},
		"TAG_HANDLE_EXTRA_CREW": {
			"string": "Обробляє додатковий екіпаж",
			"version_hash": 1697697785
		},
		"HEVLIB_TAG_FILTER": {
			"string": "Фільтрувати моди за тегом",
			"version_hash": 1706022613
		},
		"HEVLIB_VANILLA_STEAM_STORE": {
			"string": "Steam",
			"version_hash": 236865663
		},
		"HEVLIB_VANILLA_STEAM_STORE_TOOLTIP": {
			"string": "Відкриває сторінку гри в Steam",
			"version_hash": 3542265316
		},
		"HEVLIB_VANILLA_ITCH_STORE": {
			"string": "itch.io",
			"version_hash": 2888975475
		},
		"HEVLIB_VANILLA_ITCH_STORE_TOOLTIP": {
			"string": "Відкриває сторінку гри на itch.io",
			"version_hash": 2978883672
		},
		"HEVLIB_VANILLA_EPIC_STORE": {
			"string": "Epic Games",
			"version_hash": 1050618451
		},
		"HEVLIB_VANILLA_EPIC_STORE_TOOLTIP": {
			"string": "Відкриває сторінку гри в Epic Games",
			"version_hash": 2631198840
		},
		"HEVLIB_VANILLA_GOG_STORE": {
			"string": "GOG",
			"version_hash": 193456994
		},
		"HEVLIB_VANILLA_GOG_STORE_TOOLTIP": {
			"string": "Відкриває сторінку гри в GOG",
			"version_hash": 3604779527
		},
		"HEVLIB_CONFIG_SORT_BY_PRICE": {
			"string": "Сортувати обладнання за ціною",
			"version_hash": 3049697875
		},
		"HEVLIB_CONFIG_SORT_BY_PRICE_TOOLTIP": {
			"string": "Примусово сортує обладнання за ціною. Порушить сортування допоміжних (AUX) модулів за типом, але запобігає проблемам з модованим обладнанням.",
			"version_hash": 3695605117
		},
		"HEVLIB_CONFIG_SORT_SLOT_BY_TYPE": {
			"string": "Сортувати слоти за типом",
			"version_hash": 2003290207
		},
		"HEVLIB_CONFIG_SORT_SLOT_BY_TYPE_TOOLTIP": {
			"string": "Сортує слоти за подібністю. Запобігає довільному сортуванню модованих слотів.",
			"version_hash": 820864655
		},
		"HEVLIB_CONFIG_USE_LEGACY_EQUIPMENT_HANDLING": {
			"string": "Використовувати застарілу обробку обладнання",
			"version_hash": 1321146980
		},
		"HEVLIB_CONFIG_USE_LEGACY_EQUIPMENT_HANDLING_TOOLTIP": {
			"string": "Вмикає обробку обладнання як до версії 1.7. Використовуйте лише для старих модів, які не працюють з новою системою. Не очікуйте, що це спрацює для більшості модів.",
			"version_hash": 1725865707
		},
		"HEVLIB_CONFIG_WRITE_EVENTS": {
			"string": "Записувати назви подій",
			"version_hash": 924663846
		},
		"HEVLIB_CONFIG_WRITE_EVENTS_TOOLTIP": {
			"string": "Записує до кеш-файлу, розташованого в user://cache/.HevLib_Cache/current_events.txt, який містить усі події, завантажені грою на момент завантаження кілець.",
			"version_hash": 4263193676
		},
		"HEVLIB_CONFIG_SHOW_HIDDEN_LIBRARIES": {
			"string": "Показувати приховані бібліотеки",
			"version_hash": 342727087
		},
		"HEVLIB_CONFIG_SHOW_HIDDEN_LIBRARIES_TOOLTIP": {
			"string": "Робить видимою будь-яку бібліотеку без тегу always display.",
			"version_hash": 3751304199
		},
		"HEVLIB_CONFIG_INPUT_DEBUGGER": {
			"string": "Налагоджувач вводу",
			"version_hash": 1682321818
		},
		"HEVLIB_CONFIG_INPUT_DEBUGGER_TOOLTIP": {
			"string": "Відображає інформацію налагодження про поточний ввід.",
			"version_hash": 688163626
		},
		"HEVLIB_CONFIG_EVENT_DEBUGGER": {
			"string": "Налагоджувач подій",
			"version_hash": 843030316
		},
		"HEVLIB_CONFIG_EVENT_DEBUGGER_TOOLTIP": {
			"string": "Відкриває ключові події та відображає, активні вони чи неактивні.",
			"version_hash": 297150667
		},
		"HEVLIB_CONFIG_POSITION_DATA_DEBUGGER": {
			"string": "Налагоджувач даних позиції",
			"version_hash": 710020793
		},
		"HEVLIB_CONFIG_POSITION_DATA_DEBUGGER_TOOLTIP": {
			"string": "Відображає поточний хаос та приблизну кількість можливих подій під час занурення.",
			"version_hash": 3508993106
		},
		"HEVLIB_CONFIG_SHOW_ACCURATE_EVENTS": {
			"string": "Показувати точні події",
			"version_hash": 179893315
		},
		"HEVLIB_CONFIG_SHOW_ACCURATE_EVENTS_TOOLTIP": {
			"string": "Використовується разом з Налагоджувачем даних позиції. Відображає фактичну кількість подій у зоні. Через принцип роботи цього налаштування продуктивність знизиться на значну величину, і це генеруватиме тисячі логів за хвилину.\\n\\nВИКОРИСТАННЯ ЦЬОГО НАЛАШТУВАННЯ ПОВНІСТЮ НЕ ПІДТРИМУЄТЬСЯ І АНУЛЮЄ ВСІ ЗВІТИ ПРО ПОМИЛКИ! ВАС ПОПЕРЕДИЛИ!",
			"version_hash": 3996342359
		},
		"HEVLIB_CONFIG_OPEN_DEBUG_EVENT_MENU": {
			"string": "Меню налагодження подій",
			"version_hash": 1572595843
		},
		"HEVLIB_CONFIG_OPEN_DEBUG_EVENT_MENU_TOOLTIP": {
			"string": "Клавіші, що використовуються для відкриття меню налагодження подій.",
			"version_hash": 1644117010
		},
		"HEVLIB_CONFIG_OPEN_DEBUGGER": {
			"string": "Перемкнути відображення налагодження",
			"version_hash": 3629985732
		},
		"HEVLIB_CONFIG_OPEN_DEBUGGER_TOOLTIP": {
			"string": "Перемикає видимість консолі налагодження (--debug-console) без необхідності командного рядка.",
			"version_hash": 2762277725
		},
		"HEVLIB_CONFIG_TOGGLE_DEBUG_MENUS": {
			"string": "Меню налагодження HevLib",
			"version_hash": 2934186220
		},
		"HEVLIB_CONFIG_TOGGLE_DEBUG_MENUS_TOOLTIP": {
			"string": "Перемикає видимість налагоджувача вводу та налагоджувача подій, якщо вони увімкнені",
			"version_hash": 392008755
		},
		"HEVLIB_CONFIG_LINEEDIT_PLACEHOLDER": {
			"string": "Вставте текст",
			"version_hash": 2446160991
		},
		"HEVLIB_CONFIG_SECTION_EQUIPMENT": {
			"string": "Обладнання",
			"version_hash": 3425279869
		},
		"HEVLIB_CONFIG_SECTION_EVENTS": {
			"string": "Події",
			"version_hash": 2976090426
		},
		"HEVLIB_CONFIG_SECTION_DRIVERS": {
			"string": "Драйвери",
			"version_hash": 2278708932
		},
		"HEVLIB_CONFIG_SECTION_DEBUG": {
			"string": "Налагодження",
			"version_hash": 218535180
		},
		"HEVLIB_CONFIG_SECTION_INPUT": {
			"string": "Прив'язки",
			"version_hash": 216319605
		},
		"HEVLIB_NOTIFICATIONS": {
			"string": "Сповіщення модів",
			"version_hash": 2627580863
		},
		"HEVLIB_UPDATE_COUNT": {
			"string": "%s мод(ів) потребують оновлення!",
			"version_hash": 4074946392
		},
		"HEVLIB_DEPENDANCY_COUNT": {
			"string": "%s мод(ів) мають відсутні залежності!",
			"version_hash": 4185942359
		},
		"HEVLIB_CONFLICT_COUNT": {
			"string": "%s мод(ів) конфліктують!",
			"version_hash": 3441683171
		},
		"HEVLIB_UPDATE_INFO_HEADER": {
			"string": "Цей мод має очікувані оновлення!",
			"version_hash": 189982677
		},
		"HEVLIB_DEPENDANCY_INFO_HEADER": {
			"string": "Цей мод має відсутні залежності!",
			"version_hash": 4142743351
		},
		"HEVLIB_CONFLICT_INFO_HEADER": {
			"string": "Цей мод наразі конфліктує!",
			"version_hash": 3275554923
		},
		"HEVLIB_UPDATE_INFO_BODY": {
			"string": "Оновити цей мод з версії [%s] до версії [%s]?",
			"version_hash": 3420349538
		},
		"HEVLIB_DEPENDANCY_INFO_BODY": {
			"string": "Цей мод вимагає наступних модів, які відсутні:\\n%s\\n\\n\\n\\nНе очікуйте, що цей мод працюватиме як задумано!",
			"version_hash": 3077768863
		},
		"HEVLIB_CONFLICT_INFO_BODY": {
			"string": "Цей мод конфліктує з іншими встановленими модами. Будь ласка, встановіть сумісну версію наступних модів:\\n%s\\n\\n\\n\\nНе очікуйте, що цей мод працюватиме як задумано!",
			"version_hash": 2921644039
		},
		"HEVLIB_CONFIG_RANDOMIZE_MINERALS": {
			"string": "Рандомізувати сід мінералів",
			"version_hash": 161105527
		},
		"HEVLIB_CONFIG_RANDOMIZE_MINERALS_TOOLTIP": {
			"string": "Змінює сід (seed) генерації мінералів при кожному запуску гри. \\n\\nЯкщо вимкнено, використовує заздалегідь визначений масив констант для сідів мінералів",
			"version_hash": 2736477669
		},
		"HEVLIB_UPDATE_CENTER": {
			"string": "Центр оновлення модів",
			"version_hash": 3293317673
		},
		"HEVLIB_UPDATE_CENTER_DESC": {
			"string": "Наступні моди мають оновлення",
			"version_hash": 1583276900
		},
		"HEVLIB_UPDATE_ALL": {
			"string": "Оновити всі моди",
			"version_hash": 3690503988
		},
		"HEVLIB_IGNORE_ALL": {
			"string": "Ігнорувати всі моди",
			"version_hash": 3685319509
		},
		"HEVLIB_IGNORE_UPDATE": {
			"string": "Ігнорувати оновлення",
			"version_hash": 2636390252
		},
		"HEVLIB_UPDATE_MOD": {
			"string": "Оновити мод",
			"version_hash": 234302216
		},
		"HEVLIB_CONFIRMATION_DIALOGUE_UPDATE_MOD": {
			"string": "Оновити обраний мод [%s] з версії [%s] до версії [%s]? \\n\\nЦе може зайняти деякий час, залежно від розміру мода.",
			"version_hash": 3712115181
		},
		"HEVLIB_CONFIRMATION_DIALOGUE_IGNORE_MOD_UPDATE": {
			"string": "Ігнорувати оновлення для мода [%s] до версії [%s]? \\n\\nЦе рішення можна скинути в налаштуваннях меню модів.",
			"version_hash": 173309219
		},
		"HEVLIB_CONFIRMATION_DIALOGUE_UPDATE_MODS": {
			"string": "Оновити всі моди, що відображаються в цьому меню? \\n\\nЦе може зайняти певний час, залежно від кількості та розміру модів.",
			"version_hash": 3399667694
		},
		"HEVLIB_CONFIRMATION_DIALOGUE_IGNORE_MODS": {
			"string": "Ігнорувати всі оновлення модів, що відображаються в цьому меню? \\n\\nЦе рішення можна скинути в налаштуваннях меню модів.",
			"version_hash": 719742785
		},
		"HEVLIB_ICON_TOOLTIP_CONFLICT": {
			"string": "Цей мод конфліктує з наступними модами:%s",
			"version_hash": 100480821
		},
		"HEVLIB_ICON_TOOLTIP_DEPENDANCIES": {
			"string": "Цей мод не має наступних залежностей:%s",
			"version_hash": 1674753562
		},
		"HEVLIB_ICON_TOOLTIP_COMPLEMENTARY": {
			"string": "Цей мод доповнює наступні моди:%s",
			"version_hash": 420583035
		},
		"HEVLIB_ICON_TOOLTIP_UPDATES": {
			"string": "Цей мод має оновлення! \\nВерсія [%s] -> Версія [%s]",
			"version_hash": 2631682861
		},
		"HEVLIB_MODMENU_UPDATE_NOTIFIER": {
			"string": "Є оновлення для ваших модів. \\n\\nБажаєте відкрити меню оновлень?",
			"version_hash": 3676459949
		},
		"HEVLIB_PLEASE_WAIT": {
			"string": "Будь ласка, зачекайте...",
			"version_hash": 3842636830
		},
		"HEVLIB_RESTART": {
			"string": "Перезапустити гру",
			"version_hash": 448851172
		},
		"HEVLIB_EXIT_INSTEAD": {
			"string": "Вийти з гри натомість",
			"version_hash": 2376159649
		},
		"HEVLIB_RESTART_BECAUSE_NEW_MODS": {
			"string": "Гру потрібно перезапустити, щоб застосувати зміни до модів. \\n\\nАбо ж ви можете закрити гру, або закрити це вікно, щоб продовжити гру та зберегтися.",
			"version_hash": 688430703
		},
		"HEVLIB_WAIT_TO_UPDATE_ALL": {
			"string": "Будь ласка, зачекайте... \\n\\nЗавантаження мода %02d з %02d \\n%s [%s] версія [%s]",
			"version_hash": 4167406587
		},
		"HEVLIB_TITLE_IGNORE_MOD": {
			"string": "Ігнорувати мод?",
			"version_hash": 1185318888
		},
		"HEVLIB_TITLE_UPDATE_MOD": {
			"string": "Оновити мод?",
			"version_hash": 3437005895
		},
		"HEVLIB_TITLE_IGNORE_MODS": {
			"string": "Ігнорувати моди?",
			"version_hash": 460819419
		},
		"HEVLIB_TITLE_UPDATE_MODS": {
			"string": "Оновити моди?",
			"version_hash": 1752046618
		},
		"HEVLIB_DLCLIST_DLC_HEADER": {
			"string": "------- DLC ------",
			"version_hash": 245182049
		},
		"HEVLIB_DLCLIST_MODS_HEADER": {
			"string": "------ MODS ------",
			"version_hash": 1346064212
		},
		"HEVLIB_CONFIG_SHOW_ALWAYS_LIBRARIES_IN_DLCLIST": {
			"string": "Показувати постійно видимі бібліотеки у списку DLC",
			"version_hash": 2439027097
		},
		"HEVLIB_CONFIG_SHOW_ALWAYS_LIBRARIES_IN_DLCLIST_TOOLTIP": {
			"string": "Дозволяє бібліотекам з тегом 'always_display' (таким як HevLib) з'являтися в розділі модів списку DLC",
			"version_hash": 1519865726
		},
		"HEVLIB_CONFIG_SHOW_ALL_LIBRARIES_IN_DLCLIST": {
			"string": "Показувати всі бібліотеки у списку DLC",
			"version_hash": 3753868258
		},
		"HEVLIB_CONFIG_SHOW_ALL_LIBRARIES_IN_DLCLIST_TOOLTIP": {
			"string": "Дозволяє всім бібліотекам з'являтися в розділі модів списку DLC. Це може зробити список дуже великим через бібліотеки, які мають багато основних файлів модів для підпроцесів.",
			"version_hash": 2736147
		},
		"HEVLIB_CONFIG_DLCLIST_SORT_ORDER": {
			"string": "Порядок сортування модів у списку DLC",
			"version_hash": 2104835928
		},
		"HEVLIB_CONFIG_DLCLIST_SORT_ORDER_TOOLTIP": {
			"string": "Чи потрібно сортувати розділ модів у списку DLC і як саме.",
			"version_hash": 3524220335
		},
		"HEVLIB_RESEARCH": {
			"string": "Дослідження",
			"version_hash": 2602532946
		},
		"HEVLIB_RESEARCH_CURRENT": {
			"string": "Поточне дослідження",
			"version_hash": 1810057685
		},
		"HEVLIB_CURRENT_PROJECTS": {
			"string": "Активні проекти досліджень",
			"version_hash": 2308505464
		},
		"HEVLIB_RESEARCH_STATS": {
			"string": "Статистика всіх проектів",
			"version_hash": 3481155716
		},
		"HEVLIB_RESEARCH_AVAILABLE": {
			"string": "Доступні проекти",
			"version_hash": 2078505552
		},
		"HEVLIB_CONFIG_TOGGLE_UI_SCROLL_LEFT": {
			"string": "Прокрутка інтерфейсу вліво",
			"version_hash": 239484797
		},
		"HEVLIB_CONFIG_TOGGLE_UI_SCROLL_LEFT_TOOLTIP": {
			"string": "Основний ввід прокрутки вліво для меню з лише горизонтальною прокруткою",
			"version_hash": 2459810666
		},
		"HEVLIB_CONFIG_TOGGLE_UI_SCROLL_RIGHT": {
			"string": "Прокрутка інтерфейсу вправо",
			"version_hash": 3615291088
		},
		"HEVLIB_CONFIG_TOGGLE_UI_SCROLL_RIGHT_TOOLTIP": {
			"string": "Основний ввід прокрутки вправо для меню з лише горизонтальною прокруткою",
			"version_hash": 1217894109
		},
		"HEVLIB_CONFIG_TOGGLE_UI_SCROLL_LEFT2": {
			"string": "Прокрутка інтерфейсу вліво (альт)",
			"version_hash": 2744720591
		},
		"HEVLIB_CONFIG_TOGGLE_UI_SCROLL_LEFT2_TOOLTIP": {
			"string": "Альтернативний ввід прокрутки вліво для меню з лише горизонтальною прокруткою",
			"version_hash": 4207006566
		},
		"HEVLIB_CONFIG_TOGGLE_UI_SCROLL_RIGHT2": {
			"string": "Прокрутка інтерфейсу вправо (альт)",
			"version_hash": 3554592354
		},
		"HEVLIB_CONFIG_TOGGLE_UI_SCROLL_RIGHT2_TOOLTIP": {
			"string": "Альтернативний ввід прокрутки вправо для меню з лише горизонтальною прокруткою",
			"version_hash": 3040783961
		},
		"SYSTEM_HEVLIB_INTERNALS_NODE": {
			"string": "Обробник внутрішніх систем мода",
			"version_hash": 3379743283
		},
		"NOTIFICATION_NAME_PLACEHOLDER": {
			"string": "{Тіло сповіщення відсутнє}",
			"version_hash": 1693706220
		},
		"NOTIFICATION_TITLE_PLACEHOLDER": {
			"string": "{Назва сповіщення відсутня}",
			"version_hash": 3481814879
		},
		"HEVLIB_AVAILABLE_RESEARCH": {
			"string": "Доступні проекти досліджень",
			"version_hash": 318053917
		},
		"HEVLIB_RESEARCH_TOTAL_TOOLTIP": {
			"string": "Загальний прогрес у цьому проекті",
			"version_hash": 1598981297
		},
		"DLC_ANDROID": {
			"string": "Пакет облич андроїдів",
			"version_hash": 3806021908
		},
		"HEVLIB_CONFIG_LIMIT_NANODRONE_OUTPUT": {
			"string": "Обмежити вихід нанодронів",
			"version_hash": 3207490862
		},
		"HEVLIB_CONFIG_LIMIT_NANODRONE_OUTPUT_TOOLTIP": {
			"string": "Запобігає використанню нанодронів, якщо швидкість споживання перевищує швидкість встановленого сховища. \\nПримітка: це, ймовірно, ніколи не буде досягнуто, крім дуже специфічних конфігурацій.",
			"version_hash": 3428239164
		},
		"HEVLIB_CONFIG_DISPLAY_CURRENTLY_PLAYING": {
			"string": "Відображати кількість гравців",
			"version_hash": 507597972
		},
		"HEVLIB_CONFIG_DISPLAY_CURRENTLY_PLAYING_TOOLTIP": {
			"string": "Чи відображати кількість одночасних гравців на клієнтах Steam.\\nЗауважте, що цифри для повної гри та демо-версії розділені.",
			"version_hash": 4192055013
		},
		"HEVLIB_CLEAR_LEADERBOARDS": {
			"string": "Очистити статистику таблиці лідерів",
			"version_hash": 1094632464
		},
		"HEVLIB_CLEAR_LEADERBOARDS_TOOLTIP": {
			"string": "Відкриває меню, яке дозволяє скинути окремі статистики таблиці лідерів.\\n\\nПРИМІТКА: Тільки для релізів Steam",
			"version_hash": 790679608
		},
		"HEVLIB_OPEN_MENU": {
			"string": "Відкрити меню",
			"version_hash": 2736950124
		},
		"STEAMSTAT_best_haul": {
			"string": "Найкращий улов (повний)",
			"version_hash": 1718163207
		},
		"STEAMSTAT_best_ore": {
			"string": "Найкращий улов (руда)",
			"version_hash": 474342196
		},
		"STEAMSTAT_longest_dive": {
			"string": "Найдовше занурення (включаючи астрогацію)",
			"version_hash": 2842100834
		},
		"STEAMSTAT_longest_dive_realtime": {
			"string": "Найдовше занурення (час пілотування)",
			"version_hash": 2971453009
		},
		"STEAMSTAT_money_per_day": {
			"string": "Середній дохід за день",
			"version_hash": 2616976832
		},
		"STEAMSTAT_time": {
			"string": "Дні роботи в кільцях",
			"version_hash": 1752709682
		},
		"STEAMSTAT_total_money": {
			"string": "Багатство",
			"version_hash": 3660220906
		},
		"STEAMSTAT_CLEAR_STAT": {
			"string": "Очистити статистику",
			"version_hash": 3593190152
		},
		"HEVLIB_CONFIRM": {
			"string": "Підтвердити дію",
			"version_hash": 2178666097
		},
		"HEVLIB_WIPE_STAT_ARE_YOU_SURE": {
			"string": "Ви впевнені, що хочете очистити статистику %s?",
			"version_hash": 698846716
		},
		"HEVLIB_NOSTEAM": {
			"string": "Це меню працює тільки на збірках Steam.",
			"version_hash": 3802738386
		},
		"HEVLIB_OPT_PROFILES": {
			"string": "Профілі налаштувань",
			"version_hash": 2144737018
		},
		"HEVLIB_PROFILE_SELECT": {
			"string": "Оберіть профіль",
			"version_hash": 3621498966
		},
		"HEVLIB_ADD_PROFILE": {
			"string": "Додати профіль",
			"version_hash": 610551423
		},
		"HEVLIB_RENAME_PROFILE": {
			"string": "Перейменувати профіль",
			"version_hash": 3715498190
		},
		"HEVLIB_DELETE_PROFILE": {
			"string": "Видалити профіль",
			"version_hash": 1875438633
		},
		"HEVLIB_PROFILENAME_ADD": {
			"string": "Додати профіль",
			"version_hash": 610551423
		},
		"HEVLIB_PROFILENAME_RENAME": {
			"string": "Перейменувати профіль",
			"version_hash": 3715498190
		},
		"HEVLIB_PROFILE_DELETE": {
			"string": "Видалити профіль",
			"version_hash": 1875438633
		},
		"HEVLIB_PROFILE_DELETE_ARE_YOU_SURE": {
			"string": "Ви впевнені, що хочете видалити цей профіль?",
			"version_hash": 3461730766
		},
		"HEVLIB_CHANGELOGS": {
			"string": "Перелік змін",
			"version_hash": 656124416
		},
		"HEVLIB_CHANGELOGS_NEW": {
			"string": "Нові переліки змін",
			"version_hash": 3365610410
		},
		"HEVLIB_CONFIG_MULTIPLE_MINERALS_PER_CHUNK": {
			"string": "Кілька мінералів у шматку",
			"version_hash": 3451211596
		},
		"HEVLIB_CONFIG_MULTIPLE_MINERALS_PER_CHUNK_TOOLTIP": {
			"string": "Додає функціонал, що дозволяє кільком рудам існувати в одному шматку руди. \\n\\nАвтор: Za'krin (оригінальна реалізація, яку цей мод адаптує та вдосконалює).",
			"version_hash": 3231012828
		},
		"HEVLIB_TRANSIT_TIP_1": {
			"string": "|Наявність кількох членів екіпажу з однаковою професією дозволяє їм працювати в тандемі.",
			"version_hash": 3778788784
		},
		"HEVLIB_TRANSIT_TIP_2": {
			"string": "|На відміну від автопілота, ваші маневрові двигуни можуть працювати за допомогою ручного вводу без необхідності увімкнення комп'ютера чи HUD.",
			"version_hash": 769325838
		},
		"HEVLIB_TRANSIT_TIP_3": {
			"string": "Під час порятунку рятувальної капсули невикористаний маніпулятор дозволить надійно зафіксувати її, не захаращуючи вантажний відсік.",
			"version_hash": 1685575029
		},
		"HEVLIB_TRANSIT_TIP_4": {
			"string": "Заявка на ділянку розкопок привертає підвищену увагу до навколишньої території.",
			"version_hash": 2111589941
		},
		"HEVLIB_TRANSIT_TIP_5": {
			"string": "Ваш геолог може обмежити те, що бачить ваше обладнання. Суворіші фільтри допоможуть запобігти перевантаженню систем корабля.",
			"version_hash": 46062683
		},
		"HEVLIB_TRANSIT_TIP_6": {
			"string": "Якщо вам потрібно більше страховки, а виплати від Джеймсона недостатньо, шукайте пошуково-рятувальні судна в кільцях.",
			"version_hash": 2741005409
		},
		"HEVLIB_TRANSIT_TIP_7": {
			"string": "Задоволений екіпаж працюватиме трохи старанніше, а незадоволений — матиме менше мотивації до роботи.",
			"version_hash": 294913161
		},
		"HEVLIB_TRANSIT_TIP_8": {
			"string": "Якщо об'єкт обрано автопілотом, мікросейсмічні дрони скануватимуть цільовий об'єкт, інакше — те, що знаходиться под курсором.",
			"version_hash": 4239360766
		},
		"HEVLIB_TRANSIT_TIP_9": {
			"string": "Хабітати завжди платитимуть принаймні невелику націнку понад ринкову вартість мінералу.",
			"version_hash": 1249715321
		},
		"HEVLIB_TRANSIT_TIP_10": {
			"string": "Використовуєте занадто багато нанодронів на нікчемну руду? Налаштуйте фільтри геолога, щоб ловити тільки те, що вам потрібно, і заощаджуйте на дронах.",
			"version_hash": 4012124347
		},
		"HEVLIB_TRANSIT_TIP_11": {
			"string": "Маєте проблеми з модами? Надішліть звіт на сайті, де ви їх отримали, або приєднайтеся до Discord для підтримки в реальному часі.",
			"version_hash": 3402302455
		},
		"HEVLIB_TRANSIT_TIP_12": {
			"string": "Маєте пропозицію щодо мода? Приєднуйтесь до Discord і сміливо запитуйте.",
			"version_hash": 3184450777
		},
		"HEVLIB_TRANSIT_TIP_13": {
			"string": "Хочете знайти більше модів? Перегляньте повну колекцію на 'https://delta-v.kodera.pl/index.php/Mod_List'",
			"version_hash": 3141819234
		},
		"HEVLIB_TRANSIT_TIP_14": {
			"string": "Майте на увазі, що все, що здатне розбивати камені, може якимось чином пошкодити й інші кораблі.",
			"version_hash": 635357464
		},
		"HEVLIB_TRANSIT_TIP_15": {
			"string": "втономні системи працюють так, як задумано, проте вам може знадобитися терпіння, щоб дати їм час завершити роботу.",
			"version_hash": 3043623550
		},
		"HEVLIB_TRANSIT_TIP_16": {
			"string": "Подобаються моди, якими ви користуєтеся? Подумайте про те, щоб підтримати їхніх авторів!",
			"version_hash": 79152977
		},
		"HEVLIB_TRANSIT_TIP_17": {
			"string": "Моди поводяться трохи інакше після оновлення? Перевірте останні переліки змін або запитайте автора.",
			"version_hash": 2422128719
		},
		"MODMENU2_MOD_DESCRIPTION": {
			"string": "Розширене меню модів, яке дає практично повний контроль над переглядом ваших модів.\\n\\nОсобливості:\\n\\n* Базовий перегляд модів – відображає будь-який встановлений мод, незалежно від того, чи має він сучасну інформацію маніфесту, чи є базовим модом, а також інформацію про оригінальну гру.\\n* Зміна налаштувань – дозволяє налаштовувати будь-які моди, які надають набір конфігурацій у маніфесті.\\n* Перевірка оновлень – будь-який мод, який надає відповідну інформацію для оновлення, перевірятиметься на наявність оновлень під час запуску. Оновлення можна завантажити окремо, групою або ігнорувати для цієї версії.\\n* Перевірка конфліктів та залежностей – будь-який мод, який містить ID потрібних або несумісних модів, покаже попередження на головному екрані. ПРИМІТКА: Це працює лише для модів із маніфестами.\\n* Фільтри тегів та пошуку – дозволяють фільтрувати відображені моди за ключовим словом або ID моду, або вибирати з набору тегів у модах, щоб відображати лише ті моди, які використовують певний набір тегів",
			"version_hash": 3441621910
		},
		"MODMENU2_MOD_BRIEF": {
			"string": "Розширене меню модів",
			"version_hash": 175259935
		},
		"MODMENU2_CONFIG_GENERAL": {
			"string": "Загальне",
			"version_hash": 1354717699
		},
		"MODMENU2_CLEAR_IGNORED_UPDATES": {
			"string": "Очистити ігноровані оновлення",
			"version_hash": 22297130
		},
		"MODMENU2_CLEAR_IGNORED_UPDATES_TOOLTIP": {
			"string": "Очищає список оновлень, які ви вирішили ігнорувати",
			"version_hash": 3834391056
		},
		"MODMENU2_CLEAR_IGNORED_UPDATES_BUTTON": {
			"string": "Очистити",
			"version_hash": 217603436
		},
		"TAG_OVERHAUL": {
			"string": "Глобальна переробка",
			"version_hash": 3544097003
		},
		"HEVLIB_GITHUB_PROGRESS_WAITING_ON_RESPONSE": {
			"string": "Очікування відповіді від сервера.",
			"version_hash": 1988119143
		},
		"HEVLIB_GITHUB_PROGRESS_ZIP_FOUND_AND_REQUESTING": {
			"string": "Відповідь отримана. Запит файлу.",
			"version_hash": 1619856286
		},
		"HEVLIB_GITHUB_PROGRESS_DOWNLOADING": {
			"string": "Завантаження файлу | %06.2f%%\\n\\nЗавантажено %0.2f %s з %0.2f %s",
			"version_hash": 812004994
		},
		"HEVLIB_GITHUB_PROGRESS_DOWNLOADING_ONLY_BYTES": {
			"string": "Завантаження файлу.\\n\\nЗавантажено %0.2f %s",
			"version_hash": 2232387281
		},
		"HEVLIB_GITHUB_PROGRESS_DOWNLOADED_FILE": {
			"string": "Завантаження завершено.",
			"version_hash": 249088469
		},
		"HEVLIB_SIZE_LABEL_BYTES": {
			"string": "байт",
			"version_hash": 254850636
		},
		"HEVLIB_SIZE_LABEL_KILOBYTES": {
			"string": "кілобайт",
			"version_hash": 214961083
		},
		"HEVLIB_SIZE_LABEL_MEGABYTES": {
			"string": "мегабайт",
			"version_hash": 2738237862
		},
		"HEVLIB_NO_DOWNLOAD_HEADER": {
			"string": "ПОСИЛАННЯ НЕ НАДАНО!",
			"version_hash": 3291089198
		},
		"HEVLIB_NO_DOWNLOAD_CONTENT": {
			"string": "УВАГА: для мода [%s] не надано дійсного посилання для завантаження, тому його не було завантажено. \\n\\nБудь ласка, зверніться до джерела цього мода для оновлень та повідомте автора мода.",
			"version_hash": 2446599643
		},
		"HEVLIB_SAVEOPT_FIX_CORRUPTED_CARGO": {
			"string": "Виправити виліт через пошкоджений вантаж",
			"version_hash": 802028065
		},
		"HEVLIB_SAVEOPT_FIX_CORRUPTED_CARGO_TOOLTIP": {
			"string": "Використовуйте це, щоб виправити збереження, якщо воно не завантажується через недійсний вантаж, привезений під час попереднього завантаження. \\n\\nОзнакою цього є передостанній рядок файлу engine_log.txt: \\n'ERROR: No loader found for resource: res://.' після вильоту при поверненні з кілець або завантаженні збереження.",
			"version_hash": 885117514
		},
		"HEVLIB_CONFIG_MAX_MODDED_DEALERSHIP_POOLS": {
			"string": "Максимум модованих записів у дилері",
			"version_hash": 1666179083
		},
		"HEVLIB_CONFIG_MAX_MODDED_DEALERSHIP_POOLS_TOOLTIP": {
			"string": "Максимальна кількість модованих пулів кораблів, доданих до списку вживаних кораблів дилерського центру. \\nЦе стосується лише кораблів, доданих через ShipDriver; число не збільшуватиметься, якщо додано менше кораблів, ніж це значення.",
			"version_hash": 338011646
		},
		"HEVLIB_SAVEOPT_CLEAR_SOLD_SHIPS": {
			"string": "Очистити кеш проданих кораблів",
			"version_hash": 4176761126
		},
		"HEVLIB_SAVEOPT_CLEAR_SOLD_SHIPS_TOOLTIP": {
			"string": "Очищує будь-які дані про продані кораблі. Використовується для виправлення проблем, коли після продажу модованих кораблів у дилері назавжди залишається «корабель-привид».",
			"version_hash": 713581652
		},
		"HEVLIB_CONFIG_INPUT_VIRTUALIZATION": {
			"string": "Віртуалізація вводу (WIP)",
			"version_hash": 1330041627
		},
		"HEVLIB_CONFIG_INPUT_VIRTUALIZATION_TOOLTIP": {
			"string": "Використовує програмну систему обробки вводу замість ігрової. Дозволяє використовувати комбінації клавіш для дій.",
			"version_hash": 4158244573
		},
		"HEVLIB_CONFIG_INPUT_VIRTUALIZATION_OVERRIDE_BUILTIN": {
			"string": "Ігнорувати вбудовані прив'язки",
			"version_hash": 1598156349
		},
		"HEVLIB_CONFIG_INPUT_VIRTUALIZATION_OVERRIDE_BUILTIN_TOOLTIP": {
			"string": "Чи повинна віртуалізація вводу обробляти вбудовані клавіші рушія, навіть ті, що не призначені для зміни.",
			"version_hash": 4016249648
		},
		"HEVLIB_OPT_MODPACKS": {
			"string": "Збірки модів (Modpacks)",
			"version_hash": 3714458839
		},
		"HEVLIB_MODPACKS IMPORT": {
			"string": "Імпортувати збірки модів",
			"version_hash": 126074482
		},
		"HEVLIB_MODPACKS EXPORT": {
			"string": "Експортувати збірки модів",
			"version_hash": 103317849
		},
		"HEVLIB_APPLICABLE_MODS": {
			"string": "Моди, сумісні зі збіркою",
			"version_hash": 476877116
		},
		"HEVLIB_SAVE_MODPACK": {
			"string": "Зберегти збірку",
			"version_hash": 1264474579
		},
		"HEVLIB_OPEN_MODPACK": {
			"string": "Відкрити збірку",
			"version_hash": 732682486
		},
		"HEVLIB_MODPACK_LIMITATIONS": {
			"string": "Збірки не можуть включати моди без маніфесту версії принаймні MV2.2, посилання на репозиторій GitHub та URL-адреси маніфесту.",
			"version_hash": 2148121562
		},
		"HEVLIB_MODPACK_TOGGLE": {
			"string": "Включити цей мод до збірки для експорту?",
			"version_hash": 909574562
		},
		"HEVLIB_MODPACK_DOWNLOADING": {
			"string": "Будь ласка, зачекайте... \\n\\nЗавантаження мода %02d з %02d \\n%s [%s]\\n\\n(%s модів пропущено.)",
			"version_hash": 640450355
		},
		"HEVLIB_CONFIG_CARGO_SCANNER_DISPLAY_LIMIT": {
			"string": "Межа відображення мінералів у сканері вантажу",
			"version_hash": 3554924120
		},
		"HEVLIB_CONFIG_CARGO_SCANNER_DISPLAY_LIMIT_TOOLTIP": {
			"string": "Скільки записів мінералів може відображатися в будь-якому списку сканера сирих мінералів. Сюди входять лише мінерали; порожній простір, обладнання та неідентифіковані записи ігноруються.",
			"version_hash": 3868254435
		},
		"TAG_ADD_TRANSIT_TIPS": {
			"string": "Додає підказки під час транзиту",
			"version_hash": 3276505670
		},
		"EVENTDRIVER_ENABLE_ALL": {
			"string": "Увімкнути всі події",
			"version_hash": 987521466
		},
		"EVENTDRIVER_DISABLE_ALL": {
			"string": "Вимкнути всі події",
			"version_hash": 1138158759
		},
		"HEVLIB_GITHUBMODS_TITLE": {
			"string": "Доступні моди",
			"version_hash": 2637865945
		},
		"HEVLIB_GITHUBMODS_COUNT": {
			"string": "%d доступно",
			"version_hash": 913247151
		},
		"HEVLIB_CONFIG_PROCESSED_MINERAL_DISPLAY_LIMIT": {
			"string": "Межа відображення мінералів в обробленому вантажі",
			"version_hash": 2547578582
		},
		"HEVLIB_CONFIG_PROCESSED_MINERAL_DISPLAY_LIMIT_TOOLTIP": {
			"string": "Скільки записів мінералів може відображатися одночасно в списку обробленої руди. Коли ліміт перевищено, цей список перемикається між \"сторінками\", щоб можна було переглянути всі мінерали.",
			"version_hash": 4133660626
		},
		"HEVLIB_TRANSIT_TIP_18": {
			"string": "Бажаєте бачити кілька руд в одному шматку мінералу або налаштувати інші параметри мінералів? Перегляньте вкладку \"Драйвери\" у налаштуваннях HevLib.",
			"version_hash": 2874849155
		},
		"HEVLIB_TRANSIT_TIP_19": {
			"string": "Хочете налаштувати ймовірність появи модованих кораблів у дилера? Зазирніть у вкладку \"Драйвери\" у налаштуваннях HevLib.",
			"version_hash": 809628308
		},
		"HEVLIB_TRANSIT_TIP_20": {
			"string": "Бажаєте керувати певними змінами обладнання, як-от сортування слотів або межі сканера мінералів? Перегляньте розділ \"Обладнання\" у налаштуваннях HevLib.",
			"version_hash": 186912265
		},
		"HEVLIB_TRANSIT_TIP_21": {
			"string": "Маєте проблеми з керованістю кораблем? Спробуйте змінити маневрові двигуни або автопілот, а також налаштувати потужність тяги та параметри автопілота!",
			"version_hash": 841163575
		},
		"HEVLIB_TRANSIT_TIP_22": {
			"string": "Певне обладнання може справно працювати \"з коробки\" лише на спеціально призначених для нього суднах. Якщо у вас виникли проблеми з конкретним предметом обладнання, можливо, варто спробувати використати його на відповідному кораблі?",
			"version_hash": 2483296260
		},
		"HEVLIB_TRANSIT_TIP_23": {
			"string": "Ви можете налаштувати порядок сортування будь-яких модів у списку DLC у розділі \"Драйвери\" в налаштуваннях HevLib.",
			"version_hash": 1367355062
		},
		"HEVLIB_TRANSIT_TIP_24": {
			"string": "Набрид видобуток? Існує безліч інших способів заробити гроші.",
			"version_hash": 3573113157
		},
		"HEVLIB_TRANSIT_TIP_25": {
			"string": "Магазини електромагнітних гармат та компоненти нанодронів обмежені швидкістю подачі їхнього сховища.",
			"version_hash": 2903300490
		},
		"HEVLIB_TRANSIT_TIP_26": {
			"string": "Вкладка \"Геолог\" обладнана смужкою прокрутки, щоб полегшити читання довгих назв обладнання та списків мінералів.",
			"version_hash": 1092699375
		},
		"EVENTDRIVER_LEGACY": {
			"string": "Використовувати застарілий обробник спавну?",
			"version_hash": 2630802733
		},
		"EVENTDRIVER_INJECT": {
			"string": "Ін'єктувати дивність?",
			"version_hash": 548009294
		},
		"EVENTDRIVER_SPAWNER_CONTROLS": {
			"string": "Керування спавном подій",
			"version_hash": 383031684
		},
		"EVENTDRIVER_CLEARER_CONTROLS": {
			"string": "Керування очищенням подій",
			"version_hash": 3681275490
		},
		"EVENTDRIVER_CLEAR_POI": {
			"string": "Очистити пов'язану POI",
			"version_hash": 3673548405
		},
		"EVENTDRIVER_CLEAR_POI_TOOLTIP": {
			"string": "Події на основі POI створюють локацію в кеші астрогації та знову з'являться після звичайного очищення.\n\nЦей перемикач видалить POI для події, якщо вона знаходиться поруч.",
			"version_hash": 2980544907
		},
		"EVENTDRIVER_CLEAR_CARGO": {
			"string": "Очистити у вантажному відсіку?",
			"version_hash": 3991202254
		},
		"EVENTDRIVER_EVENTS_TOOLTIP": {
			"string": "Бажана подія для спавну/очищення\n\"none\" — спавнити випадкову подію / очистити всі події",
			"version_hash": 2910940133
		},
		"EVENTDRIVER_TIMER_TOOLTIP": {
			"string": "|Час між спавнами подій у секундах",
			"version_hash": 1166419779
		},
		"EVENTDRIVER_SPAWNNOW_TOOLTIP": {
			"string": "Спавнить обрану подію.\\nЯкщо обрано \"none\", спавнить випадкову подію",
			"version_hash": 2314890076
		},
		"EVENTDRIVER_LEGACY_TOOLTIP": {
			"string": "Використовувати дуже стару систему testSpecificStoryElement для спавну події",
			"version_hash": 555589987
		},
		"EVENTDRIVER_INJECT_TOOLTIP": {
			"string": "Розмістити об'єкти події безпосередньо в кільці.\nЦе обходить звичайні механізми спавну подій і може спричинити аномалії",
			"version_hash": 324336902
		},
		"EVENTDRIVER_CLEAREVENT_TOOLTIP": {
			"string": "Очищує всі події обраного типу.\\nЯкщо обрано \"none\", очищує всі події",
			"version_hash": 30519526
		},
		"EVENTDRIVER_CLEAR_CARGO_TOOLTIP": {
			"string": "Якщо вибрано, також очищає всі дивності (oddities), спавнені подією прямо у вашому вантажному відсіку.",
			"version_hash": 917771176
		},
		"HEVLIB_DOWNLOAD_MOD": {
			"string": "Завантажити мод!",
			"version_hash": 570592894
		},
		"MODMENU_MOD_UNAVAILABLE": {
			"string": "Цей мод наразі недоступний. Це може бути викликано кількома причинами, зокрема:\\n\\n- Обмеження частоти запитів GitHub (ймовірно, занадто багато запитів)\\n- Проблеми з підключенням до Інтернету\\n- Мод не має належного налаштування завантаження",
			"version_hash": 3639564067
		},
		"HEVLIB_CONFIG_FULL_LOGGING": {
			"string": "Детальне логування",
			"version_hash": 2478639519
		},
		"HEVLIB_CONFIG_FULL_LOGGING_TOOLTIP": {
			"string": "изначає, чи повинні будь-які потенційно детальні функції HevLib створювати додаткові логи",
			"version_hash": 3570790396
		},
		"MODMENU_GET_NEW_MODS": {
			"string": "Отримати нові моди з GitHub",
			"version_hash": 2573811993
		},
		"HEVLIB_MM_TOOLTIP_LANGUAGE_ENTRY": {
			"string": "%s: %s",
			"version_hash": 1718567247
		},
		"HEVLIB_SUPPORTED_LANGUAGES": {
			"string": "Підтримувані мови / завершено %:",
			"version_hash": 31187306
		},
		"HEVLIB_CONFIG_SECTION_KEYMAPPING": {
			"string": "Призначення клавіш",
			"version_hash": 3052849914
		},
		"HEVLIB_MODMENU_CANNOT_RESTART": {
			"string": "Наразі в кільцях.\\nБудь ласка, перезапустіть вручну.",
			"version_hash": 3242006044
		},
		"HEVLIB_CONFIG_UNRESTRICTED_AMMO_OUTPUT": {
			"string": "Скасувати обмеження постачання боєприпасів",
			"version_hash": 537716554
		},
		"HEVLIB_CONFIG_UNRESTRICTED_AMMO_OUTPUT_TOOLTIP": {
			"string": "Повертає поведінку магазину боєприпасів до версії перед 1.64.14, без жодних обмежень щодо швидкості подачі боєприпасів до обладнання.",
			"version_hash": 1753521849
		},
		"HEVLIB_SETTING_REQUIRES_RESTART": {
			"string": "ЗВЕРНІТЬ УВАГУ: Цей параметр потребує перезапуску після його зміни.",
			"version_hash": 1236302953
		},
		"HEVLIB_MODMENU_MODNAME_DISABLED": {
			"string": "(вимкнено)",
			"version_hash": 3167290830
		},
		"HEVLIB_MODLET_ENABLED": {
			"string": "Увімкнено?",
			"version_hash": 644251567
		},
		"HEVLIB_MODMENU_MODNAME_ENABLED_NEEDS_RESTART": {
			"string": "(увімкнено, потрібен перезапуск)",
			"version_hash": 1899921857
		},
		"HEVLIB_MODMENU_MODNAME_DISABLED_NEEDS_RESTART": {
			"string": "(вимкнено, потрібен перезапуск)",
			"version_hash": 2601371502
		},
		"MODMENU2_TRANSIT_TIP_1": {
			"string": "Модпаки спрощують обмін модами! Створюйте або імпортуйте їх у Меню Модів.",
			"version_hash": 2128454254
		},
		"MODMENU2_TRANSIT_TIP_2": {
			"string": "Бажаєте спробувати нові налаштування без ризику для поточної конфігурації? Створіть новий профіль налаштувань, щоб легко перемикатися на бажані параметри.",
			"version_hash": 331405958
		},
		"MODMENU2_TRANSIT_TIP_3": {
			"string": "Бажаєте нових модів, але не хочете шукати їх в інтернеті? Перевірте меню завантажувача з GitHub!",
			"version_hash": 2668803293
		},
		"HEVLIB_MODMENU_MODLET_TOGGLE_TOOLTIP": {
			"string": "Перемикає, чи увімкнено цей модлет.\\n\\n(потребує перезапуску гри)",
			"version_hash": 3820371863
		},
		"HEVLIB_MODMENU_MODLET_TOGGLE_MM2FALLBACK": {
			"string": "Неможливо перемикнути ModMenu2.\\n\\nАрхів ZIP потрібно видалити вручну або\\nперемикнути безпосередньо у файлі конфігурації.",
			"version_hash": 915722318
		}
	}
}