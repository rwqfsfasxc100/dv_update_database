extends Reference
class_name SimpleZip

# SimpleZip
# ---------
# A pure-GDScript reader/writer for standard .zip archives, for Godot 3.6.
#
# WHY THIS EXISTS
# Godot's ZIPReader / ZIPPacker classes are NOT available in Godot 3.x --
# they were added to the engine in Godot 4.0 (godotengine/godot#65281).
# Since Godot 3.6 has no built-in scripting API for creating or editing
# .zip files, this script implements the zip file format directly --
# including its own DEFLATE encoder/decoder, since Godot's own
# PoolByteArray.compress()/decompress() only speak the zlib container
# format (a 2-byte header + 4-byte Adler-32 trailer), not the raw deflate
# stream a .zip actually stores internally, so they can't be reused for
# zip entries on the read side. On the write side this script does reuse
# Godot's compressor and simply trims that wrapper back off, since raw
# deflate is zlib-minus-wrapper by definition.
#
# ARCHITECTURE: BYTES FIRST, FILES ON TOP
# Every actual zip-format operation - reading, building, inserting into,
# removing from an archive - works on a complete zip held as a
# PoolByteArray. The `_bytes` functions in the PUBLIC API section below
# are that core, directly: hand them (and get back) an in-memory archive,
# with no disk I/O at all, for whenever a zip is already in memory (e.g.
# downloaded, generated, or stored as a blob) rather than sitting in a
# file. The plain-named functions (create_zip, read_file, insert_file,
# etc.) are thin wrappers around the same core that load from / save to
# a path on disk, for convenience when a file is what you've got.
#
# INSERT/REMOVE PERFORMANCE
# insert_file(s)() and remove_file(s)() do NOT decompress and recompress
# every entry the way rebuilding an archive from scratch would. Entries
# that aren't being added, replaced, or removed are copied verbatim -
# same compressed bytes, no touching their content at all - so cost
# scales with what's actually changing, not with the size of the whole
# archive. See _patch_zip_bytes() below for exactly how.
#
# COMPRESSION
# create_zip() / zip_directory() / insert_file(s)() all take an optional
# `compress` flag (default false, for the fastest/simplest option) that
# writes entries with DEFLATE instead of Stored. Reading transparently
# handles both methods either way, including zips made by other programs,
# and archives with a mix of both. A handful of far less common methods
# (bzip2, LZMA, etc.) are still out of scope for entries being newly
# compressed, but are no longer a problem for entries just passing
# through an insert/remove untouched - see above, they're never decoded.
# Archives over ~4 GB or with more than 65535 entries (zip64) aren't
# supported.

const _LOCAL_FILE_SIG  := 0x04034b50
const _CENTRAL_DIR_SIG := 0x02014b50
const _EOCD_SIG        := 0x06054b50
const _VERSION_NEEDED  := 20     # 2.0 - no encryption, no zip64, etc.
const _FLAG_UTF8       := 0x0800 # names/content are UTF-8
const _METHOD_STORED   := 0
const _METHOD_DEFLATE  := 8
const _EOCD_FIXED_SIZE := 22


# --------------------------------------------------------------------
# PUBLIC API - in-memory (PoolByteArray) core
# --------------------------------------------------------------------

# Builds a brand-new zip, entirely in memory, from `files` formatted as
# { "path/inside/zip.txt": <String or PoolByteArray>, ... }. Pass
# compress=true to write entries with DEFLATE instead of Stored.
static func create_zip_bytes(files: Dictionary, compress: bool = false) -> PoolByteArray:
	return _build_zip_bytes(files, compress)


# Returns the list of entry names stored inside an in-memory zip (folders
# included, as Godot's own ZIPReader.get_files() would list them).
static func list_files_bytes(zip_bytes: PoolByteArray) -> Array:
	var names := []
	for entry in _read_central_directory_from_bytes(zip_bytes):
		names.append(entry.name)
	return names


# Returns true if `file_in_zip` is present in an in-memory zip.
static func file_exists_bytes(zip_bytes: PoolByteArray, file_in_zip: String) -> bool:
	for entry in _read_central_directory_from_bytes(zip_bytes):
		if entry.name == file_in_zip:
			return true
	return false


# Reads one file's raw bytes out of an in-memory zip (transparently
# inflating it first if it's Deflate-compressed). Returns an empty
# PoolByteArray (and logs an error) if the entry is missing or uses an
# unsupported compression method.
static func read_file_bytes(zip_bytes: PoolByteArray, file_in_zip: String) -> PoolByteArray:
	for entry in _read_central_directory_from_bytes(zip_bytes):
		if entry.name == file_in_zip:
			return _read_entry_data_from_bytes(zip_bytes, entry)
	push_error("SimpleZip: '%s' not found in the given zip bytes" % file_in_zip)
	return PoolByteArray()


# Convenience wrapper: reads a file from an in-memory zip as a UTF-8 string.
static func read_file_as_text_bytes(zip_bytes: PoolByteArray, file_in_zip: String) -> String:
	return read_file_bytes(zip_bytes, file_in_zip).get_string_from_utf8()


# Adds (or replaces) a single file in an in-memory zip and returns the
# updated archive bytes. See _patch_zip_bytes() for what makes this fast.
static func insert_file_bytes(zip_bytes: PoolByteArray, file_in_zip: String, content, compress: bool = false) -> PoolByteArray:
	return insert_files_bytes(zip_bytes, {file_in_zip: content}, compress)


# Adds/replaces several files at once (one pass instead of one per file)
# and returns the updated archive bytes.
static func insert_files_bytes(zip_bytes: PoolByteArray, files: Dictionary, compress: bool = false) -> PoolByteArray:
	return _patch_zip_bytes(zip_bytes, files, [], compress)


# Removes a single entry from an in-memory zip and returns the updated
# archive bytes.
static func remove_file_bytes(zip_bytes: PoolByteArray, file_in_zip: String, compress: bool = false) -> PoolByteArray:
	return remove_files_bytes(zip_bytes, [file_in_zip], compress)


# Removes several entries at once (one pass instead of one per file) and
# returns the updated archive bytes.
static func remove_files_bytes(zip_bytes: PoolByteArray, names: Array, compress: bool = false) -> PoolByteArray:
	return _patch_zip_bytes(zip_bytes, {}, names, compress)


# Extracts every entry from an in-memory zip onto disk under
# destination_dir, preserving the folder structure stored in the archive.
static func extract_all_bytes(zip_bytes: PoolByteArray, destination_dir: String) -> bool:
	var entries := _read_central_directory_from_bytes(zip_bytes)
	if entries.empty():
		return false

	var dir := Directory.new()
	dir.make_dir_recursive(destination_dir)

	for entry in entries:
		if entry.name.find("..") != -1:
			push_error("SimpleZip: skipping suspicious entry '%s'" % entry.name)
			continue

		if entry.name.ends_with("/"):
			dir.make_dir_recursive(destination_dir.plus_file(entry.name))
			continue

		var out_path := destination_dir.plus_file(entry.name)
		dir.make_dir_recursive(out_path.get_base_dir())

		var out_file := File.new()
		if out_file.open(out_path, File.WRITE) != OK:
			push_error("SimpleZip: could not write '%s'" % out_path)
			continue
		out_file.store_buffer(_read_entry_data_from_bytes(zip_bytes, entry))
		out_file.close()
	return true


# --------------------------------------------------------------------
# PUBLIC API - file-based convenience wrappers
# --------------------------------------------------------------------
# Everything below just loads a path into bytes, calls the in-memory
# core above, and (for anything that changes the archive) saves the
# result back out - no zip-format logic lives down here.

static func create_zip(zip_path: String, files: Dictionary, compress: bool = false) -> bool:
	return _save_bytes_to_file(zip_path, create_zip_bytes(files, compress))


# Zips up an entire directory (recursively) into a new archive.
static func zip_directory(source_dir: String, zip_path: String, compress: bool = false) -> bool:
	var files := {}
	_collect_directory(source_dir, "", files)
	return create_zip(zip_path, files, compress)


# Returns the list of entry names stored in the zip (folders included).
static func list_files(zip_path: String) -> Array:
	return list_files_bytes(_load_bytes_from_file(zip_path))


# Returns true if `file_in_zip` is present in the archive.
static func file_exists(zip_path: String, file_in_zip: String) -> bool:
	return file_exists_bytes(_load_bytes_from_file(zip_path), file_in_zip)


# Reads one file's raw bytes out of the zip.
static func read_file(zip_path: String, file_in_zip: String) -> PoolByteArray:
	return read_file_bytes(_load_bytes_from_file(zip_path), file_in_zip)


# Convenience wrapper: reads a file from the zip as a UTF-8 string.
static func read_file_as_text(zip_path: String, file_in_zip: String) -> String:
	return read_file(zip_path, file_in_zip).get_string_from_utf8()


# Extracts every entry in the zip to disk under destination_dir,
# preserving the folder structure stored in the archive.
static func extract_all(zip_path: String, destination_dir: String) -> bool:
	return extract_all_bytes(_load_bytes_from_file(zip_path), destination_dir)


# Adds (or replaces) a single file inside an existing zip, writing the
# result back to zip_path. Creates zip_path if it doesn't exist yet.
static func insert_file(zip_path: String, file_in_zip: String, content, compress: bool = false) -> bool:
	return insert_files(zip_path, {file_in_zip: content}, compress)


# Adds/replaces several files at once (one pass instead of one per file).
static func insert_files(zip_path: String, files: Dictionary, compress: bool = false) -> bool:
	var zip_bytes := _load_bytes_from_file(zip_path)
	return _save_bytes_to_file(zip_path, _patch_zip_bytes(zip_bytes, files, [], compress))


# Removes a single entry from an existing zip, writing the result back
# to zip_path.
static func remove_file(zip_path: String, file_in_zip: String, compress: bool = false) -> bool:
	return remove_files(zip_path, [file_in_zip], compress)


# Removes several entries at once (one pass instead of one per file).
static func remove_files(zip_path: String, names: Array, compress: bool = false) -> bool:
	var dir := Directory.new()
	if not dir.file_exists(zip_path):
		push_error("SimpleZip: '%s' does not exist" % zip_path)
		return false
	var zip_bytes := _load_bytes_from_file(zip_path)
	return _save_bytes_to_file(zip_path, _patch_zip_bytes(zip_bytes, {}, names, compress))


static func _to_bytes(content) -> PoolByteArray:
	if typeof(content) == TYPE_STRING:
		return content.to_utf8()
	if typeof(content) == TYPE_RAW_ARRAY:
		return content
	push_error("SimpleZip: file content must be a String or PoolByteArray")
	return PoolByteArray()


static func _dos_time_date() -> Dictionary:
	var dt := OS.get_datetime()
	# Dictionary values come back as Variant, and GDScript 3.x can't infer
	# a concrete type for bitwise ops performed directly on them -- pull
	# them into explicitly-typed ints first.
	var year: int = dt.year
	var month: int = dt.month
	var day: int = dt.day
	var hour: int = dt.hour
	var minute: int = dt.minute
	var second: int = dt.second

	var dos_year := int(max(year - 1980, 0)) # max() returns float in 3.x, even for ints
	var dos_time := (hour << 11) | (minute << 5) | int(second / 2.0)
	var dos_date := (dos_year << 9) | (month << 5) | day
	return {"time": dos_time, "date": dos_date}


# Precomputed CRC-32 lookup tables used by _crc32() below, kept in a
# separate file so opening/editing THIS script doesn't require the Godot
# editor to parse thousands of numeric literals - see crc32_tables.gd for
# what's actually in there and why. Both files need to stay together;
# adjust this path if you move them somewhere other than res://.
const _CrcTables = preload("res://HevLib/scripts/crc32_table_cache.gd")


# Standard CRC-32 (same checksum zip/gzip/PNG use), using "slicing-by-32":
# 32 bytes are folded into the running CRC per loop iteration instead of
# one, via 32 precomputed lookup tables XORed together - the same family
# of technique zlib itself uses for its fast path. Tables are hardcoded
# consts rather than computed at load time, both because GDScript 3.x has
# no `static var` to cache a computed table in across calls, and because
# that setup cost measurably matters when writing many small files.
#
# This specific width was chosen by measuring, not guessed: slicing-by-4
# actually loses to the plain single-table version below it (more work per
# iteration than it saves), while 8/16/32 each gave a further real speedup
# in testing (roughly 20%, 30%, 40% faster than the single-table version,
# in that order), and 64 only added a few more percent on top for double
# the table data - so 32 is close to the practical ceiling here without
# the source file size ballooning further for little extra gain.
static func _crc32(data: PoolByteArray) -> int:
	var t0 = _CrcTables.T0
	var t1 = _CrcTables.T1
	var t2 = _CrcTables.T2
	var t3 = _CrcTables.T3
	var t4 = _CrcTables.T4
	var t5 = _CrcTables.T5
	var t6 = _CrcTables.T6
	var t7 = _CrcTables.T7
	var t8 = _CrcTables.T8
	var t9 = _CrcTables.T9
	var t10 = _CrcTables.T10
	var t11 = _CrcTables.T11
	var t12 = _CrcTables.T12
	var t13 = _CrcTables.T13
	var t14 = _CrcTables.T14
	var t15 = _CrcTables.T15
	var t16 = _CrcTables.T16
	var t17 = _CrcTables.T17
	var t18 = _CrcTables.T18
	var t19 = _CrcTables.T19
	var t20 = _CrcTables.T20
	var t21 = _CrcTables.T21
	var t22 = _CrcTables.T22
	var t23 = _CrcTables.T23
	var t24 = _CrcTables.T24
	var t25 = _CrcTables.T25
	var t26 = _CrcTables.T26
	var t27 = _CrcTables.T27
	var t28 = _CrcTables.T28
	var t29 = _CrcTables.T29
	var t30 = _CrcTables.T30
	var t31 = _CrcTables.T31

	var crc := 0xFFFFFFFF
	var size := data.size()
	var groups := size / 32
	var i := 0
	for _g in range(groups):
		# The running crc is 4 bytes; XOR each of its bytes with the next
		# 4 data bytes before their lookups. The remaining bytes in the
		# group need no such XOR - by this point crc's influence on the
		# result has already been fully captured by the first four.
		var n0 := (crc & 0xFF) ^ data[i]
		var n1 := ((crc >> 8) & 0xFF) ^ data[i + 1]
		var n2 := ((crc >> 16) & 0xFF) ^ data[i + 2]
		var n3 := ((crc >> 24) & 0xFF) ^ data[i + 3]
		crc = (t31[n0] ^
			t30[n1] ^
			t29[n2] ^
			t28[n3] ^
			t27[data[i + 4]] ^
			t26[data[i + 5]] ^
			t25[data[i + 6]] ^
			t24[data[i + 7]] ^
			t23[data[i + 8]] ^
			t22[data[i + 9]] ^
			t21[data[i + 10]] ^
			t20[data[i + 11]] ^
			t19[data[i + 12]] ^
			t18[data[i + 13]] ^
			t17[data[i + 14]] ^
			t16[data[i + 15]] ^
			t15[data[i + 16]] ^
			t14[data[i + 17]] ^
			t13[data[i + 18]] ^
			t12[data[i + 19]] ^
			t11[data[i + 20]] ^
			t10[data[i + 21]] ^
			t9[data[i + 22]] ^
			t8[data[i + 23]] ^
			t7[data[i + 24]] ^
			t6[data[i + 25]] ^
			t5[data[i + 26]] ^
			t4[data[i + 27]] ^
			t3[data[i + 28]] ^
			t2[data[i + 29]] ^
			t1[data[i + 30]] ^
			t0[data[i + 31]])
		i += 32
	# Tail: 0 to 31 leftover bytes that don't fill a full group,
	# handled the plain single-byte-per-step way.
	while i < size:
		crc = t0[(crc ^ data[i]) & 0xFF] ^ (crc >> 8)
		i += 1
	return crc ^ 0xFFFFFFFF


static func _read_u32_le(bytes: PoolByteArray, at: int) -> int:
	return bytes[at] | (bytes[at + 1] << 8) | (bytes[at + 2] << 16) | (bytes[at + 3] << 24)


static func _read_u16_le(bytes: PoolByteArray, at: int) -> int:
	return bytes[at] | (bytes[at + 1] << 8)


# Compresses data with Godot's built-in zlib-format compressor, then trims
# the 2-byte zlib header and 4-byte Adler-32 trailer off. What's left is a
# raw deflate stream: exactly the payload format a zip's "Deflated" method
# expects, since the zlib container is by definition just that wrapped.
static func _deflate_compress(data: PoolByteArray) -> PoolByteArray:
	var wrapped := data.compress(File.COMPRESSION_DEFLATE)
	return wrapped.subarray(2, wrapped.size() - 5)


# Writes every entry in `files`, then the central directory and
# end-of-central-directory record. `compress` selects Deflate over Stored
# per file, but only where it actually saves space.
# --------------------------------------------------------------------
# INTERNAL HELPERS - file <-> bytes
# --------------------------------------------------------------------

static func _load_bytes_from_file(zip_path: String) -> PoolByteArray:
	var file := File.new()
	if file.open(zip_path, File.READ) != OK:
		return PoolByteArray()
	var data := file.get_buffer(file.get_len())
	file.close()
	return data


static func _save_bytes_to_file(zip_path: String, data: PoolByteArray) -> bool:
	var file := File.new()
	if file.open(zip_path, File.WRITE) != OK:
		push_error("SimpleZip: could not open '%s' for writing" % zip_path)
		return false
	file.store_buffer(data)
	file.close()
	return true


# --------------------------------------------------------------------
# INTERNAL HELPERS - building zip bytes
# --------------------------------------------------------------------
# A note on style: every function here either builds a small, complete
# PoolByteArray from scratch and returns it, or owns a single growing
# buffer as a local variable and calls .append_array() on that local
# directly. Neither pattern ever mutates a PoolByteArray that arrived as
# a function parameter or an object property and expects the caller to
# see the change - that silently does NOT work in GDScript 3.x (Pool*
# Array parameters/properties are value-copied on mutation), which is
# also why the DEFLATE decoder further down uses a plain Array instead.

# Builds the complete local file header + (possibly compressed) data for
# one entry. Returns {bytes, record}: `bytes` is what to place directly
# in the archive, `record` is what _build_central_directory_and_eocd()
# needs once the entry's final offset is known.
#
# The buffer is sized once (30-byte fixed header + name + payload) and
# filled with direct indexed writes rather than many small
# append_array() calls - resize-then-index measured faster than
# append_array in this environment. Fields that are the same for every
# entry (the signature, version-needed, and UTF-8 flag) are written as
# their already-known bytes instead of being bit-shifted out of
# _LOCAL_FILE_SIG/_VERSION_NEEDED/_FLAG_UTF8 on every single call; update
# both if any of those three constants ever change.
static func _build_local_entry(name: String, content, compress: bool, mod_time: int, mod_date: int) -> Dictionary:
	var data := _to_bytes(content)
	var name_bytes: PoolByteArray = name.to_utf8()
	var crc := _crc32(data)

	var method := _METHOD_STORED
	var payload := data
	if compress and data.size() > 0:
		var deflated := _deflate_compress(data)
		if deflated.size() < data.size():
			method = _METHOD_DEFLATE
			payload = deflated

	var name_len := name_bytes.size()
	var comp_size := payload.size()
	var uncomp_size := data.size()

	var out := PoolByteArray()
	out.resize(30 + name_len + comp_size)

	out[0] = 0x50 # local file header signature (_LOCAL_FILE_SIG), fixed
	out[1] = 0x4b
	out[2] = 0x03
	out[3] = 0x04
	out[4] = 20   # version needed (_VERSION_NEEDED = 20), fixed
	out[5] = 0
	out[6] = 0x00 # general purpose flag (_FLAG_UTF8 = 0x0800), fixed
	out[7] = 0x08
	out[8] = method & 0xFF
	out[9] = (method >> 8) & 0xFF
	out[10] = mod_time & 0xFF
	out[11] = (mod_time >> 8) & 0xFF
	out[12] = mod_date & 0xFF
	out[13] = (mod_date >> 8) & 0xFF
	out[14] = crc & 0xFF
	out[15] = (crc >> 8) & 0xFF
	out[16] = (crc >> 16) & 0xFF
	out[17] = (crc >> 24) & 0xFF
	out[18] = comp_size & 0xFF
	out[19] = (comp_size >> 8) & 0xFF
	out[20] = (comp_size >> 16) & 0xFF
	out[21] = (comp_size >> 24) & 0xFF
	out[22] = uncomp_size & 0xFF
	out[23] = (uncomp_size >> 8) & 0xFF
	out[24] = (uncomp_size >> 16) & 0xFF
	out[25] = (uncomp_size >> 24) & 0xFF
	out[26] = name_len & 0xFF
	out[27] = (name_len >> 8) & 0xFF
	out[28] = 0 # extra field length, always 0
	out[29] = 0

	for i in range(name_len):
		out[30 + i] = name_bytes[i]
	for i in range(comp_size):
		out[30 + name_len + i] = payload[i]

	return {
		"bytes": out,
		"record": {
			"name_bytes": name_bytes,
			"crc": crc,
			"method": method,
			"comp_size": comp_size,
			"uncomp_size": uncomp_size,
			"mod_time": mod_time,
			"mod_date": mod_date,
		},
	}


# Builds the central directory (one record per entry) followed by the
# end-of-central-directory record. `central_dir_offset` is where this
# data will sit within the *final* archive, which the caller must know
# (it's just "how much I've written so far"), since the EOCD needs to
# record it as an absolute position.
#
# Same approach as _build_local_entry(): the exact final size is known
# up front (46 bytes per record, plus its name, plus the fixed 22-byte
# EOCD), so the buffer is resized once and filled by indexed writes with
# a running cursor `p`, instead of building it up through many small
# append_array() calls. As above, the per-record signature/version/flag
# bytes and the always-zero fields are written directly rather than
# recomputed from the constants each time.
static func _build_central_directory_and_eocd(records: Array, central_dir_offset: int) -> PoolByteArray:
	var central_dir_size := 0
	for rec in records:
		var name_bytes: PoolByteArray = rec.name_bytes
		central_dir_size += 46 + name_bytes.size()

	var out := PoolByteArray()
	out.resize(central_dir_size + _EOCD_FIXED_SIZE)

	var p := 0
	for rec in records:
		var name_bytes: PoolByteArray = rec.name_bytes
		var name_len := name_bytes.size()
		var method: int = rec.method
		var mod_time: int = rec.mod_time
		var mod_date: int = rec.mod_date
		var crc: int = rec.crc
		var comp_size: int = rec.comp_size
		var uncomp_size: int = rec.uncomp_size
		var offset: int = rec.offset

		out[p] = 0x50 # central file header signature (_CENTRAL_DIR_SIG), fixed
		out[p + 1] = 0x4b
		out[p + 2] = 0x01
		out[p + 3] = 0x02
		out[p + 4] = 20   # version made by (_VERSION_NEEDED = 20), fixed
		out[p + 5] = 0
		out[p + 6] = 20   # version needed (_VERSION_NEEDED = 20), fixed
		out[p + 7] = 0
		out[p + 8] = 0x00 # general purpose flag (_FLAG_UTF8 = 0x0800), fixed
		out[p + 9] = 0x08
		out[p + 10] = method & 0xFF
		out[p + 11] = (method >> 8) & 0xFF
		out[p + 12] = mod_time & 0xFF
		out[p + 13] = (mod_time >> 8) & 0xFF
		out[p + 14] = mod_date & 0xFF
		out[p + 15] = (mod_date >> 8) & 0xFF
		out[p + 16] = crc & 0xFF
		out[p + 17] = (crc >> 8) & 0xFF
		out[p + 18] = (crc >> 16) & 0xFF
		out[p + 19] = (crc >> 24) & 0xFF
		out[p + 20] = comp_size & 0xFF
		out[p + 21] = (comp_size >> 8) & 0xFF
		out[p + 22] = (comp_size >> 16) & 0xFF
		out[p + 23] = (comp_size >> 24) & 0xFF
		out[p + 24] = uncomp_size & 0xFF
		out[p + 25] = (uncomp_size >> 8) & 0xFF
		out[p + 26] = (uncomp_size >> 16) & 0xFF
		out[p + 27] = (uncomp_size >> 24) & 0xFF
		out[p + 28] = name_len & 0xFF
		out[p + 29] = (name_len >> 8) & 0xFF
		out[p + 30] = 0 # extra field length, always 0
		out[p + 31] = 0
		out[p + 32] = 0 # file comment length, always 0
		out[p + 33] = 0
		out[p + 34] = 0 # disk number start, always 0
		out[p + 35] = 0
		out[p + 36] = 0 # internal file attributes, always 0
		out[p + 37] = 0
		out[p + 38] = 0 # external file attributes, always 0
		out[p + 39] = 0
		out[p + 40] = 0
		out[p + 41] = 0
		out[p + 42] = offset & 0xFF
		out[p + 43] = (offset >> 8) & 0xFF
		out[p + 44] = (offset >> 16) & 0xFF
		out[p + 45] = (offset >> 24) & 0xFF

		for i in range(name_len):
			out[p + 46 + i] = name_bytes[i]

		p += 46 + name_len

	var count := records.size()
	out[p] = 0x50 # end of central directory signature (_EOCD_SIG), fixed
	out[p + 1] = 0x4b
	out[p + 2] = 0x05
	out[p + 3] = 0x06
	out[p + 4] = 0 # number of this disk, always 0
	out[p + 5] = 0
	out[p + 6] = 0 # disk where central directory starts, always 0
	out[p + 7] = 0
	out[p + 8] = count & 0xFF
	out[p + 9] = (count >> 8) & 0xFF
	out[p + 10] = count & 0xFF
	out[p + 11] = (count >> 8) & 0xFF
	out[p + 12] = central_dir_size & 0xFF
	out[p + 13] = (central_dir_size >> 8) & 0xFF
	out[p + 14] = (central_dir_size >> 16) & 0xFF
	out[p + 15] = (central_dir_size >> 24) & 0xFF
	out[p + 16] = central_dir_offset & 0xFF
	out[p + 17] = (central_dir_offset >> 8) & 0xFF
	out[p + 18] = (central_dir_offset >> 16) & 0xFF
	out[p + 19] = (central_dir_offset >> 24) & 0xFF
	out[p + 20] = 0 # zip comment length, always 0
	out[p + 21] = 0

	return out


# Builds a brand-new zip's complete bytes from `files`.
static func _build_zip_bytes(files: Dictionary, compress: bool) -> PoolByteArray:
	var dt := _dos_time_date()
	var out := PoolByteArray()
	var records := []

	for entry_path in files.keys():
		var built := _build_local_entry(entry_path, files[entry_path], compress, dt.time, dt.date)
		built.record["offset"] = out.size()
		out.append_array(built.bytes)
		records.append(built.record)

	var central_dir_offset := out.size()
	out.append_array(_build_central_directory_and_eocd(records, central_dir_offset))
	return out


# --------------------------------------------------------------------
# INTERNAL HELPERS - reading zip bytes
# --------------------------------------------------------------------

# Locates the end-of-central-directory record, then walks the central
# directory to build a lightweight index of every entry. Returns [] if
# `zip_bytes` isn't a valid zip.
static func _read_central_directory_from_bytes(zip_bytes: PoolByteArray) -> Array:
	var total_len := zip_bytes.size()
	if total_len < _EOCD_FIXED_SIZE:
		return []

	# EOCD sits at the end of the archive; a trailing zip comment (up to
	# 65535 bytes) can follow it, so search backward far enough to allow
	# for the largest possible comment.
	var search_start = max(total_len - _EOCD_FIXED_SIZE - 65536, 0)

	var eocd_pos := -1
	var i := total_len - _EOCD_FIXED_SIZE
	while i >= search_start:
		if zip_bytes[i] == 0x50 and zip_bytes[i + 1] == 0x4b and zip_bytes[i + 2] == 0x05 and zip_bytes[i + 3] == 0x06:
			eocd_pos = i
			break
		i -= 1

	if eocd_pos == -1:
		push_error("SimpleZip: doesn't look like a zip (no End Of Central Directory record found)")
		return []

	var total_entries := _read_u16_le(zip_bytes, eocd_pos + 10)
	var pos := _read_u32_le(zip_bytes, eocd_pos + 16)

	var entries := []
	for _n in range(total_entries):
		if _read_u32_le(zip_bytes, pos) != _CENTRAL_DIR_SIG:
			push_error("SimpleZip: central directory is corrupt")
			break

		var method := _read_u16_le(zip_bytes, pos + 10)
		var mod_time := _read_u16_le(zip_bytes, pos + 12)
		var mod_date := _read_u16_le(zip_bytes, pos + 14)
		var crc := _read_u32_le(zip_bytes, pos + 16)
		var comp_size := _read_u32_le(zip_bytes, pos + 20)
		var uncomp_size := _read_u32_le(zip_bytes, pos + 24)
		var name_len := _read_u16_le(zip_bytes, pos + 28)
		var extra_len := _read_u16_le(zip_bytes, pos + 30)
		var comment_len := _read_u16_le(zip_bytes, pos + 32)
		var local_offset := _read_u32_le(zip_bytes, pos + 42)

		var name := ""
		if name_len > 0:
			name = zip_bytes.subarray(pos + 46, pos + 46 + name_len - 1).get_string_from_utf8()

		entries.append({
			"name": name,
			"method": method,
			"comp_size": comp_size,
			"uncomp_size": uncomp_size,
			"crc": crc,
			"mod_time": mod_time,
			"mod_date": mod_date,
			"local_offset": local_offset,
		})

		pos += 46 + name_len + extra_len + comment_len

	return entries


# Given an entry's local_offset, returns the position where its actual
# (possibly compressed) data begins - i.e. just after its local header,
# name, and extra field. Reads the name/extra lengths fresh from the
# LOCAL header rather than trusting the central directory's copy, since
# the extra field in particular is allowed to differ in length between
# the two.
static func _local_data_offset_bytes(zip_bytes: PoolByteArray, local_offset: int) -> int:
	var name_len := _read_u16_le(zip_bytes, local_offset + 26)
	var extra_len := _read_u16_le(zip_bytes, local_offset + 28)
	return local_offset + 30 + name_len + extra_len


# The file position one past the end of an entry's data - i.e. where the
# next entry (or the central directory, if this is the last entry) would
# start if the archive has no gaps between entries.
static func _entry_extent_end_bytes(zip_bytes: PoolByteArray, entry: Dictionary) -> int:
	return _local_data_offset_bytes(zip_bytes, entry.local_offset) + entry.comp_size


# Reads (and decompresses, if needed) one entry's data, given a record
# from _read_central_directory_from_bytes().
static func _read_entry_data_from_bytes(zip_bytes: PoolByteArray, entry: Dictionary) -> PoolByteArray:
	if entry.method != _METHOD_STORED and entry.method != _METHOD_DEFLATE:
		push_error("SimpleZip: '%s' uses compression method %d, which isn't supported (only Stored/0 and Deflate/8 are)" % [entry.name, entry.method])
		return PoolByteArray()

	var data_start := _local_data_offset_bytes(zip_bytes, entry.local_offset)
	var raw := PoolByteArray()
	if entry.comp_size > 0:
		raw = zip_bytes.subarray(data_start, data_start + entry.comp_size - 1)

	var data: PoolByteArray = _inflate(raw, entry.uncomp_size) if entry.method == _METHOD_DEFLATE else raw

	if data.size() != entry.uncomp_size:
		push_error("SimpleZip: '%s' decompressed to %d bytes, expected %d - it may be corrupted" % [entry.name, data.size(), entry.uncomp_size])

	return data


# Turns an existing entry (from _read_central_directory_from_bytes) into
# the record shape _build_central_directory_and_eocd() expects, at
# whatever offset it now lives at.
static func _record_from_entry(entry: Dictionary, new_offset: int) -> Dictionary:
	return {
		"name_bytes": String(entry.name).to_utf8(),
		"crc": entry.crc,
		"method": entry.method,
		"comp_size": entry.comp_size,
		"uncomp_size": entry.uncomp_size,
		"mod_time": entry.mod_time,
		"mod_date": entry.mod_date,
		"offset": new_offset,
	}


# --------------------------------------------------------------------
# INTERNAL HELPERS - efficient insert/replace/remove
# --------------------------------------------------------------------
#
# The key idea: an entry that is neither being added, replaced, nor
# removed doesn't need to be understood at all, just relocated as a
# block of bytes. So this never decompresses or recompresses anything
# except the actual new/changed content the caller provided.
#
#   upsert       {"path/in/zip": content, ...} - files to add or replace
#   remove_names [...]                         - names to delete
#
# Two shapes of update:
#
#  - PURE ADD (nothing in upsert/remove_names matches an existing name):
#    every kept entry's bytes AND offset are left completely untouched -
#    new entries are appended where the old central directory used to
#    sit, followed by a fresh central directory. Nothing existing is
#    ever copied, read, or moved.
#
#  - ANY REPLACE OR REMOVE: since an entry is leaving its slot, the
#    result is assembled fresh - but "assembled" still just means
#    concatenating each kept entry's original bytes verbatim (via
#    subarray, a fast native copy) with the newly-built entries, never
#    decoding a kept entry's content.
static func _patch_zip_bytes(zip_bytes: PoolByteArray, upsert: Dictionary, remove_names: Array, compress: bool) -> PoolByteArray:
	if zip_bytes.empty():
		return _build_zip_bytes(upsert, compress)

	var old_entries := _read_central_directory_from_bytes(zip_bytes)

	var remove_set := {}
	for n in remove_names:
		remove_set[n] = true

	var has_conflict := false
	for entry in old_entries:
		if upsert.has(entry.name) or remove_set.has(entry.name):
			has_conflict = true
			break

	var dt := _dos_time_date()
	var out := PoolByteArray()
	var records := []

	if not has_conflict:
		# Fast path: keep every existing byte exactly where it is. Only
		# the (comparatively tiny) old central directory + EOCD, which
		# sit past the last real entry, get replaced.
		var append_at := 0
		for entry in old_entries:
			append_at = max(append_at, _entry_extent_end_bytes(zip_bytes, entry))
			records.append(_record_from_entry(entry, entry.local_offset))

		out = zip_bytes.subarray(0, append_at - 1) if append_at > 0 else PoolByteArray()
	else:
		# Something is moving: copy every kept entry's bytes verbatim
		# into a fresh buffer, skipping whatever's being replaced/removed.
		for entry in old_entries:
			if upsert.has(entry.name) or remove_set.has(entry.name):
				continue
			var start: int = entry.local_offset
			var end := _entry_extent_end_bytes(zip_bytes, entry)
			records.append(_record_from_entry(entry, out.size()))
			out.append_array(zip_bytes.subarray(start, end - 1))

	for entry_path in upsert.keys():
		var built := _build_local_entry(entry_path, upsert[entry_path], compress, dt.time, dt.date)
		built.record["offset"] = out.size()
		out.append_array(built.bytes)
		records.append(built.record)

	var central_dir_offset := out.size()
	out.append_array(_build_central_directory_and_eocd(records, central_dir_offset))
	return out


static func _collect_directory(disk_dir: String, zip_prefix: String, out_files: Dictionary) -> void:
	var dir := Directory.new()
	if dir.open(disk_dir) != OK:
		push_error("SimpleZip: could not open directory '%s'" % disk_dir)
		return

	dir.list_dir_begin(true, true) # skip navigational + hidden entries
	var entry_name := dir.get_next()
	while entry_name != "":
		var disk_path := disk_dir.plus_file(entry_name)
		var zip_entry_path := entry_name if zip_prefix == "" else zip_prefix + "/" + entry_name

		if dir.current_is_dir():
			_collect_directory(disk_path, zip_entry_path, out_files)
		else:
			var f := File.new()
			if f.open(disk_path, File.READ) == OK:
				out_files[zip_entry_path] = f.get_buffer(f.get_len())
				f.close()

		entry_name = dir.get_next()
	dir.list_dir_end()


# --------------------------------------------------------------------
# INTERNAL HELPERS - a from-scratch RFC 1951 DEFLATE decoder
# --------------------------------------------------------------------
#
# Godot's own PoolByteArray.decompress() can't be reused here (see the
# note at the top of this file), so this is a real, independent INFLATE
# implementation - a GDScript port of the same tinf-style algorithm the
# "gdunzip" addon uses, chosen after comparing against it directly:
#
#  - Huffman decoding uses plain array indexing (a per-length count
#    table plus a symbols-sorted-by-code array, walked with simple
#    arithmetic - see _decode_huffman_symbol) rather than nested
#    Dictionary lookups. Dictionary hashing per bit, for every symbol
#    decoded, was the single biggest cost in an earlier version of this
#    file.
#  - The output buffer is allocated once, up front, to the exact
#    decompressed size (always known from the zip entry's own header),
#    and filled with direct indexed writes instead of growing via
#    append().
#
# A GDScript-specific trap shapes how the code below is written: indexed
# assignment into a PoolByteArray/PoolIntArray held as an object property
# or a Dictionary value (e.g. `some_state.output[i] = x`, repeated many
# times) is not just uncached - it's quadratic overall, apparently
# re-touching the whole buffer on every single write. The fix is the one
# gdunzip also uses: a Pool*Array only ever gets indexed in a tight loop
# after it's a genuine local variable or a plain function parameter
# (confirmed by direct measurement to be the fast, expected O(1)-per-write
# case) - never through a `.property[i] =` or `dict['key'][i] =` chain.
# Concretely, that means `output` is threaded through the block-decoding
# functions as a parameter, and handed back (since parameter mutations
# don't propagate to the caller either - only *reading* a Pool*Array
# through a property or parameter is cheap; every kind of write through
# one is not) for the caller to reassign into its own local variable.

const _LENGTH_BASE  := [3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258]
const _LENGTH_EXTRA := [0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0]
const _DIST_BASE    := [1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577]
const _DIST_EXTRA   := [0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13]
const _CL_ORDER     := [16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15]

# Bit-level cursor over the compressed bytes. `input` is only ever read
# from (never written to) through this object, which is the cheap case
# regardless of it being a property - see the note above.
class _InflateState:
	var input: PoolByteArray
	var pos: int = 0
	var bit_buf: int = 0
	var bit_count: int = 0

	func _init(data: PoolByteArray) -> void:
		input = data

	func get_bit() -> int:
		if bit_count == 0:
			if pos >= input.size():
				return 0
			bit_buf = input[pos]
			pos += 1
			bit_count = 8
		var bit := bit_buf & 1
		bit_buf = bit_buf >> 1
		bit_count -= 1
		return bit

	# Fixed-width fields (extra bits, header counts, stored-block length)
	# are packed LSB-first: the first bit read is bit 0 of the value.
	# `base` is added directly to the result, since every call site wants
	# "N extra bits, plus some base value" - one fewer place to add it.
	func get_bits(n: int, base: int = 0) -> int:
		var val := 0
		if n > 0:
			var limit := 1 << n
			var mask := 1
			while mask < limit:
				if get_bit():
					val += mask
				mask = mask * 2
		return val + base

	func align_to_byte() -> void:
		bit_buf = 0
		bit_count = 0


# Builds a tinf-style decode structure from an array of code lengths
# (lengths[symbol] = bit length, 0 = symbol unused, for the first `num`
# symbols): table[L] holds the plain count of symbols with length L, and
# trans[] holds every symbol with a nonzero length, grouped by length
# and then by symbol index - i.e. codes in canonical order. Decoding
# (_decode_huffman_symbol) only ever does array indexing against these,
# no dictionary/hash lookups, which is the main speed win over a more
# direct "build a code->symbol map" approach.
static func _build_huffman_tree(lengths: PoolByteArray, num: int) -> Dictionary:
	var table := PoolIntArray()
	table.resize(16)
	for i in range(16):
		table[i] = 0
	for i in range(num):
		table[lengths[i]] += 1
	table[0] = 0

	var offs := PoolIntArray()
	offs.resize(16)
	var sum := 0
	for i in range(16):
		offs[i] = sum
		sum += table[i]

	var trans := PoolIntArray()
	trans.resize(288)
	for i in range(num):
		if lengths[i]:
			trans[offs[lengths[i]]] = i
			offs[lengths[i]] += 1

	return {"table": table, "trans": trans}


# Decodes one Huffman symbol. `sum`/`cur` track, bit by bit, how far the
# code read so far is from the first code of the current length; once
# `cur` goes negative the code has landed within this length's block of
# `table[length]` codes, and `trans[sum + cur]` is exactly that symbol.
# (Concretely verified against a hand-traced example before trusting it.)
static func _decode_huffman_symbol(state: _InflateState, table: PoolIntArray, trans: PoolIntArray) -> int:
	var sum := 0
	var cur := 0
	var length := 0
	while true:
		cur = 2 * cur + state.get_bit()
		length += 1
		sum += table[length]
		cur -= table[length]
		if cur < 0:
			return trans[sum + cur]
	return -1 # unreachable: the loop above always returns once cur < 0


static func _fixed_litlen_tree() -> Dictionary:
	var lengths := PoolByteArray()
	lengths.resize(288)
	for i in range(0, 144):
		lengths[i] = 8
	for i in range(144, 256):
		lengths[i] = 9
	for i in range(256, 280):
		lengths[i] = 7
	for i in range(280, 288):
		lengths[i] = 8
	return _build_huffman_tree(lengths, 288)


static func _fixed_dist_tree() -> Dictionary:
	var lengths := PoolByteArray()
	lengths.resize(30)
	for i in range(30):
		lengths[i] = 5
	return _build_huffman_tree(lengths, 30)


# Reads a dynamic block's header (RFC 1951 3.2.7) and returns
# [litlen_tree, dist_tree] built from the code lengths it describes.
static func _read_dynamic_trees(state: _InflateState) -> Array:
	var hlit := state.get_bits(5, 257)
	var hdist := state.get_bits(5, 1)
	var hclen := state.get_bits(4, 4)

	var cl_lengths := PoolByteArray()
	cl_lengths.resize(19)
	for i in range(19):
		cl_lengths[i] = 0
	for i in range(hclen):
		cl_lengths[_CL_ORDER[i]] = state.get_bits(3)
	var cl_tree := _build_huffman_tree(cl_lengths, 19)
	var cl_table: PoolIntArray = cl_tree.table
	var cl_trans: PoolIntArray = cl_tree.trans

	var lengths := PoolByteArray()
	lengths.resize(288 + 32)
	var num := 0
	var total := hlit + hdist
	while num < total:
		var sym := _decode_huffman_symbol(state, cl_table, cl_trans)
		if sym < 16:
			lengths[num] = sym
			num += 1
		elif sym == 16:
			var prev := lengths[num - 1]
			var repeat := state.get_bits(2, 3)
			while repeat > 0:
				lengths[num] = prev
				num += 1
				repeat -= 1
		elif sym == 17:
			var repeat := state.get_bits(3, 3)
			while repeat > 0:
				lengths[num] = 0
				num += 1
				repeat -= 1
		else: # 18
			var repeat := state.get_bits(7, 11)
			while repeat > 0:
				lengths[num] = 0
				num += 1
				repeat -= 1

	var litlen_tree := _build_huffman_tree(lengths, hlit)
	var dist_lengths := lengths.subarray(hlit, hlit + hdist - 1)
	var dist_tree := _build_huffman_tree(dist_lengths, hdist)

	return [litlen_tree, dist_tree]


# Decompresses a raw DEFLATE stream (RFC 1951, no zlib/gzip wrapper) -
# exactly what a zip's "Deflated" entries contain on disk - into exactly
# `uncompressed_size` bytes (always known up front from the entry's own
# header, which is what lets the output buffer be allocated once instead
# of grown incrementally).
#
# The literal/length/distance decode loop lives directly in this
# function rather than in a helper it calls once per block, and that's
# not just style: passing a PoolByteArray as a parameter and then writing
# through it costs time proportional to the array's *entire* current
# size, not to the write - confirmed by direct measurement, apparently a
# copy-on-write detach that copies the whole buffer on first mutation
# rather than tracking the single change. A small file with few blocks
# barely notices; a large file making that trip once per block (of which
# there can be hundreds) turns into real quadratic-ish overhead. Keeping
# `output`/`out_pos` as this one function's own locals for the entire
# decompression avoids it.
static func _inflate(data: PoolByteArray, uncompressed_size: int) -> PoolByteArray:
	var state := _InflateState.new(data)
	var output := PoolByteArray()
	output.resize(uncompressed_size)
	var out_pos := 0

	var fixed_litlen: Dictionary
	var fixed_dist: Dictionary
	var have_fixed := false

	while true:
		var bfinal := state.get_bit()
		var btype := state.get_bits(2)

		if btype == 0:
			state.align_to_byte()
			var len_lo: int = state.input[state.pos]
			var len_hi: int = state.input[state.pos + 1]
			var length := len_lo | (len_hi << 8)
			state.pos += 4 # skip LEN + one's-complement NLEN
			for i in range(length):
				output[out_pos + i] = state.input[state.pos + i]
			out_pos += length
			state.pos += length
			if bfinal == 1:
				break
			continue

		var table: PoolIntArray
		var trans: PoolIntArray
		var dtable: PoolIntArray
		var dtrans: PoolIntArray

		if btype == 1:
			if not have_fixed:
				fixed_litlen = _fixed_litlen_tree()
				fixed_dist = _fixed_dist_tree()
				have_fixed = true
			table = fixed_litlen.table
			trans = fixed_litlen.trans
			dtable = fixed_dist.table
			dtrans = fixed_dist.trans
		elif btype == 2:
			var trees := _read_dynamic_trees(state)
			var litlen_tree: Dictionary = trees[0]
			var dist_tree: Dictionary = trees[1]
			table = litlen_tree.table
			trans = litlen_tree.trans
			dtable = dist_tree.table
			dtrans = dist_tree.trans
		else:
			push_error("SimpleZip: reserved/invalid DEFLATE block type (corrupt data?)")
			break

		while true:
			var sym := _decode_huffman_symbol(state, table, trans)
			if sym < 256:
				output[out_pos] = sym
				out_pos += 1
			elif sym == 256:
				break
			else:
				sym -= 257
				var length := state.get_bits(_LENGTH_EXTRA[sym], _LENGTH_BASE[sym])
				var dist_sym := _decode_huffman_symbol(state, dtable, dtrans)
				var distance := state.get_bits(_DIST_EXTRA[dist_sym], _DIST_BASE[dist_sym])
				# One byte at a time (not a bulk copy): when distance <
				# length this back-reference deliberately reads bytes
				# this same loop just wrote, e.g. distance=1 repeats the
				# previous byte `length` times.
				for i in range(length):
					output[out_pos + i] = output[out_pos + i - distance]
				out_pos += length

		if bfinal == 1:
			break

	return output
