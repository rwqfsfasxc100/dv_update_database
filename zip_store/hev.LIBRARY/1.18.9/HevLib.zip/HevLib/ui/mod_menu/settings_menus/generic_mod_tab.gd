# [license]
# SPDX-License-Identifier: LicenseRef-Proprietary
# Copyright © 2026 __hev (Benjamin Buckhurst). All Rights Reserved.
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that all following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

extends Tabs

export var mod = ""
export var mod_id = ""
var pointers:HevLibPointers = ModLoader._savedObjects[0]

var tab_base:PackedScene = load("res://HevLib/ui/mod_menu/settings_menus/generic_section_tab.tscn")

onready var container = $MarginContainer/TabContainer

func _ready():
	name = mod
	var data = pointers.ConfigDriver.__get_config(mod)
	var mdata = pointers.ManifestV2.__get_mod_by_id(mod_id)["manifest"]["manifest_data"].get("configs",{})
	
	for section in mdata:
		var sec_data = mdata[section]
		var tab = tab_base.instance()
		tab.name = section
		tab.section_info = sec_data
		tab.section_values = data[section]
		tab.mod = mod
		container.add_child(tab)
		yield(pointers,"process_tick")
	yield(pointers,"process_tick")
	get_tree().call_group("hevlib_settings_tab","recheck_availability")

#func _process(_delta):
func _draw():
	$MarginContainer.rect_size = rect_size
	
	name = mod

#func _gui_input(event):
#	var this_pos = get_position_in_parent()
#	if get_parent().current_tab == this_pos:
#		if event.is_action_pressed("ui_page_up"):
#			var subtab_count = container.get_child_count()
#			if current_tab != 0:
#				current_tab -= 1
#			else:
#				if not this_pos == 0:
#					get_parent().current_tab -= 1
#
#		if event.is_action_pressed("ui_page_down"):
#			var subtab_count = container.get_child_count()
#			if current_tab != subtab_count - 1:
#				current_tab += 1
#			else:
#				if not this_pos == get_parent().get_child_count() - 1:
#					get_parent().current_tab += 1
	
