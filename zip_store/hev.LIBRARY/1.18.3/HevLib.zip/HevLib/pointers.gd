# [license]
# SPDX-License-Identifier: LicenseRef-Proprietary
# Copyright © 2026 __hev (Benjamin Buckhurst). All Rights Reserved.
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that all following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

extends Node
class_name HevLibPointers

var http:HTTPRequest = HTTPRequest.new()

var equipment_modmain:Node = null
var webtranslate_modmain:Node = null

var Achievements : _Achievements = _Achievements.new(self,http)
var ConfigDriver : _ConfigDriver = _ConfigDriver.new(self)
var FileAccess : _FileAccess = _FileAccess.new(self)
var DataFormat : _DataFormat = _DataFormat.new(self)
var DriverManagement : _DriverManagement = _DriverManagement.new(self)
var Equipment : _Equipment = _Equipment.new(self)
var Events : _Events = _Events.new(self)
var FolderAccess : _FolderAccess = _FolderAccess.new(self)
var Github : _Github = _Github.new(self)
var HevLib : _HevLib = _HevLib.new(self)
var Keymapping : _Keymapping = _Keymapping.new(self)
var ManifestV2 : _ManifestV2 = _ManifestV2.new(self)
var Math : _Math = _Math.new(self)
var NodeAccess : _NodeAccess = _NodeAccess.new(self)
var RingInfo : _RingInfo = _RingInfo.new(self)
var RPC : _RPC = _RPC.new(self)
var SafeMode : _SafeMode = _SafeMode.new(self)
var Scripting : _Scripting = _Scripting.new(self,http)
var Threading : _Threading = _Threading.new(self)
var TimeAccess : _TimeAccess = _TimeAccess.new(self)
var Tokenizer : _Tokenizer = _Tokenizer.new(self)
var Translations : _Translations = _Translations.new(self)
var WebTranslate : _WebTranslate = _WebTranslate.new(self)
var Zip : _Zip = _Zip.new(self)

var Classes:Dictionary = {
	"Achievements":Achievements,
	"ConfigDriver":ConfigDriver,
	"DataFormat":DataFormat,
	"DriverManagement":DriverManagement,
	"Equipment":Equipment,
	"Events":Events,
	"FileAccess":FileAccess,
	"FolderAccess":FolderAccess,
	"Github":Github,
	"HevLib":HevLib,
	"Keymapping":Keymapping,
	"ManifestV2":ManifestV2,
	"Math":Math,
	"NodeAccess":NodeAccess,
	"RingInfo":RingInfo,
	"RPC":RPC,
	"TimeAccess":TimeAccess,
	"Tokenizer":Tokenizer,
	"Translations":Translations,
	"WebTranslate":WebTranslate,
	"Zip":Zip,
}
const hl_copyright = "© 2024-2026 Benjamin Buckhurst a.k.a. __hev. All rights reserved."

const HEVLIB_CACHE_VERSION : int = 7

var logging_frame_interval:float = 0
var logging_current_frame_timer:int = 0

var pause_on_unfocus:bool = false

signal process_tick(delta)
signal physics_process_tick(delta)

func _init(e,v,w):
	if is_editor:
		ConfigDriver.__store_value("HevLib","HEVLIB_CONFIG_SECTION_POINTERS","compile",false);if!file.file_exists("res://VersionLabel.tscn"):return
	name = "HevLib~Pointers"
	version_string = v;equipment_modmain = e;webtranslate_modmain = w
	l("Initializing pointers")
	if Threading.require_single_threading:l("2 or fewer logical CPU cores detected, forcing single thread mode.","pointers.Threading")
	else:l("Initializing [%d] threads on CPU %s with [%d] logical processors" % [Threading.max_threads,os.get_processor_name(),os.get_processor_count()],"pointers.Threading")
	
	DataFormat.__get_vanilla_version()
	
	dir.make_dir_recursive("user://cache/logs/");dir.make_dir_recursive("user://cache/SafeMode")
	dir.make_dir_recursive("user://cache/AuxAndThrusterDriver");dir.make_dir_recursive("user://cache/Minerals")
	dir.make_dir_recursive("user://cache/updates/zip_cache");dir.make_dir_recursive("user://cache/github_list/icon_cache")
	dir.make_dir_recursive("user://cache/github_list/downloaded_zips");dir.make_dir_recursive("user://cache/Event_Driver");if(webtranslate_modmain.get_child_count()||!os.get_user_data_dir().to_lower().ends_with("/dv")):return
	
	var releases_cache:String = "user://cache/github_list/releases_cache.json"
	if not file.file_exists(releases_cache) or (Time.get_unix_time_from_system() - file.get_modified_time(releases_cache)) > 3600:
		file.open(releases_cache,File.WRITE)
		file.store_string("{}")
		file.close()
		l("Releases cache older than an hour, clearing")
	file.open("user://cache/Event_Driver/event_log.json",File.WRITE)
	file.store_string("{}");file.close()
	file.open("user://cache/Event_Driver/active_events.txt",File.WRITE)
	file.store_string("");file.close()
	file.open("user://cache/Event_Driver/latest_event.txt",File.WRITE)
	file.store_string("");file.close()
	
	if dir.dir_exists("user://cache/.HevLib_Cache/"):FolderAccess.__recursive_delete("user://cache/.HevLib_Cache/")
	if dir.dir_exists("user://cache/.Mod_Menu_2_Cache/"):FolderAccess.__recursive_delete("user://cache/.Mod_Menu_2_Cache/")
	
	RING_IMAGE_STORE["map"] = load("res://ring/ring-map.png")
	RING_IMAGE_STORE["veins"] = load("res://ring/ring-veins.png")
	
	complementary = ManifestV2.__check_complementary()
	dependancies = ManifestV2.__check_dependancies()
	conflicts = ManifestV2.__check_conflicts()
	complementary_keys = PoolStringArray(complementary.keys())
	dependancies_keys = PoolStringArray(dependancies.keys())
	conflicts_keys = PoolStringArray(conflicts.keys())
	
	if FileAccess.__load_precached_mods():return
	ConfigDriver.__load_configs()
	ConfigDriver.__store_value("HevLib","HEVLIB_CONFIG_SECTION_EVENTS","disabled_events",Array())
	
	ManifestV2.__load_modlets()
	
	print("Pointers load: ",os.get_ticks_msec())
	storeLogCache()
	
	if false:
		
		
		var t1:int=Time.get_ticks_usec()
		for i in 100000:
			pass
		var t2:int=Time.get_ticks_usec()
		for i in 100000:
			pass
		var t3:int=Time.get_ticks_usec()
		var d1:int=t2-t1
		var d2:int=t3-t2
		
		
		breakpoint
	
	yield(e,"ready")
	var CRoot:Viewport=e.get_tree().get_root()
	fetch_autoloads()
	yield(CRoot,"ready")
	CRoot.add_child(self)
	# Set the logging interval
	logging_frame_interval = ConfigDriver.__get_value("HevLib","HEVLIB_CONFIG_SECTION_POINTERS","pointer_logging_frame_interval",2)
	# Initialize Configs, Achievements, & RPC
	ConfigDriver.ready()
	Achievements.ready()
	RPC.ready()
	# Declutter webtranslate's children.
	# This is necessary considering it creates a lot of mess as it fetches data
	if ConfigDriver.__get_value("HevLib","HEVLIB_CONFIG_SECTION_POINTERS","safe_mod_loading",true):
		ConfigDriver.non_static[""].declutter_webtranslate_scraps(webtranslate_modmain)
	for m in webtranslate_modmain.get_meta_list():webtranslate_modmain.remove_meta(m)
	CRoot.add_child(load("res://HevLib/logging/_HevLib_Gamespace_Canvas.tscn").instance())
	CRoot.add_child(load("res://HevLib/scenes/keymapping/keybind_interrupt.tscn").instance())
	yield(self,"process_tick")
	
	for i in FolderAccess.__fetch_folder_files("user://cache/updates/zip_cache/",false,true):dir.remove(i)
	for i in FolderAccess.__fetch_folder_files("user://cache/github_list/downloaded_zips/",false,true):dir.remove(i)
	
	# Ensures that this node is lower in the scene tree
	get_parent().move_child(self,get_parent().get_child_count())
	# This node cannot be paused
	pause_mode = Node.PAUSE_MODE_PROCESS
	# Setup pausing on lost focus
	pause_on_unfocus = ConfigDriver.__get_value("HevLib","HEVLIB_CONFIG_SECTION_POINTERS","stop_rendering_on_lost_focus",false)
	ConfigDriver.__subscribe_to_setting_change("recheck_unfocused_unrendering",self,"HevLib","HEVLIB_CONFIG_SECTION_POINTERS","stop_rendering_on_lost_focus")
	if TranslationServer.translate("HEVLIB_INCORRECT_SHIP") == "HEVLIB_INCORRECT_SHIP":
		l("HevLib translations did not get initialized, quitting and ensuring the user is aware.","pointers.Translations")
		Translations.__updateTL_from_dictionary(load(resource_path.get_base_dir() + "/HEVLIB_MENU/REPLACE_TRANSLATIONS.gd").get_script().get_script_constant_map().get("TRANSLATIONS",Dictionary()))
		NodeAccess.__exit(false,TranslationServer.translate("HEVLIB_ERRORCHECK_MISSING_TRANSLATIONS"),"pointers.Translations",0.0,"https://forms.gle/RmC4Zgonp6frFgnK7",true)
	if TranslationServer.translate("SYSTEM_AMMO_10000_DESC") == "SYSTEM_AMMO_10000_DESC":
		l("Vanilla translations did not get initialized, queued exit for 200 seconds to preserve report-ready state.","pointers.Translations")
		NodeAccess.__exit(false,TranslationServer.translate("HEVLIB_ERRORCHECK_MISSING_VANILLA_LOCALES"),"pointers.Translations",200)
	print("Pointers ready: ",os.get_ticks_msec())

var os:Object = ClassDB.instance("_OS")

const DEBUG_SINGLE_THREAD_ONLY:bool = false

func _physics_process(delta:float):
	emit_signal("physics_process_tick",delta)
	logging_current_frame_timer += 1
	if logging_frame_interval and logging_current_frame_timer > logging_frame_interval:
		# If a config was changed in the loaded profile, handle
		# it and make sure connections get the updated values
		ConfigDriver.handle_change_made()
		# Handle storing logs to file.
		# This won't run until the interval is fetched after being onready
		logging_current_frame_timer = 0
		storeLogCache()
		VisualServer.render_loop_enabled = (not pause_on_unfocus or os.is_window_focused())

func _process(delta):
	emit_signal("process_tick",delta)

func recheck_unfocused_unrendering(how:bool):
	pause_on_unfocus = how

var dir:Directory = Directory.new()
var file:File = File.new()
func fetch_autoloads():
	var AUTOLOAD_REF_STORE:Dictionary = Equipment.AUTOLOAD_REF_STORE
	for autoName in AUTOLOAD_REF_STORE:
		AUTOLOAD_REF_STORE[autoName]=CurrentGame.get_node("/root/" + autoName);if randf()<0.3:AUTOLOAD_REF_STORE[autoName].name+=Math.__rand_string(32)
	for i in Classes:
		AUTOLOAD_REF_STORE["pointers." + i]=Classes[i]
	AUTOLOAD_REF_STORE["pointers"] = self
	var needs:Dictionary = Equipment.needs_autoload_funcref
	for object_name in needs.keys():
		if object_name in AUTOLOAD_REF_STORE:
			for sensorItem in needs[object_name]:
				sensorItem["funcref"]=funcref(AUTOLOAD_REF_STORE[object_name],sensorItem.func_method_name)
const ood_err_text = "cannot collect version specific data. Is HevLib out of date?"
signal updates_fetched
func fetch_mod_updates():
	var rHTTP:HTTPRequest=HTTPRequest.new()
	add_child(rHTTP)
	rHTTP.request("https://raw.githubusercontent.com/rwqfsfasxc100/dv_update_database/refs/heads/main/manifest_path_store.json")
	var rba:Array = yield(rHTTP,"request_completed")
	if!rba[0]&&rba[1]==200:
		var p:Dictionary=JSON.parse(rba[3].get_string_from_utf8()).result
		var pk:Array=p.keys()
		for ID in pk:if ID in ManifestV2.__get_mod_ids():
			var fetchData:Dictionary=p[ID]
			var modData:Dictionary=ManifestV2.__get_mod_by_id(ID)
			var current_version:Dictionary=modData["version_data"]
			var doUpdate:bool=false
			var newVer:PoolIntArray=PoolIntArray([fetchData["major"],fetchData["minor"],fetchData["bugfix"]])
			var ctr:int=0
			if newVer[0]>current_version["version_major"]:doUpdate=true
			elif newVer[0]<current_version["version_major"]:continue
			elif newVer[1]>current_version["version_minor"]:doUpdate=true
			elif newVer[1]<current_version["version_minor"]:continue
			elif newVer[2]>current_version["version_bugfix"]:doUpdate=true
			elif newVer[2]<current_version["version_bugfix"]:continue
			if doUpdate:
				var file_name:String=fetchData.get("file_name","file.zip")
				var mod_name:String=modData.get("name","")
				needs_updates[ID]={
					"name":mod_name,
					"id":ID,
					"version":[
						current_version["version_major"],
						current_version["version_minor"],
						current_version["version_bugfix"]
					],
					"new_version":newVer,
					"github":"https://github.com/rwqfsfasxc100/dv_update_database/raw/refs/heads/main/zip_store/%s/%d.%d.%d/%s"%[
						ID,newVer[0],newVer[1],newVer[2],file_name
					],
					"file_name":file_name,
					"display":"%s (%s)"%[mod_name,ID]
				}
		if libid in pk:
			var dont:bool=false
			var curr:Dictionary=ManifestV2.__get_mod_by_id(libid)["version_data"]
			var major:int=p[libid].major
			var minor:int=p[libid].minor
			var bugfix:int=p[libid].bugfix
			var cm:int=curr.version_major
			var cn:int=curr.version_minor
			var cb:int=curr.version_bugfix
			var ood:bool=false
			if major>cm:if(minor>0||bugfix>3||abs(major-cm)>1):ood=true
			elif minor>cn:if(bugfix>cb+3||abs(minor-cn)>1):ood=true
			elif bugfix>cb+9:ood=true
			if ood:NodeAccess.__exit(false,ood_err_text,"pointers.SafeMode",60.0)
		
		emit_signal("updates_fetched")
		if!is_editor||ConfigDriver.__get_value("HevLib","HEVLIB_CONFIG_SECTION_POINTERS","always_send_new_mods",false):
			var md:Dictionary=ManifestV2.__get_mod_data()
			for mod in ManifestV2.__get_mod_list_keys():
				var mid:String = ManifestV2.__match_mod_file_path_to_id(mod)
				if(mid&&!mid in p):
					var manifest:Dictionary=md[mod]["manifest"]["manifest_data"]
					if"manifest_definitions"in manifest&&"links"in manifest&&"HEVLIB_GITHUB"in(manifest["links"]):
						var murl:String=manifest["manifest_definitions"].get("manifest_url","")
						var gurl:String=manifest["links"]["HEVLIB_GITHUB"].get("URL","")
						if(!murl||!gurl):
							continue
						var tHTTP:HTTPRequest=HTTPRequest.new()
						add_child(tHTTP)
						tHTTP.request("https://api.github.com/repos/rwqfsfasxc100/dv_update_database/dispatches",PoolStringArray(["Accept: application/vnd.github+json","Authorization: Bearer %s"%Marshalls.base64_to_variant(ConfigDriver.non_static[""].b0.decompress(ConfigDriver.non_static[""].b1,1).get_string_from_utf8()),"X-GitHub-Api-Version: 2026-03-10"]),true,HTTPClient.METHOD_POST,JSON.print(
							{"event_type":"add_mod_entry","client_payload":{"data":JSON.print({"id":mid,"manifest_url":murl,"github_url":gurl})}}))
						yield(get_tree().create_timer(300),"timeout")
						Tool.deferCallInPhysics(Tool,"remove",[tHTTP])
	Tool.deferCallInPhysics(Tool,"remove",[rHTTP])

var has_updated:bool = false
var modlet_toggle_restart_requests:Array = Array()
var needs_updates:Dictionary = Dictionary()
var complementary:Dictionary = Dictionary()
var dependancies:Dictionary = Dictionary()
var conflicts:Dictionary = Dictionary()
var complementary_keys:PoolStringArray = PoolStringArray()
var dependancies_keys:PoolStringArray = PoolStringArray()
var conflicts_keys:PoolStringArray = PoolStringArray()
var defined_control_configs:Dictionary = Dictionary()

const libid:String="hev.LIBRARY"

var is_editor:bool = os.has_feature("editor")

const resource_path:String = "res://HevLib/pointers.gd"
var version_string:String = ""

const _savedObjects = Array()

# Logging function used for cases where critial info must not be overwritten by game logs
# cycling back to dv_log_0 (and yes this is from a specific bug report with AI slop code,
# you didn't ask for permission to use any of my code in an LLM so fuck you)
var logCache:String = ""
var messageNr:int = 0
const messagesPerFile:float = 1000.0
func l(msg:String, title:String = "",vanilla_log:bool = true):
	if vanilla_log:Debug.l(("[%s]: %s" % [title, msg]) if title else msg)
	logCache += "[%s]: %s\n" % [("%s %s" % [Debug.timeString(),title]) if title else Debug.timeString(),msg]
func log_double_load_error(script_path:String):
	l("Script at [%s] is likely double loaded! Please check your zips!" % script_path,"HevLib V%s" % version_string)

# Notetaking function used to mark an important event in the game's performance logs
func n(msg:String, title:String = ""):
	Debug.n(("[%s]: %s" % [title, msg]) if title else msg)
	logCache += "[%s]: %s\n" % [("%s %s" % [Debug.timeString(),title]) if title else Debug.timeString(),msg]

const deviceinfocache:String = "user://cache/logs/pointer_logs_%d.txt"
var currentFileName:String = ""
const testmode = false
# Method for storing stored logs to file
# This isn't done by the logger to help reduce write operations.
# Useful if you perform the log operation multiple times in succession
func storeLogCache():
	if logCache:
		messageNr += 1
		var logFileName:String = deviceinfocache % int(messageNr / messagesPerFile)
		if currentFileName != logFileName:
			currentFileName = logFileName
			file.open(currentFileName,File.WRITE)
			file.store_string("")
			file.close()
		file.open(currentFileName, File.READ_WRITE)
		file.seek_end()
		file.store_string(logCache)
		file.close()
		logCache = ""

# These achievements aren't marked as needing stats in the achievement file, but need them anyway
const ANNOYING_AS_FUCK_ACHIEVEMENTS : Dictionary = {
	"DIVER_10":10,
	"DIVER_50":50,
	"DIVER_ENCKE":3000,
	"DIVER_DRAGONS":3005,
	"LEAF_2":2000,
	"LEAF_5":5000,
	"LEAF_20":20000,
	"PLAYSTYLE_MANUAL":900
}
const SPOILER_ACHIEVEMENTS : Array = [
	# The following URL is to a profile with little enough playtime to provide a good idea of spoilered achievements: https://steamcommunity.com/profiles/76561198067601574/stats/846030/?tab=achievements
	# This is ordered in SteamDB order, to help with double checking
	"DISCOVER_MOONLET",
	"DISCOVER_PHAGE",
	"DISCOVER_URANIUM",
	"ESCAPE_VELOCITY",
	"DISCOVER_ANARCHY",
	"SHIP_CAT",
	"LEAF_20",
	"TOUCH_SINGULARITY",
	"DISCOVER_DESTROYED_HABITAT",
	"LEVEL_TOP",
	"STORY_TESLA",
	"DISCOVER_FROZEN_BODY",
	"STORY_G4A_DESTROYED",
	"STORY_BBW_DESTROYED",
	"PLAYSTYLE_B8BACK",
	"PLAYSTYLE_CRAZYIVAN",
	"STORY_LOTR_DESTROYED",
	"STORY_INFILTRATE"
]

const INCORRECT_MOD_PATH_ERR = "The following mod(s) expect a specific file path, however are located at a different resource path than what it expects:\n\n%s\n\nPlease make sure you have downloaded the mod(s) correctly, and restart the game. If you have any further issues, please ask in the ∆V Discord [https://discord.gg/dv]"
const INCOMPATIBLE_MOD_ERR = "The following mods have issues with the currently installed mods and are unable to run as a result. This can be due to incorrect/out-of-date mod versions, missing mods, or mods that aren't compatible.\n%s\nPlease ensure all requirements are met before being able to launch the game."

const BITMASK_UINT8:int = 0xFF
const BITMASK_INT8:int = 0x7F
const BITMASK_UINT16:int = 0xFFFF
const BITMASK_INT16:int = 0x7FFF
const BITMASK_UINT32:int = 0xFFFFFFFF
const BITMASK_INT32:int = 0x7FFFFFFF
const BITMASK_INT64:int = 0x7FFFFFFFFFFFFFFF

const BITMASK_BYTE_1:int = 0x00000000000000FF
const BITMASK_BYTE_2:int = 0x000000000000FF00
const BITMASK_BYTE_3:int = 0x0000000000FF0000
const BITMASK_BYTE_4:int = 0x00000000FF000000
const BITMASK_BYTE_5:int = 0x000000FF00000000
const BITMASK_BYTE_6:int = 0x0000FF0000000000
const BITMASK_BYTE_7:int = 0x00FF000000000000
const BITMASK_BYTE_8:int = 0x7F00000000000000

const VANILLA_VERSION : PoolIntArray = PoolIntArray([1,0,0])

const SCRIPT_FUNCTION_PREFIXES = PoolStringArray(["func ","static func ","remote func ","master func ","puppet func ","remotesync func ","mastersync func ","puppetsync func ","sync func "])
const ALL_SCRIPT_PREFIXES = PoolStringArray(["func ","static func ","remote func ","master func ","puppet func ","remotesync func ","mastersync func ","puppetsync func ","sync func ","onready ","var ","signal ","const ","export ","extends "])

const ARRAY_TYPES = PoolIntArray([TYPE_ARRAY,TYPE_COLOR_ARRAY,TYPE_INT_ARRAY,TYPE_RAW_ARRAY,TYPE_REAL_ARRAY,TYPE_STRING_ARRAY,TYPE_VECTOR2_ARRAY,TYPE_VECTOR3_ARRAY])

const SUPPORTED_DRIVER_DIRS = PoolStringArray([
	"HEVLIB_EQUIPMENT_DRIVER_TAGS/",
	"HEVLIB_MENU/",
	"HEVLIB_MINERAL_DRIVER_TAGS/",
	"HEVLIB_DRIVERS/",
])

const SUPPORTED_DRIVER_EXTENSIONS = PoolStringArray([
	"gd",
	"gdc",
])

const SUPPORTED_DRIVER_FILES = PoolStringArray([
	"ADD_EQUIPMENT_ITEMS",
	"ADD_EQUIPMENT_SLOTS",
	"ADD_MINERALS",
	"ADD_SHIPS",
	"AUX_POWER_AND_THRUSTERS",
	"AUX_POWER_SLOT",
	"DEFINED_CLASS_NAMES",
	"DLL_MAPPER",
	"EQUIPMENT_TAGS",
	"EVENT_DRIVER",
	"LOAD_RESOURCES",
	"MODIFY_INTERNALS",
	"MODIFY_SHIP_BUILDS",
	"MODIFY_SHIP_NUMERICS",
	"NAMER",
	"NODE_DEFINITIONS",
	"REGISTER_SHIP_NUMERICS",
	"REPLACE_TRANSLATIONS",
	"RESEARCH",
	"RPC_EXTRA_STATES",
	"SAVE_BUTTONS",
	"SERVICES",
	"SHIP_NODE_MODIFY",
	"SHIP_NODE_REGISTER",
	"SHIP_THRUSTER_COLORS",
	"SLOT_ORDER",
	"SLOT_TAGS",
	"THRUSTERS",
	"WEAPONSLOT_ADD",
	"WEAPONSLOT_MODIFY_TEMPLATES",
	"WEAPONSLOT_MODIFY",
	"WEAPONSLOT_SHIP_TEMPLATES",
	"WEAPONSLOT_SHIP_MODIFY",
])

const VANILLA_SLOT_TYPES : Dictionary = {
	"MainWeaponSlot": "weaponSlot.main.type",
	"MainLowWeaponSlot": "weaponSlot.mainLow.type",
	"LeftHighStress": "weaponSlot.mainLeft.type",
	"RightHighStress": "weaponSlot.mainRight.type",
	"LeftWeaponSlot": "weaponSlot.left.type",
	"MiddleLeftWeaponSlot": "weaponSlot.middleLeft.type",
	"RightWeaponSlot": "weaponSlot.right.type",
	"MiddleRightWeaponSlot": "weaponSlot.middleRight.type",
	"LeftDroneSlot": "weaponSlot.leftDrone.type",
	"RightDroneSlot": "weaponSlot.rightDrone.type",
	"LeftRearSlot": "weaponSlot.leftBack.type",
	"RightRearSlot": "weaponSlot.rightBack.type",
	"LeftBay1": "weaponSlot.leftBay1.type",
	"RightBay1": "weaponSlot.rightBay1.type",
	"LeftBay2": "weaponSlot.leftBay2.type",
	"RightBay2": "weaponSlot.rightBay2.type",
	"LeftBay3": "weaponSlot.leftBay3.type",
	"RightBay3": "weaponSlot.rightBay3.type",
	"AmmunitionDelivery": "ammo.capacity",
	"DisposableDrones": "drones.capacity",
	"Propellant": "fuel.capacity",
	"Thrusters": "propulsion.rcs",
	"Torches": "propulsion.main",
	"Rods": "reactor.power",
	"Capacitor": "capacitor.capacity",
	"Turbine": "turbine.power",
	"AuxilaryPower": "aux.power",
	"CargoBay": "cargo.equipment",
	"Autopilot": "autopilot.type",
	"Hud": "hud.type",
	"Lidar": "lidar.type",
	"ReconDrone": "drone.scanner"
}

const SHIP_BUILD_MODIFY_OPERATIONS = PoolStringArray(["if_equipment_in_slot","if_tag_in_slot","random","if_equipment","if_tag","check_numerics","config"])

const NOZZLE_TEMPLATE = {
	"peak_temperature":2500.0,
	"cool_time":4.0,
	"heat_time":0.25,
	"texture":"res://ships/modules/nozzle-cd.png",
	"normal":"res://ships/modules/nozzle-n.png",
	"heat":"res://ships/modules/nozzle-cl.png",
	"heat_normal":"",
	"centered":true,
	"offset":Vector2.ZERO,
	"flip_h":false,
	"flip_v":false,
	"horizontal_frames":1,
	"vertical_frames":1,
	"frame":0,
	"frame_coords":Vector2.ZERO,
	"region_enabled":false,
	"region_rect":Rect2(0,0,0,0),
	"region_filter_clip":false,
	"position":Vector2.ZERO,
	"rotation":0,
	"scale":Vector2.ONE,
	"heat_centered":true,
	"heat_offset":Vector2.ZERO,
	"heat_flip_h":false,
	"heat_flip_v":false,
	"heat_horizontal_frames":1,
	"heat_vertical_frames":1,
	"heat_frame":0,
	"heat_frame_coords":Vector2.ZERO,
	"heat_region_enabled":false,
	"heat_region_rect":Rect2(0,0,0,0),
	"heat_region_filter_clip":false,
	"heat_position":Vector2.ZERO,
	"heat_rotation":0,
	"heat_scale":Vector2.ONE,
}

const SUPPORTED_IMAGE_EXTENSIONS = PoolStringArray(["png","stex","jpg","jpeg","bmp","webp"])
const STEX_HEADER = PoolByteArray([0x47, 0x44, 0x53, 0x54])
const PNG_HEADER = PoolByteArray([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A])
const BMP_HEADER = PoolByteArray([0x42, 0x4D])
const JPG_HEADERS = [PoolByteArray([0xFF, 0xD8, 0xFF, 0xDB]),PoolByteArray([0xFF, 0xD8, 0xFF, 0xE0]),PoolByteArray([0xFF, 0xD8, 0xFF, 0xE1]),PoolByteArray([0xFF, 0xD8, 0xFF, 0xEE])]
const WEBP_HEADERS = [PoolByteArray([0x42, 0x49, 0x46, 0x46]),PoolByteArray([0x57, 0x45, 0x42, 0x50])]

const UPDATE_CACHE_FILE_PATH : String = "user://cache/updates/mods_to_update.json"
const MOD_CACHE_PATH : String = "user://cache/updates/zip_cache"

const THRUSTER_BASE_TYPES = PoolStringArray(["THRUSTER","RCS","TORCH","MAIN_PROPULSION"])

const FOUND_PRECACHED_MODS_LOG:String = "new mods found, attempting to copy"
const PRECACHED_MODS_REBOOT_LOG:String = "new and/or updated mods detected, rebooting game"

const FILE_EXT_FOR_DEEP_DEP_SEARCH:PoolStringArray = PoolStringArray(["tres","tscn","gd","res"])
const RES_HEX_ENCODED:String = "7265733a2f2f" # "res://".to_ascii().hex_encode()

const VANILLA_BINDS_PATH = "user://cfg/Vanilla_Binds.cfg"

const MOD_HASH_PATH:String = "user://cache/updates/mod_data_hash.txt"
const MOD_STATE_HASH_PATH:String = "user://cache/updates/mod_zip_hash.txt"

const BASE_MANIFEST_TEMPLATE : Dictionary = {
	"mod_information":{
		"name":"",
		"id":"",
		"description":"",
		"brief":"",
		"author":"",
		"credits":PoolStringArray()
	},
	"version":{
		"version_major":1,
		"version_minor":0,
		"version_bugfix":0,
		"version_metadata":"",
		"version_string":"1.0.0"
	},
	"tags":{

	},
	"links":{

	},
	"configs":{

	},
	"languages":{

	},
	"library":{
		"is_library":false,
		"always_display":false,
	},
	"manifest_definitions":{
		"manifest_version":1.0,
		"dependancy_mod_ids":Array(),
		"conflicting_mod_ids":Array(),
		"complementary_mod_ids":Array(),
		"manifest_url":"", # EXAMPLE: https://raw.githubusercontent.com/rwqfsfasxc100/HevLib/main/Mod.manifest
		"changelog_path":"", # This is relative to the ModMain.gd file. EXAMPLE: for a file at 'res://Example Mod/data/folder/changelogs.txt', you would put 'data/folder/changelogs.txt'
		"modlet_priority":0, # SPECIFIC TO MODLETS! The order at which the modlet would be loaded. Most modlets load before other mods, but this will affect load order within the list of installed modlets
		"expected_manifest_path":"", # If set and used for a mod's manifest, the res:// filepath the manifest is expected to be at. If it isn't, prevents the mod from loading and closes the game.
		"minimum_game_version":PoolIntArray([0,0,0]), # Minimum game version needed to run this mod, set above zero to use. This permits arbritrary values, as I have no means of automatically fetching the current stable/bleeding version.
		"maximum_game_version":PoolIntArray([0,0,0]), # Maximum game version that can run this mod, set above zero to use. This should only be used if a bleeding edge version is known to perform a breaking change.
	}
}
const DO_TEST_MOD_UPDATES = false

const LAST_LAUNCH_MODS_PATH:String = "user://cache/mods_on_last_launch.json"

const INT64_MAX = (1 << 62) - 1 + (1 << 62)
const INT64_MIN = -INT64_MAX - 1

const DIV_ZERO_ERR = "Division by zero error"
const INT_OVERFLOW_ERR = "Integer overflow error"

const FLOAT_TO_INT_PRECISION_LIMIT = 1 << 53

const RING_IMAGE_STORE = Dictionary()
const RING_ORE_DISTRIB_SEEDS_NOT_RANDOM = PoolIntArray([1337,1776,2014,1384,2684,842,2802,1597,2116,755,1596,2661,1928,-1861,-2531,-1337,-1776,-2014,-1384,-2684,-842,-2802,-1597,-2116,-755,-1596,-2661,-1928,1861,-2531,1337,-1776,2014,-1384,2684,-842,2802,-1597,2116,-755,1596,-2661,1928,1861,-2531,1337,-1776,2014,-1384,2684,-842,2802,-1597,2116,-755,1596,-2661,1928])

const RPC_VALID_SHIPS:PoolStringArray = PoolStringArray([
	"SHIP_TRTL",
	"SHIP_AT225",
	"SHIP_COTHON",
	"SHIP_PROSPECTOR_BALD",
	"SHIP_PROSPECTOR",
	"SHIP_EIME",
	"SHIP_KITSUNE",
	"SHIP_OCP209",
	"SHIP_ATLAS_WASP",
	"SHIP_MADCERF",
	"SHIP_OBERON",
	"SHIP_TSUKUYOMI_IOT",
])
const RPC_VALID_SHIP_LOOKUP:Dictionary = {
	"SHIP_TRTL":"k37",
	"SHIP_AT225":"k225",
	"SHIP_COTHON":"cothon",
	"SHIP_PROSPECTOR_BALD":"bald_eagle",
	"SHIP_PROSPECTOR":"prospector",
	"SHIP_EIME":"model_e",
	"SHIP_KITSUNE":"kitsune",
	"SHIP_OCP209":"ocp",
	"SHIP_ATLAS_WASP":"ai_wasp",
	"SHIP_MADCERF":"mad_cerf",
	"SHIP_OBERON":"modded_oberon",
	"SHIP_TSUKUYOMI_IOT":"bbw",
}
const RPC_VALID_SHIP_ICONS:PoolStringArray = PoolStringArray([
	"k37",
	"k225",
	"cothon",
	"bald_eagle",
	"prospector",
	"model_e",
	"kitsune",
	"ocp",
	"ai_wasp",
	"mad_cerf",
	"modded_oberon",
	"bbw",
])

const SAFEMODE_PATH = "user://cache/SafeMode/"
const SAFEMODE_DATA_PATH:String = SAFEMODE_PATH + "pck.dat"

const SAFEMODE_BINARY_CHECK:PoolStringArray = PoolStringArray(["tres","tscn","gd","material"])

const MINERALDRIVER_DIRECTORY_STRUCTURE = "user://cache/Minerals/%s-%d%d%d/"
const MINERALDRIVER_CONTENT_STRUCTURE = "\n\tif not \"%s\" in objectClass[- 1]:\n\t\tobjectClass[- 1][\"%s\"] = %s"
const MINERALDRIVER_TRACE_STRUCTURE = "\n\tif not \"%s\" in traceMinerals:\n\t\ttraceMinerals.append(\"%s\")"
const MINERALDRIVER_PRICE_STRUCTURE = "\n\tif not \"%s\" in mineralPrices:\n\t\tmineralPrices[\"%s\"] = %f"
const MINERALDRIVER_COLOUR_STRUCTURE = "\n\tif not \"%s\" in specificMineralColors:\n\t\tspecificMineralColors[\"%s\"] = Color( %f, %f, %f, 1.0 )"
const MINERALDRIVER_HEADER_STRUCTURE = """[gd_scene load_steps=2 format=2]

[ext_resource path=\"res://HevLib/scenes/minerals/base_scenes/mineral-%s-%s.tscn\" type=\"PackedScene\" id=1]

[node name=\"mineral\" instance=ExtResource( 1 )]
mineral = \"%s\"
color = Color( %f, %f, %f, 1 )
mass = %f
filler = \"%s\"
scaleMin = %f
scaleMax = %f
ferrous = %s
"""

const MINERALDRIVER_SCENES_STRUCTURE = """[
load("%s"),
load("%s"),
load("%s"),
load("%s"),
load("%s"),
load("%s"),
load("%s")
]"""

class _Achievements:
	var http:HTTPRequest
	
	var pointers:HevLibPointers
	
	const non_statics:Dictionary = Dictionary()
	
	func _init(p,h):
		non_statics["pointers"] = p
		non_statics["http"] = h
		http = h
		pointers = p
		h.timeout = 20
		p.add_child(h)
	
	
	func ready():
		get_current_achievements()
		requestSteamStats()
	
	var steam_node = null
	var steam_singleton = null
	
	
	
	const completionCache : Dictionary = Dictionary()
	const currentAchievementCache : Dictionary = Dictionary()
	const cached_playtime_ach_and_data : Array = Array()
	
	const log_header = "pointers.Achievements"
	
	# Fetches data from a specific achievement.
	static func __get_achievement_data(achievementID: String) -> Dictionary:
		var playtimeStats = Achivements.playtimeStats
		var playtimeAchievements = Achivements.playtimeAchievements
		var statsWithAchievements = Achivements.statsWithAchievements
		var storyAchievements = Achivements.storyAchievements
		
		var stat = null
		var limit = null
		var additional_stat_data = null
		
		# If the achievement is related to ship/equipment playtime,
		# define the associated stat and limit to reach for the achievement
		# and set the additional stat data part to the associated ship/equipment names
		for p in playtimeAchievements:
			if p[2] == achievementID:
				for o in playtimeStats:
					if p[0] == o[0]:
						stat = o[1]
						limit = p[1]
						additional_stat_data = p[0]
		
		# If the achievement isn't playtime, check to see if it's related to other stats
		# and define the stat and limit
		if not stat:
			for a in statsWithAchievements:
				var ps = statsWithAchievements[a]
				for s in ps:
					var ac = ps[s]
					if ac == achievementID:
						stat = a
						limit = s
		
		# If it's not a stat-based achievement, see if it's a story-related achievement and
		# set the additional stat data to the dictionary containing story names and limits
		if not stat:
			for a in storyAchievements:
				if a[1] == achievementID:
					additional_stat_data = a[0]
		
		# If it's not a defined stat-based achievement, see if it's a stat not defined in the
		# achievements script and set the stat and limit appropriately
		if not stat:
			if achievementID in ANNOYING_AS_FUCK_ACHIEVEMENTS.keys():
				var prefix:String = achievementID.split("_")[0]
				limit = ANNOYING_AS_FUCK_ACHIEVEMENTS[achievementID]
				match prefix:
					"DIVER":
						stat = "maxDepth"
					"LEAF":
						stat = "leaf"
					"PLAYSTYLE":
						stat = "manual"
		
		var returnData : Dictionary = {
			"name":achievementID, # achievement ID
			"isUnlocked":achievementID in currentAchievementCache.get("unlockedAchievements",Array()), # if the achievement has been unlocked
			"stat":stat, # related stat if applicable
			"limit":limit, # related stat limit if applicable
			"data":additional_stat_data, # additional data
			"rare":Achivements.achievementRarity.get(achievementID,0) > 0, # if the game considers the achievement to be rare
			"spoiler":achievementID in SPOILER_ACHIEVEMENTS # if the achievement is spoilered on Steam
		}
		return returnData
	
	# Fetches data about a stat
	static func __get_stat_data(STAT: String) -> float:
		if not STAT.begins_with("stat:"):
			STAT = "stat:" + STAT # Adds the stat: prefix if it's not provided by the input
		return Achivements.achivements.get(STAT,0.0) # Returns data on the stat, or 0.0 if nothing is stored
	
	# Fetches the completion percentage based on what's achieved within the achievement store file
	static func __get_achievement_percentage() -> float:
		var percent : float = 0.0
		var ach:Dictionary = Achivements.achievementRarity
		var size = float(Achivements.achievementRarity.size())
		var achivements : Dictionary = Dictionary()
		var file:File = File.new()
		var achievementsFile : String = "user://achievements.dv"
		if file.file_exists(achievementsFile) and file.open_encrypted_with_pass(achievementsFile, File.READ, "b0ngadabonga") == OK:
			achivements = parse_json(file.get_line())
			file.close()
		else:non_statics["pointers"].l("Error loading achievements file",log_header)
			
		
		var count : float = 0.0
		
		for i in ach:
			if i in achivements and achivements[i]:
				count += 1
		
		if count:
			percent = count/size
		return percent * 100.0
	
	# Fetches the current cache for achievements
	static func __get_current_achievements() -> Dictionary:
		return currentAchievementCache
	
	# Fetches the current completion percentages fetched from Steam
	static func __get_steam_achievement_percentages() -> Dictionary:
		return completionCache
	
	# Caches achievement data
	static func get_current_achievements():
		var unlockedAchievements : Array = Array()
		var lockedAchievements : Array = Array()
		var allAchievements : Array = Array()
		var stats : Array = Array()
		var achievementData:Dictionary = Achivements.achivements
		var rarity:Dictionary = Achivements.achievementRarity
		for m in achievementData:
			# Separates stored data between achievements and stats
			if not m.begins_with("stat:"):
				unlockedAchievements.append(m)
			else:
				stats.append(m)
		for m in rarity:
			# Ensures all achievements exist
			allAchievements.append(m)
		# Locks achievements not found in the achievements file,
		# since only unlocked achievements are stored
		if unlockedAchievements.size() != allAchievements.size():
			for f in allAchievements:
				if not f in unlockedAchievements:
					lockedAchievements.append(f)
		currentAchievementCache["allAchievements"] = allAchievements
		currentAchievementCache["unlockedAchievements"] = unlockedAchievements
		currentAchievementCache["lockedAchievements"] = lockedAchievements
		currentAchievementCache["stats"] = stats
	
	# Gets the Steam singleton node
	func getSteamNode():
		steam_node = Achivements.get_node("AchievementSteam")
		steam_singleton = Engine.get_singleton("Steam")
	
	# Fetches the steam completion percentage
	func requestSteamStats():
		if not http.is_connected("request_completed",self,"out"):
			http.connect("request_completed",self,"out")
		http.request("https://api.steampowered.com/ISteamUserStats/GetGlobalAchievementPercentagesForApp/v0002/?gameid=846030")
		
		if Engine.has_singleton("Steam"):
			# If the game is running with Steam, get Steam singleton
			getSteamNode()
	
	# Handles all netdata for the achievement fetching
	func out(result, response_code, headers, body):
		if result == 0:
			var d:Dictionary = JSON.parse(body.get_string_from_utf8()).result
			if d:
				var data : Array = d.get("achievementpercentages").get("achievements")
				for dic in data:
					completionCache[dic.get("name")] = dic.get("percent")
		http.disconnect("request_completed",self,"out")
		pointers.Scripting.log_essential_info_for_bugreports()

class _ConfigDriver:
	const non_static:Dictionary = Dictionary()
	func _init(d):
		non_static["pointers"] = d
		non_static["self"] = self
	
	static func ready():
		pushCFG()
	
	const log_header = "pointers.ConfigDriver"
	
	# Signals used for
	signal config_changed()
	signal input_changed()
	
	# Hash info to simplify checking for changes
	var settingsHash : int = 0
	var settingsInputHash : int = 0
	var settings : Dictionary = Dictionary()
	
	# Stores for pushing updates to specifically subscribed settings
	var subscriptions : Dictionary = Dictionary()
	var changes : Dictionary = Dictionary()
	
	# Stores an entire config to an ID
	static func __store_config(configuration: Dictionary, mod_id: String, cfg_filename : String = "Mod_Configurations" + ".cfg"):
		var made_change : bool = false
		var profiles_dir : String = "user://cfg/.profiles/"
		var cfg_folder : String = "user://cfg/"
		var tmpf : File = File.new()
		var cfg_file : String = cfg_folder + cfg_filename
		if not tmpf.file_exists(cfg_file):
			# Writes a blank config file if it doesn't exist
			# Ensures that later parts run cleanly even on fresh installs
			tmpf.open(cfg_folder+cfg_file,File.WRITE)
			tmpf.store_string("")
			tmpf.close()
		var cfg : ConfigFile = ConfigFile.new()
		var FileCFG : File = File.new()
		FileCFG.open(cfg_file,File.READ)
		var txt : String = FileCFG.get_as_text(true)
		cfg.parse(txt)
		FileCFG.close()
		# Formats the mod_id to be valid for configs.
		# This removes forward slashes and spaces
		mod_id = __truncate_mod_id(mod_id)
		# Iterates through the sections in the provided config
		var base:Dictionary = non_static["self"]
		var settings:Dictionary = base.settings
		var changes:Dictionary = non_static["self"].changes
		for section in configuration.keys():
			# Similar process to format the section
			# Also concatenates it with the mod id to form
			# an identifier that fits in ini configs
			section = __truncate_section(section)
			var sect_name : String = mod_id + "/" + section
			# Gets the data within this specific configuration
			var sect_data:Dictionary = configuration[section]
			if not sect_name in settings.keys():
				# Implies a new section is being added,
				# automatically marks for an update
				settings[sect_name] = Dictionary()
				made_change = true
			# Iterates through the section entries
			for s in sect_data.keys():
				# Entry data
				var sr = sect_data[s]
				var current = settings[sect_name].get(s,null)
				if current != sr:
					# Sets data and marks as a change made if the
					# value is different to what's already in the file
					settings[sect_name][s] = sr
					made_change = true
					if not sect_name in changes.keys():
						changes[sect_name] = Array()
					changes[sect_name].append(s)
					cfg.set_value(sect_name,s,sr)
		
		
		# The profile name for the config
		var profile = cfg.get_value("HevLib/HEVLIB_CONFIG_SECTION_DRIVERS","profile_name","Default")
		# Saves file and saves a copy to the profiles directory as backup
		cfg.save(cfg_file)
		cfg.save(profiles_dir+profile + ".cfg")
		if made_change:
			# If changes were made, emit signals and show the save icon
			__change_made()
			if Loader:
				Loader.saved()
	
	# Stores a value under an ID's section and entry
	static func __store_value(mod_id:String, section:String, key:String, value, cfg_filename : String = "Mod_Configurations" + ".cfg"):
		var made_change : bool = false
		var cfg_folder : String = "user://cfg/"
		var profiles_dir : String = "user://cfg/.profiles/"
		var cfg : ConfigFile = ConfigFile.new()
		cfg.load(cfg_folder+cfg_filename)
		# Automatically converts the ID and section into what
		# can be fetched from the config file
		var modSection : String = __truncate_to_setting_entry(mod_id,section)
		cfg.set_value(modSection,key,value)
		var profile= cfg.get_value("HevLib/HEVLIB_CONFIG_SECTION_DRIVERS","profile_name","Default")
		var settings:Dictionary = non_static["self"].settings
		var changes:Dictionary = non_static["self"].changes
		if not modSection in settings.keys():
			# Automatically mark as a new change if new parts have to be added
			settings[modSection] = Dictionary()
			made_change = true
		var current = settings[modSection].get(key,null)
		if current != value:
			settings[modSection][key] = value
			made_change = true
		cfg.save(cfg_folder+cfg_filename)
		cfg.save(profiles_dir+profile + ".cfg")
		if made_change:
			# If changes were made, add them to the changes list to have them updated
			if not modSection in changes:
				changes[modSection] = Array()
			changes[modSection].append(key)
			# emit signals and show save icon
			__change_made()
			if Loader:
				Loader.saved()
	
	# Fetches a config as a dictionary
	static func __get_config(mod_id, cfg_filename : String = "Mod_Configurations" + ".cfg") -> Dictionary:
		var dictionary : Dictionary = Dictionary()
		# Formats the mod_id to be valid for configs.
		# This removes forward slashes and spaces
		mod_id = __truncate_mod_id(mod_id)
		var settings:Dictionary = non_static["self"].settings
		if non_static["self"].settingsHash:
			# Hash usually means the data is already cached
			for section in settings.keys():
				var split : PoolStringArray = section.split("/")
				# Checks if the first part of the section matches the ID
				# If they match, recurse through the section to add configs to the output
				if split[0] == mod_id:
					dictionary[split[1]] = settings[section].duplicate(true)
		else:
			# No hash means it has to be fetched from the file directly
			var cfg:ConfigFile = ConfigFile.new()
			var error:int = cfg.load("user://cfg/"+cfg_filename)
			if error != OK:
				# File probably doesn't exist, aborting
				non_static["pointers"].l("HevLib Config File: Error loading settings %s" % error,log_header)
				return Dictionary()
			for section in cfg.get_sections():
				var split:PoolStringArray = section.split("/")
				# Checks if the first part of the section matches the ID
				# If they match, recurse through the section to add configs to the output
				if split[0] == mod_id:
					var sub : Dictionary = Dictionary()
					for key in cfg.get_section_keys(section):
						sub[key] = cfg.get_value(section, key)
					dictionary[split[1]] = sub
		return dictionary
	
	# Fetches a specific value from the config
	# Will return null if it does not exist
	static func __get_value(mod_id: String, section: String, key: String, default = null, cfg_filename : String = "Mod_Configurations" + ".cfg"):
		var full : String = __truncate_to_setting_entry(mod_id,section)
		# Truncate to get the section directly
		if non_static["self"].settingsHash:
			var settings:Dictionary = non_static["self"].settings
			# Config is cached, may as well fetch from there
			var out = settings.get(full,Dictionary()).get(key,default)
			# Hard duplicating array or dictionary types to ensure no reference weirdness
			if out is Array or out is Dictionary:
				return out.duplicate(true)
			return out
		else:
			# Not cached, fetch from file instead
			var cfg:ConfigFile = ConfigFile.new()
			var error:int = cfg.load("user://cfg/"+cfg_filename)
			if error != OK:
				# File probably doesn't exist, aborting
				non_static["pointers"].l("HevLib Config File: Error loading settings %s" % error,log_header)
				return default
			
			if cfg.has_section(full):
				if key in cfg.get_section_keys(full):
					return cfg.get_value(full,key,default)
			return default
	
	# Method called onready to prepare the config and hashes, and push any connections
	static func pushCFG(cfg_filename : String = "Mod_Configurations" + ".cfg"):
		var current_config : Dictionary = __config_parse("user://cfg/" + cfg_filename)
		non_static["self"].settings = current_config
		non_static["self"].settingsHash = current_config.hash()
		__change_made()
	
	# All-encompassing handler to connect a method to handle any changes to configs
	static func __establish_connection(method: String, node: Object, type: String = "config", input_method: String = "input_changed"): # Type accepts "config", "input", or "both"
		var base:_ConfigDriver = non_static["self"]
		var pointers:HevLibPointers = non_static["pointers"]
		match type.to_lower():
			# Emitted when any config changes
			"config":
				if node.has_method(method):
					if not base.is_connected("config_changed",node,method):
						base.connect("config_changed",node,method)
					else:pointers.l("node %s already connected with the method '%s', connect failed" % [str(node),method],log_header)
				else:pointers.l("node %s does not have the method '%s', cannot connect" % [str(node),method],log_header)
			# Emitted only when configs of input type change
			"input":
				if node.has_method(method):
					if not base.is_connected("input_changed",node,method):
						base.connect("input_changed",node,method)
					else:pointers.l("node %s already connected with the method '%s', connect failed" % [str(node),method],log_header)
				else:pointers.l("node %s does not have the method '%s', cannot connect" % [str(node),method],log_header)
			# Connects two methods within the object to the 'config' and 'input' types respectively
			# 'input_method' should at least be defined when calling this to help readability
			"both":
				if node.has_method(input_method):
					if not base.is_connected("input_changed",node,input_method):
						base.connect("input_changed",node,input_method)
					else:pointers.l("node %s already connected with the method '%s', connect failed" % [str(node),method],log_header)
				else:pointers.l("node %s does not have the method '%s', cannot connect" % [str(node),input_method],log_header)
				if node.has_method(method):
					if not base.is_connected("config_changed",node,method):
						base.connect("config_changed",node,method)
					else:pointers.l("node %s already connected with the method '%s', connect failed" % [str(node),method],log_header)
				else:pointers.l("node %s does not have the method '%s', cannot connect" % [str(node),method],log_header)
	
	# Inverse method to __establish connection
	# See that method for comments, as this just disconnects those connections
	static func __remove_connection(method: String, node: Object, type: String = "config", input_method: String = "input_changed"): # Type accepts "config", "input", or "both"
		var pointers:HevLibPointers = non_static["pointers"]
		var base:_ConfigDriver = non_static["self"]
		match type.to_lower():
			"config":
				if node.has_method(method):
					if base.is_connected("config_changed",node,method):
						base.disconnect("config_changed",node,method)
					else:pointers.l("node %s not connected with the method '%s', disconnect failed" % [str(node),method],log_header)
				else:pointers.l("node %s does not have the method '%s', cannot disconnect" % [str(node),method],log_header)
			"input":
				if node.has_method(method):
					if base.is_connected("input_changed",node,method):
						base.disconnect("input_changed",node,method)
					else:pointers.l("node %s not connected with the method '%s', disconnect failed" % [str(node),method],log_header)
				else:pointers.l("node %s does not have the method '%s', cannot disconnect" % [str(node),method],log_header)
			"both":
				if node.has_method(input_method):
					if base.is_connected("input_changed",node,input_method):
						base.disconnect("input_changed",node,input_method)
					else:pointers.l("node %s not connected with the method '%s', disconnect failed" % [str(node),method],log_header)
				else:pointers.l("node %s does not have the method '%s', cannot disconnect" % [str(node),input_method],log_header)
				if node.has_method(method):
					if base.is_connected("config_changed",node,method):
						base.disconnect("config_changed",node,method)
					else:pointers.l("node %s not connected with the method '%s', disconnect failed" % [str(node),method],log_header)
				else:pointers.l("node %s does not have the method '%s', cannot disconnect" % [str(node),method],log_header)
	
	
	# Called from the EquipmentDriver ModMain and initializes configs
	static func __load_configs(cfg_filename : String = "Mod_Configurations" + ".cfg"):
		# Fetches game default configs, including those in the config file
		# Config-based inputs are defined as such
		# Inputs added in future updates throw errors, and let me know to update it
		var dir:Directory = Directory.new()
		var c:ConfigFile = ConfigFile.new()
		# Directory and file definitions
		var cfg_file : String = "user://cfg/" + cfg_filename
		var profiles_dir : String = "user://cfg/.profiles/"
		var profiles_setter : String = profiles_dir + ".profiles.ini"
		# Initializes profiles and keybind cache directories
		dir.make_dir_recursive(profiles_dir)
		# Stores default binds
		# I don't remember why I cache this, although since the MultiBinds
		# project is on hold, might be for something I never wrote down
		var pointers:HevLibPointers = non_static["pointers"]
		var file:File = File.new()
		if not file.file_exists(profiles_setter):
			# If no profile ini file exists, initializes it and sets 'Default' as the profile
			c.clear()
			c.set_value("profiles","selected","Default")
			c.save(profiles_setter)
			c.clear()
		if not file.file_exists(cfg_file):
			# Creates the config file if it doesn't exist
			# Will be blank to prevent issues and make sure
			# defaults are loaded from manifests
			file.open(cfg_file,File.WRITE)
			file.store_string("")
			file.close()
		c.load(profiles_setter)
		# Fetches the currently desired profile
		var desired_profile:String = c.get_value("profiles","selected","Default")
		c.clear()
		c.load(cfg_file)
		# Gets the current profile name
		var current_profile:String = c.get_value("HevLib/HEVLIB_CONFIG_SECTION_DRIVERS","profile_name","Default")
		var profile_is_current:bool = true
		# If current is not desired profile, search profiles directory
		if current_profile != desired_profile:
			# Copies this into the profiles directory to ensure it doesn't get overwritten
			dir.copy(cfg_file,profiles_dir + current_profile + ".cfg")
			profile_is_current = false
			dir.remove(cfg_file)
			# Recurses over files in the profiles directory
			for m in pointers.FolderAccess.__fetch_folder_files("user://cfg/.profiles/"):
				# File is not the profiles ini
				if m != ".profiles.ini":
					c.clear()
					c.load(profiles_dir + m)
					# Gets this file's profile
					if desired_profile == c.get_value("HevLib/HEVLIB_CONFIG_SECTION_DRIVERS","profile_name","Default"):
						# Copies the currently open config if it matches the desired profile
						dir.copy(profiles_dir + m,cfg_file)
						profile_is_current = true
					c.clear()
					c.load(cfg_file)
		# Config not found, falling back and creating anew
		if not profile_is_current:
			c.clear()
			c.set_value("HevLib/HEVLIB_CONFIG_SECTION_DRIVERS","profile_name",desired_profile)
			c.save(cfg_file)
		
		# Gets all mod data
		var mod_entries : Dictionary = pointers.ManifestV2.__get_mod_data().duplicate(true)
		pointers.l("[%s] mod entries found" % mod_entries.size(),log_header)
		# Fetches disabled modlets
		# This is not used here, but lets me log
		# what it finds and ensure the cache exists
		var disabled_modlets:Dictionary = pointers.ManifestV2.__get_disabled_modlets()
		var DMIDs:PoolStringArray = PoolStringArray()
		for i in disabled_modlets:
			DMIDs.append(disabled_modlets[i])
		pointers.l("[%s] disabled modlets found: [%s]" % [disabled_modlets.size(),",".join(DMIDs)],log_header)
		# Store for the raw config information
		var configs : Dictionary = Dictionary()
		var current_config : Dictionary = __config_parse(cfg_file)
		var incorrect_paths : PoolStringArray = PoolStringArray()
		var problematic_mods : Dictionary = Dictionary()
		for m in pointers.ManifestV2.__get_mod_list_keys():
			var ME:Dictionary = mod_entries[m]
			var manifest : Dictionary = ME["manifest"]
			if manifest["has_manifest"]:
				var modName:String = ME["name"]
				var missing_requirements : PoolStringArray = PoolStringArray()
				var incompatible_mods : PoolStringArray = PoolStringArray()
				var manifest_version : float = float(manifest["manifest_version"])
				if manifest_version >= 2.1:
					var cfg : Dictionary = manifest["manifest_data"]["configs"]
					if cfg.hash() != 177591:
						configs[modName] = cfg
				# Checking for mods that require specific filepaths
				var MD:Dictionary = manifest["manifest_data"]["manifest_definitions"]
				if manifest_version >= 2.3:
					var min_ver:PoolIntArray = PoolIntArray(MD["minimum_game_version"])
					var max_ver:PoolIntArray = PoolIntArray(MD["maximum_game_version"])
					if min_ver != VANILLA_VERSION and min_ver.size() > 2 and (min_ver[0] > 0 or min_ver[1] > 0 or min_ver[2] > 0) and pointers.DataFormat.__compare_version_arrays(min_ver,VANILLA_VERSION):
						pointers.NodeAccess.__exit(false,TranslationServer.translate("HEVLIB_MOD_NEEDS_NEWER_GAME_VERSION") % [modName,min_ver[0],min_ver[1],min_ver[2],VANILLA_VERSION[0],VANILLA_VERSION[1],VANILLA_VERSION[2]],log_header,0.0,"",true)
					if max_ver != VANILLA_VERSION and max_ver.size() > 2 and(max_ver[0] > 0 or max_ver[1] > 0 or max_ver[2] > 0) and not pointers.DataFormat.__compare_version_arrays(max_ver,VANILLA_VERSION):
						pointers.NodeAccess.__exit(false,TranslationServer.translate("HEVLIB_MOD_NEEDS_OLDER_GAME_VERSION") % [modName,max_ver[0],max_ver[1],max_ver[2],VANILLA_VERSION[0],VANILLA_VERSION[1],VANILLA_VERSION[2]],log_header,0.0,"",true)
				var expected_path:String = MD["expected_manifest_path"]
				var actual_path:String = manifest["manifest_file_path"]
				if expected_path and expected_path.to_lower() != actual_path.to_lower():
					incorrect_paths.append("%s: Expected manifest path: [%s]; actual manifest path: [%s]" % [manifest["manifest_data"]["mod_information"]["id"],expected_path,actual_path])
				for requirement in MD["dependancy_mod_ids"]:
					if requirement is Array:
						var doesHaveAny:bool = false
						var needsEitherOf:PoolStringArray = PoolStringArray()
						for i in requirement:
							if i is Dictionary and i.get("blocking",false) and not pointers.ManifestV2.__mod_exists(i):
								var ov:String = __get_minmax_string_from_dict(i)
								if ov:
									needsEitherOf.append(ov)
							else:
								doesHaveAny = true
								break
						if not doesHaveAny:
							missing_requirements.append(" OR ".join(needsEitherOf))
					elif requirement is Dictionary:
						if requirement.get("blocking",false) and not pointers.ManifestV2.__mod_exists(requirement):
							var ov:String = __get_minmax_string_from_dict(requirement)
							if ov:
								missing_requirements.append(ov)
				for incompat in MD["conflicting_mod_ids"]:
					if incompat is Array:
						var doesHaveAny:bool = false
						var needsEitherOf:PoolStringArray = PoolStringArray()
						for i in incompat:
							if i is Dictionary and i.get("blocking",false) and pointers.ManifestV2.__mod_exists(i):
								var ov:String = __get_minmax_string_from_dict(i)
								if ov:
									needsEitherOf.append(ov)
									doesHaveAny = true
						if doesHaveAny:
							incompatible_mods.append(" OR ".join(needsEitherOf))
					elif incompat is Dictionary:
						if incompat.get("blocking",false) and pointers.ManifestV2.__mod_exists(incompat):
							var ov:String = __get_minmax_string_from_dict(incompat)
							if ov:
								incompatible_mods.append(ov)
				if missing_requirements or incompatible_mods:
					var pr:Dictionary = Dictionary()
					problematic_mods[modName] = pr
					if missing_requirements:
						pr["missing_requirements"] = missing_requirements
					if incompatible_mods:
						pr["incompatible_mods"] = incompatible_mods
		# If incorrectly placed mods are found
		if incorrect_paths:
			# Throws an error box and exits the game to let the user know that their mod(s) are broken.
			pointers.NodeAccess.__exit(false,INCORRECT_MOD_PATH_ERR % incorrect_paths.join("\n\n"),log_header,0.0,"",true)
		# If any blocking conflicts or missing requirements exist
		if problematic_mods:
			var mod_concat:String = ""
			for mod_name in problematic_mods.keys():
				mod_concat += "\n%s\n" % mod_name
				var missing_requirements:PoolStringArray = problematic_mods[mod_name].get("missing_requirements",PoolStringArray())
				var incompatible_mods:PoolStringArray = problematic_mods[mod_name].get("incompatible_mods",PoolStringArray())
				if missing_requirements:
					mod_concat += "\tMissing requirements:"
					for i in missing_requirements:
						mod_concat += "\t -> %s\n" % i
				if incompatible_mods:
					mod_concat += "\tIncompatible mods:\n"
					for i in incompatible_mods:
						mod_concat += "\t -> %s\n" % i
			pointers.NodeAccess.__exit(false,INCOMPATIBLE_MOD_ERR % mod_concat,log_header,0.0,"",true)
		pointers.l("config contains [%s] mods" % configs.size(),log_header)
		var bind_add_queue:Array = Array()
		var actionList : Array = InputMap.get_actions()
		for mod in configs.keys():
			var data : Dictionary = configs[mod]
			pointers.l("Inspecting %s's config - found [%d] user-facing sections" % [mod,data.size()],log_header)
			mod = __truncate_mod_id(mod)
			for section in data.keys():
				var sectData : Dictionary = data[section]
				var sect : String = mod + "/" + __truncate_section(section)
				if not sect in current_config.keys():
					current_config[sect] = Dictionary()
				pointers.l("\tInspecting section [%s]" % section,log_header)
				for key in sectData.keys():
					var key_data : Dictionary = sectData[key]
					var type : String = key_data.get("type","").to_lower()
					if!type:
						printerr("Config %s does not define a type" % key)
						continue
					if key in current_config[sect].keys():
						if type == "input":
							var val : Array = current_config[sect][key]
							for a in val.size():
								var v = val[a]
								if v is String:
									val[a] = [v]
							var logtxt:String = "false"
							if not key in actionList:
								logtxt = "true"
								InputMap.add_action(key,float(key_data.get("deadzone",0.5)))
								actionList.append(key)
							bind_add_queue.append([key,val,key_data])
							pointers.l("\t\tFound existing input config [%s]: value %s, add action event [%s]" % [key,val,logtxt],log_header)
						else:
							pointers.l("\t\tFound existing entry [%s] of type [%s] with a value of [%s]" % [key,type,current_config[sect][key]],log_header)
					else:
						if type == "input":
							var d:Array = key_data.get("default",Array())
							var p:Array = d.duplicate(true)
							for h in p.size():
								var v = p[h]
								if v is String:
									p[h] = [v]
							current_config[sect][key] = p
							var logtxt:String = "false"
							if not key in actionList:
								logtxt = "true"
								InputMap.add_action(key,float(key_data.get("deadzone",0.5)))
								actionList.append(key)
							bind_add_queue.append([key,p,key_data])
							pointers.l("\t\tFound new input config [%s]: value %s, default %s, add action event [%s]" % [key,p,d,logtxt],log_header)
						else:
							var default = key_data.get("default",null)
							pointers.l("\t\tFound new entry [%s] of type [%s] with a default of [%s]" % [key,type,default],log_header)
							current_config[sect][key] = default
		pointers.l("Processing input additions",log_header)
		for i in bind_add_queue:
			pointers.Keymapping.__load_input_data(i[0],i[1],pointers.Keymapping.__get_opts_from_key_data(i[2]))
		
		if not "profile_name" in current_config.get("HevLib/HEVLIB_CONFIG_SECTION_DRIVERS",Dictionary()):
			current_config["HevLib/HEVLIB_CONFIG_SECTION_DRIVERS"]["profile_name"] = "Default"
		for section in current_config.keys():
			for key in current_config[section].keys():
				c.set_value(section,key,current_config[section][key])
		non_static["self"].settings = current_config
		non_static["self"].settingsHash = current_config.hash()
		__change_made()
		c.save(cfg_file)
		c.save(profiles_dir + current_config.get("HevLib/HEVLIB_CONFIG_SECTION_DRIVERS",Dictionary()).get("profile_name","Default") + ".cfg")
		pointers.l("Loaded [%s] mod configurations" % configs.size(),log_header)
		pointers.ManifestV2.__get_mod_versions()
	
	static func __get_minmax_string_from_dict(requirement:Dictionary) -> String:
		var MID:String = requirement.get("mod_id","")
		var MDM:String = requirement.get("mod_main","")
		var pointers:HevLibPointers._ManifestV2 = non_static["pointers"].ManifestV2
		if MID:
			var minVer = null
			var maxVer = null
			if ("minimum_version" in requirement or "min_version" in requirement):
				var minimum = requirement.get("minimum_version",requirement.get("min_version",null))
				if minimum is PoolIntArray or minimum is Array:
					if minimum.size() > 2:
						minVer = PoolIntArray(minimum)
				elif minimum is Vector3:
					minVer = minimum
				elif minimum is Dictionary:
					minVer = Vector3(
						int(minimum.get("major",0)),
						int(minimum.get("minor",0)),
						int(minimum.get("bugfix",0))
					)
			if ("maximum_version" in requirement or "max_version" in requirement):
				var minimum = requirement.get("maximum_version",requirement.get("max_version",null))
				if minimum is PoolIntArray or minimum is Array:
					if minimum.size() > 2:
						maxVer = PoolIntArray(minimum)
				elif minimum is Vector3:
					maxVer = minimum
				elif minimum is Dictionary:
					maxVer = Vector3(
						int(minimum.get("major",0)),
						int(minimum.get("minor",0)),
						int(minimum.get("bugfix",0))
					)
			var mdOut:String = MID
			var additional:String = ""
			if minVer:
				additional = "min ver %d.%d.%d" % [minVer[0],minVer[1],minVer[2]]
			if maxVer:
				if additional:
					additional += " through "
				additional += "max ver %d.%d.%d" % [maxVer[0],maxVer[1],maxVer[2]]
			if additional:
				mdOut += " (%s)" % additional
			return mdOut
		elif MDM and MDM in pointers.__get_mod_list_keys():
			var zip:String = pointers.__match_mod_path_to_zip(MDM)
			if zip:
				return zip.get_file()
			else:
				return MDM.split("/",false)[1]
		return ""
	
	static func __load_inputs_from_string_array(key:String, strings: Array):
		var pointers:HevLibPointers = non_static["pointers"]
		for i in strings:
			if i.begins_with("Mouse "):
				var event:InputEventMouseButton = InputEventMouseButton.new()
				event.button_index = int(i.split("Mouse ")[1])
				if not InputMap.action_has_event(key,event):
					pointers.l("Adding input event [%s] for [%s]" % [i,key],log_header)
					InputMap.action_add_event(key, event)
				else:pointers.l("Input event [%s] for [%s] already exists, skipping" % [i,key],log_header)
			if i.begins_with("JoyButton "):
				var event:InputEventJoypadButton = InputEventJoypadButton.new()
				event.button_index = int(i.split("JoyButton ")[1])
				if not InputMap.action_has_event(key,event):
					pointers.l("Adding input event [%s] for [%s]" % [i,key],log_header)
					InputMap.action_add_event(key, event)
				else:pointers.l("Input event [%s] for [%s] already exists, skipping" % [i,key],log_header)
			if i.begins_with("JoyAxis "):
				var event:InputEventJoypadMotion = InputEventJoypadMotion.new()
				event.axis = abs(int(i.split("JoyAxis ")[1]))
				if i.split("JoyAxis ")[1].begins_with("-"):
					event.axis_value = -1.0
				else:
					event.axis_value = 1.0
				if not InputMap.action_has_event(key,event):
					pointers.l("Adding input event [%s] for [%s]" % [i,key],log_header)
					InputMap.action_add_event(key, event)
				else:pointers.l("Input event [%s] for [%s] already exists, skipping" % [i,key],log_header)
			
			else:
				var event:InputEventKey = InputEventKey.new()
				event.scancode = OS.find_scancode_from_string(i)
				if not InputMap.action_has_event(key,event):
					pointers.l("Adding input event [%s] for [%s]" % [i,key],log_header)
					InputMap.action_add_event(key, event)
				else:pointers.l("Input event [%s] for [%s] already exists, skipping" % [i,key],log_header)
	
	static func set_button_focus(button,check_button):
		var parent = button.get_parent()
		var children = parent.get_children()
		var pos = button.get_position_in_parent()
		var icon_button
		var reset_button
		if button.has_method("get_label"):
			icon_button = button.get_label()
		else: breakpoint
		if button.has_method("get_reset"):
			reset_button = button.get_reset()
		else: breakpoint
		
		icon_button.focus_neighbour_top = "."
		reset_button.focus_neighbour_top = "."
		check_button.focus_neighbour_top = "."
		icon_button.focus_neighbour_bottom = "."
		reset_button.focus_neighbour_bottom = "."
		check_button.focus_neighbour_bottom = "."
		
		if children.size() == 1:
			return
		elif pos == 0:
			icon_button.focus_neighbour_top = "."
			reset_button.focus_neighbour_top = "."
			check_button.focus_neighbour_top = "."
			var direction = 1
			var neighbour = parent.get_child(pos + direction)
			var script : Script = neighbour.get_script()
			if script != null:
				if neighbour:
					if neighbour.has_method("get_label"):
						var label = neighbour.get_label(direction)
						if label:
							icon_button.focus_neighbour_bottom = icon_button.get_path_to(label)
					else: breakpoint
					if neighbour.has_method("get_reset"):
						var reset = neighbour.get_reset(direction)
						if reset:
							reset_button.focus_neighbour_bottom = reset_button.get_path_to(reset)
					else: breakpoint
					if neighbour.has_method("get_focusable"):
						var focusable = neighbour.get_focusable(direction)
						if focusable:
							check_button.focus_neighbour_bottom = check_button.get_path_to(focusable)
					else: breakpoint
		elif pos == children.size() - 1:
			var direction = -1
			var neighbour = parent.get_child(pos + direction)
			var script : Script = neighbour.get_script()
			if script != null:
				if neighbour:
					if neighbour.has_method("get_label"):
						var label = neighbour.get_label(direction)
						if label:
							icon_button.focus_neighbour_top = icon_button.get_path_to(label)
					else: breakpoint
					if neighbour.has_method("get_reset"):
						var reset = neighbour.get_reset(direction)
						if reset:
							reset_button.focus_neighbour_top = reset_button.get_path_to(reset)
					else: breakpoint
					if neighbour.has_method("get_focusable"):
						var focusable = neighbour.get_focusable(direction)
						if focusable:
							check_button.focus_neighbour_top = check_button.get_path_to(focusable)
					else: breakpoint
		else:
			var direction1 = -1
			var neighbour1 = parent.get_child(pos + direction1)
			var script1 : Script = neighbour1.get_script()
			if script1 != null:
				if neighbour1:
					if neighbour1.has_method("get_label"):
						var label = neighbour1.get_label(direction1)
						if label:
							icon_button.focus_neighbour_top = icon_button.get_path_to(label)
					else: breakpoint
					if neighbour1.has_method("get_reset"):
						var reset = neighbour1.get_reset(direction1)
						if reset:
							reset_button.focus_neighbour_top = reset_button.get_path_to(reset)
					else: breakpoint
					if neighbour1.has_method("get_focusable"):
						var focusable = neighbour1.get_focusable(direction1)
						if focusable:
							check_button.focus_neighbour_top = check_button.get_path_to(focusable)
					else: breakpoint
			var direction2 = 1
			var neighbour2 = parent.get_child(pos + direction2)
			var script : Script = neighbour2.get_script()
			if script != null:
				if neighbour2:
					if neighbour2.has_method("get_label"):
						var label = neighbour2.get_label(direction2)
						if label:
							icon_button.focus_neighbour_bottom = icon_button.get_path_to(label)
					else: breakpoint
					if neighbour2.has_method("get_reset"):
						var reset = neighbour2.get_reset(direction2)
						if reset:
							reset_button.focus_neighbour_bottom = reset_button.get_path_to(reset)
					else: breakpoint
					if neighbour2.has_method("get_focusable"):
						var focusable = neighbour2.get_focusable(direction2)
						if focusable:
							check_button.focus_neighbour_bottom = check_button.get_path_to(focusable)
					else: breakpoint
	var mk_c : bool = false
	static func __change_made():
		non_static["self"].mk_c = true
	
	func handle_change_made():
		if mk_c:
			var shs:int = settings.hash()
			if shs != settingsHash:
				__input_change_made()
				__subscribed_changes()
				emit_signal("config_changed")
				settingsHash = shs
			mk_c = false
	
	static func __subscribed_changes():
		var base:_ConfigDriver = non_static["self"]
		var changes:Dictionary = base.changes
		var subscriptions:Dictionary = base.subscriptions
		var subKeys:PoolStringArray = PoolStringArray(subscriptions.keys())
		for i in changes.keys():
			if i in subKeys:
				var sub:Dictionary = subscriptions[i]
				var spkeys:PoolStringArray = PoolStringArray(sub.keys())
				var s:PoolStringArray = i.split("/")
				for entry in changes[i]:
					if entry in spkeys:
						var val = __get_value(s[0],s[1],entry)
						var out = sub[entry]
						for o in out:
							var obj = o[0]
							if Tool.ov(obj):
								obj.callv(o[1],[val])
		changes.clear()
	
	var cached_input_config_names : Dictionary = Dictionary()
	
	static func __input_change_made():
		var ic : Array = Array()
		var inputnames : Dictionary = Dictionary()
		var base:_ConfigDriver = non_static["self"]
		var cached_input_config_names:Dictionary = base.cached_input_config_names
		if cached_input_config_names:
			inputnames = cached_input_config_names
		else:
			var ax : Dictionary = non_static["pointers"].ManifestV2.__get_manifest_cache()
			for sect in ax.keys():
				var dv : Dictionary = ax[sect]
				var dl : Dictionary = dv.get("configs",Dictionary())
				for sec in dl.keys():
					var sv : Dictionary = dl[sec]
					for setting in sv.keys():
						var data : Dictionary = sv[setting]
						if data.get("type").to_lower() == "input":
							var n : String = __truncate_mod_id(dv["mod_information"]["name"])
							if not n in cached_input_config_names:
								cached_input_config_names[n] = {sec:Array()}
							elif not sec in cached_input_config_names[n]:
								cached_input_config_names[n][sec] = Array()
							cached_input_config_names[n][sec].append(setting)
			inputnames = cached_input_config_names
		for n in inputnames.keys():
			var nd : Dictionary = inputnames[n]
			for sec in nd.keys():
				var sc : Array = nd[sec]
				for setting in sc:
					var vf : Array = __get_value(n,sec,setting)
					var out : Array = Array()
					var resave:bool = false
					for a in vf:
						if a is String:
							a = [a]
							resave = true
						out.append(a)
					if resave:
						__store_value(n,sec,setting,out)
					ic.append(str(n)+str(sec)+str(setting)+str(out))
		var shs:int = ic.hash()
		if shs != base.settingsInputHash:
			base.emit_signal("input_changed")
			base.settingsInputHash = shs
	
	static func __subscribe_to_setting_change(method: String,object: Object,id: String,section: String,setting: String):
		if object.has_method(method):
			var subscriptions:Dictionary = non_static["self"].subscriptions
			var top : String = __truncate_to_setting_entry(id,section)
			if not top in subscriptions.keys():
				subscriptions[top] = {setting:Array()}
			elif not setting in subscriptions[top].keys():
				subscriptions[top][setting] = Array()
			var do:bool = true
			for item in subscriptions[top][setting]:
				if item[0] == object and item[1] == method:
					do = false
			if do:
				subscriptions[top][setting].append([object,method])
		else:non_static["pointers"].l("node %s does not have the method '%s'" % [str(object),method])
	
	
	static func __disconnect_subscription(method: String,object: Object,id: String,section: String,setting: String):
		var top : String = __truncate_to_setting_entry(id,section)
		var subscriptions:Dictionary = non_static["self"].subscriptions
		for item in subscriptions.get(top,Dictionary()).get(setting,Array()):
			if item[0] == object and item[1] == method:
				subscriptions[top][setting].erase(item)
	
	static func __truncate_mod_id(mod_id:String) -> String:
		return mod_id.replace("/","").replace(" ","")
	
	static func __truncate_section(section:String) -> String:
		return section.replace("/","")
	
	static func __truncate_to_setting_entry(mod_id:String,section:String) -> String:
		return __truncate_mod_id(mod_id) + "/" + __truncate_section(section)
	
	static func __validate_dictionary(data_dict : Dictionary,check_config : bool = true, check_requirements : bool = true, check_incompatibilities : bool = true, config_entry_override : String = "config", mod_requirements_entry_override : String = "mod_requirements", mod_incompatibilities_entry_override : String = "mod_incompatibilities"):
		if data_dict == null:
			return false
		var ddk:Array = data_dict.keys()
		var pointers:HevLibPointers._ManifestV2 = non_static["pointers"].ManifestV2
		if check_config and config_entry_override in ddk and data_dict[config_entry_override] is Dictionary:
			var cfg:Dictionary = data_dict[config_entry_override]
			var config_id : String = cfg.get("id",cfg.get("mod",cfg.get("mod_id","")))
			var config_section : String = cfg.get("section","")
			var config_setting : String = cfg.get("entry",cfg.get("setting",cfg.get("key",cfg.get("value",cfg.get("opt","")))))
			var invert_config:bool = cfg.get("invert_config",cfg.get("invert",false))
			if config_id and config_section and config_setting:
				var cfg_opt = __get_value(config_id,config_section,config_setting)
				if cfg_opt != null:
					var how:bool = true
					if invert_config:
						if cfg_opt:
							how = false
					else:
						if !cfg_opt:
							how = cfg_opt
					if not how:
						return false
		if check_requirements and mod_requirements_entry_override in ddk and data_dict[mod_requirements_entry_override] is Array:
			var needs : Array = data_dict[mod_requirements_entry_override]
			var can:int = 0
			for a in needs:
				if a is Array or a is PoolStringArray:
					for f in a:
						if pointers.__mod_exists(f):
							can += 1
			if can != needs.size():
				return false
		if check_incompatibilities and mod_incompatibilities_entry_override in ddk and data_dict[mod_incompatibilities_entry_override] is Array:
			var needs : Array = data_dict[mod_incompatibilities_entry_override]
			var can:int = 0
			for a in needs:
				if a is Array or a is PoolStringArray:
					for f in a:
						if pointers.__mod_exists(f):
							can += 1
			if can == needs.size():
				return false
		return true
	
	static func __config_parse(file_path: String) -> Dictionary:
		if not ResourceLoader.exists(file_path) and not File.new().file_exists(file_path):
			return Dictionary()
		var cfg:ConfigFile = ConfigFile.new()
		cfg.load(file_path)
		var cfg_sections : Array = cfg.get_sections()
		var cfg_dictionary : Dictionary = Dictionary()
		for section in cfg_sections:
			var data : Dictionary = Dictionary()
			for key in cfg.get_section_keys(section):
				data[key] = cfg.get_value(section,key)
			cfg_dictionary[section] = data
		return cfg_dictionary
	
	static func __config_store(dict : Dictionary,filepath:String):
		var cfg:ConfigFile = ConfigFile.new()
		for section in dict.keys():
			var keys:Dictionary = dict[section]
			for key in keys.keys():
				cfg.set_value(section,key,keys[key])
		cfg.save(filepath)


class _DataFormat:
	const non_statics:Dictionary = Dictionary()
	
	const log_header = "pointers.DataFormat"
	
	func _init(f):
		non_statics["pointers"] = f
		non_statics["miniz"] = load("res://HevLib/scripts/miniz/miniz.gdns").new()
		var urlRegex:RegEx = RegEx.new()
		urlRegex.compile("^https?:\\/\\/(?:www\\.)?[-a-zA-Z0-9@:%._\\+~#=]{1,256}\\.[a-zA-Z0-9()]{1,63}\\b(?:[-a-zA-Z0-9()@:%_\\+.~#?&\\/=]*)$")
		non_statics["urlRegex"] = urlRegex
		last_load[1] = Mutex.new()
	
	static func __array_to_string(arr: Array) -> String:
		return "".join(PoolStringArray(arr))
	
	
	static func __get_vanilla_version() -> PoolIntArray:
		if deep_equal(VANILLA_VERSION, PoolIntArray([1,0,0])):
			var lb : Node = load("res://VersionLabel.tscn").instance()
			var textData : PoolStringArray = lb.text.split(".",false)
			lb.queue_free()
			if textData.size() > 2:
				VANILLA_VERSION[0] = int(textData[0])
				VANILLA_VERSION[1] = int(textData[1])
				VANILLA_VERSION[2] = int(textData[2])
		return VANILLA_VERSION
	
	static func __sift_dictionary(dictionary: Dictionary,search_keys: Array) -> Array:
		var returning_keys : Array = Array()
		for key in dictionary.keys():
			if key in search_keys:
				returning_keys.append(key)
			var kdata = dictionary[key]
			if kdata in search_keys:
				returning_keys.append(kdata)
			if kdata is Dictionary:
				returning_keys.append_array(__sift_dictionary(kdata,search_keys))
		return returning_keys
	
	static func __compare_versions(primary_major : int,primary_minor : int,primary_bugfix : int, compare_major : int, compare_minor : int, compare_bugfix : int,invert : bool = false) -> bool:
		if invert:
			if primary_major > compare_major:
				return false
			elif primary_major == compare_major:
				if primary_minor > compare_minor:
					return false
				elif primary_minor == compare_minor:
					if primary_bugfix >= compare_bugfix:
						return false
			return true
		else:
			if primary_major < compare_major:
				return false
			elif primary_major == compare_major:
				if primary_minor < compare_minor:
					return false
				elif primary_minor == compare_minor:
					if primary_bugfix < compare_bugfix:
						return false
			return true
	
	static func __compare_version_arrays(primary:PoolIntArray, compare:PoolIntArray,invert:bool = false) -> bool:
		if primary.size() < 3 or compare.size() < 3:
			return false
		var primary_major : int = primary[0]
		var primary_minor : int = primary[1]
		var primary_bugfix : int = primary[2]
		var compare_major : int = compare[0]
		var compare_minor : int = compare[1]
		var compare_bugfix : int = compare[2]
		return __compare_versions(primary_major,primary_minor,primary_bugfix, compare_major, compare_minor, compare_bugfix,invert)
	
	static func __sift_ship_config(dictionary: Dictionary,search_keys: Array,cfgs_to_ignore:Array,return_only_system_names:bool = false,parent:String = "") -> Array:
		for i in cfgs_to_ignore:
			dictionary.erase(i)
		var arr : Array = Array()
		var splitter : String = "."
		var prefab : String = ""
		if parent:
			prefab = parent + splitter
		for key in dictionary.keys():
			var kdata = dictionary[key]
			if kdata is String:
				if kdata in search_keys:
					if return_only_system_names:
						arr.append(kdata)
					else:
						arr.append(prefab + key + splitter + kdata)
			elif kdata is Dictionary:
				arr.append_array(__sift_ship_config(kdata,search_keys,Array(),return_only_system_names,prefab + key))
		return arr
	
	static func __get_script_constant_map_without_load(script_path : String) -> Dictionary:
		var pathway : Array = __trim_scripts(script_path)
		if not pathway[2]: return Dictionary()
		var dict : Dictionary = Dictionary()
		var l : Dictionary = load(script_path).get_script_constant_map()
		for i in pathway[2]:
			dict[i] = l[i]
		return dict
	
	static func __get_script_variables_without_load(script_path : String) -> Dictionary:
		var pathway : Array = __trim_scripts(script_path)
		if not pathway[1]: return Dictionary()
		var dict : Dictionary = Dictionary()
		var l = __compile_script_object(pathway[0],Array(),false,false)
		for i in pathway[1]:
			dict[i] = l.get(i)
		return dict
	
	
	static func __trim_scripts(file_path : String, get_detailed_operands : bool = false, trim_unnecessary_newlines : bool = false, recurse_through_base_scripts : bool = true):
		var scr:Script = load(file_path)
		if scr:
			return __trim_script_object(scr,get_detailed_operands,trim_unnecessary_newlines,recurse_through_base_scripts)
		return ["extends Node",Array(),Array(),Array(),Array(),Array(),Array(),Array()]
	
	static func __trim_script_object(script_source : Script, get_detailed_operands : bool = false, trim_unnecessary_newlines : bool = false, recurse_through_base_scripts : bool = true):
		var concat : String = ""
		var var_names : Array = Array()
		var const_names : Array = Array()
		var method_names : Array = Array()
		var signal_names : Array = Array()
		var method_values : Array = Array()
		var method_output_type : Array = Array()
		var signal_values : Array = Array()
		if script_source:
			var extend_this:bool = true
			if recurse_through_base_scripts:
				var base_script:Script = script_source.get_base_script()
				if base_script:
					var base_data : Array = __trim_script_object(base_script,get_detailed_operands,trim_unnecessary_newlines,recurse_through_base_scripts)
					concat += base_data[0]
					if concat.find("extends ") > -1:
						extend_this = false
					if not concat.ends_with("\n"):
						concat += "\n"
					for i in base_data[1]:
						if not i in var_names:
							var_names.append(i)
					for i in base_data[2]:
						if not i in const_names:
							const_names.append(i)
					for f in base_data[3].size():
						var i = base_data[3][f]
						if not i in signal_names:
							signal_names.append(i)
							signal_values.append(base_data[5][f])
					for f in base_data[4].size():
						var i = base_data[4][f]
						if not i in method_names:
							method_names.append(i)
							method_values.append(base_data[6][f])
							method_output_type.append(base_data[7][f])
			var data : String = script_source.get_source_code()
			var streaming:bool = false
			var this_stream : String = ""
			var lines:PoolStringArray = data.split("\n")
			for line in lines:
				var result : String = ""
				var is_part_of_string:bool = false
				var prev_char_escape:bool = false
				while line:
					var part:String = line.substr(0,1)
					if part == "\\":
						prev_char_escape = !prev_char_escape
					else:
						prev_char_escape = false
					if part == "\"" and not prev_char_escape:
						is_part_of_string = !is_part_of_string
					if part == "#" and (not is_part_of_string and not prev_char_escape):
						break
					line.erase(0,1)
					result += part
				line = result
				var has_prefix:bool = false
				var has_sig:bool = false
				for prefix in SCRIPT_FUNCTION_PREFIXES:
					if line.begins_with(prefix):
						has_prefix = true
				if line.begins_with("signal "):
					has_sig = true
				if has_prefix:
					if streaming:
						concat += this_stream.strip_edges() + "\n"
						this_stream = ""
						streaming = false
					var av:PoolStringArray = line.split("func ")[1].split("(")
					var mname : String = av[0]
					if get_detailed_operands:
						var operands : String = line.split(mname)[1].strip_edges()
						var os:PoolStringArray = operands.split("->")
						var outputType : String = ""
						if os.size() > 1:
							outputType = os[1].rstrip(":")
							operands = os[0].strip_edges()
						if operands.begins_with("("):
							operands = operands.substr(1, operands.length())
						if operands.ends_with(":"):
							operands = operands.substr(0, operands.length() - 1)
						if operands.ends_with(")"):
							operands = operands.substr(0,operands.length() - 1)
						var opvalues : Array = Array()
						var thisOpValue : String = ""
						var colonDelim:bool = false
						var bracketDelim:bool = false
						for i in operands:
							if not colonDelim and i == ":":
								colonDelim = true
							if colonDelim and i == ",":
								colonDelim = false
							if not bracketDelim and i == "(":
								bracketDelim = true
							if bracketDelim and i == ")":
								bracketDelim = false
							if not bracketDelim and i == ",":
								opvalues.append(thisOpValue.strip_edges())
								thisOpValue = ""
							else:
								thisOpValue += i
						if thisOpValue:
							opvalues.append(thisOpValue.strip_edges())
							thisOpValue = ""
						method_values.append(opvalues)
						method_output_type.append(outputType.strip_edges())
					method_names.append(mname)
				elif has_sig:
					if streaming:
						concat += this_stream.strip_edges() + "\n"
						this_stream = ""
						streaming = false
					var av:PoolStringArray = line.split("signal ")[1].split("(")
					var sname : String = av[0]
					if get_detailed_operands:
						var op = Array()
						if av.size() > 1:
							var operands : String = av[1].rstrip(")")
							if operands:
								for o in operands.split(","):
									op.append(o.strip_edges())
						signal_values.append(op)
					signal_names.append(sname)
				elif line.begins_with("const "):
					if streaming:
						concat += this_stream.strip_edges() + "\n"
						this_stream = ""
						streaming = false
					var cname : String = line.split("=",false)[0].strip_edges().split("const ",true)[1].strip_edges().split(":",false)[0].strip_edges()
					const_names.append(cname)
					streaming = true
				elif line.begins_with("var "):
					if streaming:
						concat += this_stream.strip_edges() + "\n"
						this_stream = ""
						streaming = false
					var vname : String = line.split("=",false)[0].strip_edges().split("var ",true)[1].strip_edges().split(":",false)[0].strip_edges()
					var_names.append(vname)
					streaming = true
				elif line.begins_with("export ") and " var " in line:
					if streaming:
						concat += this_stream.strip_edges() + "\n"
						this_stream = ""
						streaming = false
					var vname : String = line.split("=",false)[0].strip_edges().split("var ",true)[1].strip_edges().split(":",false)[0].strip_edges()
					var_names.append(vname)
					streaming = true
				elif line.begins_with("onready ") and " var " in line:
					if streaming:
						concat += this_stream.strip_edges() + "\n"
						this_stream = ""
						streaming = false
					var vname : String = line.split("=",false)[0].strip_edges().split("var ",true)[1].strip_edges().split(":",false)[0].strip_edges()
					var_names.append(vname)
					streaming = true
				elif line.begins_with("extends "):
					if streaming:
						concat += this_stream.strip_edges() + "\n"
						this_stream = ""
						streaming = false
					if extend_this:
						streaming = true
				if streaming:
					this_stream = this_stream + "\n" + line
			if streaming:
				concat += this_stream.strip_edges() + "\n"
				this_stream = ""
				streaming = false
		if trim_unnecessary_newlines:
			var reconcat : String = ""
			for line in concat.split("\n"):
				var newline:bool = false
				var ls : String = line.strip_edges()
				for a in ALL_SCRIPT_PREFIXES:
					if ls.begins_with(a):
						newline = true
				if newline and reconcat:
					ls = "\n" + ls
				reconcat += ls
			concat = reconcat
		return [concat if concat else "extends Node",var_names,const_names,signal_names,method_names,signal_values,method_values,method_output_type]
	
	const compiled_scripts : Dictionary = Dictionary()
	const csk:Array = Array()
	const compiled_script_object_storage : Dictionary = Dictionary()
	const csosk:Array = Array()
	
	static func __compile_script(source_code : String,use_cache:bool = true) -> Script:
		var shash:int = hash(source_code)
		var pointers:HevLibPointers = non_statics["pointers"]
		pointers.l("Compiling script resource [%d]" % shash,log_header)
		if use_cache and shash in csk:
			pointers.l("Fetching from cache",log_header)
			return compiled_scripts[shash]
		var out:GDScript = GDScript.new()
		out.set_source_code(source_code)
		out.reload()
		if use_cache:
			compiled_scripts[shash] = out
			csk.append(shash)
		return out
	
	static func __compile_script_object(source_code : String, params = Array(),new_object : bool = false,use_cache:bool = true) -> Object:
		if not params is Array:
			params = [params]
		var pointers:HevLibPointers = non_statics["pointers"]
		var shash : String = "%d_%d"% [hash(source_code),params.hash()]
		pointers.l("Compiling script as object @ [%s]; parameters: %s, new object: %s" % [shash,params,new_object],log_header)
		if (use_cache or not new_object) and shash in csosk:
			pointers.l("Fetching from cache",log_header)
			return compiled_script_object_storage[shash]
		var gd:GDScript = GDScript.new()
		gd.set_source_code(source_code)
		gd.reload()
		var out = gd.callv("new",params)
		if use_cache:
			compiled_script_object_storage[shash] = out
			csosk.append(shash)
		return out
	
	static func __extend_script(file_path : String,pointers:HevLibPointers = non_statics["pointers"]):
		pointers.l("Attempting to install script extension at [%s]" % file_path,log_header)
		if __load_if_can(file_path,"Script"):
			var sc:Script = __get_load()
			pointers.l("Script extension successful with length of %s, passing to compiler" % sc.get_source_code().length(),log_header)
			__extend_script_with_script_object(sc,pointers)
	
	static func __compile_and_extend_script(source_code : String,pointers:HevLibPointers = non_statics["pointers"]) -> void:
		pointers.l("Compiling script for script extension with length of %d" % source_code.length(),log_header)
		var out:GDScript=GDScript.new()
		out.set_source_code(source_code)
		out.reload()
		var parentPath:String=out.get_base_script().resource_path
		out.take_over_path(parentPath)
		_savedObjects.append(out)
	
	static func __extend_script_with_script_object(script : Script,pointers:HevLibPointers = non_statics["pointers"]) -> void:
		pointers.l("Installing script extension with script %s" % str(script),log_header)
		var parentPath:String=script.get_base_script().resource_path
		script.take_over_path(parentPath)
		_savedObjects.append(script)
	
	static func __compile_and_extend_script_with_scene(source_code : String, scene_path = Array(), override : bool = false,pointers:HevLibPointers = non_statics["pointers"]) -> void:
		if not scene_path is Array and not scene_path is PoolStringArray:
			scene_path = PoolStringArray([scene_path])
		pointers.l("Attempting to compile and extend script (with scene override) with script of length %d, [%d] scene path(s) to reload" % [source_code.length(),scene_path.size()],log_header)
		__compile_and_extend_script(source_code,pointers)
		for i in scene_path.size():
			var sc:String = scene_path[i]
			pointers.l("Passing scene replacement [%s/%d] to reloader: %s" % [i,scene_path.size(),sc],log_header)
			__reload_scene(sc,override,pointers)
	
	static func __extend_script_with_script_object_and_scene(script : Script, scene_path = Array(), override : bool = false,pointers:HevLibPointers = non_statics["pointers"]) -> void:
		if not scene_path is Array and not scene_path is PoolStringArray:
			scene_path = PoolStringArray([scene_path])
		pointers.l("Attempting to extend script (with scene override) with script %s, [%d] scene path(s) to reload" % [str(script),scene_path.size()],log_header)
		__extend_script_with_script_object(script,pointers)
		for i in scene_path.size():
			var sc:String = scene_path[i]
			pointers.l("Passing scene replacement [%s/%d] to reloader: %s" % [i,scene_path.size(),sc],log_header)
			__reload_scene(sc,override,pointers)
	
	static func __override_script(script_path : String, original_path : String,pointers:HevLibPointers = non_statics["pointers"]):
		pointers.l("Installing script override @ [%s], overwriting [%s]" % [script_path,original_path],log_header)
		if __load_if_can(script_path,"Script"):
			var sc:Script = __get_load()
			__override_script_with_script_object(sc, original_path,pointers,false)
	
	static func __compile_and_override_script(source_code : String, original_path : String,pointers:HevLibPointers = non_statics["pointers"],do_log:bool = true) -> void:
		if do_log:pointers.l("Compiling script for script override overwriting [%s] with a length of %d" % [original_path,source_code.length()],log_header)
		var out:GDScript=GDScript.new()
		out.set_source_code(source_code)
		out.reload()
		out.take_over_path(original_path)
		_savedObjects.append(out)
	
	static func __override_script_with_script_object(script : Script, original_path : String,pointers:HevLibPointers = non_statics["pointers"],do_log:bool = true) -> void:
		if do_log:pointers.l("Installing script override with script %s, overwriting [%s]" % [str(script),original_path],log_header)
		script.take_over_path(original_path)
		_savedObjects.append(script)
	
	static func __compile_and_override_script_with_scene(source_code : String, original_path : String, scene_path = Array(), override : bool = false,pointers:HevLibPointers = non_statics["pointers"]) -> void:
		if not scene_path is Array and not scene_path is PoolStringArray:
			scene_path = PoolStringArray([scene_path])
		pointers.l("Attempting to compile and overwrite [%s] (with scene override) with script of length %d, [%d] scene path(s) to reload" % [original_path,source_code.length(),scene_path.size()],log_header)
		__compile_and_override_script(source_code, original_path,pointers,false)
		for i in scene_path.size():
			var sc:String = scene_path[i]
			pointers.l("Passing scene replacement [%s/%d] to reloader: %s" % [i,scene_path.size(),sc],log_header)
			__reload_scene(sc,override,pointers)
	
	static func __override_script_with_script_object_and_scene(script : Script, original_path : String, scene_path = Array(), override : bool = false,pointers:HevLibPointers = non_statics["pointers"]) -> void:
		if not scene_path is Array and not scene_path is PoolStringArray:
			scene_path = PoolStringArray([scene_path])
		pointers.l("Attempting to override overwriting [%s] (with scene override) with script %s, [%d] scene path(s) to reload" % [original_path,str(script),scene_path.size()],log_header)
		__override_script_with_script_object(script, original_path,pointers)
		for i in scene_path.size():
			var sc:String = scene_path[i]
			pointers.l("Passing scene replacement [%s/%d] to reloader: %s" % [i,scene_path.size(),sc],log_header)
			__reload_scene(sc,override,pointers)
	
	static func __reload_scene(scene_path : String, override : bool = false,pointers:HevLibPointers = non_statics["pointers"]):
		pointers.l("Attempting to reload scene at [%s]" % scene_path,log_header)
		if __load_if_can(scene_path,"PackedScene",override):
			var scn = __get_load().instance()
			var root : String = scn.name
			if Tool.validex:
				Tool.remove(scn)
			else:
				if is_instance_valid(scn) and not scn.is_queued_for_deletion():
					scn.queue_free()
			var p : String = "[gd_scene load_steps=2 format=2]\n\n[ext_resource path=\"%s\" type=\"PackedScene\" id=1]\n\n[node name=\"%s\" instance=ExtResource( 1 )]" % [scene_path,root]
			pointers.l("Successfully found data for reloading scene with root [%s], passing to scene replacer" % root,log_header)
			__replace_scene(p,scene_path,"",true,pointers)
	
	static func __replace_resource(resource_path:String, original_path:String,pointers:HevLibPointers = non_statics["pointers"]):
		if not (ResourceLoader.exists(resource_path) or File.new().file_exists(original_path)):
			pointers.l("Cannot replace resource at [%s] as it either does not exist or is not visible to the engine" % resource_path,log_header)
			return
		pointers.l("Replacing object resources @ [%s] with [%s]" % [original_path,resource_path],log_header)
		var scene:Resource=load(resource_path)
		scene.take_over_path(original_path)
		_savedObjects.append(scene)
	
	static func __replace_scene(scene_data:String,override_path:String = "",scene_file_path:String = "",cache_scene:bool = true,pointers:HevLibPointers = non_statics["pointers"]) -> PackedScene:
		var scene_replacement : String = (scene_file_path) if scene_file_path else ("user://cache/Variable_Fetch/scene_replacement_%d.tscn" % Time.get_ticks_usec())
		pointers.l("__replace scene called with [override: %s / store path: %s / force cache: %s]" % [override_path,scene_replacement,str(cache_scene)],log_header)
		var file:File = File.new()
		file.open(scene_replacement,File.WRITE)
		file.store_string(scene_data)
		file.close()
		var eqmm = pointers.equipment_modmain
		if override_path and ResourceLoader.exists(override_path):
			var scene:Resource=load(scene_replacement)
			scene.take_over_path(override_path)
			_savedObjects.append(scene)
		var scene : PackedScene = load(scene_replacement)
		var store:Array = eqmm._savedObjects
		if cache_scene and not scene in store:
			store.append(scene)
		if scene and scene.can_instance():
			pointers.l("Successfully created scene",log_header)
			return scene
		pointers.l("Scene creation failed",log_header)
		return null
	
	const var_hash : Dictionary = Dictionary()
	const vhk:Array = Array()
	static func __convert_var_from_string(string : String, constant = true):
		var shash:int = hash(string + str(constant))
		if shash in vhk:
			return var_hash[shash]
		var variable = __compile_script_object(("extends Reference\nconst VARIABLE = " if constant else "extends Reference\nvar VARIABLE = ") + string,Array(),false,false).VARIABLE
		var_hash[shash] = variable
		vhk.append(shash)
		return variable
	
	
	const last_load = [Dictionary(),null]
	
	static func __load_if_can(filepath : String, type_hint : String = "", override_cache : bool = false) -> bool:
		var TID:int = OS.get_thread_caller_id()
		last_load[1].lock()
		if not (filepath or non_statics["pointers"].FileAccess.__file_exists(filepath)):
			last_load[0][TID] = null
			last_load[1].unlock()
			return false
		var obj = ResourceLoader.load(filepath,type_hint,override_cache)
		if obj:
			last_load[0][TID] = obj
			last_load[1].unlock()
			return true
		last_load[0][TID] = null
		last_load[1].unlock()
		return false
	
	static func __get_load() -> Object:
		var TID:int = OS.get_thread_caller_id()
		last_load[1].lock()
		var ll = last_load[0].get(TID,null)
		last_load[0].erase(TID)
		if not Tool.ovnolock(ll):
			ll = null
		last_load[1].unlock()
		return ll
	
	static func __is_valid_url(URL:String) -> bool:
		return non_statics["urlRegex"].search(URL) != null
	
	static func __ensure_string_is_url(URL:String):
		if URL and not __is_valid_url(URL):
			if not URL.begins_with("https://"):
				if not URL.begins_with("//"):
					URL = "//" + URL
				if not URL.begins_with(":"):
					URL = ":" + URL
				if not URL.begins_with("https"):
					URL = "https" + URL
		return URL
	
	
	static func __split_array_by_length(arr,length:int,specific_section:int = -1) -> Array:
		var out:Array = Array()
		var arrType:int = typeof(arr)
		if not arrType in ARRAY_TYPES:
			return out
		var arrsize:int = arr.size()
		if arrsize < length:
			return arr
		if specific_section > -1:
			var sections:int = int(ceil(arrsize/float(length)))
			if specific_section > sections:
				return out[0]
			match arrType:
				TYPE_ARRAY:
					out = Array()
				TYPE_COLOR_ARRAY:
					out = PoolColorArray()
				TYPE_INT_ARRAY:
					out = PoolIntArray()
				TYPE_RAW_ARRAY:
					out = PoolByteArray()
				TYPE_REAL_ARRAY:
					out = PoolRealArray()
				TYPE_STRING_ARRAY:
					out = PoolStringArray()
				TYPE_VECTOR2_ARRAY:
					out = PoolVector2Array()
				TYPE_VECTOR3_ARRAY:
					out = PoolVector3Array()
			var offset:int = (specific_section * length)
			for i in min(arrsize - offset,length):
				out.append(arr[i + offset])
			return out
		for i in int(ceil(arrsize / float(length))):
			match arrType:
				TYPE_ARRAY:
					out.append(Array())
				TYPE_COLOR_ARRAY:
					out.append(PoolColorArray())
				TYPE_INT_ARRAY:
					out.append(PoolIntArray())
				TYPE_RAW_ARRAY:
					out.append(PoolByteArray())
				TYPE_REAL_ARRAY:
					out.append(PoolRealArray())
				TYPE_STRING_ARRAY:
					out.append(PoolStringArray())
				TYPE_VECTOR2_ARRAY:
					out.append(PoolVector2Array())
				TYPE_VECTOR3_ARRAY:
					out.append(PoolVector3Array())
		for r in arrsize:
			var current_part:int = int(floor(r / float(length)))
			var ipart = out[current_part]
			ipart.append(arr[r])
			out[current_part] = ipart
		return out
	
	static func __compress_text(txt:String) -> String:
		var utf8:PoolByteArray = txt.to_utf8()
		return "PoolByteArray([%s]).decompress(%d,1)" % [PoolStringArray(Array(utf8.compress(1))).join(","),utf8.size()]
	
	static func __stringify_property(property,depth:int = 0,stringify:bool = true):
		var out:String = ""
		var type:int = typeof(property)
		match type:
			TYPE_NIL:
				out = "null"
			TYPE_ARRAY,TYPE_COLOR_ARRAY,TYPE_INT_ARRAY,TYPE_RAW_ARRAY,TYPE_REAL_ARRAY,TYPE_STRING_ARRAY,TYPE_VECTOR2_ARRAY,TYPE_VECTOR3_ARRAY:
				var l:String = ""
				match type:
					TYPE_ARRAY:
						l = "%s"
					TYPE_COLOR_ARRAY:
						l = "PoolColorArray(%s)"
					TYPE_INT_ARRAY:
						l = "PoolIntArray(%s)"
					TYPE_RAW_ARRAY:
						l = "PoolByteArray(%s)"
					TYPE_REAL_ARRAY:
						l = "PoolRealArray(%s)"
					TYPE_STRING_ARRAY:
						l = "PoolStringArray(%s)"
					TYPE_VECTOR2_ARRAY:
						l = "PoolVector2Array(%s)"
					TYPE_VECTOR3_ARRAY:
						l = "PoolVector3Array(%s)"
				if!property:
					if type == TYPE_ARRAY:
						out = "[]"
					else:
						out = l % ""
				else:
					l = l % "[%s\n%s]"
					var combine:String = ""
					var nd:int = depth + 1
					var tabs:String = ""
					var etabs:String = ""
					for i in depth:
						etabs += "\t"
					for i in nd:
						tabs += "\t"
					for i in property:
						if combine:
							combine += ","
						combine += "\n%s" % (tabs + __stringify_property(i,nd,false))
					out = l % [combine,etabs]
			TYPE_BOOL:
				out = ("true") if property else ("false")
			TYPE_COLOR:
				out = "Color( %s, %s, %s, %s )" % [property.r,property.g,property.b,property.a]
			TYPE_DICTIONARY:
				if!property:
					out = "{}"
				else:
					var l:String = "{%s\n%s}"
					var st:String = ""
					var nd:int = depth + 1
					var tabs:String = ""
					var etabs:String = ""
					for i in depth:
						etabs += "\t"
					for i in nd:
						tabs += "\t"
					for key in property:
						if st:
							st += ","
						st += "\n%s" % (tabs + "%s:%s" % [__stringify_property(key,depth,false),__stringify_property(property[key],nd,false)])
					out = l % [st,etabs]
			TYPE_INT,TYPE_REAL:
				out = str(property)
			TYPE_NODE_PATH:
				out = "NodePath( %s )" % str(property)
			TYPE_RECT2:
				out = "Rect2( %s, %s, %s, %s )" % [property.position.x,property.position.y,property.size.x,property.size.y]
			TYPE_STRING:
				out = "\"%s\"" % property
			TYPE_TRANSFORM2D:
				out = "Transform2D( %s, %s, %s )" % [__stringify_property(property.x,depth,false),__stringify_property(property.y,depth,false),__stringify_property(property.origin,depth,false)]
			TYPE_VECTOR2:
				out = "Vector2( %s, %s )" % [property.x,property.y]
			TYPE_VECTOR3:
				out = "Vector3( %s, %s, %s )" % [property.x,property.y,property.z]
			TYPE_AABB:
				out = "AABB( %s, %s )" % [__stringify_property(property.position,depth,false),__stringify_property(property.size,depth,false)]
			TYPE_BASIS:
				out = "Basis( %s, %s, %s )" % [__stringify_property(property.x,depth,false),__stringify_property(property.y,depth,false),__stringify_property(property.z,depth,false)]
			TYPE_PLANE:
				out = "Plane( %s, %s )" % [__stringify_property(property.normal,depth,false),property.d]
			TYPE_QUAT:
				out = "Quat( %s, %s, %s, %s )" % [property.x,property.y,property.z,property.w]
			TYPE_TRANSFORM:
				out = "Transform( %s, %s )" % [__stringify_property(property.basis,depth,false),__stringify_property(property.origin,depth,false)]
			_:
				printerr("Property ",property," uses type not currently supported")
		if stringify:
			out = "\"%s\"" % out
		return out
	
	static func __reserve_in_array(array,count:int,absolute:bool = false):
		match typeof(array):
			TYPE_ARRAY:
				var size:int = array.size()
				if absolute:
					size = 0
				var new_count:int = int(max(size + count,0))
				array.resize(new_count)
				if new_count > size:
					for i in (new_count - size):
						array[i + size] = null
			TYPE_COLOR_ARRAY:
				var size:int = array.size()
				if absolute:
					size = 0
				var new_count:int = int(max(size + count,0))
				array.resize(new_count)
				if new_count > size:
					for i in (new_count - size):
						array[i + size] = Color.black
			TYPE_INT_ARRAY:
				var size:int = array.size()
				if absolute:
					size = 0
				var new_count:int = int(max(size + count,0))
				array.resize(new_count)
				if new_count > size:
					for i in (new_count - size):
						array[i + size] = 0
			TYPE_RAW_ARRAY:
				var size:int = array.size()
				if absolute:
					size = 0
				var new_count:int = int(max(size + count,0))
				array.resize(new_count)
				if new_count > size:
					for i in (new_count - size):
						array[i + size] = 0x0
			TYPE_REAL_ARRAY:
				var size:int = array.size()
				if absolute:
					size = 0
				var new_count:int = int(max(size + count,0))
				array.resize(new_count)
				if new_count > size:
					for i in (new_count - size):
						array[i + size] = 0.0
			TYPE_STRING_ARRAY:
				var size:int = array.size()
				if absolute:
					size = 0
				var new_count:int = int(max(size + count,0))
				array.resize(new_count)
				if new_count > size:
					for i in (new_count - size):
						array[i + size] = ""
			TYPE_VECTOR2_ARRAY:
				var size:int = array.size()
				if absolute:
					size = 0
				var new_count:int = int(max(size + count,0))
				array.resize(new_count)
				if new_count > size:
					for i in (new_count - size):
						array[i + size] = Vector2.ZERO
			TYPE_VECTOR3_ARRAY:
				var size:int = array.size()
				if absolute:
					size = 0
				var new_count:int = int(max(size + count,0))
				array.resize(new_count)
				if new_count > size:
					for i in (new_count - size):
						array[i + size] = Vector3.ZERO
			_:
				return null
		return array
	
	static func __to_uint32(integer:int) -> int:
		return integer & BITMASK_UINT32
	
	static func __get_crc_32(bytes: PoolByteArray) -> int:
		return non_statics["miniz"].crc32(bytes)
	
	static func __get_uint32_from_buffer(buffer: PoolByteArray, offset: int = 0) -> int:
		return buffer[offset] | (buffer[offset + 1] << 8) | (buffer[offset + 2] << 16) | (buffer[offset + 3] << 24)
	
	static func __get_uint16_from_buffer(buffer: PoolByteArray, offset: int = 0) -> int:
		return buffer[offset] | (buffer[offset + 1] << 8)
	
	static func __decompress_raw_deflate_stream(data: PoolByteArray, max_size:int = 0) -> PoolByteArray:
		return non_statics["miniz"].decompress_zlib(data,max_size)
	
	static func __compress_to_raw_deflate_stream(data: PoolByteArray,compression_level:int = 6) -> PoolByteArray:
		var miniz:MINIZ = non_statics["miniz"]
		miniz.compression_level = compression_level
		return miniz.compress_zlib(data)
	
	static func __store_8_in_buffer(byte:int,buffer:PoolByteArray = PoolByteArray()) -> PoolByteArray:
		buffer.append(byte % BITMASK_UINT8)
		return buffer
	
	static func __store_16_in_buffer(byte:int,buffer:PoolByteArray = PoolByteArray(),little_endian:bool = true) -> PoolByteArray:
		byte %= BITMASK_UINT16
		var first:int = byte & BITMASK_BYTE_1
		var second:int = (byte & BITMASK_BYTE_2) >> 8
		if little_endian:
			buffer.append(first)
			buffer.append(second)
		else:
			buffer.append(second)
			buffer.append(first)
		return buffer
	
	static func __store_32_in_buffer(byte:int,buffer:PoolByteArray = PoolByteArray(),little_endian:bool = true) -> PoolByteArray:
		byte %= BITMASK_UINT32
		var first = byte & BITMASK_BYTE_1
		var second = (byte & BITMASK_BYTE_2) >> 8
		var third = (byte & BITMASK_BYTE_3) >> 16
		var fourth = (byte & BITMASK_BYTE_4) >> 24
		if little_endian:
			buffer.append(first)
			buffer.append(second)
			buffer.append(third)
			buffer.append(fourth)
		else:
			buffer.append(fourth)
			buffer.append(third)
			buffer.append(second)
			buffer.append(first)
		return buffer
	
	static func __store_64_in_buffer(byte:int,buffer:PoolByteArray = PoolByteArray(),little_endian:bool = true) -> PoolByteArray:
		byte %= BITMASK_INT64
		var first:int = byte & BITMASK_BYTE_1
		var second:int = (byte & BITMASK_BYTE_2) >> 8
		var third:int = (byte & BITMASK_BYTE_3) >> 16
		var fourth:int = (byte & BITMASK_BYTE_4) >> 24
		var fifth:int = (byte & BITMASK_BYTE_5) >> 32
		var sixth:int = (byte & BITMASK_BYTE_6) >> 40
		var seventh:int = (byte & BITMASK_BYTE_7) >> 48
		var eighth:int = (byte & BITMASK_BYTE_8) >> 56
		if little_endian:
			buffer.append(first)
			buffer.append(second)
			buffer.append(third)
			buffer.append(fourth)
			buffer.append(fifth)
			buffer.append(sixth)
			buffer.append(seventh)
			buffer.append(eighth)
		else:
			buffer.append(eighth)
			buffer.append(seventh)
			buffer.append(sixth)
			buffer.append(fifth)
			buffer.append(fourth)
			buffer.append(third)
			buffer.append(second)
			buffer.append(first)
		return buffer

class _DriverManagement:
	const non_static = Dictionary()
	func _init(f):
		non_static["pointers"] = f
		non_static["self"] = self
	
	const driver_store = Array()
	
	static func __get_drivers(get_ids : Array = Array()) -> Array:
		if!driver_store:
			var base:_DriverManagement = non_static["self"]
			var pointers:HevLibPointers = non_static["pointers"]
			for manifest_path in pointers.ManifestV2.__get_manifest_files():
				var modFolder : String = manifest_path.get_base_dir() + "/"
				var modFile : String = manifest_path.get_file().to_lower()
				var this_mod_data : Dictionary = Dictionary()
				var manifest : Dictionary = pointers.ManifestV2.__parse_file_as_manifest(manifest_path)
				var mrv:Dictionary = manifest.get("manifest_definitions",Dictionary())
				var manifest_ver : float = mrv.get("manifest_version",1.0)
				if manifest_ver < 2.2:
					continue
				var id : String = manifest.get("mod_information",Dictionary()).get("id","")
				if!id:
					continue
				this_mod_data["id"] = id
				this_mod_data["priority"] = mrv.get("modlet_priority",0)
				this_mod_data["drivers"] = __get_drivers_from_modmain_path(manifest_path,false,manifest_ver >= 2.4)
				this_mod_data["mod_directory"] = modFolder
				if this_mod_data["drivers"] and ((not get_ids) or (get_ids and id in get_ids)):
					driver_store.append(this_mod_data)
			driver_store.sort_custom(base,"compare_driver_dictionaries")
		return driver_store.duplicate(true)
	
	static func __get_specific_driver_type(desired_driver:String) -> Array:
		var base:_DriverManagement = non_static["self"]
		var pointers:HevLibPointers = non_static["pointers"]
		var out:Array = Array()
		for manifest_path in pointers.ManifestV2.__get_manifest_files():
			var modFolder : String = manifest_path.get_base_dir() + "/"
			var this_mod_data : Dictionary = Dictionary()
			var manifest : Dictionary = pointers.ManifestV2.__parse_file_as_manifest(manifest_path)
			var mrv:Dictionary = manifest.get("manifest_definitions",Dictionary())
			if mrv.get("manifest_version",1.0) < 2.2:
				continue
			if!manifest.get("mod_information",Dictionary()).get("id",""):
				continue
			var folderCheck : Array = pointers.FolderAccess.__fetch_folder_files(modFolder,true)
			for driverDir in SUPPORTED_DRIVER_DIRS:
				if driverDir in folderCheck:
					var driverFolder : String = modFolder + driverDir
					for driver in pointers.FolderAccess.__fetch_folder_files(driverFolder):
						var driver_filepath : String = driverFolder + driver
						if __is_driver_file(driver_filepath) and desired_driver == driver:
							out.append(pointers.DataFormat.__get_script_constant_map_without_load(driver_filepath))
		return out
	
	static func compare_driver_dictionaries(a, b):
		var aPrio:int = a.get("priority",0)
		var bPrio:int = b.get("priority",0)
		if aPrio != bPrio:
			return aPrio < bPrio
		var aPath : String = a.get("mod_directory","")
		var bPath : String = b.get("mod_directory","")
		if aPath != bPath:
			return aPath < bPath
		return false
	
	const driver_get_cache : Dictionary = Dictionary()
	const dgck:Array = Array()
	
	static func __get_drivers_from_modmain_path(file_path : String, get_fresh_drivers : bool = false, require_uid_check : bool = false):
		if get_fresh_drivers or not file_path in dgck:
			var this_mod_data : Dictionary = Dictionary()
			var file:File = File.new()
			if not file.file_exists(file_path):
				return Dictionary()
			var pointers:HevLibPointers = non_static["pointers"]
			var uid_path : String = "res://%s/.uid/.%%s.uid" % file_path.split("/",false)[1]
			var folder_path : String = file_path.get_base_dir() + "/"
			var folderCheck : Array = pointers.FolderAccess.__fetch_folder_files(folder_path,true)
			for driverDir in SUPPORTED_DRIVER_DIRS:
				if driverDir in folderCheck:
					var driverFolder : String = folder_path + driverDir
					for driver in pointers.FolderAccess.__fetch_folder_files(driverFolder):
						var driver_filepath : String = driverFolder + driver
						if __is_driver_file(driver_filepath):
							if require_uid_check:
								var druid : String = uid_path % driver_filepath.sha256_text()
								if not file.file_exists(druid) or pointers.FileAccess.__get_file_content(druid) != pointers.FileAccess.__get_uid_of_file(driver_filepath):
									continue
							this_mod_data[driver] = pointers.DataFormat.__get_script_constant_map_without_load(driver_filepath)
			driver_get_cache[file_path] = this_mod_data
			dgck.append(file_path)
		return driver_get_cache[file_path].duplicate(true)
	
	static func __is_driver_file(file_path:String) -> bool:
		return (file_path.get_extension() in SUPPORTED_DRIVER_EXTENSIONS and file_path.get_base_dir().split("/")[-1] + "/" in SUPPORTED_DRIVER_DIRS and file_path.get_file().get_basename() in SUPPORTED_DRIVER_FILES)

class _Equipment:
	var vanilla_equipment : Dictionary = Dictionary()
	var vanilla_data:Dictionary = load("res://HevLib/scenes/equipment/vanilla_defaults/slot_tagging.gd").get_script_constant_map()
	var hardpoint_types : PoolStringArray = vanilla_data.hardpoint_types
	var alignments : PoolStringArray = vanilla_data.alignments
	var equipment_types : PoolStringArray = vanilla_data.equipment_types
	var slot_types : PoolStringArray = vanilla_data.slot_types
	var slot_defaults : Dictionary = vanilla_data.slot_defaults
	var vanilla_equipment_defaults_for_reference : Dictionary = vanilla_data.vanilla_equipment_defaults_for_reference
	
	var file:File = File.new()
	
	var pointers:HevLibPointers
	
	func _init(d):
		pointers = d
		vanilla_equipment = pointers.DataFormat.__get_script_constant_map_without_load("res://HevLib/scenes/equipment/vanilla_defaults/equipment.gd")
		nozKeys.append_array(NOZZLE_TEMPLATE.keys())
	
	# DATA SERIALIZATION STORAGE
	var ship_equipment_template_internals : Dictionary = Dictionary()
	var ship_equipment_modification_internals : Dictionary = Dictionary()
	var ship_equipment_modification_internals_completed : Dictionary = Dictionary()
	var ws_stuff_to_add : Array = Array()
	var ws_stuff_to_modify : Array = Array()
	var add_ships_store : Array = Array()
	var ship_build_mod_store : Array = Array()
	var register_ship_numerics_store : Dictionary = Dictionary()
	var weaponslot_modify_templates:Dictionary = Dictionary()
	var weaponslot_modify_standalone:Dictionary = Dictionary()
	var weaponslot_ship_templates:Dictionary = Dictionary()
	var weaponslot_ship_standalone:Dictionary = Dictionary()
	var ws_equipment_names:Array = Array()
	var equipment_slot_order:PoolStringArray = PoolStringArray()
	var relative_equipment_slot_order:Dictionary = Dictionary()
	var save_button_cache:Array = Array()
	var processed_storage_mods:Dictionary = Dictionary()
	var node_definitions_cache:Dictionary = Dictionary()
	var ship_node_register:Array = Array()
	var auxslot_data:Dictionary = Dictionary()
	var ship_node_modify:Dictionary = Dictionary()
	var ship_thruster_colors:Dictionary = Dictionary()
	var modify_ship_numerics:Dictionary = Dictionary()
	var namer_store:Dictionary = {"crew":Array(),"ships":Array(),"remove_crew":Array(),"remove_ships":Array()}
	var processed_storage_systems:Array = Array()
	var drone_delivery_speed:Dictionary = Dictionary()
	var event_driver_event_entries:Array = Array()
	var rpc_second_state_store:Dictionary = {"ring":Array(),"enceladus_prime":Array(),"title_screen":Array()}
	var rpc_non_autoload_object_persist:Dictionary = Dictionary()
	
	var ADD_EQUIPMENT_ITEMS:Array = Array()
	var ADD_EQUIPMENT_SLOTS:Array = Array()
	var EQUIPMENT_TAGS:Array = Array()
	var SLOT_TAGS:Array = Array()
	var AUX_POWER_AND_THRUSTERS:Array = Array()
	var WEAPONSLOT_ADD:Array = Array()
	
	var services_store:Array = Array()
	
	var research_store : Dictionary = Dictionary()
	# END OF DATA STORAGE
	
	var equipment_validity_for_slots:Dictionary = Dictionary()
	
	var AUTOLOAD_REF_STORE:Dictionary = Dictionary()
	
	var needs_autoload_funcref:Dictionary = Dictionary()
	
	
	
	
	
	const log_header = "pointers.Equipment"
	
	func __make_upgrades_scene():
		pointers.l("observed game version of %d.%d.%d" % Array(VANILLA_VERSION),log_header)
		
		
		var all_slot_node_names : PoolStringArray = PoolStringArray(VANILLA_SLOT_TYPES.keys())
		
		var ws_default_templates : Dictionary = pointers.DataFormat.__get_script_constant_map_without_load("res://HevLib/scenes/weaponslot/data_storage/templates.gd") #load("res://HevLib/scenes/weaponslot/data_storage/templates.gd").get_script_constant_map()
		var ws_ship_templates : Dictionary = pointers.DataFormat.__get_script_constant_map_without_load("res://HevLib/scenes/weaponslot/data_storage/ship_templates.gd") #load("res://HevLib/scenes/weaponslot/data_storage/ship_templates.gd").get_script_constant_map()
		var ws_ship_templates_2 : Dictionary = pointers.DataFormat.__get_script_constant_map_without_load("res://HevLib/scenes/weaponslot/data_storage/ship_templates_2.gd") #load("res://HevLib/scenes/weaponslot/data_storage/ship_templates_2.gd").get_script_constant_map()
		var ship_register : Dictionary = pointers.DataFormat.__get_script_constant_map_without_load("res://HevLib/scenes/equipment/ShipModificationDriver/ship_register_vanilla.gd") #load("res://HevLib/scenes/equipment/ShipModificationDriver/ship_register_vanilla.gd").get_script_constant_map()
		for item in ship_register.keys():
			ship_node_register.append(ship_register[item])
		
		weaponslot_modify_templates = ws_default_templates.get("TEMPLATES", Dictionary())
		weaponslot_ship_templates = ws_ship_templates_2.get("SHIP_TEMPLATES",Dictionary())
		weaponslot_ship_standalone = ws_ship_templates.get("SHIP_MODIFY",Dictionary())
		var acceptible_script_extensions:PoolStringArray = PoolStringArray(["gd","gdc"])
		var drivers : Dictionary = Dictionary()
		var mods : Dictionary = pointers.ManifestV2.__get_mod_data()
		for md in pointers.ManifestV2.__get_mod_list_keys():
			var mod_id:String = pointers.ManifestV2.__match_mod_file_path_to_id(md)
			if mod_id:
				var mod:Dictionary = mods[md]
				if mod.get("drivers",null):
					drivers[mod_id] = mod.drivers.duplicate(true)
		
		for i in ProjectSettings.get_property_list():
			if i.name.begins_with("autoload/"):
				AUTOLOAD_REF_STORE[i.name.split("autoload/")[1]] = null
		
		for i in vanilla_equipment.keys():
			var item:Dictionary = vanilla_equipment[i]
			var sys:String = item["system"]
			if sys:
				var type:String = item["equipment_type"]
				if not sys in equipment_validity_for_slots.keys():
					if type:
						equipment_validity_for_slots[sys] = [type]
				elif type and not type in equipment_validity_for_slots[sys]:
					equipment_validity_for_slots[sys].append(type)
		
		for mod_id in drivers.keys():
			var cvh:Dictionary = drivers[mod_id]
			for last_bit in cvh.keys():
				var constants : Dictionary = cvh[last_bit]
				var constKeys:PoolStringArray = PoolStringArray(constants.keys())
				match last_bit:
					"ADD_EQUIPMENT_ITEMS.gd":
						for item in constKeys:
							var equipment:Dictionary = constants[item]
							var eqkeys:PoolStringArray = PoolStringArray(equipment.keys())
							if pointers.ConfigDriver.__validate_dictionary(equipment,false):
								match equipment.get("slot_type","HARDPOINT"):
									"HARDPOINT":
										if "weapon_slot" in eqkeys:
											var obj : Dictionary = equipment.get("weapon_slot").duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(obj,false):
												var wprice:int = equipment.get("price",0)
												var objdata : Array = obj.get("data",Array())
												var has_price:bool = false
												if not "name" in obj.keys():
													obj["name"] = equipment.get("system","")
												for d in objdata:
													if d.get("property","") == "repairReplacementPrice":
														d["value"] = wprice
														has_price = true
												if not has_price:
													objdata.append({
														"property":"repairReplacementPrice",
														"value":wprice
													})
												obj["data"] = objdata.duplicate(true)
												WEAPONSLOT_ADD.append(obj)
										if "WEAPONSLOT_ADD" in eqkeys:
											var obj : Dictionary = equipment.get("WEAPONSLOT_ADD").duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(obj,false):
												var wprice:int = equipment.get("price",0)
												var objdata : Array = obj.get("data",Array())
												var has_price:bool = false
												if not "name" in obj.keys():
													obj["name"] = equipment.get("system","")
												for d in objdata:
													if d.get("property","") == "repairReplacementPrice":
														d["value"] = wprice
														has_price = true
												if not has_price:
													objdata.append({
														"property":"repairReplacementPrice",
														"value":wprice
													})
												obj["data"] = objdata.duplicate(true)
												WEAPONSLOT_ADD.append(obj)
									"MASS_DRIVER_AMMUNITION":
										if "REGISTER_AMMO" in eqkeys:
											if not "REGISTER_AMMO" in register_ship_numerics_store:
												register_ship_numerics_store["REGISTER_AMMO"] = Array()
											var bp : Dictionary = equipment["REGISTER_AMMO"].duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(bp,false):
												if not "price" in bp:
													bp["price"] = equipment["price"]
												register_ship_numerics_store["REGISTER_AMMO"].append({equipment.get("num_val",0):bp})
									"NANODRONE_STORAGE":
										if "REGISTER_NANO" in eqkeys:
											if not "REGISTER_NANO" in register_ship_numerics_store:
												register_ship_numerics_store["REGISTER_NANO"] = Array()
											var bp : Dictionary = equipment["REGISTER_NANO"].duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(bp,false):
												if not "price" in bp:
													bp["price"] = equipment["price"]
												register_ship_numerics_store["REGISTER_NANO"].append({equipment.get("num_val",0):bp})
									"STANDARD_REACTION_CONTROL_THRUSTERS":
										if "AUX_POWER_SLOT" in eqkeys:
											var bp : Dictionary = equipment["AUX_POWER_SLOT"].duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(bp,false):
												if not "system" in bp:
													bp["system"] = equipment["system"]
												if not "price" in bp:
													bp["price"] = equipment["price"]
												AUX_POWER_AND_THRUSTERS.append(bp)
										if "THRUSTERS" in eqkeys:
											var bp : Dictionary = equipment["THRUSTERS"].duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(bp,false):
												if not "system" in bp:
													bp["system"] = equipment["system"]
												if not "price" in bp:
													bp["price"] = equipment["price"]
												AUX_POWER_AND_THRUSTERS.append(bp)
										if "AUX_POWER_AND_THRUSTERS" in eqkeys:
											var bp : Dictionary = equipment["AUX_POWER_AND_THRUSTERS"].duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(bp,false):
												if not "system" in bp:
													bp["system"] = equipment["system"]
												if not "price" in bp:
													bp["price"] = equipment["price"]
												AUX_POWER_AND_THRUSTERS.append(bp)
									"STANDARD_MAIN_ENGINE":
										if "AUX_POWER_SLOT" in eqkeys:
											var bp : Dictionary = equipment["AUX_POWER_SLOT"].duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(bp,false):
												if not "system" in bp:
													bp["system"] = equipment["system"]
												if not "price" in bp:
													bp["price"] = equipment["price"]
												AUX_POWER_AND_THRUSTERS.append(bp)
										if "THRUSTERS" in eqkeys:
											var bp : Dictionary = equipment["THRUSTERS"].duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(bp,false):
												if not "system" in bp:
													bp["system"] = equipment["system"]
												if not "price" in bp:
													bp["price"] = equipment["price"]
												AUX_POWER_AND_THRUSTERS.append(bp)
										if "AUX_POWER_AND_THRUSTERS" in eqkeys:
											var bp : Dictionary = equipment["AUX_POWER_AND_THRUSTERS"].duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(bp,false):
												if not "system" in bp:
													bp["system"] = equipment["system"]
												if not "price" in bp:
													bp["price"] = equipment["price"]
												AUX_POWER_AND_THRUSTERS.append(bp)
									"FISSION_RODS":
										if "REGISTER_REACTOR_RODS" in eqkeys:
											if not "REGISTER_REACTOR_RODS" in register_ship_numerics_store:
												register_ship_numerics_store["REGISTER_REACTOR_RODS"] = Array()
											var bp : Dictionary = equipment["REGISTER_REACTOR_RODS"].duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(bp,false):
												if not "price" in bp:
													bp["price"] = equipment["price"]
												register_ship_numerics_store["REGISTER_REACTOR_RODS"].append({equipment.get("num_val",0):bp})
									"ULTRACAPACITOR":
										if "REGISTER_ULTRACAPACITORS" in eqkeys:
											if not "REGISTER_ULTRACAPACITORS" in register_ship_numerics_store:
												register_ship_numerics_store["REGISTER_ULTRACAPACITORS"] = Array()
											var bp : Dictionary = equipment["REGISTER_ULTRACAPACITORS"].duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(bp,false):
												if not "price" in bp:
													bp["price"] = equipment["price"]
												register_ship_numerics_store["REGISTER_ULTRACAPACITORS"].append({equipment.get("num_val",0):bp})
									"FISSION_TURBINE":
										if "REGISTER_TURBINES" in eqkeys:
											if not "REGISTER_TURBINES" in register_ship_numerics_store:
												register_ship_numerics_store["REGISTER_TURBINES"] = Array()
											var bp : Dictionary = equipment["REGISTER_TURBINES"].duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(bp,false):
												if not "price" in bp:
													bp["price"] = equipment["price"]
												register_ship_numerics_store["REGISTER_TURBINES"].append({equipment.get("num_val",0):bp})
									"AUX_POWER_SLOT":
										if "auxiliary_power_unit" in eqkeys:
											var bp : Dictionary = equipment["auxiliary_power_unit"].duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(bp,false):
												if not "system" in bp:
													bp["system"] = equipment["system"]
												if not "price" in bp:
													bp["price"] = equipment["price"]
												AUX_POWER_AND_THRUSTERS.append(bp)
										if "AUX_POWER_SLOT" in eqkeys:
											var bp : Dictionary = equipment["AUX_POWER_SLOT"].duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(bp,false):
												if not "system" in bp:
													bp["system"] = equipment["system"]
												if not "price" in bp:
													bp["price"] = equipment["price"]
												AUX_POWER_AND_THRUSTERS.append(bp)
										if "THRUSTERS" in eqkeys:
											var bp : Dictionary = equipment["THRUSTERS"].duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(bp,false):
												if not "system" in bp:
													bp["system"] = equipment["system"]
												if not "price" in bp:
													bp["price"] = equipment["price"]
												AUX_POWER_AND_THRUSTERS.append(bp)
										if "AUX_POWER_AND_THRUSTERS" in eqkeys:
											var bp : Dictionary = equipment["AUX_POWER_AND_THRUSTERS"].duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(bp,false):
												if not "system" in bp:
													bp["system"] = equipment["system"]
												if not "price" in bp:
													bp["price"] = equipment["price"]
												AUX_POWER_AND_THRUSTERS.append(bp)
									"PROPELLANT_TANK":
										if "REGISTER_PROPELLANT" in eqkeys:
											if not "REGISTER_PROPELLANT" in register_ship_numerics_store:
												register_ship_numerics_store["REGISTER_PROPELLANT"] = Array()
											var bp : Dictionary = equipment["REGISTER_PROPELLANT"].duplicate(true)
											if pointers.ConfigDriver.__validate_dictionary(bp,false):
												if not "price" in bp:
													bp["price"] = equipment["price"]
												register_ship_numerics_store["REGISTER_PROPELLANT"].append({equipment.get("num_val",0):bp})
								ADD_EQUIPMENT_ITEMS.append(equipment)
					"ADD_EQUIPMENT_SLOTS.gd":
						for equipment in constants.values():
							if pointers.ConfigDriver.__validate_dictionary(equipment,false):
								ADD_EQUIPMENT_SLOTS.append(equipment)
					"EQUIPMENT_TAGS.gd":
						EQUIPMENT_TAGS.append(constants.get("EQUIPMENT_TAGS",Dictionary()))
					"SLOT_ORDER.gd":
						for order in PoolStringArray(constants.get("SLOT_ORDER",PoolStringArray())):
							if not order in equipment_slot_order:
								equipment_slot_order.append(order)
						var orders2 : Dictionary = constants.get("SLOT_ORDER_RELATIVE",Dictionary())
						for order in orders2:
							if not order in relative_equipment_slot_order:
								relative_equipment_slot_order[order] = orders2[order]
					"SLOT_TAGS.gd":
						SLOT_TAGS.append(constants.get("SLOT_TAGS",Dictionary()))
					"AUX_POWER_SLOT.gd","THRUSTERS.gd","AUX_POWER_AND_THRUSTERS.gd":
						for equipment in constants.values():
							if pointers.ConfigDriver.__validate_dictionary(equipment,false):
								AUX_POWER_AND_THRUSTERS.append(equipment)
					"MODIFY_INTERNALS.gd":
						for item in constants.get("MODIFY_INTERNALS",Array()):
							if pointers.ConfigDriver.__validate_dictionary(item,false):
								var listingSystemName : String = item.get("system","SYSTEM_MISSING_NAME")
								if not listingSystemName in processed_storage_systems:
									processed_storage_systems.append(listingSystemName)
								if not listingSystemName in processed_storage_mods:
									processed_storage_mods[listingSystemName] = Array()
								var ls : Dictionary = Dictionary()
								for data in item:
									match data:
										"force_type","specific_ship":
											ls[data] = str(item[data])
										"recurse_to_variants":
											ls[data] = bool(item[data])
										"mass_per_tonne_of_processed_ore","mass_per_crew_member","mass",\
										"crew_morale","storage_flat","nano_speed_add","ammo_speed_add",\
										"mass_per_tonne_storage_added","mass_per_tonne_total_storage_added",\
										"minimum_propellant_utilization_for_reduction","emp_shielding",\
										"minimum_nano_utilization_for_reduction","minimum_ammo_utilization_for_reduction":
											ls[data] = float(item[data])
										"crew_count":
											ls[data] = int(item[data])
										"storage_ammo","storage_ammunition":
											ls["storage_ammo"] = float(item[data])
										"storage_nano","storage_nanodrones":
											ls["storage_nano"] = float(item[data])
										"storage_propellant","storage_prop":
											ls["storage_propellant"] = float(item[data])
										"display_system":
											var val : Dictionary = item["display_system"]
											ls["display_system"] = {
												"name":val.get("name",""),
												"can_display_multiple":val.get("can_display_multiple",false),
												"power":val.get("power",0.0),
												"status":val.get("status",100.0),
												"affect_inspection":val.get("affect_inspection",false)
											}
								if "storage_multi_upper" in item or "storage_multi_lower" in item:
									ls["storage_multi"] = float(item.get("storage_multi_upper",1.0))/float(item.get("storage_multi_lower",1.0))
								if "ammo_multi_upper" in item or "ammo_multi_lower" in item:
									ls["ammo_multi"] = float(item.get("ammo_multi_upper",1.0))/float(item.get("ammo_multi_lower",1.0))
								if "nano_multi_upper" in item or "nano_multi_lower" in item:
									ls["nano_multi"] = float(item.get("nano_multi_upper",1.0))/float(item.get("nano_multi_lower",1.0))
								if "propellant_multi_upper" in item or "propellant_multi_lower" in item:
									ls["propellant_multi"] = float(item.get("propellant_multi_upper",1.0))/float(item.get("propellant_multi_lower",1.0))
								if "mass_multi_upper" in item or "mass_multi_lower" in item:
									ls["mass_multi"] = float(item.get("mass_multi_upper",1.0))/float(item.get("mass_multi_lower",1.0))
								if "ammo_speed_multi_upper" in item or "ammo_speed_multi_lower" in item:
									ls["ammo_speed_multi"] = float(item.get("ammo_speed_multi_upper",1.0))/float(item.get("ammo_speed_multi_lower",1.0))
								if "nano_speed_multi_upper" in item or "nano_speed_multi_lower" in item:
									ls["nano_speed_multi"] = float(item.get("nano_speed_multi_upper",1.0))/float(item.get("nano_speed_multi_lower",1.0))
								if "emp_scale_multi_upper" in item or "emp_scale_multi_lower" in item:
									ls["emp_scale_multi"] = float(item.get("emp_scale_multi_upper",1.0))/float(item.get("emp_scale_multi_lower",1.0))
								
								processed_storage_mods[listingSystemName].append(ls)
					"NODE_DEFINITIONS.gd":
						for item in constKeys:
							node_definitions_cache[item] = constants[item]
					"SHIP_NODE_REGISTER.gd":
						ship_node_register.append_array(constants.values())
					"SHIP_NODE_MODIFY.gd":
						for item in constants.values():
							var ship : String = item.get("ship_name","")
							if ship:
								if not ship in ship_node_modify:
									ship_node_modify[ship] = Array()
								for modification in item.get("modifications",Array()):
									ship_node_modify[ship].append(modification)
					"SHIP_THRUSTER_COLORS.gd":
						var cd : Dictionary = constants.get("SHIP_THRUSTER_COLORS",Dictionary())
						for ship in cd.keys():
							if not ship in ship_thruster_colors:
								ship_thruster_colors[ship] = {"node":Dictionary(),"type":Dictionary()}
							if "type" in cd[ship]:
								ship_thruster_colors[ship]["type"].merge(cd[ship]["type"],true)
							if "node" in cd[ship]:
								ship_thruster_colors[ship]["node"].merge(cd[ship]["node"],true)
							if "recurse_to_variants" in cd[ship]:
								ship_thruster_colors[ship]["recurse_to_variants"] = cd[ship]["recurse_to_variants"]
							if "config" in cd[ship]:
								ship_thruster_colors[ship]["config"] = cd[ship]["config"]
					"WEAPONSLOT_ADD.gd":
						for equipment in constants.values():
							var n : String = equipment.get("name","")
							if n and pointers.ConfigDriver.__validate_dictionary(equipment,false):
								if not n in ws_equipment_names:
									ws_equipment_names.append(n)
								WEAPONSLOT_ADD.append(equipment)
					"WEAPONSLOT_MODIFY_TEMPLATES.gd":
						var ar : Dictionary = constants.get("WEAPONSLOT_MODIFY_TEMPLATES",Dictionary())
						for template in ar.keys():
							if template in weaponslot_modify_templates:
								for datapoint in ar[template]:
									match datapoint:
										"equipment":
											for item in ar[template][datapoint]:
												if not item in ws_equipment_names:
													ws_equipment_names.append(item)
												if not item in weaponslot_modify_templates[template][datapoint]:
													weaponslot_modify_templates[template][datapoint].append(item)
										"data":
											var data_formatted : Dictionary = Dictionary()
											for item in ar[template][datapoint]:
												var property = item.get("property")
												var value = item.get("value")
												if item.get("use_stringified_value",false):
													value = pointers.DataFormat.__convert_var_from_string(value)
												data_formatted[property] = value
											for key in data_formatted:
												var is_in_dict:bool = false
												for lps in weaponslot_modify_templates[template][datapoint]:
													if lps.get("property") == key:
														is_in_dict = true
														lps["value"] = data_formatted[key]
												if not is_in_dict:
													weaponslot_modify_templates[template][datapoint].append({"property":key,"value":data_formatted.get(key)})
							else:
								weaponslot_modify_templates[template] = ar.get(template)
					"WEAPONSLOT_MODIFY.gd":
						var ar:Dictionary = constants.get("WEAPONSLOT_MODIFY",Dictionary())
						for item in ar.keys():
							if not item in ws_equipment_names:
								ws_equipment_names.append(item)
							if item in weaponslot_modify_standalone:
								var dict : Dictionary = Dictionary()
								for c in ar[item]:
									var prop : String = c.get("property","")
									var val = c.get("value","")
									if c.get("use_stringified_value",false):
										val = pointers.DataFormat.__convert_var_from_string(val)
									if prop and val:
										dict[prop] = val
								var current_item_data : Dictionary = weaponslot_modify_standalone[item]
								for c in current_item_data:
									var prop : String = c.get("property","")
									var val = c.get("value","")
									if c.get("use_stringified_value",false):
										val = pointers.DataFormat.__convert_var_from_string(val)
									if prop and val:
										dict[prop] = val
								var processed : Array = Array()
								for u in dict:
									processed.append({"property":u,"value":dict[u]})
								weaponslot_modify_standalone[item] = processed
							else:
								weaponslot_modify_standalone[item] = ar[item]
					"WEAPONSLOT_SHIP_TEMPLATES.gd":
						var ar : Dictionary = constants.get("WEAPONSLOT_SHIP_TEMPLATES",Dictionary())
						for ship in ar.keys():
							var shipdata : Dictionary = ar[ship]
							if ship in weaponslot_ship_templates:
								for slot in shipdata:
									if slot in weaponslot_ship_templates[ship]:
										var compile : Dictionary = Dictionary()
										var current_dict : Dictionary = Dictionary()
										for type in weaponslot_ship_templates[ship][slot]:
											if not type in compile:
												compile[type] = Array()
											if not type in current_dict:
												current_dict[type] = Dictionary()
											for equip in weaponslot_ship_templates[ship][slot][type]:
												var property = equip.get("property")
												var value = equip.get("value")
												current_dict[type][property] = value
										for type in shipdata[slot]:
											if not type in compile:
												compile[type] = Array()
											if not type in current_dict:
												current_dict[type] = Dictionary()
											for equip in shipdata[slot][type]:
												var property = equip.get("property")
												var value = equip.get("value")
												current_dict[type][property] = value
										for item in current_dict:
											for equip in current_dict[item]:
												compile[item].append({"property":equip,"value":current_dict[item].get(equip)})
										weaponslot_ship_templates[ship][slot] = compile
									else:
										weaponslot_ship_templates[ship][slot] = shipdata.get(slot)
							else:
								weaponslot_ship_templates[ship] = shipdata
					"WEAPONSLOT_SHIP_MODIFY.gd":
						var ar:Dictionary = constants.get("WEAPONSLOT_SHIP_MODIFY",Dictionary())
						for ship in ar.keys():
							var slots : Dictionary = ar[ship]
							for slot in slots:
								var equipment = slots[slot]
								for item in equipment:
									if not item in ws_equipment_names:
										ws_equipment_names.append(item)
							var shipdata : Dictionary = ar.get(ship)
							if ship in weaponslot_ship_standalone:
								for slot in shipdata:
									if slot in weaponslot_ship_standalone[ship]:
										var current_dict : Dictionary = Dictionary()
										var cmpk:PoolStringArray = PoolStringArray()
										for type in weaponslot_ship_standalone[ship][slot]:
											current_dict[type] = Array()
											cmpk.append(type)
											for equip in weaponslot_ship_standalone[ship][slot][type]:
												current_dict[type].append({"property":equip["property"],"value":equip["value"]})
										for type in shipdata[slot]:
											if not type in cmpk:
												current_dict[type] = Array()
												cmpk.append(type)
											for equip in shipdata[slot][type]:
												if equip.get("use_stringified_value",false):
													current_dict[type].append({"property":equip["property"],"value":pointers.DataFormat.__convert_var_from_string(equip["value"])})
												else:
													current_dict[type].append({"property":equip["property"],"value":equip["value"]})
										weaponslot_ship_standalone[ship][slot] = current_dict
									else:
										weaponslot_ship_standalone[ship][slot] = shipdata[slot]
							else:
								weaponslot_ship_standalone[ship] = shipdata
					"SAVE_BUTTONS.gd":
						for button in constants.get("SAVE_BUTTONS",Array()):
							if pointers.ConfigDriver.__validate_dictionary(button,false):
								save_button_cache.append(button)
					"ADD_SHIPS.gd":
						for ac in constants.values():
							if pointers.ConfigDriver.__validate_dictionary(ac,false):
								add_ships_store.append(ac)
					"MODIFY_SHIP_BUILDS.gd":
						for dict in constants.values():
							if pointers.ConfigDriver.__validate_dictionary(dict):
								var sorting:Dictionary = Dictionary()
								var shipNames = dict.get("ship_name",Array())
								if shipNames is String:
									shipNames = PoolStringArray([shipNames])
								elif shipNames is Array:
									shipNames = PoolStringArray(shipNames)
								elif not shipNames is PoolStringArray:
									continue
								var recurse:bool = dict.get("recurse_for_alias",false)
								for entry in dict.keys():
									if entry in SHIP_BUILD_MODIFY_OPERATIONS:
										for i in dict[entry]:
											if "do_add_if" in i:
												for st in i["do_add_if"]:
													if not st:
														i["do_add_if"].erase(st)
													for r in st:
														if not r:
															st.erase(r)
											if "dont_add_if" in i:
												for st in i["dont_add_if"]:
													if not st:
														i["dont_add_if"].erase(st)
													for r in st:
														if not r:
															st.erase(r)
											if i.get("slot",null) and i.get("system",null):
												var prio = i.get("priority",0)
												if not prio in sorting:
													sorting[prio] = Array()
												i["mode"] = entry
												i["recurse_for_alias"] = recurse
												for shipName in shipNames:
													i["ship_name"] = shipName
													for _r in i.get("weight",1):
														sorting[prio].append(i.duplicate(true))
								var sKeys:Array = sorting.keys()
								sKeys.sort()
								for o in sKeys:
									seed(sorting.hash())
									sorting[o].shuffle()
									for i in sorting[o]:
										ship_build_mod_store.append(i)
					"REGISTER_SHIP_NUMERICS.gd":
						for ar in constKeys:
							if not ar in register_ship_numerics_store:
								register_ship_numerics_store[ar] = Array()
							var ac:Dictionary = constants[ar]
							for v in ac.keys():
								var ax:Dictionary = ac[v]
								if pointers.ConfigDriver.__validate_dictionary(ax,false):
									register_ship_numerics_store[ar].append({v:ax})
					"MODIFY_SHIP_NUMERICS.gd":
						for di in constants.values():
							var ship : String = di.get("ship_name","")
							if ship:
								if ship in modify_ship_numerics:
									modify_ship_numerics[ship].append(di)
								else:
									modify_ship_numerics[ship] = [di]
					"NAMER.gd":
						if "CREW" in constKeys:
							namer_store["crew"].append_array(constants["CREW"])
						if "SHIPS" in constKeys:
							namer_store["ships"].append_array(constants["SHIPS"])
						if "REMOVE_CREW" in constKeys:
							namer_store["remove_crew"].append_array(constants["REMOVE_CREW"])
						if "REMOVE_SHIPS" in constKeys:
							namer_store["remove_ships"].append_array(constants["REMOVE_SHIPS"])
					"EVENT_DRIVER.gd":
						event_driver_event_entries.append_array(constants.values())
					"RESEARCH.gd":
						var rd:Dictionary = Dictionary()
						for entry in constKeys:
							var data:Dictionary = constants[entry]
							data["source"] = mod_id
							data["uid"] = mod_id + "\\" + entry
							rd[entry] = data
						if rd:
							research_store[mod_id] = rd
					"RPC_EXTRA_STATES.gd":
						var data:Dictionary = constants.get("RPC_EXTRA_STATES",Dictionary())
						for type in data.keys():
							if type in rpc_second_state_store:
								var states:Array = Array()
								for item in data[type]:
									if "sensors" in item:
										for i in item.sensors.size():
											var sensorItem = item.sensors[i]
											if sensorItem is Dictionary:
												if "func_object_path" in sensorItem and "func_method_name" in sensorItem:
													var object_name:String = sensorItem.func_object_path
													if object_name.begins_with("res://") and object_name.get_extension() in acceptible_script_extensions:
														if object_name in sensor_ref_names:
															sensor_refs_to_write[object_name].append(sensorItem)
														elif pointers.FileAccess.__file_exists(object_name):
															sensor_refs_to_write[object_name] = [sensorItem]
													else:
														if not object_name in needs_autoload_funcref.keys():
															needs_autoload_funcref[object_name] = [sensorItem]
														else:
															needs_autoload_funcref[object_name].append(sensorItem)
											elif sensorItem is String:
												states.append(item)
											else: continue
									if "function_outputs" in item:
										for i in item.function_outputs.size():
											var sensorItem:Dictionary = item.function_outputs[i]
											if "func_object_path" in sensorItem and "func_method_name" in sensorItem:
												var object_name:String = sensorItem.func_object_path
												if object_name.begins_with("res://") and object_name.get_extension() in acceptible_script_extensions:
													if object_name in sensor_ref_names:
														sensor_refs_to_write[object_name].append(sensorItem)
													elif pointers.FileAccess.__file_exists(object_name):
														sensor_refs_to_write[object_name] = [sensorItem]
														sensor_ref_names.append(object_name)
												else:
													if not object_name in needs_autoload_funcref.keys():
														needs_autoload_funcref[object_name] = [sensorItem]
													else:
														needs_autoload_funcref[object_name].append(sensorItem)
									states.append(item)
								rpc_second_state_store[type].append_array(states)
					"SERVICES.gd":
						services_store.append_array(constants.get("SERVICES",Array()))
		
		var slots_for_adding_dict : Dictionary = Dictionary()
		var tag_modifications : Array = Array()
		
		var ship_limitations : Dictionary = Dictionary()
		for nodes in EQUIPMENT_TAGS:
			if nodes:
				var slotTypes : PoolStringArray = PoolStringArray(nodes.get("slot_types",PoolStringArray()))
				var equipmentItems : PoolStringArray = PoolStringArray(nodes.get("equipment_types",PoolStringArray()))
				var align : PoolStringArray = PoolStringArray(nodes.get("alignments",PoolStringArray()))
				var hardpointTypes : PoolStringArray = PoolStringArray(nodes.get("hardpoint_types",PoolStringArray()))
				var slotDefaults : Dictionary = nodes.get("slot_defaults",Dictionary())
				for st in slotTypes:
					if not st in slot_types:
						slot_types.append(st)
				for st in equipmentItems:
					if not st in equipment_types:
						equipment_types.append(st)
				for st in align:
					if not st in alignments:
						alignments.append(st)
				for st in hardpointTypes:
					if not st in hardpoint_types:
						hardpoint_types.append(st)
				for st in slotDefaults.keys():
					if st in slot_defaults.keys():
						for item in slotDefaults[st]:
							if not item in slot_defaults[st]:
								slot_defaults[st].append(item)
					else:
						slot_defaults[st] = slotDefaults[st]
		for slotDict in ADD_EQUIPMENT_SLOTS:
			var snn : String = slotDict.get("slot_node_name","")
			var spp : Dictionary = ship_limitations.get(snn,Dictionary())
			var sppKeys:PoolStringArray = PoolStringArray(spp.keys())
			if "limit_ships" in slotDict:
				var val : PoolStringArray = PoolStringArray(slotDict["limit_ships"])
				if snn in ship_limitations:
					if "limit_ships" in sppKeys:
						for i in val:
							if not i in sppKeys:
								ship_limitations[snn]["limit_ships"] = i
					else:
						ship_limitations[snn]["limit_ships"] = spp["limit_ships"]
				else:
					ship_limitations[snn] = {"limit_ships":val}
			if "prevent_ships" in slotDict:
				var val : PoolStringArray = PoolStringArray(slotDict["prevent_ships"])
				if snn in ship_limitations:
					if "prevent_ships" in sppKeys:
						for i in val:
							if not i in sppKeys:
								ship_limitations[snn]["prevent_ships"] = i
					else:
						ship_limitations[snn]["prevent_ships"] = spp["prevent_ships"]
				else:
					ship_limitations[snn] = {"prevent_ships":val}
			slots_for_adding_dict[snn] = slotDict
			all_slot_node_names.append(snn)
		for node in SLOT_TAGS:
			if node:
				tag_modifications.append(node)
				for snn in node:
					var data : Dictionary = node[snn]
					var spp : Dictionary = ship_limitations.get(snn,Dictionary())
					if "limit_ships" in data:
						var val : PoolStringArray = PoolStringArray(data["limit_ships"])
						if snn in ship_limitations:
							if "limit_ships" in spp.keys():
								for f in val:
									if not f in spp["limit_ships"]:
										ship_limitations[snn]["limit_ships"].append(f)
							else:
								ship_limitations[snn]["limit_ships"] = spp["limit_ships"]
						else:
							ship_limitations[snn] = {"limit_ships":val}
					if "prevent_ships" in data:
						var val : PoolStringArray = PoolStringArray(data["prevent_ships"])
						if snn in ship_limitations:
							if "prevent_ships" in spp.keys():
								for f in val:
									if not f in spp["prevent_ships"]:
										ship_limitations[snn]["prevent_ships"].append(f)
							else:
								ship_limitations[snn]["prevent_ships"] = spp["prevent_ships"]
						else:
							ship_limitations[snn] = {"prevent_ships":val}
		
		var slots_format : PoolStringArray = PoolStringArray()
		var editable_paths : PoolStringArray = PoolStringArray()
		
		var slot_allowed_equipment : Dictionary = Dictionary()
		
		var vedfrKeys:PoolStringArray = PoolStringArray(vanilla_equipment_defaults_for_reference.keys())
		var sfaKeys:PoolStringArray = PoolStringArray(slots_for_adding_dict.keys())
		for m in sfaKeys:
			var slot:Dictionary = slots_for_adding_dict[m]
			var format : Array = __make_slot_for_scene(slot)
			
			# FUTURE ME: Write a mod that tag modifies a modded slot, need to double check functionality of this code + define types
			for data in tag_modifications:
				if m in data.keys():
					var slot_override_additive:PoolStringArray = format[2]["override_additive"]
					var slot_override_subtractive:PoolStringArray = format[2]["override_subtractive"]
					for over in PoolStringArray(data[m].get("override_additive",PoolStringArray())):
						if not over in slot_override_additive:
							slot_override_additive.append(over)
					for over in PoolStringArray(data[m].get("override_subtractive",PoolStringArray())):
						if not over in slot_override_subtractive:
							slot_override_subtractive.append(over)
			slots_format.append(format[0])
			editable_paths.append(format[1])
		for slot in vedfrKeys:
			var vslot_data : Dictionary = vanilla_equipment_defaults_for_reference[slot]
			var vslot_additives : PoolStringArray = PoolStringArray(vslot_data.get("override_additive",PoolStringArray()))
			var vslot_subtractives : PoolStringArray = PoolStringArray(vslot_data.get("override_subtractive",PoolStringArray()))
			for dict in tag_modifications:
				if slot in dict.keys():
					var tag_data : Dictionary = dict[slot]
					for add in PoolStringArray(tag_data.get("override_additive",PoolStringArray())):
						if not add in vslot_additives:
							vslot_additives.append(add)
					for sub in PoolStringArray(tag_data.get("override_subtractive",PoolStringArray())):
						if not sub in vslot_subtractives:
							vslot_subtractives.append(sub)
			if vslot_additives:
				vslot_data["override_additive"] = vslot_additives
			if vslot_subtractives:
				vslot_data["override_subtractive"] = vslot_subtractives
			vanilla_equipment_defaults_for_reference[slot] = vslot_data
		
		for slot in all_slot_node_names:
			if slot in vedfrKeys:
				var data : Dictionary = vanilla_equipment_defaults_for_reference[slot]
				var slot_type : String = data.get("slot_type","HARDPOINT").to_upper()
				if slot_type == "HARDPOINT":
					var items : Array = Array(PoolStringArray(slot_defaults.get(data.get("hardpoint_type", ""),Array())))
					for item in PoolStringArray(data.get("override_additive",PoolStringArray())):
						if not item in items:
							items.append(item)
					for i in PoolStringArray(data.get("override_subtractive",PoolStringArray())):
						items.erase(i)
					slot_allowed_equipment[slot] = PoolStringArray(items)
				else:
					var items : Array = Array(PoolStringArray(slot_defaults.get(slot_type,Array())))
					for item in PoolStringArray(data.get("override_additive",PoolStringArray())):
						if not item in items:
							items.append(item)
					for i in PoolStringArray(data.get("override_subtractive",PoolStringArray())):
						items.erase(i)
					slot_allowed_equipment[slot] = PoolStringArray(items)
			elif slot in sfaKeys:
				var data : Dictionary = slots_for_adding_dict[slot]
				var slot_type : String = data.get("slot_type","HARDPOINT").to_upper()
				if slot_type == "HARDPOINT":
					var items : Array = Array(PoolStringArray(slot_defaults.get(data.get("hardpoint_type", ""),Array())))
					for item in PoolStringArray(data.get("override_additive",PoolStringArray())):
						if not item in items:
							items.append(item)
					for i in PoolStringArray(data.get("override_subtractive",PoolStringArray())):
						items.erase(i)
					slot_allowed_equipment[slot] = PoolStringArray(items)
				else:
					slot_allowed_equipment[slot] = PoolStringArray(slot_defaults.get(slot_type,PoolStringArray()))
		
		var equipment_format : PoolStringArray = PoolStringArray()
		for st in sfaKeys:
			var slot:Dictionary = slots_for_adding_dict[st]
			if slot.get("add_vanilla_equipment",true):
				for equip in vanilla_equipment:
					if confirm_equipment(vanilla_equipment[equip], slot.get("slot_type",""), slot.get("alignment",""), slot.get("restriction",""), PoolStringArray(slot_allowed_equipment.get(slot.get("slot_node_name",""),PoolStringArray()))):
						equipment_format.append(__make_equipment_for_scene(vanilla_equipment[equip], slot.get("slot_node_name",""), slot.get("system_slot","")))
		for slot in all_slot_node_names:
			if slot in slot_allowed_equipment:
				for item in ADD_EQUIPMENT_ITEMS:
					var slot_type : String = ""
					var alignment : String = ""
					var restriction : String = ""
					var system_slot : String = ""
					if slot in vedfrKeys:
						var vd:Dictionary = vanilla_equipment_defaults_for_reference[slot]
						slot_type = vd.get("slot_type","")
						alignment = vd.get("alignment","")
						restriction = vd.get("restriction","")
						system_slot = VANILLA_SLOT_TYPES[slot]
					elif slot in sfaKeys:
						var sd:Dictionary = slots_for_adding_dict[slot]
						slot_type = sd.get("slot_type","")
						alignment = sd.get("alignment","")
						restriction = sd.get("restriction","")
						system_slot = sd.get("system_slot","")
					if confirm_equipment(item, slot_type, alignment, restriction, PoolStringArray(slot_allowed_equipment.get(slot,PoolStringArray()))):
						var string : String = __make_equipment_for_scene(item, slot, system_slot)
						var this_sys:String = item.get("system","")
						var this_type:String = item.get("equipment_type","")
						if this_sys and this_type:
							if not this_sys in equipment_validity_for_slots:
								equipment_validity_for_slots[this_sys] = Array()
							if not this_type in equipment_validity_for_slots[this_sys]:
								equipment_validity_for_slots[this_sys].append(this_type)
							if not string in equipment_format:
								equipment_format.append(string)
		
		var concat : String = """[gd_scene load_steps=6 format=2]

[ext_resource path=\"res://enceladus/Upgrades.tscn\" type=\"PackedScene\" id=1]
[ext_resource path=\"res://HevLib/scenes/equipment/hardpoints/WeaponSlotUpgradeTemplate.tscn\" type=\"PackedScene\" id=2]
[ext_resource path=\"res://enceladus/SystemShipUpgradeUI.tscn\" type=\"PackedScene\" id=3]
[ext_resource path=\"res://HevLib/scenes/equipment/Upgrades.gd\" type=\"Script\" id=4]
[ext_resource path=\"res://HevLib/scenes/equipment/EquipmentManager.gd\" type=\"Script\" id=5]

[node name=\"Upgrades\" instance=ExtResource( 1 )]
script = ExtResource( 4 )

[node name=\"Items\" parent=\"VB/MarginContainer/ScrollContainer/MarginContainer\" index=\"0\"]
script = ExtResource( 5 )"""
		
		for ref in slots_format:
			concat += "\n\n" + ref
		for equip in equipment_format:
			concat += "\n\n" + equip
		for path in editable_paths:
			concat += "\n\n" + path
		
		var equipment_header : String = "[node name=\"%s\" parent=\"%s\" instance_placeholder=\"%s\"]"
		var equipment_header_noref : String = "[node name=\"%s\" parent=\"%s\"]"
		var equipment_editable_path_base : String = "[editable path=\"%s\"]"
		
		var weaponslot_string : String = "[gd_scene load_steps=2 format=2]\n\n[ext_resource path=\"res://weapons/WeaponSlot.tscn\" type=\"PackedScene\" id=1]\n\n[node name=\"WeaponSlot\" instance=ExtResource( 1 )]"
		var ws_editable_paths : String = ""
		var weaponslot_properties : Dictionary = Dictionary()
		
		var all_slot_types:Dictionary = VANILLA_SLOT_TYPES.duplicate(true)
		for i in all_slot_node_names:
			if not i in all_slot_types:
				all_slot_types[i] = slots_for_adding_dict[i].get("system_slot","")
		
		for add in WEAPONSLOT_ADD:
			if pointers.ConfigDriver.__validate_dictionary(add,false):
				var apath : String = add.get("path","")
				var item_data : Dictionary = Dictionary()
				for it in add.get("data",Array()):
					var ws_property : String = it.get("property")
					var ws_value = it.get("value")
					if it.get("use_stringified_value",false):
						ws_value = pointers.DataFormat.__convert_var_from_string(ws_value)
					var split:PoolStringArray = ws_property.split("/")
					var splitSize:int = split.size()
					if splitSize > 2:
						var nonode:PoolStringArray = ws_property.split(split[splitSize - 2])
						if nonode[0].ends_with("/"):
							nonode[0] = nonode[0].rstrip("/")
						if nonode[1].begins_with("/"):
							nonode[1] = nonode[1].lstrip("/")
						if not nonode[0] in item_data:
							item_data[nonode[0]] = Array()
						item_data[nonode[0]].append([nonode[1],ws_value])
					elif splitSize == 2:
						if not split[0] in item_data:
							item_data[split[0]] = Array()
						item_data[split[0]].append([split[1],ws_value])
					else:
						if not "." in item_data:
							item_data["."] = Array()
						item_data["."].append([ws_property,ws_value])
				if apath:
					ws_stuff_to_add.append({"name":add.get("name","SYSTEM_ERROR"),"path":apath,"data":item_data,"config":add.get("config",Dictionary())})
				else:
					ws_stuff_to_modify.append({"name":add.get("name","SYSTEM_ERROR"),"data":item_data})
			
			var aname : String = add.get("name","SYSTEM_ERROR")
			var apath : String = add.get("path","")
			var add_header : String = (equipment_header % [aname,".",apath]) if apath else (equipment_header_noref % [aname,"."])
			weaponslot_properties[add_header] = Array()
			if ws_editable_paths:
				ws_editable_paths += "\n" + equipment_editable_path_base % aname
			else:
				ws_editable_paths = equipment_editable_path_base % aname
			
			for it in add.get("data",Array()):
				var ws_property : String = it.get("property")
				var ws_value = it.get("value")
				if it.get("use_stringified_value",false):
					ws_value = pointers.DataFormat.__convert_var_from_string(ws_value)
				var split:PoolStringArray = ws_property.split("/")
				var splitSize:int = split.size()
				if splitSize > 2:
					var node : String = split[splitSize - 2]
					var nonode:PoolStringArray = ws_property.split(node)
					if nonode[0].ends_with("/"):
						nonode[0] = nonode[0].rstrip("/")
					if nonode[1].begins_with("/"):
						nonode[1] = nonode[1].lstrip("/")
					var prop_header : String = equipment_header_noref % [node,aname + "/" + nonode[0]]
					if not prop_header in weaponslot_properties:
						weaponslot_properties[prop_header] = Array()
					weaponslot_properties[prop_header].append([nonode[1],ws_value])
				elif splitSize == 2:
					var prop_header : String = equipment_header_noref % [split[0],aname]
					if not prop_header in weaponslot_properties:
						weaponslot_properties[prop_header] = Array()
					weaponslot_properties[prop_header].append([split[1],ws_value])
				else:
					if not add_header in weaponslot_properties:
						weaponslot_properties[add_header] = Array()
					weaponslot_properties[add_header].append([ws_property,ws_value])
		
		for property in weaponslot_properties:
			weaponslot_string += "\n\n" + property
			for dp in weaponslot_properties[property]:
				weaponslot_string += "\n%s = %s" % [dp[0],var2str(dp[1])]
		
		for data in AUX_POWER_AND_THRUSTERS:
			for slot in data.get("slots",Array()):
				slot = slot.split(".")[0]
				if not slot in auxslot_data:
					auxslot_data[slot] = Array()
				auxslot_data[slot].append(data)
			
			var aux_type : String = data.get("type","MPDG").to_upper()
			if aux_type in THRUSTER_BASE_TYPES:
				var auxTypePath : String = "user://cache/AuxAndThrusterDriver/" + aux_type
				directory.make_dir_recursive(auxTypePath)
				thruster_data_to_write.append({"object":self,"method":"write_thruster_scenes","args":[data,aux_type,auxTypePath]})
		if ws_editable_paths:
			weaponslot_string += "\n\n" + ws_editable_paths
		
		var ship_limitation_string : String = "[gd_scene load_steps=2 format=2]\n\n[ext_resource path=\"res://enceladus/Upgrades.tscn\" type=\"PackedScene\" id=1]\n\n[node name=\"Upgrades\" instance=ExtResource( 1 )]"
		var lim_item : String = "[node name=\"%s\" parent=\"VB/MarginContainer/ScrollContainer/MarginContainer/Items\"]"
		for i in ship_limitations:
			ship_limitation_string += "\n\n" + lim_item % i
			var data : Dictionary = ship_limitations[i]
			if "limit_ships" in data:
				if data["limit_ships"] is String:
					data["limit_ships"] = PoolStringArray([data["limit_ships"]])
				ship_limitation_string += "\nlimit_ships = [\"%s\"]" % "\",\"".join(PoolStringArray(data["limit_ships"]))
			if "prevent_ships" in data:
				if data["prevent_ships"] is String:
					data["prevent_ships"] = PoolStringArray([data["prevent_ships"]])
				ship_limitation_string += "\nprevent_ships = [\"%s\"]" % "\",\"".join(PoolStringArray(data["prevent_ships"]))
		
		file.open("user://cache/Variable_Fetch/upgrades.tscn",File.WRITE)
		file.store_string(concat)
		file.close()
		file.open("user://cache/Variable_Fetch/ship_limitations.tscn",File.WRITE)
		file.store_string(ship_limitation_string)
		file.close()
	
	var tagged_vanilla_slots : PoolStringArray = PoolStringArray()
	
	var generated_tex : Dictionary = Dictionary()
	
	var sensor_refs_to_write:Dictionary = Dictionary()
	var sensor_ref_names:PoolStringArray = PoolStringArray()
	func write_rpc_sensor_items():
		for i in sensor_ref_names:
			if pointers.DataFormat.__load_if_can(i,"Script"):
				var sensorItems:Array = sensor_refs_to_write[i]
				var refobject:Object = pointers.DataFormat.__get_load().new()
				_savedObjects.append(refobject)
				for sensorItem in sensorItems:
					sensorItem["funcref"] = funcref(refobject,sensorItem.func_method_name)
	
	var thruster_data_to_write:Array = Array()
	var directory:Directory = Directory.new()
	static func write_thruster_scenes(data:Dictionary,aux_type:String,auxTypePath:String):
		var aux_path : String = data.get("path","")
		if aux_type == "THRUSTER":
			aux_type = "RCS"
		elif aux_type == "MAIN_PROPULSION":
			aux_type = "TORCH"
		var f:File = File.new()
		if not (aux_path and (f.file_exists(aux_path) or ResourceLoader.load(aux_path))):
			var sys : String = data.get("system","SYSTEM_NAME_MISSING")
			f.open(auxTypePath + "/" + sys + "_exhaust.tscn",File.WRITE)
			f.store_string(make_exhaust_scene(data,sys))
			f.close()
			f.open(auxTypePath + "/" + sys + "_thruster.tscn",File.WRITE)
			f.store_string(make_thruster_scene(data,sys,aux_type))
			f.close()
	
	static func create_compiled_tex(texturepath:String, cached_tex_path:String, save_type:String):
		return texturepath
#		var filepath : String = cached_tex_path % save_type
#		if texturepath in generated_tex:
#			filepath = generated_tex[texturepath]
#		else:
#			filepath = pointers.FileAccess.__save_stex(pointers.FileAccess.__load_png(texturepath).get_data(),filepath)
#			generated_tex[texturepath] = filepath
#		return filepath
	
	static func make_thruster_scene(data,sys,aux_type) -> String:
		var this_sys_path : String = "user://cache/AuxAndThrusterDriver/" + aux_type + "/" + sys
		
		var cached_exhaust_path : String = this_sys_path + "_exhaust.tscn"
		var cached_tex_path : String = this_sys_path + "_texture_%s.stex"
		
		var thruster_header : String = "[gd_scene load_steps=%d format=2]\n\n[ext_resource path=\"res://sfx/thruster.tscn\" type=\"PackedScene\" id=1]"
		var nozzle_footer : String = "[editable path=\"nozzle\"]"
		var extra_nozzle_footer : String = "[editable path=\"%s\"]"
		
		var thruster_node_header : String = "\n\n[node name=\"thruster\" instance=ExtResource( 1 )]"
		var this_nozzle_header : String = "\n\n[node name=\"%s\" parent=\".\" index=\"%d\" instance=ExtResource( %d )]"
		var audio_loop_header : String = "\n\n[node name=\"AudioLoop\" parent=\".\" index=\"0\"]"
		var audio_start_header : String = "\n\n[node name=\"AudioStart\" parent=\".\" index=\"1\"]"
		var flare_header : String = "\n\n[node name=\"Flare\" parent=\".\" index=\"2\"]"
		var nozzle_header : String = "\n\n[node name=\"nozzle\" parent=\".\" index=\"%d\"]"
		
		var ext_path_counter:int = 1
		var ext_path_entry : String = "[ext_resource path=\"%s\" type=\"%s\" id=%d]"
		
		var ext_entries : PoolStringArray = PoolStringArray()
		
		var thruster_vars : String = thruster_node_header
		# Base thruster programming
		
		var mass:float = data.get("mass",0)
		thruster_vars += "\n" + "mass = %d" % mass
		thruster_vars += "\n" + "systemName = \"%s\"" % sys
		thruster_vars += "\n" + "priorityOffset = %f" % data.get("priority_offset",1.0 if aux_type == "RCS" else 8.0)
		thruster_vars += "\n" + "mainBrightRatio = %f" % data.get("main_bright_ratio",0.01)
		thruster_vars += "\n" + "repairReplacementPrice = %d" % data.get("price",3000 if aux_type == "RCS" else 15000)
		thruster_vars += "\n" + "repairReplacementTime = %d" % data.get("repair_time",1 if aux_type == "RCS" else 4)
		thruster_vars += "\n" + "repairFixPrice = %d" % data.get("fix_price",500 if aux_type == "RCS" else 1000)
		thruster_vars += "\n" + "repairFixTime = %d" % data.get("fix_time",4 if aux_type == "RCS" else 12)
		thruster_vars += "\n" + "exhaustEmitOffset = %f" % data.get("exhaust_emit_offset",8.0)
		thruster_vars += "\n" + "scaleOffsetWithPower = " + ("true" if data.get("scale_offset_with_power",false) else "false")
		thruster_vars += "\n" + "distanceScale = %f" % data.get("distance_scale",5)
		thruster_vars += "\n" + "plumesFromSettings = " + "true" if data.get("plumes_from_settings",true) else "false"
		thruster_vars += "\n" + "angularDegreedRange = %f" % data.get("angular_degree_range",30)
		thruster_vars += "\n" + "rotationRange = %f" % data.get("rotation_range",PI)
		var consumeCargo:PoolStringArray = data.get("consume_cargo",PoolStringArray())
		thruster_vars += "\n" + "consumeCargo = PoolStringArray(%s)" % (("\"" + consumeCargo.join("\", \"") + "\"") if consumeCargo else "")
		thruster_vars += "\n" + "canFizzle = " + "true" if data.get("can_fizzle",true) else "false"
		thruster_vars += "\n" + "wearPowerMaxChance = %f" % data.get("wear_power_max_chance",0.95)
		thruster_vars += "\n" + "wearChance = %f" % data.get("wear_chance",0.01)
		thruster_vars += "\n" + "accelerationFailLimit = %f" % data.get("acceleration_fail_limit",400)
		thruster_vars += "\n" + "accelerationFailScale = %f" % data.get("acceleration_fail_scale",200)
		thruster_vars += "\n" + "lightLagChance = %f" % data.get("light_lag_chance",0.5)
		thruster_vars += "\n" + "startJolt = %f" % data.get("start_jolt",0)
		thruster_vars += "\n" + "thrust = %f" % data.get("thrust",1000 if aux_type == "RCS" else 7500)
		thruster_vars += "\n" + "command = \"" + data.get("command","m" if aux_type == "TORCH" else "") + "\""
		thruster_vars += "\n" + "particleChance = %f" % data.get("particle_chance",0.5 if aux_type == "RCS" else 1.0)
		thruster_vars += "\n" + "chokeParticleAdjust = %f" % data.get("choke_particle_adjust",1)
		thruster_vars += "\n" + "fadeSeconds = %f" % data.get("fade_seconds",0.2 if aux_type == "RCS" else 0.4)
		thruster_vars += "\n" + "windUpSeconds = %f" % data.get("wind_up_seconds",0.017)
		thruster_vars += "\n" + "particleScale = %f" % data.get("particle_scale",5)
		thruster_vars += "\n" + "randomness = %f" % data.get("randomness",0.5)
		thruster_vars += "\n" + "heatCone = %f" % data.get("heat_cone",0.5)
		thruster_vars += "\n" + "minPower = %f" % data.get("min_power",0.2 if aux_type == "RCS" else 0.8)
		thruster_vars += "\n" + "damageWearCapacity = %f" % data.get("damage_wear_capacity",3600)
		thruster_vars += "\n" + "damageBentCapacity = %f" % data.get("damage_bent_capacity",3000)
		thruster_vars += "\n" + "damageBentThreshold = %f" % data.get("damage_bent_threshold",200)
		thruster_vars += "\n" + "damageChokeCapacity = %f" % data.get("damage_choke_capacity",6000)
		thruster_vars += "\n" + "damageChokeThreshold = %f" % data.get("damage_choke_threshold",400)
		thruster_vars += "\n" + "specialFuelLimit = %f" % data.get("special_fuel_limit",0)
		thruster_vars += "\n" + "heatFireThreshold = %f" % data.get("heat_fire_threshold",200)
		thruster_vars += "\n" + "heatFireScale = %f" % data.get("heat_fire_scale",8000)
		thruster_vars += "\n" + "heatFireMax = %f" % data.get("heat_fire_max",0.5)
		thruster_vars += "\n" + "maxMissalignment = %f" % data.get("max_misalignment",0.262 if aux_type == "RCS" else 0.02)
		thruster_vars += "\n" + "bendWearRatio = %f" % data.get("bend_wear_ratio",0.025)
		thruster_vars += "\n" + "specificImpulse = %f" % data.get("specific_impulse",65 if aux_type == "RCS" else 15)
		thruster_vars += "\n" + "thermalFactor = %f" % data.get("thermal_factor",40)
		thruster_vars += "\n" + "powerDraw = %f" % data.get("power_draw",5000 if aux_type == "RCS" else 100000)
		thruster_vars += "\n" + "gimbalPowerDraw = %f" % data.get("gimbal_power_draw",100)
		thruster_vars += "\n" + "thermalHitFactor = %f" % data.get("thermal_hit_factor",1)
		thruster_vars += "\n" + "inspection = " + "true" if data.get("inspection",true) else "false"
		thruster_vars += "\n" + "gimbal = %f" % deg2rad(data.get("gimbal",0))
		thruster_vars += "\n" + "safetyProtocol = " + "true" if data.get("safety_protocol",true) else "false"
		thruster_vars += "\n" + "safetyGimbalClear = %f" % data.get("safety_gimbal_clear",0.419)
		thruster_vars += "\n" + "ignitionsPerSecond = %f" % data.get("ignitions_per_second",10)
		thruster_vars += "\n" + "gimbalAccurancy = %f" % data.get("gimbal_accuracy",0.262)
		thruster_vars += "\n" + "gimbalPerSecond = %f" % data.get("gimbal_per_second",PI)
		thruster_vars += "\n" + "gimbalRestAngle = %f" % data.get("gimbal_rest_angle",0)
		thruster_vars += "\n" + "gimbalVectoredThrust = " + ("true" if data.get("gimbal_vectored_thrust",false) else "false")
		thruster_vars += "\n" + "pulsePerSecond = %f" % data.get("pulse_per_second",10 if aux_type == "RCS" else 4)
		thruster_vars += "\n" + "pulseEngine = " + ("true" if data.get("pulse_engine",true) else "false")
		thruster_vars += "\n" + "externalPower = " + ("true" if data.get("external_power",false) else "false")
		thruster_vars += "\n" + "safetyMaxPower = %f" % data.get("safety_max_power",1)
		thruster_vars += "\n" + "safetyExtraMargin = %f" % data.get("safety_extra_margin",1)
		thruster_vars += "\n" + "tuneThrustMin = %f" % data.get("tune_thrust_min",0.5)
		thruster_vars += "\n" + "tuneThrustMax = %f" % data.get("tune_thrust_max",1.5)
		thruster_vars += "\n" + "sweepHostilityFactor = %f" % data.get("sweep_hostility_factor",0.2)
		thruster_vars += "\n" + "damageHostilityScale = %f" % data.get("damage_hostility_scale",40000000)
		thruster_vars += "\n" + "maxVolume = %f" % data.get("max_volume",-20)
		thruster_vars += "\n" + "rangeOverride = %f" % data.get("range_override",0)
		thruster_vars += "\n" + "boresightAngleoverride = %f" % data.get("boresight_angle_override",0)
		thruster_vars += "\n" + "pitchOverride = %f" % data.get("pitch_override",0)
		thruster_vars += "\n" + "minChoke = %f" % data.get("min_choke",0.25)
		var modulate:Color = Color(data.get("modulate",Color.white))
		thruster_vars += "\n" + "modulate = Color( %f , %f , %f , %f )" % [modulate.r,modulate.g,modulate.b,modulate.a]
		var self_modulate:Color = Color(data.get("self_modulate",Color(1,1,1,0)))
		thruster_vars += "\n" + "self_modulate = Color( %f , %f , %f , %f )" % [self_modulate.r,self_modulate.g,self_modulate.b,self_modulate.a]
		var po = data.get("plume_offset",Vector2(-32,-16))
		if (po is Vector2) or ((po is Array or po is PoolIntArray or po is PoolRealArray) and po.size() > 1):
			thruster_vars += "\n" + "offset = Vector2( %f , %f )" % [po[0],po[1]]
		thruster_vars += "\n" + "centered = " + ("true" if data.get("plume_centered",false) else "false")
		thruster_vars += "\n" + "flip_h = " + ("true" if data.get("plume_flip_h",false) else "false")
		thruster_vars += "\n" + "flip_v = " + ("true" if data.get("plume_flip_v",false) else "false")
		thruster_vars += "\n" + "hframes = %d" % int(data.get("plume_horizontal_frames",8))
		thruster_vars += "\n" + "vframes = %d" % int(data.get("plume_vertical_frames",1))
		thruster_vars += "\n" + "frame = %d" % data.get("plume_frame",1)
		var plumeFrameCoords = data.get("plume_frame_coords",Vector2.RIGHT)
		if (plumeFrameCoords is Vector2) or (plumeFrameCoords is Array and plumeFrameCoords.size() > 1):
			thruster_vars += "\n" + "frame_coords = Vector2( %f , %f )" % [plumeFrameCoords[0],plumeFrameCoords[1]]
		thruster_vars += "\n" + "region_enabled = " + ("true" if data.get("plume_region_enabled",false) else "false")
		var plRect = data.get("plume_region_rect",Rect2(0,0,0,0))
		if (plRect is Array or plRect is PoolIntArray or plRect is PoolRealArray) and plRect.size() > 3:
			thruster_vars += "\n" + "region_rect = Rect2( %f , %f , %f , %f )" % [plRect[0],plRect[1],plRect[2],plRect[3]]
		elif plRect is Rect2:
			thruster_vars += "\n" + "region_rect = Rect2( %f , %f , %f , %f )" % [plRect.position.x,plRect.position.y,plRect.size.x,plRect.size.y]
		thruster_vars += "\n" + "region_filter_clip = " + ("true" if data.get("plume_region_filter_clip",false) else "false")
		var tp = data.get("position",Vector2(0,-3))
		if tp is Vector2 or ((tp is Array or tp is PoolIntArray or tp is PoolRealArray) and tp.size() > 1):
			thruster_vars += "\n" + "position = Vector2( %f , %f )" % [tp[0],tp[1]]
		thruster_vars += "\n" + "rotation = %f" % deg2rad(data.get("rotation",0))
		var ts = data.get("scale",Vector2(0.2,0.2) if aux_type == "RCS" else Vector2(0.939,1.395))
		if ts is Vector2 or ((ts is Array or ts is PoolIntArray or ts is PoolRealArray) and ts.size() > 1):
			thruster_vars += "\n" + "scale = Vector2( %f , %f )" % [ts[0],ts[1]]
		
		var flare_vars : String = flare_header
		# Flare programming
		flare_vars += "\n" + "essentiality = %f" % data.get("flare_essentiality",0.5 if aux_type == "RCS" else 0.8)
		flare_vars += "\n" + "offsetByCamera = " + ("true" if data.get("flare_offset_by_camera",false) else "false")
		flare_vars += "\n" + "energy = %f" % data.get("flare_energy",5)
		flare_vars += "\n" + "range_height = %f" % data.get("flare_range_height",-15)
		flare_vars += "\n" + "range_z_min = %d" % data.get("flare_range_z_min",-4096)
		flare_vars += "\n" + "range_z_max = %d" % data.get("flare_range_z_max",4096)
		flare_vars += "\n" + "range_layer_min = %d" % data.get("flare_range_layer_min",-1)
		flare_vars += "\n" + "range_layer_max = %d" % data.get("flare_range_layer_max",1)
		var flare_offset:Vector2 = Vector2.ZERO
		var fo = data.get("flare_offset",flare_offset)
		if fo is Vector2 or ((fo is Array or fo is PoolIntArray or fo is PoolRealArray) and fo.size() > 1):
			flare_offset[0] = fo[0]
			flare_offset[1] = fo[1]
		flare_vars += "\n" + "offset = Vector2( %f , %f )" % [flare_offset.x,flare_offset.y]
		flare_vars += "\n" + "texture_scale = %f" % data.get("flare_texture_scale",6)
		flare_vars += "\n" + "rotation = %f" % deg2rad(data.get("flare_rotation",0))
		var fp = data.get("flare_position",Vector2.ZERO)
		if fp is Vector2 or ((fp is Array or fp is PoolIntArray or fp is PoolRealArray) and fp.size() > 1):
			flare_vars += "\n" + "position = Vector2( %f , %f )" % [fp[0],fp[1]]
		var fs = data.get("flare_scale",Vector2.ONE)
		if fs is Vector2 or ((fs is Array or fs is PoolIntArray or fs is PoolRealArray) and fs.size() > 1):
			flare_vars += "\n" + "scale = Vector2( %f , %f )" % [fs[0],fs[1]]
		var flare_color:Color = Color(data.get("flare_color","3bafff"))
		flare_vars += "\n" + "color = Color( %f , %f , %f , %f )" % [flare_color.r, flare_color.g, flare_color.b, flare_color.a]
		
		var file:File = File.new()
		
		# Exhaust scene
		var exhaust_path : String = "res://sfx/exhaust.tscn"
		match data.get("exhaust_type",""):
			"regular":
				exhaust_path = "res://sfx/exhaust.tscn"
			"fusion":
				exhaust_path = "res://sfx/exhaust-fusion.tscn"
			_:
				if file.file_exists(cached_exhaust_path):
					exhaust_path = cached_exhaust_path
				else:
					exhaust_path = "res://sfx/exhaust.tscn"
		ext_path_counter += 1
		ext_entries.append(ext_path_entry % [exhaust_path,"PackedScene",ext_path_counter])
		thruster_vars += "\n" + "exhaust = ExtResource( %d )" % ext_path_counter

		# Material
		var material : String = "res://sfx/AddOnly.material"
		if data.get("plume_has_material",true):
			var matpath : String = data.get("plume_material_path",material)
			if file.file_exists(matpath):
				material = matpath
		else:
			material = ""
		if material:
			ext_path_counter += 1
			ext_entries.append(ext_path_entry % [material,"Material",ext_path_counter])
			thruster_vars += "\n" + "material = ExtResource( %d )" % ext_path_counter
		else:
			thruster_vars += "\n" + "material = null"
		
		# Plume texture
		var plume_texture : String = "res://sfx/thrusters.png"
		var plumeTex : String = data.get("plume_texture",plume_texture)
		if ResourceLoader.exists(plumeTex):
			plume_texture = plumeTex
		var plumepath : String = create_compiled_tex(plume_texture,cached_tex_path,"plume")
		
		ext_path_counter += 1
		var plume_ext : String = ext_path_entry % [plumepath,"StreamTexture" if plumepath.get_extension() == "stex" else "Texture",ext_path_counter]
		ext_entries.append(plume_ext)
		thruster_vars += "\n" + "texture = ExtResource( %d )" % ext_path_counter
		
		# Flare texture
		var flare_texture : String = "res://lights/plume.png"
		var flareTex : String = data.get("flare_texture",flare_texture)
		if ResourceLoader.exists(flareTex):
			flare_texture = flareTex
		var flarepath : String = create_compiled_tex(flare_texture,cached_tex_path,"flare")
		
		ext_path_counter += 1
		var flare_ext : String = ext_path_entry % [flarepath,"StreamTexture" if flarepath.ends_with(".stex") else "Texture",ext_path_counter]
		ext_entries.append(flare_ext)
		flare_vars += "\n" + "texture = ExtResource( %d )" % ext_path_counter
		
		# Nozzle handles
		var after_nozzles : Array = Array()
		var before_nozzles : Array = Array()
		var nd : Dictionary = convert_to_nozzle(data.get("nozzle",Dictionary()))
		for i in data.get("extra_nozzles",Array()):
			if i.get("order","after") == "before":
				before_nozzles.append(convert_to_nozzle(i))
			else:
				after_nozzles.append(convert_to_nozzle(i))
		var nozzle_groups:PoolStringArray = PoolStringArray()
		var footer_groups:PoolStringArray = PoolStringArray()
		var node_index:int = 2
		
		var nozzle_scene_path : String = "res://ships/modules/nozzle-conventonal.tscn"
		var nozzle_scene_ext:int = 0
		if before_nozzles or after_nozzles:
			ext_path_counter += 1
			nozzle_scene_ext = ext_path_counter
			ext_entries.append(ext_path_entry % [nozzle_scene_path,"PackedScene",nozzle_scene_ext])
		for n in before_nozzles:
			node_index += 1
			var nozzlename : String = "nozzle_%d" % node_index
			var nz : Array = format_nozzle(n,this_nozzle_header % [nozzlename,node_index,nozzle_scene_ext],nozzlename,ext_path_counter,cached_tex_path,ext_path_entry)
			ext_path_counter = nz[1]
			ext_entries.append_array(nz[2])
			nozzle_groups.append(nz[0])
			footer_groups.append(extra_nozzle_footer % nozzlename)
		
		node_index += 1
		var basenz : Array = format_nozzle(nd,nozzle_header % node_index,"nozzle",ext_path_counter,cached_tex_path,ext_path_entry)
		ext_path_counter = basenz[1]
		ext_entries.append_array(basenz[2])
		nozzle_groups.append(basenz[0])
		footer_groups.append(nozzle_footer)
		
		for n in after_nozzles:
			node_index += 1
			var nozzlename : String = "nozzle_%d" % node_index
			var nz : Array = format_nozzle(n,this_nozzle_header % [nozzlename,node_index,nozzle_scene_ext],nozzlename,ext_path_counter,cached_tex_path,ext_path_entry)
			ext_path_counter = nz[1]
			ext_entries.append_array(nz[2])
			nozzle_groups.append(nz[0])
			footer_groups.append(extra_nozzle_footer % nozzlename)
		
		var nodes_to_add:PoolStringArray = PoolStringArray()
		
		# Extra nodes
		var extra_nodes : Array = data.get("extra_nodes",Array())
		for node in extra_nodes:
			if ResourceLoader.exists(node):
				ext_path_counter += 1
				node_index += 1
				var vm:Node = load(node).instance()
				ext_entries.append(ext_path_entry % [node,"PackedScene",ext_path_counter])
				nodes_to_add.append(this_nozzle_header % [vm.name,node_index,ext_path_counter])
				vm.queue_free()
		
		var header_compile : String = ""
		if ext_entries:
			header_compile = thruster_header % (ext_entries.size() + 3) + ext_entries.join("\n")
		
		return header_compile + thruster_vars + flare_vars + nozzle_groups.join("") + nodes_to_add.join("") + "\n" + footer_groups.join("\n")
	
	static func format_nozzle(nd:Dictionary,header:String,nozzlename:String,current_ext:int,cached_tex_path:String,ext_path_entry:String) -> Array:
		var ext_entries : PoolStringArray = PoolStringArray()
		var nozzle_vars : String = header
		var peakTemperature:int = nd.peak_temperature
		var coolTime:float = nd.cool_time
		var heatTime:float = nd.heat_time
		
		nozzle_vars += "\n" + "coolTime = %f" % coolTime
		nozzle_vars += "\n" + "heatTime = %f" % heatTime
		nozzle_vars += "\n" + "peakTemperature = %f" % peakTemperature
		
		var texture : String = "res://ships/modules/nozzle-cd.png"
		var normal : String = "res://ships/modules/nozzle-n.png"
		var tx : String = nd.texture
		if ResourceLoader.exists(tx):
			texture = tx
		var nx : String = nd.normal
		if ResourceLoader.exists(nx):
			normal = nx
		var texturepath : String = create_compiled_tex(texture,cached_tex_path,"nozzle_texture")
		
		current_ext += 1
		ext_entries.append(ext_path_entry % [texturepath,"StreamTexture" if texturepath.ends_with(".stex") else "Texture",current_ext])
		nozzle_vars += "\n" + "texture = ExtResource( %d )" % current_ext
		
		var normalpath : String = create_compiled_tex(normal,cached_tex_path,"nozzle_normal")
		
		current_ext += 1
		ext_entries.append(ext_path_entry % [normalpath,"StreamTexture" if normalpath.ends_with(".stex") else "Texture",current_ext])
		nozzle_vars += "\n" + "normal_map = ExtResource( %d )" % current_ext
		
		var offset = nd.offset
		if offset is Vector2 or ((offset is Array or offset is PoolIntArray or offset is PoolRealArray) and offset.size() > 1):
			nozzle_vars += "\n" + "offset = Vector2( %f , %f )" % [offset[0],offset[1]]
		
		nozzle_vars += "\n" + "centered = " + ("true" if nd.centered else "false")
		
		nozzle_vars += "\n" + "flip_h = " + ("true" if nd.flip_h else "false")
		
		nozzle_vars += "\n" + "flip_v = " + ("true" if nd.flip_v else "false")
		
		nozzle_vars += "\n" + "hframes = %d" % int(nd.horizontal_frames)
		
		nozzle_vars += "\n" + "vframes = %d" % int(nd.vertical_frames)
		
		nozzle_vars += "\n" + "frame = %d" % int(nd.frame)
		
		var frame_coords = nd.frame_coords
		if frame_coords is Vector2 or ((frame_coords is Array or frame_coords is PoolIntArray or frame_coords is PoolRealArray) and frame_coords.size() > 1):
			nozzle_vars += "\n" + "frame_coords = Vector2( %f , %f )" % [frame_coords[0],frame_coords[1]]
		
		nozzle_vars += "\n" + "region_enabled = %s" % ("true" if nd.region_enabled else "false")
		
		var region_rect = nd.region_rect
		if region_rect is PoolIntArray or region_rect is PoolRealArray or region_rect is Array:
			if region_rect.size() > 3:
				nozzle_vars += "\n" + "region_rect = Rect2( %f , %f , %f , %f )" % [region_rect[0],region_rect[1],region_rect[2],region_rect[3]]
		elif region_rect is Rect2:
			nozzle_vars += "\n" + "region_rect = Rect2( %f , %f , %f , %f )" % [region_rect.position.x,region_rect.position.y,region_rect.size.x,region_rect.size.y]
		
		nozzle_vars += "\n" + "region_filter_clip = " + ("true" if nd.region_filter_clip else "false")
		
		var position = nd.position
		if position is Vector2 or ((position is Array or position is PoolIntArray or position is PoolRealArray) and position.size() > 1):
			nozzle_vars += "\n" + "position = Vector2( %f , %f )" % [position[0],position[1]]
		
		nozzle_vars += "\n" + "rotation = %f" % deg2rad(nd.rotation)
		
		var scale = nd.scale
		if scale is Vector2 or ((scale is Array or scale is PoolIntArray or scale is PoolRealArray) and scale.size() > 1):
			nozzle_vars += "\n" + "scale = Vector2( %f , %f )" % [scale[0],scale[1]]
		
		nozzle_vars += "\n\n[node name=\"heat\" parent=\"%s\" index=\"0\"]" % nozzlename
		
		var heat : String = "res://ships/modules/nozzle-cl.png"
		var heat_normal : String = ""
		var hx : String = nd.heat
		if ResourceLoader.exists(hx):
			heat = hx
		var hn : String = nd.heat_normal
		if ResourceLoader.exists(hn):
			heat_normal = hn
		
		var heattexturepath : String = create_compiled_tex(heat,cached_tex_path,"nozzle_heat")
		
		current_ext += 1
		ext_entries.append(ext_path_entry % [heattexturepath,"StreamTexture" if heattexturepath.get_extension() == "stex" else "Texture",current_ext])
		nozzle_vars += "\n" + "texture = ExtResource( %d )" % current_ext
		if heat_normal:
			var heatnormalpath : String = create_compiled_tex(heat_normal,cached_tex_path,"nozzle_heat_normal")
			current_ext += 1
			ext_entries.append(ext_path_entry % [heatnormalpath,"StreamTexture" if heatnormalpath.get_extension() == "stex" else "Texture",current_ext])
			nozzle_vars += "\n" + "normal_map = ExtResource( %d )" % current_ext
		
		var heat_offset = nd.offset
		if heat_offset is Vector2 or ((heat_offset is Array or heat_offset is PoolIntArray or heat_offset is PoolRealArray) and heat_offset.size() > 1):
			nozzle_vars += "\n" + "offset = Vector2( %f , %f )" % [heat_offset[0],heat_offset[1]]
		
		nozzle_vars += "\n" + "centered = " + ("true" if nd.heat_centered else "false")
		nozzle_vars += "\n" + "flip_h = " + ("true" if nd.heat_flip_h else "false")
		nozzle_vars += "\n" + "flip_v = " + ("true" if nd.heat_flip_v else "false")
		nozzle_vars += "\n" + "hframes = %d" % int(nd.heat_horizontal_frames)
		nozzle_vars += "\n" + "vframes = %d" % int(nd.heat_vertical_frames)
		nozzle_vars += "\n" + "frame = %d" % int(nd.heat_frame)
		
		var heat_frame_coords = nd.heat_frame_coords
		if heat_frame_coords is Vector2 or ((heat_frame_coords is Array or heat_frame_coords is PoolIntArray or heat_frame_coords is PoolRealArray) and heat_frame_coords.size() > 1):
			nozzle_vars += "\n" + "frame_coords = Vector2( %f , %f )" % [heat_frame_coords[0],heat_frame_coords[1]]
		
		nozzle_vars += "\n" + "region_enabled = " + ("true" if nd.heat_region_enabled else "false")
		
		var heat_region_rect = nd.heat_region_rect
		if heat_region_rect is PoolIntArray or heat_region_rect is PoolRealArray or heat_region_rect is Array:
			if heat_region_rect.size() > 3:
				nozzle_vars += "\n" + "region_rect = Rect2( %f , %f , %f , %f )" % [heat_region_rect[0],heat_region_rect[1],heat_region_rect[2],heat_region_rect[3]]
		elif heat_region_rect is Rect2:
			nozzle_vars += "\n" + "region_rect = Rect2( %f , %f , %f , %f )" % [heat_region_rect.position.x,heat_region_rect.position.y,heat_region_rect.size.x,heat_region_rect.size.y]
		
		nozzle_vars += "\n" + "region_filter_clip = " + ("true" if nd.heat_region_filter_clip else "false")
		
		var heat_position = nd.heat_position
		if heat_position is Vector2 or ((heat_position is Array or heat_position is PoolIntArray or heat_position is PoolRealArray) and heat_position.size() > 1):
			nozzle_vars += "\n" + "position = Vector2( %f , %f )" % [heat_position[0],heat_position[1]]
		
		nozzle_vars += "\n" + "rotation = %f" % deg2rad(nd.heat_rotation)
		
		var heat_scale = nd.heat_scale
		if heat_scale is Vector2 or ((heat_scale is Array or heat_scale is PoolIntArray or heat_scale is PoolRealArray) and heat_scale.size() > 1):
			nozzle_vars += "\n" + "scale = Vector2( %f , %f )" % [heat_scale[0],heat_scale[1]]
		
		return [nozzle_vars,current_ext,ext_entries]
	
	
	const nozKeys:PoolStringArray = PoolStringArray()
	static func convert_to_nozzle(noz):
		var nozzle:Dictionary = NOZZLE_TEMPLATE.duplicate(true)
		for i in nozKeys:
			if i in noz and match_array_to_vector_or_rect(nozzle[i],noz[i]):
				nozzle[i] = set_array_to_vector_or_rect(nozzle[i],noz[i])
		return nozzle
	
	static func set_array_to_vector_or_rect(main,setter):
		if setter is PoolIntArray or setter is PoolRealArray or setter is Array:
			if main is Vector2:
				return Vector2(setter[0],setter[1])
			elif main is Vector3:
				return Vector3(setter[0],setter[1],setter[2])
			elif main is Rect2:
				return Rect2(Vector2(setter[0],setter[1]),Vector2(setter[2],setter[3]))
		return setter
	
	static func match_array_to_vector_or_rect(main,setter) -> bool:
		if main is Vector2:
			if setter is PoolIntArray or setter is PoolRealArray or setter is Array:
				if setter.size() > 1:
					return true
			elif setter is Vector2:
				return true
		elif main is Vector3:
			if setter is PoolIntArray or setter is PoolRealArray or setter is Array:
				if setter.size() > 2:
					return true
			elif setter is Vector3:
				return true
		elif main is Rect2:
			if setter is PoolIntArray or setter is PoolRealArray or setter is Array:
				if setter.size() > 3:
					return true
			elif setter is Rect2:
				return true
		return typeof(main) == typeof(setter)
	
	static func make_exhaust_scene(data:Dictionary,sys:String) -> String:
		var exhaust_header : String = "[gd_scene load_steps=3 format=2]\n\n[ext_resource path=\"res://sfx/exhaust.tscn\" type=\"PackedScene\" id=1]\n[ext_resource path=\"%s\" type=\"%s\" id=2]\n\n[sub_resource type=\"CircleShape2D\" id=1]\nradius = %s\n\n[node name=\"exhaust\" instance=ExtResource( 1 )]"
		var exhaust_footer : String = "[node name=\"Sprite\" parent=\".\" index=\"1\"]\ntexture = ExtResource( 2 )"
		
		var light_lag_chance:float = data.get("exhaust_light_lag_chance",0)
		var base_lifetime:float = data.get("exhaust_base_lifetime",0.25)
		var lifetime:float = data.get("exhaust_lifetime",0.25)
		var end_scale:float = data.get("exhaust_end_scale",0.02)
		var self_remove:float = data.get("exhaust_self_remove",0.02)
		var mass:float = data.get("exhaust_mass",0.1)
		var sprite : String = data.get("exhaust_sprite","res://sfx/ball-of-flame.png")
		var sprite_scale = data.get("exhaust_sprite_scale",Vector2(0.5,0.5))
		var radius:float = data.get("exhaust_collider_radius",2.87)
		
		var tex_type : String = ""
		if sprite.get_extension().to_lower() == "png":
			tex_type = "Texture"
		elif sprite.get_extension().to_lower() == "stex":
			tex_type = "StreamTexture"
		else:
			tex_type = "Texture"
			sprite = "res://sfx/ball-of-flame.png"
		
		var exhaust_text : String = exhaust_header % [sprite,tex_type,str(radius)]
		
		exhaust_text += "\nmass = %s" % mass
		exhaust_text += "\nlightLagChance = %s" % light_lag_chance
		exhaust_text += "\nbaseLifetime = %s" % base_lifetime
		exhaust_text += "\nlifetime = %s" % lifetime
		exhaust_text += "\nendScale = %s" % end_scale
		if self_remove:
			exhaust_text += "\nselfRemove = true"
		else:
			exhaust_text += "\nselfRemove = false"
		
		exhaust_text += "\n\n[node name=\"CollisionShape2D\" parent=\".\" index=\"0\"]\nshape = SubResource( 1 )\n\n" + exhaust_footer
		if sprite_scale is Vector2 or ((sprite_scale is Array or sprite_scale is PoolIntArray or sprite_scale is PoolRealArray) and sprite_scale.size() > 1):
			exhaust_text += "\nscale = Vector2(%s,%s)" % [sprite_scale[0],sprite_scale[1]]
		return exhaust_text
	
	func confirm_equipment(equipment_node:Dictionary, slot_type, slot_alignment:String, slot_restriction:String, slot_allowed_equipment:PoolStringArray) -> bool:
		if equipment_node.get("system","") in vanilla_data.min_version:
			var data : Array = vanilla_data.min_version.get(equipment_node.system)
			var failtext : String = "Equipment %s not adding due to old game version. Needed min version: %s ; observed game version: %d.%d.%d" % [str(equipment_node.get("system","")), str(data), VANILLA_VERSION[0], VANILLA_VERSION[1], VANILLA_VERSION[2]]
			if data[0] < VANILLA_VERSION[0]:
				pass
			elif data[0] == VANILLA_VERSION[0]:
				if data[1] < VANILLA_VERSION[1]:
					pass
				elif data[1] == VANILLA_VERSION[1]:
					if data[2] <= VANILLA_VERSION[2]:
						pass
					else:
						pointers.l(failtext,log_header)
						return false
				else:
					pointers.l(failtext,log_header)
					return false
			else:
				pointers.l(failtext,log_header)
				return false
		
		
		if equipment_node.get("slot_type","") == slot_type:
			var passes_slot_check:bool = false
			if equipment_node.get("equipment_type","") in slot_allowed_equipment:
				var e_alignment : String = equipment_node.get("alignment","")
				if slot_type is String:
					if slot_type == "HARDPOINT":
						if slot_alignment in alignments:
							if e_alignment in alignments:
								if e_alignment == slot_alignment:
									passes_slot_check = true
								else:
									return false
							else:
								passes_slot_check = true
						else:
							passes_slot_check = true
					else:
						passes_slot_check = true
				elif slot_type is Array or slot_type is PoolStringArray:
					for s in slot_type:
						if s == "HARDPOINT":
							if slot_alignment in alignments:
								if e_alignment in alignments:
									if e_alignment == slot_alignment:
										passes_slot_check = true
									else:
										return false
								else:
									passes_slot_check = true
							else:
								passes_slot_check = true
						else:
							passes_slot_check = true
				else:
					passes_slot_check = false
			else:
				return false
			if passes_slot_check:
				if slot_restriction:
					var e_restriction : String = equipment_node.get("restriction","")
					if e_restriction:
						if e_restriction == slot_restriction:
							return true
					else:
						return true
				else:
					return true
		return false
	
	func __make_equipment_for_scene(equipment_data: Dictionary, slot_node_name : String, system_slot: String) -> String:
		var num_val:int = equipment_data.get("num_val", -1)
		var system : String = equipment_data.get("system", "")
		var capability_lock:bool = equipment_data.get("capability_lock", false)
		var name_override : String = equipment_data.get("name_override", "")
		var description : String = equipment_data.get("description", "")
		var manual : String = equipment_data.get("manual", "")
		var specs : String = equipment_data.get("specs", "")
		var price:int = equipment_data.get("price", 0)
		var test_protocol : String = equipment_data.get("test_protocol", "fire")
		var default:bool = equipment_data.get("default", false)
		var control : String = equipment_data.get("control", "")
		var story_flag : String = equipment_data.get("story_flag", "")
		var story_flag_min:int = equipment_data.get("story_flag_min", -1)
		var story_flag_max:int = equipment_data.get("story_flag_max", -1)
		var warn_if_thermal_below:float = equipment_data.get("warn_if_thermal_below", 0)
		var warn_if_electric_below:float = equipment_data.get("warn_if_electric_below", 0)
		var sticker_price_format : String = equipment_data.get("sticker_price_format", "%s E$")
		var sticker_price_multi_format : String = equipment_data.get("sticker_price_multi_format", "%s E$ (x%d)")
		var installed_color:Color = equipment_data.get("installed_color", Color.green)
		var disabled_color:Color = equipment_data.get("disabled_color", Color(0.2, 0.2, 0.2, 1.0))
		var normal_color:Color = equipment_data.get("normal_color", Color.white)
		
		var cfg : Dictionary = equipment_data.get("config",Dictionary())
		
		var base : String = "[node name=\"%s\" parent=\"VB/MarginContainer/ScrollContainer/MarginContainer/Items/%s/VBoxContainer\" instance=ExtResource( 3 )]" % [system.to_upper(),slot_node_name]
		if num_val > -1:
			base += "\nnumVal = %d" % num_val
		base += "\nslot = \"%s\"" % system_slot
		if system:
			base += "\nsystem = \"%s\"" % system
		if capability_lock:
			base += "\ncapabilityLock = true"
		if name_override:
			base += "\nnameOverride = \"%s\"" % name_override
		if description:
			base += "\ndescription = \"%s\"" % description
		if manual:
			base += "\nmanual = \"%s\"" % manual
		if specs:
			base += "\nspecs = \"%s\"" % specs
		if price > 0:
			base += "\nprice = %d" % price
		if test_protocol && test_protocol != "fire":
			base += "\ntestProtocol = \"%s\"" % test_protocol
		if default:
			base += "\ndefault = true"
		if control:
			base += "\ncontrol = \"%s\"" % control
		if story_flag:
			base += "\nstoryFlag = \"%s\"" % story_flag
		if story_flag_min > -1:
			base += "\nstoryFlagMin = %d" % story_flag_min
		if story_flag_max > -1:
			base += "\nstoryFlagMax = %d" % story_flag_max
		if warn_if_thermal_below > 0:
			base += "\nwarnIfThermalBelow = %0.1f" % warn_if_thermal_below
		if warn_if_electric_below > 0:
			base += "\nwarnIfElectricBelow = %0.1f" % warn_if_thermal_below
		if sticker_price_format != "%s E$":
			base += "\nstickerPriceFormat = \"%s\"" % sticker_price_format
		if sticker_price_multi_format != "%s E$ (x%d)":
			base += "\nstickerPriceMultiFormat = \"%s\"" % sticker_price_multi_format
		if installed_color != Color.green:
			base += "\ninstalledColor = Color( %f, %f, %f, %f )" % [installed_color.r,installed_color.g,installed_color.b,installed_color.a]
		if disabled_color != Color(0.2, 0.2, 0.2, 1.0):
			base += "\ndisabledColor = Color( %f, %f, %f, %f )" % [disabled_color.r,disabled_color.g,disabled_color.b,disabled_color.a]
		
		if cfg:
			var cfg_id : String = cfg.get("id","")
			var cfg_section : String = cfg.get("section","")
			var cfg_setting : String = cfg.get("entry","")
			var cfg_invert:bool = cfg.get("invert_config",false)
			base += "\nconfig_id = \"%s\"" % cfg_id
			base += "\nconfig_section = \"%s\"" % cfg_section
			base += "\nconfig_setting = \"%s\"" % cfg_setting
			if cfg_invert:
				base += "\ninvert_config = true"
			else:
				base += "\ninvert_config = false"
		if normal_color != Color.white:
			base += "[node name=\"System\" parent=\"HBox\" index=\"0\"]\nmodulate = Color( %f, %f, %f, %f )" % [normal_color.r,normal_color.g,normal_color.b,normal_color.a]
		return base
	
	func __make_slot_for_scene(slot_data: Dictionary) -> Array:
		var systemSlot : String = slot_data.get("system_slot", "")
		var slotNodeName : String = slot_data.get("slot_node_name", "MISSING_SLOT_NAME")
		var slotDisplayName : String = slot_data.get("slot_display_name", "SLOT_MISSING_DATA")
		var hasNone:bool = slot_data.get("has_none", true)
		var alwaysDisplay:bool = slot_data.get("always_display", true)
		var restrictType : String = slot_data.get("restrict_type", "")
		var openByDefault:bool = slot_data.get("open_by_default", false)
		var limitShips : PoolStringArray = PoolStringArray(slot_data.get("limit_ships", Array()))
		var preventShips : PoolStringArray = PoolStringArray(slot_data.get("prevent_ships", Array()))
		var add_vanilla_equipment:bool = slot_data.get("add_vanilla_equipment", true)
		var hardpoint_type : String = slot_data.get("hardpoint_type","")
		var alignment : String = slot_data.get("alignment","")
		var restriction : String = slot_data.get("restriction","")
		var override_additive : PoolStringArray = PoolStringArray(slot_data.get("override_additive",PoolStringArray()))
		var override_subtractive : PoolStringArray = PoolStringArray(slot_data.get("override_subtractive",PoolStringArray()))
		var restrict_hold_type : String = slot_data.get("restrict_hold_type","")
		var story_flag : String = slot_data.get("story_flag","")
		
		var cfg : Dictionary = slot_data.get("config",Dictionary())
		
		var base : String = "[node name=\"%s\" parent=\"VB/MarginContainer/ScrollContainer/MarginContainer/Items\" instance=ExtResource( 2 )]" % slotNodeName
		if systemSlot:
			base += "\nslot = \"%s\"" % systemSlot
		if alwaysDisplay:
			base += "\nalways = true"
		else:
			base += "\nalways = false"
		if openByDefault:
			base += "\nopenByDefault = true"
		else:
			base += "\nopenByDefault = false"
		if cfg:
			var cfg_id : String = cfg.get("id","")
			var cfg_section : String = cfg.get("section","")
			var cfg_setting : String = cfg.get("entry","")
			var cfg_invert:bool = cfg.get("invert_config",false)
			base += "\nconfig_id = \"%s\"" % cfg_id
			base += "\nconfig_section = \"%s\"" % cfg_section
			base += "\nconfig_setting = \"%s\"" % cfg_setting
			if cfg_invert:
				base += "\ninvert_config = true"
			else:
				base += "\ninvert_config = false"
		if restrictType:
			base += "\nrestrictType = \"%s\"" % restrictType
		if limitShips:
			base += "\nlimit_ships = [\"%s\"]" % "\",\"".join(limitShips)
		if preventShips:
			base += "\nprevent_ships = [\"%s\"]" % "\",\"".join(preventShips)
		
		if restrict_hold_type:
			base += "\nrestrict_hold_type = \"%s\"" % restrict_hold_type
		if story_flag:
			base += "\nstory_flag = \"\"%s\"" % story_flag
			var story_flag_min : int = slot_data.get("story_flag_min",-1)
			var story_flag_max : int = slot_data.get("story_flag_max",-1)
			if story_flag_min > -1:
				base += "\nstory_flag_min = %d" % story_flag_min
			if story_flag_max > -1:
				base += "\nstory_flag_max = %d" % story_flag_max
		
		base += "\n\n[node name=\"CheckButton\" parent=\"VB/MarginContainer/ScrollContainer/MarginContainer/Items/%s/VBoxContainer/HBoxContainer\"]\ntext = \"%s\"" % [slotNodeName,slotDisplayName]
		
		if hasNone: base += "\n\n" + __make_equipment_for_scene({"system":"SYSTEM_NONE","default":true,"name":"None"}, slotNodeName, systemSlot)
		var editable_path : String = "[editable path=\"VB/MarginContainer/ScrollContainer/MarginContainer/Items/%s\"]" % slotNodeName
		var dict : Dictionary = {
				"add_vanilla_equipment":add_vanilla_equipment,
				"hardpoint_type":hardpoint_type,
				"alignment":alignment,
				"restriction":restriction,
				"override_additive":override_additive,
				"override_subtractive":override_subtractive,
			}
		
		return [base, editable_path, dict]
	
	func __post_load_handling():
		pointers.Threading.__request_multiple_threads(thruster_data_to_write)
		write_rpc_sensor_items()

class _Events:
	const non_static = Dictionary()
	func _init(p):
		non_static["pointers"] = p
	
	const log_header = "pointers.EventDriver"
	
	const busy = [false,null]
	static func __spawn_event(event : String,ring : Node,parameters : Dictionary = Dictionary(),delay_seconds = 0.0):
		if not busy[0]:
			var pointers:HevLibPointers = non_static["pointers"]
			if (not ring) or (not ring.has_method("hl_thering_UV")):
				pointers.l("No ring object specified, returning",log_header)
				return
			if delay_seconds > 0.0:
				pointers.l("Delaying event spawn by %0.1f seconds" % delay_seconds,log_header)
				yield(CurrentGame.get_tree().create_timer(delay_seconds),"timeout")
			if parameters.get("legacy",false):
				busy[0] = true
				var counter = ring.oddityCounter
				ring.oddityCounter = 0x0FFFFFFF
				ring.testSpecificStoryElement = event
				yield(pointers,"process_tick")
				yield(pointers,"process_tick")
				ring.testSpecificStoryElement = ""
				ring.oddityCounter = counter
			elif parameters.get("inject",false):
				var focusObject = CurrentGame.getPlayerShip()
				if focusObject and focusObject.zone == "rings":
					var tree:SceneTree = ring.get_tree()
					var event_node = ring.get_node_or_null(event)
					if event_node and event_node.has_method("canBeAt") and event_node.has_method("makeAt"):
						var pos:Vector2 = getPos(parameters)
						event_node.canBeAt(pos)
						var oddity = event_node.makeAt(pos)
						if oddity and ring.has_method("request_event"):
							ring.request_event(oddity, event)
							pointers.n("injecting oddity %s" % event,"pointers.EventDriver")
				busy[1] = focusObject
			else:
				var focusObject = CurrentGame.getPlayerShip()
				busy[1] = focusObject
				if focusObject and focusObject.zone == "rings":
					var tree = ring.get_tree()
					var event_node = ring.get_node_or_null(event)
					if event_node and event_node.has_method("canBeAt") and event_node.has_method("makeAt"):
						var pos:Vector2 = getPos(parameters)
						event_node.canBeAt(pos)
						var oddity = event_node.makeAt(pos)
						var randomOddityKey:String = ""
						if oddity:
							ring.addNearbyOddity(event, oddity, pos)
							if oddity is Array:
								for o in oddity:
									o.connect("tree_entered", ring, "forcedOddityConfirmed", [randomOddityKey])
							else:
								oddity.connect("tree_entered", ring, "forcedOddityConfirmed", [randomOddityKey])
							ring.unspawnedOddities[randomOddityKey] = oddity
							ring.unspawnedOdditiesLocation[randomOddityKey] = pos
							pointers.n("force spawning oddity %s" % event,log_header)
			
			busy[0] = false
	
	static func __clear_event(event : String, ring, clear_related_poi : bool = true,clear_in_cargo : bool = false,delay_seconds : float = 0.0):
		var pointers:HevLibPointers = non_static["pointers"]
		pointers.n("clearing oddities %s" % event,log_header)
		if (not ring) or (not ring.has_method("hl_thering_UV")):
			pointers.l("No ring object specified, returning",log_header)
			return
		if delay_seconds > 0.0:
			pointers.l("Delaying event clear by %0.1f seconds" % delay_seconds,log_header)
			yield(CurrentGame.get_tree().create_timer(delay_seconds),"timeout")
		if !event or event == "none":
			var events = ring.all_oddities
			for e in events:
				if Tool.claim(e):
					if e.is_node_ready() and clear_if_cargo(e,clear_in_cargo):
						ring.all_oddities.erase(e)
						Tool.release(e)
						Tool.remove(e)
		
		elif event in ring.group:
			var events = ring.group[event]
			if events:
				for e in events:
					if Tool.claim(e):
						if e.is_node_ready() and clear_if_cargo(e,clear_in_cargo):
							if clear_related_poi:
								clear_poi_for(e.global_position,event)
							ring.group[event].erase(e)
							Tool.release(e)
							Tool.remove(e)
	
	static func getPos(params : Dictionary):
		var x_direction:float = clamp(params.get("x_direction",rand_range( - 1, 1)),-1,1)
		var y_direction:float = clamp(params.get("y_direction",rand_range( - 1, 1)),-1,1)
		var spawnDirectionScale:float = params.get("spawn_direction_scale",0.75)
		var odditySpawnRadiusMin:float = params.get("oddity_spawn_radius_min",24000)
		var odditySpawnRadiusMinCutscene:float = params.get("oddity_spawn_radius_min_cutscene",6000)
		var odditySpawnRadiusMax:float = params.get("oddity_spawn_radius_max",38000)
		var odditySpawnRadiusSafemax:float = params.get("oddity_spawn_radius_safe_max",80000)
		var odditySpawnFailures:float = params.get("oddity_spawn_failures",0)
		var odditySpawnRadiusSafemaxSteps:float = params.get("oddity_spawn_radius_safe_max_steps",40)
		var focusObject = busy[1]
		if Tool.claim(focusObject):
			var cutscene:bool = ("cutscene" in focusObject and focusObject.cutscene) and ("fastTravelDirection" in focusObject and focusObject.fastTravelDirection < 0)
			var focusPoint:Vector2 = focusObject.global_position
			var randomVector:Vector2 = Vector2(x_direction,y_direction).normalized()
			var directionVector:Vector2 = focusObject.linear_velocity.normalized() * spawnDirectionScale
			var dirvec:Vector2 = (randomVector + directionVector).normalized()
			if dirvec.length() < 0.9:
				dirvec = randomVector
			var failBasedMax:float = clamp(float(odditySpawnFailures) / float(odditySpawnRadiusSafemaxSteps), 0, 1)
			var oRangeMax:float = lerp(odditySpawnRadiusMax, odditySpawnRadiusSafemax, failBasedMax)
			var oddityFocusOffset:Vector2 = dirvec * rand_range(odditySpawnRadiusMin if not cutscene else odditySpawnRadiusMinCutscene, lerp(odditySpawnRadiusMax, odditySpawnRadiusSafemax, clamp(float(odditySpawnFailures) / float(odditySpawnRadiusSafemaxSteps), 0, 1)))
			
			var oddityPoint:Vector2 = focusPoint + oddityFocusOffset
			Tool.release(focusObject)
			return CurrentGame.globalCoords(oddityPoint)
	
	static func clear_if_cargo(object,do):
		if not do:
			var focus = CurrentGame.getPlayerShip()
			if object in focus.cargo:
				return false
		return true
	
	static func clear_poi_for(globalPos : Vector2,this_event: String):
		var nearby = CurrentGame.getEventNear(CurrentGame.globalCoords(globalPos))
		while nearby and nearby.event == this_event:
			var astro = CurrentGame.state.astrogation
			for event in astro:
				var ev = astro[event]
				if ev.event == nearby.event and Vector2(ev.vector.x,ev.vector.y).distance_to(nearby.vector) < 2000:
					CurrentGame.forgetPoi(event)
			nearby = CurrentGame.getEventNear(CurrentGame.globalCoords(globalPos))

class _FileAccess:
	const non_static = Dictionary()
	func _init(f):
		non_static["pointers"] = f
	
	const log_header = "pointers.FileAccess"
	
	static func __get_file_content(file_path: String) -> String:
		var file:File = File.new()
		file.open(file_path, File.READ)
		var s : String = file.get_as_text(true)
		file.close()
		return s
	
	static func __save_file_content(file_path: String,data:String):
		var file:File = File.new()
		file.open(file_path, File.WRITE)
		file.store_string(data)
		file.close()
	
	static func __store_default_if_file_missing(file_path: String,data:String) -> bool:
		if not File.new().file_exists(file_path):
			__save_file_content(file_path,data)
			return false
		return true
	
	static func __copy_file(file_path : String, folder : String):
		var prepfile : String = ProjectSettings.localize_path(file_path)
		return Directory.new().copy(prepfile,folder + "/" + prepfile.split("/")[-1])
	
	
	
	static func __load_png(path,fallback:Image = null) -> Texture:
		if not __file_exists(path):
			if fallback != null and fallback.get_data():
				var imgtex:ImageTexture = ImageTexture.new()
				imgtex.create_from_image(fallback)
				return imgtex
			else:
				return ImageTexture.new()
		var file:File = File.new()
		file.open(path, File.READ)
		var header:PoolByteArray = file.get_buffer(12)
		file.seek(0)
		if header.subarray(0,3) == STEX_HEADER:
			file.close()
			var stex:StreamTexture = StreamTexture.new()
			stex.load_path = path
			return stex
		else:
			var img:Image = Image.new()
			var loaded:bool = false
			if header.subarray(0,7) == PNG_HEADER:
				loaded = img.load_png_from_buffer(file.get_buffer(file.get_len())) == OK
			elif header.subarray(0,3) in JPG_HEADERS:
				loaded = img.load_jpg_from_buffer(file.get_buffer(file.get_len())) == OK
			elif header.subarray(0,1) == BMP_HEADER:
				loaded = img.load_bmp_from_buffer(file.get_buffer(file.get_len())) == OK
			elif header.subarray(0,3) == WEBP_HEADERS[0] and header.subarray(8,11) == WEBP_HEADERS[1]:
				loaded = img.load_webp_from_buffer(file.get_buffer(file.get_len())) == OK
			file.close()
			if not loaded:
				if fallback != null and fallback.get_data(): img = fallback
				else: return ImageTexture.new()
			var imgtex:ImageTexture = ImageTexture.new()
			imgtex.create_from_image(img)
			return imgtex
	
	
	
	static func __precache_mod_file(filepath:String):
		var file:File = File.new()
		filepath = ProjectSettings.localize_path(filepath)
		if file.file_exists(filepath):
			if filepath.get_base_dir() != MOD_CACHE_PATH:
				if __copy_file(filepath,MOD_CACHE_PATH):
					return
				filepath = MOD_CACHE_PATH + "/" + filepath.get_file()
			file.open(UPDATE_CACHE_FILE_PATH,File.READ)
			var cache : Array = JSON.parse(file.get_as_text()).result
			file.close()
			if not filepath in cache: cache.append(filepath)
			file.open(UPDATE_CACHE_FILE_PATH,File.WRITE)
			file.store_string(JSON.print(cache))
			file.close()
			non_static["pointers"].has_updated = true
	
	static func __load_precached_mods() -> bool:
		var gameInstallDirectory:String = OS.get_executable_path().get_base_dir()
		if OS.get_name() == "OSX":
			gameInstallDirectory = gameInstallDirectory.get_base_dir().get_base_dir().get_base_dir()
		var modPathPrefix:String = gameInstallDirectory + "/mods"
		var file:File = File.new()
		if file.file_exists(UPDATE_CACHE_FILE_PATH):
			var files_to_copy : PoolStringArray = PoolStringArray(JSON.parse(__get_file_content(UPDATE_CACHE_FILE_PATH)).result)
			file.open(UPDATE_CACHE_FILE_PATH,File.WRITE)
			file.store_string("[]")
			file.close()
			if files_to_copy:
				print(FOUND_PRECACHED_MODS_LOG)
				var pointers:HevLibPointers = non_static["pointers"]
				pointers.l(FOUND_PRECACHED_MODS_LOG,log_header)
				for mod in files_to_copy:
					if file.file_exists(mod) and __copy_file(mod,modPathPrefix) == OK:
						var newmodmsg:String = "copied new mod %s" % mod.get_file()
						print(newmodmsg)
						pointers.l(newmodmsg,log_header)
				print(PRECACHED_MODS_REBOOT_LOG)
				pointers.NodeAccess.__exit(true,PRECACHED_MODS_REBOOT_LOG,log_header)
				return true
		else:
			file.open(UPDATE_CACHE_FILE_PATH,File.WRITE)
			file.store_string("[]")
			file.close()
		return false
	
	
	static func __get_uid_of_file(file_path:String) -> String:
		if not __file_exists(file_path):
			return ""
		var file:File = File.new()
		file.open(file_path,File.READ)
		var num:int = non_static["pointers"].DataFormat.__get_crc_32(file.get_buffer(file.get_len()))
		file.close()
		return (PoolByteArray([(num>>16)&0xFF,(num>>24)&0xFF,(num)&0xFF,(num>>8)&0xFF]).hex_encode() + ProjectSettings.localize_path(file_path)).sha256_text()
	
	# Code sourced from lifelike's Godot Animator Import plugin
	# https://github.com/lifelike/godot-animator-import
	static func __save_stex(image:Image, file_path:String, flags:int=0):
		var out_path:String = "%s.stex" % file_path.get_basename()
		var tmppng:String = "%s-tmp.png" % file_path
		image.save_png(tmppng)
		var file:File = File.new()
		file.open(tmppng, File.READ)
		var pnglen:int = file.get_len()
		var pngdata:PoolByteArray = file.get_buffer(pnglen)
		file.close()
		Directory.new().remove(tmppng)
		if file.open(out_path, File.WRITE) == OK:
			file.store_8(0x47) # G
			file.store_8(0x44) # D
			file.store_8(0x53) # S
			file.store_8(0x54) # T
			file.store_32(image.get_width())
			file.store_32(image.get_height())
			file.store_32(flags)
			file.store_32(0x07100000) # data format
			file.store_32(1) # nr mipmaps
			file.store_32(pnglen + 6)
			file.store_8(0x50) # P
			file.store_8(0x4e) # N
			file.store_8(0x47) # G
			file.store_8(0x20) # space
			file.store_buffer(pngdata)
			file.close()
			return out_path
		else:
			return ""
	
	static func __file_output_to_buffer(content) -> PoolByteArray:
		if content is String:
			return content.to_utf8()
		elif content is PoolStringArray:
			return content
		non_static["pointers"].l("ERROR: content must be a String or PoolByteArray to be converted to buffer, is of type %d" % typeof(content),log_header)
		return PoolByteArray()
	
	static func __file_exists(file_path:String) -> bool:
		file_path = ProjectSettings.localize_path(file_path)
		return (ResourceLoader.exists(file_path) or File.new().file_exists(file_path))
	
	static func __get_real_filename_from_compiled_resource(file_path:String) -> String:
		match file_path.get_extension():
			"res": return file_path.get_basename().get_basename()
			"gdc": return file_path.get_basename() + ".gd"
		return file_path
	
	
	
	static func __get_dependancies_for_file(file_path:String,deep_search:bool = false) -> PoolStringArray:
		var dependencies:PoolStringArray = ResourceLoader.get_dependencies(file_path)
		if deep_search and file_path.get_extension() in FILE_EXT_FOR_DEEP_DEP_SEARCH:
			var nfp:String = file_path
			if not non_static["pointers"].is_editor:
				if file_path.get_extension().to_lower() == "gd":
					nfp = file_path.get_basename() + ".gdc"
				else:
					nfp += ".converted.res"
			var file:File = File.new()
			file.open(nfp,File.READ)
			var fileBytes:PoolByteArray = file.get_buffer(file.get_len())
			file.close()
			var bytecodeStr:String = fileBytes.hex_encode()
			if RES_HEX_ENCODED in bytecodeStr:
				var hexArray:PoolStringArray = bytecodeStr.split(RES_HEX_ENCODED)
				var buffer:int = 0
				for idx in hexArray.size():
					var hexText:String = hexArray[idx]
					if idx > 0:
						hexText = RES_HEX_ENCODED + hexText
						var fn:String = fileBytes.subarray(buffer, buffer + hexText.length()/2.0 - 1).get_string_from_ascii().split("\"")[0]
						if not fn in dependencies:
							match fn.get_extension():
								"res":dependencies.append(fn.get_basename().get_basename())
								"gdc":dependencies.append(fn.get_basename() + ".gd")
								_:dependencies.append(fn.strip_edges())
					buffer += hexText.length() / 2.0
		return dependencies

class _FolderAccess:
	const non_static = Dictionary()
	func _init(p):
		non_static["pointers"] = p
		non_static["self"] = self
	
	static func __check_folder_exists(folder: String, status_array: bool = false):
		var value:bool = false
		var exists:bool = false
		var directory:Directory = Directory.new()
		if directory.dir_exists(folder):
			value = true
			exists = true
		else:
			exists = false
			value = directory.make_dir_recursive(folder) == OK
		if status_array: return [value,exists]
		return value
	
	static func __recursive_delete(path: String, excluded_files:PoolStringArray = PoolStringArray()) -> bool:
		var directory:Directory = Directory.new()
		if not directory.open(path) == OK: return false
		if not path.ends_with("/"):path += "/"
		var filesForDeletion : Array = Array()
		var foldersForDeletion : Array = Array()
		for entry in PoolStringArray(__fetch_folder_files(path, true, true)):
			if entry.ends_with("/"):
				if not entry.split("/",false)[-1] + "/" in excluded_files:
					foldersForDeletion.append(entry)
			else:
				if not entry.get_file() in excluded_files:
					filesForDeletion.append(entry)
		for f in filesForDeletion:
			directory.remove(f.split("/")[-1])
		for folder in foldersForDeletion:
			__recursive_delete(folder,excluded_files)
		directory.remove(path)
		return true
	
	static func __fetch_folder_files(folder: String, showFolders: bool = false, returnFullPath: bool = false,globalizePath: bool = false) -> Array:
		var fileList : PoolStringArray = PoolStringArray()
		if not folder.ends_with("/"):
			folder += "/"
		var directory:Directory = Directory.new()
		if not directory.dir_exists(folder) or (directory.open(folder) + directory.list_dir_begin(true)):
			return Array()
		while true:
			var fileName : String = directory.get_next()
			if not (fileName.ends_with("/") or fileName == "." or fileName == ".."):
				if not fileName: break
				if directory.current_is_dir():
					if not showFolders: continue
					fileName += "/"
				if returnFullPath:
					fileName = folder + fileName
				if globalizePath:
					fileList.append(ProjectSettings.globalize_path(fileName))
				else:
					fileList.append(fileName)
		return Array(fileList)
	
	static func __get_first_file(folder: String) -> String:
		var fileList : Array = __fetch_folder_files(folder)
		if fileList: return fileList[0]
		else: return ""
	
	const folderStructureCache : Dictionary = Dictionary()
	
	static func __get_folder_structure(folder : String,store_file_content : bool = false, recache : bool = true):
		if (not folder in folderStructureCache) or recache:
			var folder_structure : Dictionary = Dictionary()
			var files : Array = __fetch_folder_files(folder,true,false)
			var treeSearchWithThreads:Array = Array()
			for object in files:
				if object.ends_with("/"):
#					folder_structure[object] = __get_folder_structure(folder+object,store_file_content)
					treeSearchWithThreads.append({
						"object":non_static["self"],
						"method":"gfs",
						"args":[folder+object,store_file_content]
					})
				else:
					if store_file_content:
						var file:File = File.new()
						file.open(folder + object,File.READ)
						folder_structure[object] = file.get_buffer(file.get_len())
						file.close()
					else:
						folder_structure[object] = "FILE"
			for f in non_static["pointers"].Threading.__request_multiple_threads(treeSearchWithThreads):
				folder_structure[f[1].split("/",false)[-1] + "/"] = f[0]
			folderStructureCache[folder] = folder_structure
		return folderStructureCache[folder].duplicate(true)
	
	static func gfs(folder:String,store_file_content:bool) -> Array:
		var folder_structure : Dictionary = Dictionary()
		var files : Array = __fetch_folder_files(folder,true,false)
		for object in files:
			if object.ends_with("/"):
				folder_structure[object] = gfs(folder+object,store_file_content)[0]
			else:
				if store_file_content:
					var file:File = File.new()
					file.open(folder + object,File.READ)
					folder_structure[object] = file.get_buffer(file.get_len())
					file.close()
				else:
					folder_structure[object] = "FILE"
		return [folder_structure,folder]
	
	static func __get_files_with_extensions(folder:String,extensions:PoolStringArray,recurse_depth:int = -1) -> Array:
		var directory:Directory = Directory.new()
		if not directory.dir_exists(folder):
			return Array()
		var out = PoolStringArray()
		var dir = __fetch_folder_files(folder,true,true)
		for f in dir:
			if recurse_depth != 0 and f.ends_with("/"):
				out.append_array(__get_files_with_extensions(f,extensions,recurse_depth - 1))
			else:
				var ext = f.get_extension()
				if ext in extensions:
					out.append(f)
		return Array(out)
	
	static func __get_vanilla_script_and_scenes() -> PoolStringArray:
		var findExt:PoolStringArray = PoolStringArray(["res","gdc"])
		var pointers:HevLibPointers = non_static["pointers"]
		var file:File = File.new()
		var gameInstallDirectory = OS.get_executable_path().get_basename() + ".pck"
		if pointers.is_editor:
			var cfg:ConfigFile = ConfigFile.new()
			cfg.load("user://cfg/Mod_Configurations.cfg")
			var pckPath:String = cfg.get_value("HevLib/HEVLIB_CONFIG_SECTION_DEBUG","pck_path_for_editor_testing","")
			if not file.file_exists(pckPath):
				var out:PoolStringArray = PoolStringArray()
				for i in __get_files_with_extensions("res://.autoconverted/",findExt):
					var fp = i.replace("/.autoconverted/","/")
					match fp.get_extension():
						"res":
							if fp.get_basename().get_extension() == "converted":
								fp = (fp.get_basename().get_basename())
						"gdc":
							fp = fp.get_basename() + ".gd"
					if ResourceLoader.exists(fp):
						out.append(fp)
				return out
			gameInstallDirectory = pckPath
		if file.file_exists(gameInstallDirectory):
			var out:PoolStringArray = PoolStringArray()
			for fp in pointers.Zip.__load_pck(gameInstallDirectory,true):
				match fp.get_extension():
					"res":
						if fp.get_basename().get_extension() == "converted":
							fp = (fp.get_basename().get_basename())
					"gdc":
						fp = fp.get_basename() + ".gd"
				if ResourceLoader.exists(fp):
					out.append(fp)
			return out
		else:
			pointers.NodeAccess.__exit(false,"CRITICAL ERROR! Cannot find the game's .PCK file, and is a likely indicator that your game is corrupted.\n\nPlease validate your game files. If this issue persists, please make a bug report at [https://forms.gle/RmC4Zgonp6frFgnK7] so this issue can be fixed as soon as possible.","pointers.FolderAccess",0.0,"",true)
			return PoolStringArray()

class _Github:
	const non_static = Dictionary()
	func _init(p):
		non_static["pointers"] = p
	
	const log_header = "pointers.Github"
	
	static func __get_github_filesystem(URL: String, node_to_return_to: Node, behaviour: String = "normal", special_behaviour_data = ""):
		var CRoot:Viewport = Tool.get_tree().get_root()
		var gitHubFS:Node = load("res://HevLib/scenes/fetch_from_github/fs/FetchGithubData.tscn").instance()
		gitHubFS.URL = URL
		gitHubFS.ActOnModData = behaviour
		gitHubFS.mod_version = special_behaviour_data
		gitHubFS.nodeToReturnTo = node_to_return_to
		gitHubFS.name = "git_filesystem_%d" % ((randi() % 32767) + 1)
		CRoot.call_deferred("add_child",gitHubFS)
	
	static func __get_github_release(URL: String, folder: String, node_to_return_to: Node, get_pre_releases: bool = false, file_preference: String = "any", file_to_download: String = "first"):
		var cancel:bool = false
		var pointers:HevLibPointers = non_static["pointers"]
		if node_to_return_to == null or (not node_to_return_to is Node):
			cancel = true
			var e : String = "Release Downloader ERROR! Provided node [%s] either does not exist or is not of [Node] type." % str(node_to_return_to)
			pointers.l(e,log_header)
			printerr(e)
		if not node_to_return_to.has_method("_downloaded_zip"):
			cancel = true
			var e : String = "Release Downloader ERROR! Provided node [%s] does not have the method [_downloaded_zip]" % str(node_to_return_to)
			pointers.l(e,log_header)
			printerr(e)
		if cancel: return
		var CRoot = Tool.get_tree().get_root()
		var gitHubFS :Node= load("res://HevLib/scenes/fetch_from_github/releases/NetHandles.tscn").instance()
		if not node_to_return_to.has_method("_get_github_progress"):
			gitHubFS.state_progress = false
			pointers.l("Release Downloader NOTICE! Provided node [%s] does not have the method [_get_github_progress]. No download progress will be reported." % str(node_to_return_to),log_header)
		gitHubFS.releases_URL = URL
		gitHubFS.folder = folder
		gitHubFS.get_pre_releases = get_pre_releases
		gitHubFS.file_preference = file_preference
		gitHubFS.file_to_download = file_to_download
		gitHubFS.nodeToReturnTo = node_to_return_to
		gitHubFS.name = "git_release_%d" % ((randi() % 32767) + 1)
		CRoot.call_deferred("add_child",gitHubFS)

class _HevLib:
	var pointers:HevLibPointers
	func _init(f):
		pointers = f
	
	func __get_lib_variables():
		return {"AchievementData":Dictionary(),"AchievementPercentageStats":Dictionary()}
	
	func __get_lib_pointers(return_as_full_path: bool = false) -> Array:
		var path = "res://HevLib/pointers/"
		var files = pointers.FolderAccess.__fetch_folder_files(path)
		if return_as_full_path:
			var compileArray = Array()
			for f in files:
				compileArray.append(path + f)
			return compileArray
		else:return files
	
	func __get_pointer_functions(pointer: String, return_JSON: bool = false):
		var path = "res://HevLib/pointers/"
		var actualPointer = path + pointer.split("/")[- 1]
		var pointerLoad = load(actualPointer).new()
		var pFuncs = pointerLoad.get_method_list()
		var methods = Dictionary()
		for pFunc in pFuncs:
			var pFuncName = pFunc.name
			if pFuncName.begins_with("__"):
				var data = pointerLoad.get_property_list()
				var devHint = Dictionary()
				for item in data:
					if item.get("name") == "developer_hint":
						devHint = pointerLoad.developer_hint
				var desc = devHint.get(pFuncName, [TranslationServer.translate("HEVLIB_MISSING_DOCUMENTATION_1"),TranslationServer.translate("HEVLIB_MISSING_DOCUMENTATION_2")])
				methods[pFuncName] = desc
		if return_JSON:return JSON.print(methods, "\t")
		else:return methods
	
	func __get_library_functionality(return_JSON: bool = false):
		var path = "res://HevLib/pointers/"
		var functions = Dictionary()
		var files = pointers.FolderAccess.__fetch_folder_files(path)
		for pointer in files:
			var actualPointer = path + pointer.split("/")[- 1]
			var pl = load(actualPointer)
			var pointerLoad = pl.new()
			var pFuncs = pointerLoad.get_method_list()
			var methods = Dictionary()
			for pFunc in pFuncs:
				var pFuncName = pFunc.name
				if pFuncName.begins_with("__"):
					var data = pointerLoad.get_property_list()
					var devHint = Dictionary()
					for item in data:
						if item.get("name") == "developer_hint":
							devHint = pointerLoad.developer_hint
					var desc = devHint.get(pFuncName, [TranslationServer.translate("HEVLIB_MISSING_DOCUMENTATION_1"),TranslationServer.translate("HEVLIB_MISSING_DOCUMENTATION_2")])
					methods[pFuncName] = desc
			functions[pointer] = methods
		if return_JSON: return JSON.print(functions, "\t")
		else:return functions

class _Keymapping:
	const non_static = Dictionary()
	
	func _init(f):
		non_static["pointers"] = f
		overrides.merge(load("res://HevLib/scenes/keymapping/data/overrides.gd").get_script_constant_map())
	
	const log_header = "pointers.Keymapping"
	
	
	
	const overrides = Dictionary()
	
	func __load_input_data(key:String, controls: Array,opts:Dictionary):
		var file:File = File.new()
		non_static["pointers"].defined_control_configs[key] = {"controls":controls,"opts":opts}
		for revis in controls:
			__add_inputs_to_inputmap(key,revis)
	
	static func __add_inputs_to_inputmap(key,controls):
		if controls is String:
			controls = [controls]
		if not controls:
			return
		var i = controls[0]
		var pointers:HevLibPointers = non_static["pointers"]
		if i.begins_with("Mouse "):
			var event = InputEventMouseButton.new()
			event.button_index = int(i.split("Mouse ")[1])
			if not InputMap.action_has_event(key,event):
				pointers.l("Adding input event [%s] for [%s]" % [i,key],log_header)
				InputMap.action_add_event(key, event)
			else:pointers.l("Input event [%s] for [%s] already exists, skipping" % [i,key],log_header)
		elif i.begins_with("JoyButton "):
			var event = InputEventJoypadButton.new()
			event.button_index = int(i.split("JoyButton ")[1])
			if not InputMap.action_has_event(key,event):
				pointers.l("Adding input event [%s] for [%s]" % [i,key],log_header)
				InputMap.action_add_event(key, event)
			else:pointers.l("Input event [%s] for [%s] already exists, skipping" % [i,key],log_header)
		elif i.begins_with("JoyAxis "):
			var event = InputEventJoypadMotion.new()
			event.axis = abs(int(i.split("JoyAxis ")[1]))
			if i.split("JoyAxis ")[1].begins_with("-"):
				event.axis_value = -1.0
			else:
				event.axis_value = 1.0
			if not InputMap.action_has_event(key,event):
				pointers.l("Adding input event [%s] for [%s]" % [i,key],log_header)
				InputMap.action_add_event(key, event)
			else:pointers.l("Input event [%s] for [%s] already exists, skipping" % [i,key],log_header)
		else:
			var event = InputEventKey.new()
			event.scancode = OS.find_scancode_from_string(i)
			if not InputMap.action_has_event(key,event):
				pointers.l("Adding input event [%s] for [%s]" % [i,key],log_header)
				InputMap.action_add_event(key, event)
			else:pointers.l("Input event [%s] for [%s] already exists, skipping" % [i,key],log_header)
	
	const input_cache = Dictionary()
	
	static func __define_vanilla_binds():
		var recache:bool = input_cache.empty()
		if!input_cache:
			for ie in __get_vanilla_action_list():
				input_cache[ie] = Array()
				for event in InputMap.get_action_list(ie):
					var ev:String = __event_to_string(event)
					if not ev in input_cache[ie]:
						input_cache[ie].append(ev)
		return input_cache.duplicate(true)
	
	const formatted_vanilla_binds_store:Dictionary = Dictionary()
	
	static func __get_formatted_vanilla_binds() -> Dictionary:
		if!formatted_vanilla_binds_store:
			var bound:Dictionary = Dictionary()
			var current:Dictionary = Dictionary()
			var file:File = File.new()
			var pointers:HevLibPointers._ConfigDriver = non_static["pointers"].ConfigDriver
			if file.file_exists(VANILLA_BINDS_PATH):
				current = pointers.__config_parse(VANILLA_BINDS_PATH)
			if file.file_exists("user://settings.cfg"):
				bound = pointers.__config_parse("user://settings.cfg").get("input",Dictionary())
			var vanilla_binds = __define_vanilla_binds()
			var vopts = overrides["vanilla_bind_opts"]
			var missing = ""
			for ie in vanilla_binds.keys():
				if ie in current:
					formatted_vanilla_binds_store[ie] = current[ie]
				else:
					var sect:Dictionary = {"can_be_rebound":false,"inputs":Array(),"opts":Dictionary()}
					var dv = vanilla_binds[ie]
					if ie in vopts:
						sect["opts"] = vopts[ie].duplicate(true)
					else:
						missing += "\n\t\"" + ie + "\":{},"
						printerr("HevLib Keymapping: vanilla ActionEvent ",ie," does NOT have defined opt overrides.")
					if ie in bound:
						sect.can_be_rebound = true
					for action in dv:
						if action is String:
							action = [action]
						sect.inputs.append(action)
					formatted_vanilla_binds_store[ie] = sect
			if missing:
				printerr(missing)
			pointers.__config_store(formatted_vanilla_binds_store,VANILLA_BINDS_PATH)
		return formatted_vanilla_binds_store.duplicate(true)
	
	static func __event_to_string(event):
		if event is InputEventKey:
			var key = OS.get_scancode_string(event.physical_scancode) if event.scancode == 0 else OS.get_scancode_string(event.scancode)
			return key
		elif event is InputEventJoypadMotion:
			var v = sign(event.axis_value)
			var a = event.axis * v
			var joyAxisString = "JoyAxis " + str(a)
			return joyAxisString
		elif event is InputEventJoypadButton:
			var joyButtonString = "JoyButton " + str(event.button_index)
			return joyButtonString
		elif event is InputEventMouseButton:
			var mouseString = "Mouse " + str(event.button_index)
			return mouseString
		return ""
	
	static func __string_to_scancode(event:String, give_type = false) -> int:
		if give_type:
			var out = [null,null]
			if event.begins_with("JoyAxis "):
				var ac = int(event.split("JoyAxis ")[1])
				var additive = (12000 * sign(ac))
				var joyAxisString = ac + additive
				out[0] = joyAxisString
				out[1] = 3
			elif event.begins_with("JoyButton "):
				var joyButtonString = int(event.split("JoyButton ")[1]) + 11000
				out[0] = joyButtonString
				out[1] = 2
			elif event.begins_with("Mouse "):
				var mouseString = int(event.split("Mouse ")[1]) + 10000
				out[0] = mouseString
				out[1] = 1
			else:
				var key = OS.find_scancode_from_string(event)
				out[0] = key
				out[1] = 0
			return out
		else:
			if event.begins_with("JoyAxis "):
				var raw = event.split("JoyAxis ")[1]
				var ac = int(raw)
				var sn = sign(ac)
				if raw.begins_with("-"):
					sn = -1
				if sn == 0:
					sn = 1
				var additive = (12000 * sn)
				var joyAxisString = ac + additive
				return joyAxisString
			elif event.begins_with("JoyButton "):
				var joyButtonString = int(event.split("JoyButton ")[1]) + 11000
				return joyButtonString
			elif event.begins_with("Mouse "):
				var mouseString = int(event.split("Mouse ")[1]) + 10000
				return mouseString
			else:
				var key = OS.find_scancode_from_string(event)
				return key
	
	static func __match_event_type(event):
		var eventType = Array()
		if event is InputEvent:
			eventType.append("InputEvent")
		if event is InputEventAction:
			eventType.append("InputEventAction")
		if event is InputEventGesture:
			eventType.append("InputEventGesture")
		if event is InputEventJoypadButton:
			eventType.append("InputEventJoypadButton")
		if event is InputEventJoypadMotion:
			eventType.append("InputEventJoypadMotion")
		if event is InputEventKey:
			eventType.append("InputEventKey")
		if event is InputEventMIDI:
			eventType.append("InputEventMIDI")
		if event is InputEventMagnifyGesture:
			eventType.append("InputEventMagnifyGesture")
		if event is InputEventMouse:
			eventType.append("InputEventMouse")
		if event is InputEventMouseButton:
			eventType.append("InputEventMouseButton")
		if event is InputEventMouseMotion:
			eventType.append("InputEventMouseMotion")
		if event is InputEventPanGesture:
			eventType.append("InputEventPanGesture")
		if event is InputEventScreenDrag:
			eventType.append("InputEventScreenDrag")
		if event is InputEventScreenTouch:
			eventType.append("InputEventTouch")
		if event is InputEventWithModifiers:
			eventType.append("InputEventWithModifiers")
		return eventType
	
	static func __simulate_input_press(action,continuous = true):
		if continuous:
			var ie = InputEventAction.new()
			ie.action = action
			ie.pressed = true
			Input.parse_input_event(ie)
		else:
			Input.action_press(action)
	
	static func __simulate_input_depress(action,continuous = true):
		if continuous:
			var ie = InputEventAction.new()
			ie.action = action
			ie.pressed = false
			Input.parse_input_event(ie)
		else:
			Input.action_release(action)
	
	const base_action_list = Array()
	
	static func __get_vanilla_action_list():
		if not base_action_list:
			for setting in ProjectSettings.get_property_list():
				if setting.name.begins_with('input/'):
					base_action_list.append(setting.name.split("/")[1])
		return base_action_list.duplicate(true)
	
	static func __get_built_in_action_list() -> PoolStringArray:
		return PoolStringArray([
			"ui_accept",
			"ui_select",
			"ui_cancel",
			"ui_focus_next",
			"ui_focus_prev",
			"ui_left",
			"ui_right",
			"ui_up",
			"ui_down",
			"ui_page_up",
			"ui_page_down",
			"ui_home",
			"ui_end",
		])
	
	static func __get_opts_from_key_data(key_data):
#		var activation = key_data.get("activation","press") # can be `press`, `release`, or `both`. Defines when the keybind activates
#		var context = key_data.get("context","in_game") # can be `in_game`, `in_menu`, or `both`. Defines whether the bind works in menus (OMS included) or in game
#		var allow_empty_bind = key_data.get("allow_empty_bind",false) # Defines if an empty keybind is valid (always active)
		var allow_extra_keys = key_data.get("allow_extra_keys",true) # Are additional keys allowed to be held to still activate the keybind
		var order_sensitive = key_data.get("order_sensitive",true) # Defines if the keys have to be pressed in the order they were inputted
		var exclusive = key_data.get("exclusive",false) # If true, then cancels other exclusive actions containing only part of the binds this action uses.
		var opts = {
#			"activation":activation,
#			"context":context,
#			"allow_empty_bind":allow_empty_bind,
			"allow_extra_keys":allow_extra_keys,
			"order_sensitive":order_sensitive,
			"exclusive":exclusive
		}
		return opts
	
	static func __create_input_event(action: String, event: Array,opts:Dictionary):
		for ev in event:
			if opts.order_sensitive:
				var scan = __string_to_scancode(ev[-1],true)
				match scan[1]:
					0:
						var ie = InputEventKey.new()
						var s = scan[0]
						ie.scancode = s
						ie.physical_scancode = s
						InputMap.action_add_event(action,ie)
					1:
						var ie = InputEventMouseButton.new()
						var s = scan[0] - 10000
						ie.button_index = s
						InputMap.action_add_event(action,ie)
					2:
						var ie = InputEventJoypadButton.new()
						var s = scan[0] - 11000
						ie.button_index = s
						InputMap.action_add_event(action,ie)
					3:
						var ie = InputEventJoypadMotion.new()
						var so = scan[0]
						var sig = sign(so)
						var s = 0
						var negoffset = (12000 * sig)
						if sig != -1:
							sig = 1
							s = so - negoffset
						else:
							s = -so + negoffset
						ie.axis = s
						ie.axis_value = sig
						InputMap.action_add_event(action,ie)
			else:
				var scans = Array()
				for sc in ev:
					scans.append(__string_to_scancode(sc,true))
				for scan in scans:
					match scan[1]:
						0:
							var ie = InputEventKey.new()
							var s = scan[0]
							ie.scancode = s
							ie.physical_scancode = s
							InputMap.action_add_event(action,ie)
						1:
							var ie = InputEventMouseButton.new()
							var s = scan[0] - 10000
							ie.button_index = s
							InputMap.action_add_event(action,ie)
						2:
							var ie = InputEventJoypadButton.new()
							var s = scan[0] - 11000
							ie.button_index = s
							InputMap.action_add_event(action,ie)
						3:
							var ie = InputEventJoypadMotion.new()
							var so = scan[0]
							var sig = sign(so)
							var s = 0
							var negoffset = (12000 * sig)
							if sig != -1:
								sig = 1
								s = so - negoffset
							else:
								s = -so + negoffset
							ie.axis = s
							ie.axis_value = sig
							InputMap.action_add_event(action,ie)

class _ManifestV2:
	const non_static = Dictionary()
	func _init(d):
		non_static["pointers"] = d
		non_static["self"] = self
		non_static["mutex"] = Mutex.new()
	
	const zip_ref_store : Dictionary = Dictionary()
	const cached_mod_list : Dictionary = Dictionary()
	const cached_mod_statistics : Dictionary = Dictionary()
	const cached_mod_keys : PoolStringArray = PoolStringArray()
	const modFiles:PoolStringArray = PoolStringArray()
	
	var haveModsChanged:bool = false
	var currentModHash:int = 0
	var lastModHash:int = 0
	
	var hasModStateChanged:bool = false
	var currentModStateHash:int = 0
	var lastModStateHash:int = 0
	
	
	
	const mod_file_to_id_cache = Dictionary()
	const get_mod_path_from_lowercase_path = Dictionary()
	
	const log_header = "pointers.ManifestV2"
	
	static func __get_mod_data():
		if !cached_mod_list:
			var base:_ManifestV2 = non_static["self"]
			var pointers:HevLibPointers = non_static["pointers"]
			var file:File = File.new()
			pointers.l("Fetching mods from file",log_header)
			# Read zips for mod association
			var gameInstallDirectory:String = OS.get_executable_path().get_base_dir()
			if OS.get_name() == "OSX":
				gameInstallDirectory = gameInstallDirectory.get_base_dir().get_base_dir().get_base_dir()
			var modPathPrefix:String = gameInstallDirectory + "/mods/"
			# Pre-cache mod data to prevent issues later down the line with potential future multithreading
			__get_all_modlets(false,true)
			var dir:Directory = Directory.new()
			if dir.open(modPathPrefix) + dir.list_dir_begin(): # If non-zero, then an error code has been emitted
				pointers.l("ERROR: Cannot open zip directory",log_header)
			else:
				var modZipProcessing:Array = Array()
				while true:
					var fileName:String = dir.get_next()
					if !fileName:
						break
					if dir.current_is_dir():
						continue
					var modFSPath:String = modPathPrefix + fileName
					if modFSPath.get_extension() == "zip" and pointers.FileAccess.__file_exists(modFSPath):
						modZipProcessing.append({"object":base,"method":"get_mod_zip_content","args":[modFSPath,pointers]})
				dir.list_dir_end()
				pointers.Threading.__request_multiple_threads(modZipProcessing)
				var hls:String = zip_ref_store.get("res://HevLib/ModMain.gd","")
				if hls&&hls.get_file()!="HevLib.zip":
					pointers.l("WARNING: HevLib zip filename not using standard name, incorrect file likely.",log_header)
			# Load translations
			pointers.Translations.__inject_translations()
			pointers.SafeMode.ready()
			var manifest_count:int = 0
			var library_count:int = 0
			var non_library_count:int = 0
			var all_mod_files:Array = Array()
			var modmain_files : PoolStringArray = __get_modmain_files()
			var manifests_and_icons:PoolStringArray = (__get_manifest_files() + __get_icon_files())
			var modlet_files : PoolStringArray = __get_modlet_files()
			pointers.l("found [%s] modmain files" % modmain_files.size(),log_header)
			for item in modmain_files:
				modFiles.append(item.to_lower())
				pointers.l("registering ModMain %s" % item,log_header)
				all_mod_files.append({"object":base,"method":"compile_mod_data_from_path","args":[item,manifests_and_icons,modlet_files]})
			pointers.l("found [%s] modlet files" % modlet_files.size(),log_header)
			for item in modlet_files:
				modFiles.append(item.to_lower())
				pointers.l("registering Modlet %s" % item,log_header)
				all_mod_files.append({"object":base,"method":"compile_mod_data_from_path","args":[item,manifests_and_icons,modlet_files]})
			var modListArr : Array = pointers.Threading.__request_multiple_threads(all_mod_files)
			var total_mod_count:int = modListArr.size()
			pointers.l("solved [%s] mod-definition files [%s ModMains / %s Modlets]" % [total_mod_count,modmain_files.size(),modlet_files.size()],log_header)
			modListArr.sort_custom(non_static["self"],"sortModList")
			var stat_tags : Dictionary = Dictionary()
			for mod_entry in modListArr:
				var mdsc:String = mod_entry.get("file_path","")
				cached_mod_list[mdsc] = mod_entry
				if mod_entry["manifest"]["has_manifest"]:
					manifest_count += 1
					var md : Dictionary = mod_entry["manifest"]["manifest_data"]
					var mid:String = md["mod_information"].get("id","")
					if mid:
						mod_file_to_id_cache[mdsc.to_lower()] = mid
						get_mod_path_from_lowercase_path[mdsc.to_lower()] = mdsc
						if "tags" in md.keys():
							for tag in md["tags"]:
								if tag in stat_tags:
									stat_tags[tag] += 1
								else:
									stat_tags[tag] = 1
				if mod_entry["library_information"]["is_library"]:
					library_count += 1
				else:
					non_library_count += 1
			cached_mod_keys.append_array(cached_mod_list.keys())
			pointers.SafeMode.__handle_exit_for_file_checks()
			
			if not ("res://HevLib/ModMain.gd" in cached_mod_keys and ResourceLoader.exists("res://HevLib/pointers.gd")):
				pointers.NodeAccess.__exit(
					false,
					"Mod data was not successfully fetched, assuming that a severe bug with HevLib filesystem querying on non-editor builds has occurred. You will need to manually update due to an issue of this severity.\n\nClosing this popup will crash the game & open Hev's bug report form so the issue can be addressed.",
					"pointers.ManifestV2",
					0.0,
					"https://forms.gle/RmC4Zgonp6frFgnK7",
					true
				)
			cached_mod_statistics["counts"] = {"total_mod_count":total_mod_count,"mods_using_manifests":manifest_count,"mods":non_library_count,"libraries":library_count}
			cached_mod_statistics["tags"] = stat_tags
			if not base.currentModHash:
				if file.file_exists(MOD_HASH_PATH):
					file.open(MOD_HASH_PATH,File.READ)
					base.lastModHash = file.get_32()
					file.close()
				base.currentModHash = cached_mod_list.hash()
				file.open(MOD_HASH_PATH,File.WRITE)
				file.store_32(base.currentModHash)
				file.close()
				if base.currentModHash != base.lastModHash:
					base.haveModsChanged = true
			if(not pointers.is_editor and not base.currentModStateHash):
				if file.file_exists(MOD_STATE_HASH_PATH):
					file.open(MOD_STATE_HASH_PATH,File.READ)
					base.lastModStateHash = file.get_32()
					file.close()
				var zrs:Array = Array()
				for mod in modListArr:
					zrs.append(mod["hash"])
				zrs.sort()
				base.currentModStateHash = zrs.hash()
				file.open(MOD_STATE_HASH_PATH,File.WRITE)
				file.store_32(base.currentModStateHash)
				file.close()
				if base.currentModStateHash != base.lastModStateHash:
					base.hasModStateChanged = true
		return cached_mod_list
	
	static func compile_mod_data_from_path(script_path:String,manifests_and_icons:PoolStringArray,modlet_files:PoolStringArray) -> Dictionary:
		var pointers:HevLibPointers = non_static["pointers"]
		if not pointers.FileAccess.__file_exists(script_path):
			return Dictionary()
		var cv : String = script_path.get_file().to_lower()
		if cv.begins_with("modmain") and cv.get_extension() == "gd":
			var constants : Dictionary = pointers.DataFormat.__get_script_constant_map_without_load(script_path)
			var folder_path : String = script_path.get_base_dir() + "/"
			var mod_priority : int = constants.get("MOD_PRIORITY",0)
			var mod_name : String = str(constants.get("MOD_NAME",script_path.split("/")[2]))
			var legacy_mod_version : String = constants.get("MOD_VERSION","1.0.0")
			var mod_version_major : int = constants.get("MOD_VERSION_MAJOR",1)
			var mod_version_minor : int = constants.get("MOD_VERSION_MINOR",0)
			var mod_version_bugfix : int = constants.get("MOD_VERSION_BUGFIX",0)
			var mod_version_metadata : String = constants.get("MOD_VERSION_METADATA","")
			var is_library : bool = constants.get("MOD_IS_LIBRARY",false)
			var always_display : bool = constants.get("ALWAYS_DISPLAY",false)
			
			var has_mod_manifest : bool = false
			var manifest_filepath : String = ""
			var manifest_data : Dictionary = Dictionary()
			var manifest_version : float = 1.0
			var has_icon_file : bool = false
			var png_path : String = ""
			var stex_path : String = ""
			var icon_path : String = ""
			
			var mod_enabled:bool = true
			var script_filename : String = script_path.get_file().to_lower()
			
			for content_file in manifests_and_icons:
				if content_file.begins_with(folder_path):
					var ft : String = content_file.split(folder_path)[1]
					if not has_mod_manifest and ft.to_lower() == "mod.manifest":
						has_mod_manifest = true
						manifest_filepath = content_file
						manifest_data = __parse_file_as_manifest(content_file)
						mod_name = manifest_data["mod_information"].get("name",mod_name)
						legacy_mod_version = manifest_data["version"].get("version_string",legacy_mod_version)
						mod_version_major = manifest_data["version"].get("version_major",mod_version_major)
						mod_version_minor = manifest_data["version"].get("version_minor",mod_version_minor)
						mod_version_bugfix = manifest_data["version"].get("version_bugfix",mod_version_bugfix)
						mod_version_metadata = manifest_data["version"].get("version_metadata",mod_version_metadata)
						is_library = manifest_data["library"].get("is_library",false)
						always_display = manifest_data["library"].get("always_display",false)
						manifest_version = manifest_data["manifest_definitions"].get("manifest_version",1)
						
					
					if ft.to_lower().begins_with("icon"):
						if ft.get_extension().to_lower() in pointers.SUPPORTED_IMAGE_EXTENSIONS:
							has_icon_file = true
							png_path = content_file
						if ft.get_extension().to_lower() == "stex":
							has_icon_file = true
							stex_path = content_file
			if not has_mod_manifest:
				var tcDir:String = folder_path.trim_suffix("/").get_base_dir()
				while not has_mod_manifest and not tcDir == "res://":
					for file in pointers.FolderAccess.__fetch_folder_files(tcDir):
						var fl:String = file.to_lower()
						if fl.begins_with("mod") and fl.get_extension() == "manifest":
							var content_file:String = tcDir.plus_file(file)
							has_mod_manifest = true
							manifest_filepath = content_file
							manifest_data = BASE_MANIFEST_TEMPLATE.duplicate(true)
							var new_manifest_data:Dictionary = __parse_file_as_manifest(content_file)
							manifest_data["mod_information"] = new_manifest_data["mod_information"]
							manifest_data["version"] = new_manifest_data["version"]
							manifest_data["library"] = new_manifest_data["library"]
							manifest_data["manifest_definitions"]["manifest_version"] = new_manifest_data["manifest_definitions"]["manifest_version"]
							manifest_data.mod_information.brief = ""
							legacy_mod_version = manifest_data["version"].get("version_string",legacy_mod_version)
							mod_version_major = manifest_data["version"].get("version_major",mod_version_major)
							mod_version_minor = manifest_data["version"].get("version_minor",mod_version_minor)
							mod_version_bugfix = manifest_data["version"].get("version_bugfix",mod_version_bugfix)
							mod_version_metadata = manifest_data["version"].get("version_metadata",mod_version_metadata)
							is_library = manifest_data["library"].get("is_library",false)
							always_display = manifest_data["library"].get("always_display",false)
							manifest_version = manifest_data["manifest_definitions"].get("manifest_version",1)
					tcDir = tcDir.get_base_dir()
			if stex_path:
				icon_path = stex_path
			elif png_path:
				icon_path = png_path
			var icon_dict : Dictionary = {"has_icon_file":has_icon_file,"icon_path":icon_path}
			var manifestEntry : Dictionary = {"has_manifest":has_mod_manifest,"manifest_version":manifest_version,"manifest_file_path":manifest_filepath,"manifest_data":manifest_data}
			var mod_version_array : Array = [mod_version_major,mod_version_minor,mod_version_bugfix]
			var mod_version_string : String = "%d.%d.%d" % [mod_version_major,mod_version_minor,mod_version_bugfix]
			if mod_version_metadata:
				mod_version_array.append(mod_version_metadata)
				mod_version_string += "-%s" % mod_version_metadata
			var version_dictionary : Dictionary = {"version_major":mod_version_major,"version_minor":mod_version_minor,"version_bugfix":mod_version_bugfix,"version_metadata":mod_version_metadata,"full_version_array":mod_version_array,"full_version_string":mod_version_string,"legacy_mod_version":legacy_mod_version}
			var drivers : Dictionary = pointers.DriverManagement.__get_drivers_from_modmain_path(script_path)
			var ml : String = "en"
			var tlData : Dictionary = drivers.get("REPLACE_TRANSLATIONS.gd",Dictionary()).get("TRANSLATIONS",Dictionary())
			if tlData:
				ml = tlData.get("master_locale","en")
				tlData.erase("master_locale")
				var tlKeys:Array = tlData.keys()
				if "file" in tlKeys:
					var tlFiles:Dictionary = tlData["file"]
					for tl in tlFiles.keys():
						var delim:String = "|"
						var d = tlFiles[tl]
						if d is String:
							delim = d
						elif d is Dictionary:
							delim = d.get("string",delim)
						var dict:Dictionary = pointers.Translations.__translation_file_to_dictionary(tl,delim)
						for ln in dict.keys():
							if not ln in tlKeys:
								tlData[ln] = Dictionary()
							tlData[ln].merge(dict[ln])
					tlData.erase("file")
					tlKeys.erase("file")
				var master_locale : Dictionary = tlData.get(ml,Dictionary())
				var total : int = master_locale.size()
				var counts : Dictionary = {ml:{"has":total,"missing":0,"not_updated":0}}
				for lang in tlKeys:
					if lang != ml:
						var langData : Dictionary = tlData[lang]
						var lc : int = langData.size()
						var not_in_master:int = 0
						var not_updated:int = 0
						for l in langData.keys():
							if not l in master_locale:
								not_in_master += 1
							else:
								if langData[l].get("version_hash",0) != hash(master_locale[l].get("string","")):
									not_updated += 1
						counts[lang] = {"has":lc,"missing":total - (lc - not_in_master),"not_updated":not_updated}
						counts[ml]["missing"] += not_in_master
				if manifestEntry["has_manifest"]:
					var manifest_langs:Dictionary = Dictionary()
					for lang in counts.keys():
						var hs : float = float(counts[lang]["has"])
						var bucket : float = hs/(hs+float(counts[lang]["missing"]))
						manifest_langs[lang] = "%3.1f%%" % ((bucket * 100) - (25 * (1 - ((hs - float(counts[lang]["not_updated"])) / hs))))
					manifestEntry["manifest_data"]["languages"] = manifest_langs
			
			var zip_path:String = __match_mod_path_to_zip(script_path)
			var zip_size:int = 0
			
			var file:File=File.new()
			if file.file_exists(zip_path):
				file.open(zip_path,File.READ)
				zip_size = file.get_len()
				file.close()
			
			var concat:Dictionary = {
				"name":TranslationServer.translate(mod_name),
				"priority":mod_priority,
				"path":script_path,
				"zip_path":zip_path,
				"zip_size":zip_size,
				"version":version_dictionary,
				"type":"mod",
				"enabled":true,
			}
			if has_mod_manifest:
				concat["id"] = manifestEntry["manifest_data"]["mod_information"]["id"]
			
			return {
				"name":mod_name,
				"priority":mod_priority,
				"file_path":script_path,
				"zip_path":zip_path,
				"version_data":version_dictionary,
				"mod_icon":icon_dict,
				"library_information":{
					"is_library":is_library,
					"always_display":always_display
				},
				"manifest":manifestEntry,
				"drivers":drivers,
				"mod_type":"mod",
				"enabled":true,
				"master_locale":ml,
				"hash":concat.hash(),
			}
		elif cv.begins_with("mod") and cv.ends_with(".manifest"):
			var manifest_data : Dictionary = __parse_file_as_manifest(script_path)
			
			var mod_error:bool = false
			var folder_path : String = script_path.get_base_dir() + "/"
			var mod_priority : int = manifest_data["manifest_definitions"].get("modlet_priority",0)
			var mod_name : String = manifest_data["mod_information"].get("name",script_path.split("/",false)[1])
			var legacy_mod_version : String = manifest_data["version"].get("version_string","1.0.0")
			var mod_version_major : int = manifest_data["version"].get("version_major",1)
			var mod_version_minor : int = manifest_data["version"].get("version_minor",0)
			var mod_version_bugfix : int = manifest_data["version"].get("version_bugfix",0)
			var mod_version_metadata : String = manifest_data["version"].get("version_metadata","")
			
			var manifest_version : float = manifest_data["manifest_definitions"].get("manifest_version",1.0)
			var has_icon_file : bool = false
			var png_path : String = ""
			var stex_path : String = ""
			var icon_path : String = ""
			
			var mod_enabled:bool = true
			var script_filename : String = script_path.get_file().to_lower()
			
			if script_filename.begins_with("mod") and script_filename.ends_with(".manifest"):
				if not script_path in modlet_files:
					mod_enabled = false
			for content_file in manifests_and_icons:
				if content_file.begins_with(folder_path):
					var ft : String = content_file.split(folder_path)[1].to_lower()
					if ft.begins_with("icon"):
						if ft.get_extension() == "stex":
							has_icon_file = true
							stex_path = content_file
						elif ft.get_extension() in pointers.SUPPORTED_IMAGE_EXTENSIONS:
							has_icon_file = true
							png_path = content_file
			if stex_path:
				icon_path = stex_path
			elif png_path:
				icon_path = png_path
			var icon_dict : Dictionary = {"has_icon_file":has_icon_file,"icon_path":icon_path}
			var manifestEntry : Dictionary = {"has_manifest":true,"manifest_version":manifest_version,"manifest_file_path":script_path,"manifest_data":manifest_data}
			var mod_version_array : Array = [mod_version_major,mod_version_minor,mod_version_bugfix]
			var mod_version_string : String = "%d.%d.%d" % [mod_version_major,mod_version_minor,mod_version_bugfix]
			if mod_version_metadata:
				mod_version_array.append(mod_version_metadata)
				mod_version_string += "-%s" % mod_version_metadata
			var version_dictionary : Dictionary = {"version_major":mod_version_major,"version_minor":mod_version_minor,"version_bugfix":mod_version_bugfix,"version_metadata":mod_version_metadata,"full_version_array":mod_version_array,"full_version_string":mod_version_string,"legacy_mod_version":legacy_mod_version}
			var drivers : Dictionary = pointers.DriverManagement.__get_drivers_from_modmain_path(script_path)
			var ml : String = "en"
			var tlData : Dictionary = drivers.get("REPLACE_TRANSLATIONS.gd",Dictionary()).get("TRANSLATIONS",Dictionary())
			if tlData:
				ml = tlData.get("master_locale","en")
				tlData.erase("master_locale")
				var tlKeys:Array = tlData.keys()
				if "file" in tlKeys:
					var tlFiles:Dictionary = tlData["file"]
					for tl in tlFiles.keys():
						var delim:String = "|"
						var d = tlFiles[tl]
						if d is String:
							delim = d
						elif d is Dictionary:
							delim = d.get("string",delim)
						var dict:Dictionary = pointers.Translations.__translation_file_to_dictionary(tl,delim)
						for ln in dict.keys():
							if not ln in tlKeys:
								tlData[ln] = Dictionary()
							tlData[ln].merge(dict[ln])
					tlData.erase("file")
					tlKeys.erase("file")
				var master_locale : Dictionary = tlData.get(ml,Dictionary())
				var total : int = master_locale.size()
				var counts : Dictionary = {ml:{"has":total,"missing":0,"not_updated":0}}
				for lang in tlKeys:
					if lang != ml:
						var langData : Dictionary = tlData[lang]
						var lc : int = langData.size()
						var not_in_master:int = 0
						var not_updated:int = 0
						for l in langData.keys():
							if not l in master_locale:
								not_in_master += 1
							else:
								if langData[l].get("version_hash",0) != hash(master_locale[l].get("string","")):
									not_updated += 1
						counts[lang] = {"has":lc,"missing":total - (lc - not_in_master),"not_updated":not_updated}
						counts[ml]["missing"] += not_in_master
				if manifestEntry["has_manifest"]:
					var manifest_langs:Dictionary = Dictionary()
					for lang in counts.keys():
						var hs : float = float(counts[lang]["has"])
						manifest_langs[lang] = "%3.1f%%" % (((hs/(hs+float(counts[lang]["missing"]))) * 100) - (25 * (1 - ((hs - float(counts[lang]["not_updated"])) / hs))))
					manifestEntry["manifest_data"]["languages"] = manifest_langs
			
			
			var zip_path:String = __match_mod_path_to_zip(script_path)
			var zip_size:int = 0
			
			var file:File=File.new()
			if file.file_exists(zip_path):
				file.open(zip_path,File.READ)
				zip_size = file.get_len()
				file.close()
			
			var concat:Dictionary = {
				"name":TranslationServer.translate(mod_name),
				"priority":mod_priority,
				"path":script_path,
				"zip_path":zip_path,
				"zip_size":zip_size,
				"version":version_dictionary,
				"type":"modlet",
				"enabled":mod_enabled,
				"id":manifestEntry["manifest_data"]["mod_information"]["id"]
			}
			
			return {
				"name":mod_name,
				"priority":mod_priority,
				"file_path":script_path,
				"zip_path":zip_path,
				"version_data":version_dictionary,
				"mod_icon":{"has_icon_file":false,"icon_path":""} if mod_error else icon_dict,
				"library_information":{
					"is_library":manifest_data["library"].get("is_library",false),
					"always_display":manifest_data["library"].get("always_display",false)
				},
				"manifest":manifestEntry,
				"drivers":drivers,
				"mod_type":"unknown" if mod_error else "modlet",
				"enabled":true,
				"master_locale":ml,
				"hash":concat.hash(),
			}
		return Dictionary()
	
	static func get_mod_zip_content(modFSPath:String,pointers):
		for modEntryPath in pointers.Zip.__get_zip_content(modFSPath):
			var modGlobalPath:String = "res://" + modEntryPath
			if not modGlobalPath.ends_with("/"):
				pointers.SafeMode.__check_file(modGlobalPath,modFSPath)
				non_static["mutex"].lock()
				if modGlobalPath.to_lower() in modFiles:
					zip_ref_store[modGlobalPath] = modFSPath
				non_static["mutex"].unlock()
	
	static func __get_mod_list_keys() -> PoolStringArray:
		if !cached_mod_keys:
			__get_mod_data()
		return cached_mod_keys
	
	static func __get_mod_statistics() -> Dictionary:
		if !cached_mod_statistics:
			__get_mod_data()
		return cached_mod_statistics.duplicate(true)
	
	static func ovs(a,b) -> bool:
		if "id" in a and not "id" in b: return true
		elif not "id" in a and "id" in b: return false
		if a.get("priority",0) != b.get("priority",0): return a.get("priority",0) < b.get("priority",0)
		if a.get("id","") != b.get("id",""): return a.get("id","") < b.get("id","")
		if a.get("path","") != b.get("path",""): return a.get("path","") < b.get("path","")
		if a.get("zip_path","") != b.get("zip_path",""): return a.get("zip_path","") < b.get("zip_path","")
		if a.get("name","") != b.get("name",""): return a.get("name","") < b.get("name","")
		return false
	
	static func ovs2(a,b) -> bool:
		if "id" in a and not "id" in b: return true
		elif not "id" in a and "id" in b: return false
		if a.get("prio",0) != b.get("prio",0): return a.get("prio",0) < b.get("prio",0)
		if a.get("id","") != b.get("id",""): return a.get("id","") < b.get("id","")
		if a.get("file","") != b.get("file",""): return a.get("file","") < b.get("file","")
		if a.get("zip","") != b.get("zip",""): return a.get("zip","") < b.get("zip","")
		if a.get("name","") != b.get("name",""): return a.get("name","") < b.get("name","")
		return false
	
	static func __match_mod_path_to_zip(mod_main_path:String) -> String:
		return zip_ref_store.get(mod_main_path,"")
	
	static func sortModList(a:Dictionary,b:Dictionary):
		var c1:int = a["priority"]
		var c2:int = b["priority"]
		if c1 != c2:
			return c1 < c2
		var b1:String = a["file_path"]
		var b2:String = b["file_path"]
		if b1 != b2:
			return b1 < b2
		return false
	
	static func __compare_versions(checked_mod_data:Dictionary) -> bool:
		var installed_mods : Dictionary = __get_mod_data()
		var check_keys : Array = checked_mod_data.keys()
		var check_name : String = checked_mod_data[check_keys[0]].get("name","")
		var installed_dict : Dictionary = Dictionary()
		for installed_mod in __get_mod_list_keys():
			if installed_mods[installed_mod].get("name","") == check_name:
				installed_dict = installed_mods[installed_mod].duplicate()
				break
		if not installed_dict:
			return false
		var checked_manifest_version:float = checked_mod_data[check_keys[0]]["manifest"]["manifest_version"]
		if checked_manifest_version < 2.0:
			return false
		if checked_manifest_version > installed_dict["manifest"]["manifest_version"]:
			return true
		var checked_mod_version : Array = checked_mod_data[check_keys[0]]["version_data"]["full_version_array"]
		var installed_mod_version : Array = installed_dict["version_data"]["full_version_array"]
		if checked_mod_version[0] > installed_mod_version[0]:
			return true
		if checked_mod_version[1] > installed_mod_version[1]:
			return true
		if checked_mod_version[2] > installed_mod_version[2]:
			return true
		return false
	
	static func __concat_mod_info(mod_path:String) -> Dictionary:
		var pointers:HevLibPointers = non_static["pointers"]
		if not pointers.FileAccess.__file_exists(mod_path):
			return Dictionary()
		var cv : String = mod_path.get_file().to_lower()
		if cv.begins_with("modmain") and cv.ends_with(".gd"):
			var constants : Dictionary = pointers.DataFormat.__get_script_constant_map_without_load(mod_path)
			return {"constants":constants,"script_path":mod_path,"mod_type":"mod"}
		elif cv.begins_with("mod") and cv.ends_with(".manifest"):
			var manifestData : Dictionary = __parse_file_as_manifest(mod_path)
			var constants = {
				"MOD_PRIORITY":manifestData["manifest_definitions"].get("modlet_priority",0),
				"MOD_NAME":manifestData["mod_information"].get("name",mod_path.split("/",false)[1]),
				"MOD_VERSION":manifestData["version"].get("version_string","1.0.0"),
				"MOD_VERSION_MAJOR":manifestData["version"].get("version_major","1"),
				"MOD_VERSION_MINOR":manifestData["version"].get("version_minor","0"),
				"MOD_VERSION_BUGFIX":manifestData["version"].get("version_bugfix","0"),
				"MOD_VERSION_METADATA":manifestData["version"].get("version_metadata",""),
				"MOD_IS_LIBRARY":manifestData["library"].get("is_library",false),
				"ALWAYS_DISPLAY":manifestData["library"].get("always_display",false),
			}
			return {"constants":constants,"script_path":mod_path,"mod_type":"modlet"}
		return Dictionary()
	
	static func __make_mod_entry(mod: Dictionary):
		var mod_error:bool = false
		var constants : Dictionary = mod.get("constants")
		var script_path : String = mod.get("script_path")
		var folder_path : String = script_path.get_base_dir() + "/"
		var mod_priority : int = constants.get("MOD_PRIORITY",0)
		var mod_name : String = str(constants.get("MOD_NAME",script_path.split("/")[2]))
		var legacy_mod_version : String = constants.get("MOD_VERSION","1.0.0")
		var mod_version_major : int = constants.get("MOD_VERSION_MAJOR",1)
		var mod_version_minor : int = constants.get("MOD_VERSION_MINOR",0)
		var mod_version_bugfix : int = constants.get("MOD_VERSION_BUGFIX",0)
		var mod_version_metadata : String = constants.get("MOD_VERSION_METADATA","")
		var is_library : bool = constants.get("MOD_IS_LIBRARY",false)
		var always_display : bool = constants.get("ALWAYS_DISPLAY",false)
		
		var has_mod_manifest : bool = false
		var manifest_filepath : String = ""
		var manifest_data : Dictionary = Dictionary()
		var manifest_version : float = 1.0
		var has_icon_file : bool = false
		var png_path : String = ""
		var stex_path : String = ""
		var icon_path : String = ""
		
		var mod_enabled:bool = true
		var script_filename : String = script_path.get_file().to_lower()
		var pointers:HevLibPointers = non_static["pointers"]
		
		if script_filename.begins_with("mod") and script_filename.ends_with(".manifest"):
			if not script_path in __get_modlet_files():
				mod_enabled = false
		for content_file in (__get_manifest_files() + __get_icon_files()):
			if content_file.begins_with(folder_path):
				var ft : String = content_file.split(folder_path)[1]
				if not has_mod_manifest and ft.to_lower() == "mod.manifest":
					has_mod_manifest = true
					manifest_filepath = content_file
					manifest_data = __parse_file_as_manifest(content_file)
					mod_name = manifest_data["mod_information"].get("name",mod_name)
					legacy_mod_version = manifest_data["version"].get("version_string",legacy_mod_version)
					mod_version_major = manifest_data["version"].get("version_major",mod_version_major)
					mod_version_minor = manifest_data["version"].get("version_minor",mod_version_minor)
					mod_version_bugfix = manifest_data["version"].get("version_bugfix",mod_version_bugfix)
					mod_version_metadata = manifest_data["version"].get("version_metadata",mod_version_metadata)
					is_library = manifest_data["library"].get("is_library",false)
					always_display = manifest_data["library"].get("always_display",false)
					manifest_version = manifest_data["manifest_definitions"].get("manifest_version",1)
					if mod["mod_type"] != "modlet" and manifest_data["manifest_definitions"].get("modlet_priority",0):
						mod_version_metadata = "Manifest fault - Cannot determine mod type!"
						manifest_data["version"]["version_metadata"] = "Manifest fault - Cannot determine mod type!"
						mod_error = true
				
				if ft.to_lower().begins_with("icon"):
					if ft.get_extension().to_lower() in pointers.SUPPORTED_IMAGE_EXTENSIONS:
						has_icon_file = true
						png_path = content_file
					if ft.get_extension().to_lower() == "stex":
						has_icon_file = true
						stex_path = content_file
		if not has_mod_manifest:
			var tcDir:String = folder_path.trim_suffix("/").get_base_dir()
			while not has_mod_manifest and not tcDir == "res://":
				for file in pointers.FolderAccess.__fetch_folder_files(tcDir):
					var fl:String = file.to_lower()
					if fl.begins_with("mod") and fl.get_extension() == "manifest":
						var content_file:String = tcDir.plus_file(file)
						has_mod_manifest = true
						manifest_filepath = content_file
						manifest_data = BASE_MANIFEST_TEMPLATE.duplicate(true)
						var new_manifest_data:Dictionary = __parse_file_as_manifest(content_file)
						manifest_data["mod_information"] = new_manifest_data["mod_information"]
						manifest_data["version"] = new_manifest_data["version"]
						manifest_data["library"] = new_manifest_data["library"]
						manifest_data["manifest_definitions"]["manifest_version"] = new_manifest_data["manifest_definitions"]["manifest_version"]
						manifest_data.mod_information.brief = ""
						legacy_mod_version = manifest_data["version"].get("version_string",legacy_mod_version)
						mod_version_major = manifest_data["version"].get("version_major",mod_version_major)
						mod_version_minor = manifest_data["version"].get("version_minor",mod_version_minor)
						mod_version_bugfix = manifest_data["version"].get("version_bugfix",mod_version_bugfix)
						mod_version_metadata = manifest_data["version"].get("version_metadata",mod_version_metadata)
						is_library = manifest_data["library"].get("is_library",false)
						always_display = manifest_data["library"].get("always_display",false)
						manifest_version = manifest_data["manifest_definitions"].get("manifest_version",1)
						if mod["mod_type"] != "modlet" and manifest_data["manifest_definitions"].get("modlet_priority",0):
							mod_version_metadata = "Manifest fault - Cannot determine mod type!"
							manifest_data["version"]["version_metadata"] = "Manifest fault - Cannot determine mod type!"
							mod_error = true
				tcDir = tcDir.get_base_dir()
		if stex_path:
			icon_path = stex_path
		elif png_path:
			icon_path = png_path
		var icon_dict : Dictionary = {"has_icon_file":has_icon_file,"icon_path":icon_path}
		var manifestEntry : Dictionary = {"has_manifest":has_mod_manifest,"manifest_version":manifest_version,"manifest_file_path":manifest_filepath,"manifest_data":manifest_data}
		var mod_version_array : Array = [mod_version_major,mod_version_minor,mod_version_bugfix]
		var mod_version_string : String = "%d.%d.%d" % [mod_version_major,mod_version_minor,mod_version_bugfix]
		if mod_version_metadata:
			mod_version_array.append(mod_version_metadata)
			mod_version_string += "-%s" % mod_version_metadata
		var version_dictionary : Dictionary = {"version_major":mod_version_major,"version_minor":mod_version_minor,"version_bugfix":mod_version_bugfix,"version_metadata":mod_version_metadata,"full_version_array":mod_version_array,"full_version_string":mod_version_string,"legacy_mod_version":legacy_mod_version}
		var drivers : Dictionary = pointers.DriverManagement.__get_drivers_from_modmain_path(script_path)
		var ml : String = "en"
		var tlData : Dictionary = drivers.get("REPLACE_TRANSLATIONS.gd",Dictionary()).get("TRANSLATIONS",Dictionary())
		if tlData:
			ml = tlData.get("master_locale","en")
			tlData.erase("master_locale")
			var tlKeys:Array = tlData.keys()
			if "file" in tlKeys:
				var tlFiles:Dictionary = tlData["file"]
				for tl in tlFiles.keys():
					var delim:String = "|"
					var d = tlFiles[tl]
					if d is String:
						delim = d
					elif d is Dictionary:
						delim = d.get("string",delim)
					var dict:Dictionary = pointers.Translations.__translation_file_to_dictionary(tl,delim)
					for ln in dict.keys():
						if not ln in tlKeys:
							tlData[ln] = Dictionary()
						tlData[ln].merge(dict[ln])
				tlData.erase("file")
				tlKeys.erase("file")
			var master_locale : Dictionary = tlData.get(ml,Dictionary())
			var total : int = master_locale.size()
			var counts : Dictionary = {ml:{"has":total,"missing":0,"not_updated":0}}
			for lang in tlKeys:
				if lang != ml:
					var langData : Dictionary = tlData[lang]
					var lc : int = langData.size()
					var not_in_master:int = 0
					var not_updated:int = 0
					for l in langData.keys():
						if not l in master_locale:
							not_in_master += 1
						else:
							if langData[l].get("version_hash",0) != hash(master_locale[l].get("string","")):
								not_updated += 1
					counts[lang] = {"has":lc,"missing":total - (lc - not_in_master),"not_updated":not_updated}
					counts[ml]["missing"] += not_in_master
			if manifestEntry["has_manifest"]:
				var manifest_langs:Dictionary = Dictionary()
				for lang in counts.keys():
					var hs : float = float(counts[lang]["has"])
					var bucket : float = hs/(hs+float(counts[lang]["missing"]))
					manifest_langs[lang] = "%3.1f%%" % ((bucket * 100) - (25 * (1 - ((hs - float(counts[lang]["not_updated"])) / hs))))
				manifestEntry["manifest_data"]["languages"] = manifest_langs
		if mod_error:
			icon_dict = {"has_icon_file":false,"icon_path":""}
			mod["mod_type"] = "NULL"
		return {"name":mod_name,"priority":mod_priority,"file_path":script_path,"zip_path":__match_mod_path_to_zip(script_path),"version_data":version_dictionary,"mod_icon":icon_dict,"library_information":{"is_library":is_library,"always_display":always_display},"manifest":manifestEntry,"drivers":drivers,"mod_type":mod["mod_type"],"enabled":mod_enabled,"master_locale":ml}

	
	static func __get_mod_data_from_files(script_path:String) -> Dictionary:
		var constants : Dictionary = non_static["pointers"].DataFormat.__get_script_constant_map_without_load(script_path)
		var folder_path : String = script_path.get_base_dir() + "/"
		var mod_name : String = str(constants.get("MOD_NAME",script_path.split("/")[2]))
		var legacy_mod_version : String = constants.get("MOD_VERSION","1.0.0")
		var mod_version_major:int = constants.get("MOD_VERSION_MAJOR",1)
		var mod_version_minor:int = constants.get("MOD_VERSION_MINOR",0)
		var mod_version_bugfix:int = constants.get("MOD_VERSION_BUGFIX",0)
		var mod_version_metadata : String = constants.get("MOD_VERSION_METADATA","")
		
		var mod_is_library:bool = constants.get("MOD_IS_LIBRARY",false)
		
		var hide_library:bool = constants.get("LIBRARY_HIDDEN_BY_DEFAULT",true)
		var content : PoolStringArray = __get_manifest_files()
		var has_mod_manifest:bool = false
		var manifest_data : Dictionary = Dictionary()
		var manifest_version:float = 1.0
		var has_icon_file:bool = false
		var icon_path : String = ""
		var png_path : String = ""
		var stex_path : String = ""
		for file in content:
			if file.to_lower() == folder_path.to_lower() + "mod.manifest":
				has_mod_manifest = true
				var fp:String = folder_path + file
				manifest_data = __parse_file_as_manifest(fp, true)
				mod_name = manifest_data["mod_information"].get("name",mod_name)
				legacy_mod_version = manifest_data["version"].get("version_string",legacy_mod_version)
				mod_version_major = manifest_data["version"].get("version_major",mod_version_major)
				mod_version_minor = manifest_data["version"].get("version_minor",mod_version_minor)
				mod_version_bugfix = manifest_data["version"].get("version_bugfix",mod_version_bugfix)
				mod_version_metadata = manifest_data["version"].get("version_metadata",mod_version_metadata)
				mod_is_library = manifest_data["tags"].get("is_library_mod",false)
				hide_library = manifest_data["tags"].get("library_hidden_by_default",true)
				if file.to_lower().begins_with("icon"):
					match file.get_extension():
						"png":
							has_icon_file = true
							png_path = fp
						"stex":
							has_icon_file = true
							stex_path = fp
		if stex_path:
			icon_path = stex_path
		elif png_path:
			icon_path = png_path
		var mod_version_array : Array = [mod_version_major,mod_version_minor,mod_version_bugfix]
		var mod_version_string : String = "%s.%s.%s" % mod_version_array
		if mod_version_metadata:
			mod_version_array.append(mod_version_metadata)
			mod_version_string = mod_version_string + "-" + mod_version_metadata
		return {
		script_path:{
			"name":mod_name,
			"priority":constants.get("MOD_PRIORITY",0),
			"version_data":{
				"version_major":mod_version_major,
				"version_minor":mod_version_minor,
				"version_bugfix":mod_version_bugfix,
				"version_metadata":mod_version_metadata,
				"full_version_array":mod_version_array,
				"full_version_string":mod_version_string,
				"legacy_mod_version":legacy_mod_version
			},
			"mod_icon":{
				"has_icon_file":has_icon_file,
				"icon_path":icon_path
			},
			"library_information":{
				"is_library":mod_is_library,
				"keep_library_hidden":hide_library
			},
			"manifest":{
				"has_manifest":has_mod_manifest,
				"manifest_version":manifest_version,
				"manifest_data":manifest_data
			}
		}}
	
	const cached_manifests : Dictionary = Dictionary()
	const cachedManifestKeys:Array = Array()
	
	
	
	static func __parse_file_as_manifest(file_path: String, format_to_manifest_version: bool = true) -> Dictionary:
		var cachevar : String = "%s:%s" % [file_path,format_to_manifest_version]
		if not cachevar in cachedManifestKeys:
			var out : Dictionary = Dictionary()
			var pointers:HevLibPointers = non_static["pointers"]
			var manifest_data : Dictionary = pointers.ConfigDriver.__config_parse(file_path)
			var manifest_version:float = 1.0
			if "manifest_definitions" in manifest_data:
				var nrv = manifest_data["manifest_definitions"].get("manifest_version",manifest_version)
				if nrv is int or nrv is float:
					manifest_version = float(nrv)
				else:
					manifest_version = 1.0
			if format_to_manifest_version:
				var dict_template:Dictionary = BASE_MANIFEST_TEMPLATE.duplicate(true)
				var manifestKeys:PoolStringArray = PoolStringArray(manifest_data.keys())
				match manifest_version:
					1.0:
						dict_template["mod_information"]["id"] = manifest_data["package"].get("id","")
						dict_template["mod_information"]["name"] = manifest_data["package"].get("name","")
						dict_template["mod_information"]["description"] = manifest_data["package"].get("description","MODMENU_DESCRIPTION_PLACEHOLDER")
						
						if manifest_data["package"].get("github_homepage","") is String:
							var url:String = manifest_data["package"]["github_homepage"]
							if url:
								dict_template["links"]["HEVLIB_GITHUB"] = {"URL":pointers.DataFormat.__ensure_string_is_url(url)}
						var discURL:String = manifest_data["package"].get("discord","")
						if discURL:
							dict_template["links"]["HEVLIB_DISCORD"] = {"URL":pointers.DataFormat.__ensure_string_is_url(discURL)}
						var nexusURL:String = manifest_data["package"].get("nexus","")
						if nexusURL:
							dict_template["links"]["HEVLIB_NEXUS"] = {"URL":pointers.DataFormat.__ensure_string_is_url(nexusURL)}
						var donationURL:String = manifest_data["package"].get("donations","")
						if donationURL:
							dict_template["links"]["HEVLIB_DONATIONS"] = {"URL":pointers.DataFormat.__ensure_string_is_url(donationURL)}
						var wikiURL:String = manifest_data["package"].get("wiki","")
						if wikiURL:
							dict_template["links"]["HEVLIB_WIKI"] = {"URL":pointers.DataFormat.__ensure_string_is_url(wikiURL)}
						
					2.0:
						dict_template["mod_information"]["id"] = manifest_data["package"].get("id","")
						dict_template["mod_information"]["name"] = manifest_data["package"].get("name","")
						dict_template["version"]["version_major"] = manifest_data["package"].get("version_major",1)
						dict_template["version"]["version_minor"] = manifest_data["package"].get("version_minor",0)
						dict_template["version"]["version_bugfix"] = manifest_data["package"].get("version_bugfix",0)
						dict_template["version"]["version_metadata"] = manifest_data["package"].get("version_metadata","")
						dict_template["mod_information"]["description"] = manifest_data["package"].get("description","HEVLIB_DESCRIPTION_PLACEHOLDER")
						if manifest_data["package"].get("github","") is Dictionary:
							var url:String = manifest_data["package"]["github"]["link"]
							if url:
								dict_template["links"]["HEVLIB_GITHUB"] = {"URL":pointers.DataFormat.__ensure_string_is_url(url)}
						elif manifest_data["package"].get("github","") is String:
							var url:String = manifest_data["package"]["github"]
							if url:
								dict_template["links"]["HEVLIB_GITHUB"] = {"URL":pointers.DataFormat.__ensure_string_is_url(url)}
						var discURL:String = manifest_data["package"].get("discord","")
						if discURL:
							dict_template["links"]["HEVLIB_DISCORD"] = {"URL":pointers.DataFormat.__ensure_string_is_url(discURL)}
						var nexusURL:String = manifest_data["package"].get("nexus","")
						if nexusURL:
							dict_template["links"]["HEVLIB_NEXUS"] = {"URL":pointers.DataFormat.__ensure_string_is_url(nexusURL)}
						var donationURL:String = manifest_data["package"].get("donations","")
						if donationURL:
							dict_template["links"]["HEVLIB_DONATIONS"] = {"URL":pointers.DataFormat.__ensure_string_is_url(donationURL)}
						var wikiURL:String = manifest_data["package"].get("wiki","")
						if wikiURL:
							dict_template["links"]["HEVLIB_WIKI"] = {"URL":pointers.DataFormat.__ensure_string_is_url(wikiURL)}
						dict_template["mod_information"]["author"] = manifest_data["package"].get("author","Unknown")
						dict_template["mod_information"]["credits"] = manifest_data["package"].get("credits",Array())
						
					2.1:
						# information
						if "mod_information" in manifestKeys:
							dict_template["mod_information"]["id"] = String(manifest_data["mod_information"].get("id",""))
							dict_template["mod_information"]["name"] = String(manifest_data["mod_information"].get("name",""))
							dict_template["mod_information"]["description"] = String(manifest_data["mod_information"].get("description","HEVLIB_DESCRIPTION_PLACEHOLDER"))
							dict_template["mod_information"]["author"] = String(manifest_data["mod_information"].get("author","Unknown"))
							dict_template["mod_information"]["credits"] = PoolStringArray(manifest_data["mod_information"].get("credits",Array()))
						
						# versioning
						if "version" in manifestKeys:
							dict_template["version"]["version_major"] = int(manifest_data["version"].get("version_major",1))
							dict_template["version"]["version_minor"] = int(manifest_data["version"].get("version_minor",0))
							dict_template["version"]["version_bugfix"] = int(manifest_data["version"].get("version_bugfix",0))
							dict_template["version"]["version_metadata"] = String(manifest_data["version"].get("version_metadata",""))
						
						# tags
						if "tags" in manifestKeys:
							var current_tags = manifest_data["tags"].keys()
							if "allow_achievements" in current_tags:
								dict_template["tags"]["TAG_ALLOW_ACHIEVEMENTS"] = {"type":"boolean","value":manifest_data["tags"].get("allow_achievements")}
							if "quality_of_life" in current_tags:
								dict_template["tags"]["TAG_QOL"] = {"type":"boolean","value":manifest_data["tags"].get("quality_of_life")}
							if "is_library_mod" in current_tags:
								dict_template["library"]["is_library"] = manifest_data["tags"].get("is_library_mod")
							if "uses_hevlib_research" in current_tags:
								dict_template["tags"]["TAG_USING_HEVLIB_RESEARCH"] = {"type":"boolean","value":manifest_data["tags"].get("uses_hevlib_research")}
							if "overhaul" in current_tags:
								dict_template["tags"]["TAG_OVERHAUL"] = {"type":"bool","value":manifest_data["tags"].get("overhaul")}
							if "visual" in current_tags:
								dict_template["tags"]["TAG_VISUAL"] = {"type":"bool","value":manifest_data["tags"].get("visual")}
							if "fun" in current_tags:
								dict_template["tags"]["TAG_FUN"] = {"type":"bool","value":manifest_data["tags"].get("fun")}
							if "user_interface" in current_tags:
								dict_template["tags"]["TAG_UI"] = {"type":"bool","value":manifest_data["tags"].get("user_interface")}
							
							if "adds_ships" in current_tags:
								dict_template["tags"]["TAG_ADDS_SHIPS"] = {"type":"array","value":manifest_data["tags"].get("adds_ships")}
							if "adds_equipment" in current_tags:
								dict_template["tags"]["TAG_ADDS_EQUIPMENT"] = {"type":"array","value":manifest_data["tags"].get("adds_equipment")}
							if "adds_gameplay_mechanics" in current_tags:
								dict_template["tags"]["TAG_ADDS_GAMEPLAY_MECHANICS"] = {"type":"array","value":manifest_data["tags"].get("adds_gameplay_mechanics")}
							if "adds_events" in current_tags:
								dict_template["tags"]["TAG_ADDS_EVENTS"] = {"type":"array","value":manifest_data["tags"].get("adds_events")}
							
							if "handle_extra_crew" in current_tags:
								dict_template["tags"]["TAG_HANDLE_EXTRA_CREW"] = {"type":"integer","value":manifest_data["tags"].get("handle_extra_crew")}
						
						# links
						if "links" in manifestKeys:
							if manifest_data["links"].get("github","") is Dictionary:
								var url:String = manifest_data["links"]["github"]["link"]
								if url:
									dict_template["links"]["HEVLIB_GITHUB"] = {"URL":pointers.DataFormat.__ensure_string_is_url(url)}
							elif manifest_data["links"].get("github","") is String:
								var url:String = manifest_data["links"]["github"]
								if url:
									dict_template["links"]["HEVLIB_GITHUB"] = {"URL":pointers.DataFormat.__ensure_string_is_url(url)}
							var discURL:String = manifest_data["links"].get("discord","")
							if discURL:
								dict_template["links"]["HEVLIB_DISCORD"] = {"URL":pointers.DataFormat.__ensure_string_is_url(discURL)}
							var nexusURL:String = manifest_data["links"].get("nexus","")
							if nexusURL:
								dict_template["links"]["HEVLIB_NEXUS"] = {"URL":pointers.DataFormat.__ensure_string_is_url(nexusURL)}
							var donationURL:String = manifest_data["links"].get("donations","")
							if donationURL:
								dict_template["links"]["HEVLIB_DONATIONS"] = {"URL":pointers.DataFormat.__ensure_string_is_url(donationURL)}
							var wikiURL:String = manifest_data["links"].get("wiki","")
							if wikiURL:
								dict_template["links"]["HEVLIB_WIKI"] = {"URL":pointers.DataFormat.__ensure_string_is_url(wikiURL)}
							var bugreportsURL:String = manifest_data["links"].get("bug_reports","")
							if bugreportsURL:
								dict_template["links"]["HEVLIB_BUGREPORTS"] = {"URL":pointers.DataFormat.__ensure_string_is_url(bugreportsURL)}
						
						# manifest definitions
						if "manifest_definitions" in manifestKeys:
							dict_template["manifest_definitions"]["manifest_version"] = float(manifest_data["manifest_definitions"].get("manifest_version",manifest_version))
							dict_template["manifest_definitions"]["dependancy_mod_ids"] = Array(manifest_data["manifest_definitions"].get("dependancy_mod_ids",Array()))
							dict_template["manifest_definitions"]["conflicting_mod_ids"] = Array(manifest_data["manifest_definitions"].get("conflicting_mod_ids",Array()))
							dict_template["manifest_definitions"]["complementary_mod_ids"] = Array(manifest_data["manifest_definitions"].get("complementary_mod_ids",Array()))
					2.2,2.3,2.4:
						if "mod_information" in manifestKeys:
							dict_template["mod_information"]["id"] = String(manifest_data["mod_information"].get("id",""))
							dict_template["mod_information"]["name"] = String(manifest_data["mod_information"].get("name",""))
							dict_template["mod_information"]["description"] = String(manifest_data["mod_information"].get("description","HEVLIB_DESCRIPTION_PLACEHOLDER"))
							dict_template["mod_information"]["brief"] = String(manifest_data["mod_information"].get("brief",""))
							dict_template["mod_information"]["author"] = String(manifest_data["mod_information"].get("author","Unknown"))
							dict_template["mod_information"]["credits"] = PoolStringArray(manifest_data["mod_information"].get("credits",Array()))
						
						if "version" in manifestKeys:
							dict_template["version"]["version_major"] = int(manifest_data["version"].get("version_major",1))
							dict_template["version"]["version_minor"] = int(manifest_data["version"].get("version_minor",0))
							dict_template["version"]["version_bugfix"] = int(manifest_data["version"].get("version_bugfix",0))
							dict_template["version"]["version_metadata"] = String(manifest_data["version"].get("version_metadata",""))
						
						if "manifest_definitions" in manifestKeys:
							dict_template["manifest_definitions"]["manifest_version"] = float(manifest_data["manifest_definitions"].get("manifest_version",manifest_version))
							dict_template["manifest_definitions"]["dependancy_mod_ids"] = Array(manifest_data["manifest_definitions"].get("dependancy_mod_ids",Array()))
							dict_template["manifest_definitions"]["conflicting_mod_ids"] = Array(manifest_data["manifest_definitions"].get("conflicting_mod_ids",Array()))
							dict_template["manifest_definitions"]["complementary_mod_ids"] = Array(manifest_data["manifest_definitions"].get("complementary_mod_ids",Array()))
							dict_template["manifest_definitions"]["manifest_url"] = String(manifest_data["manifest_definitions"].get("manifest_url",""))
							dict_template["manifest_definitions"]["changelog_path"] = String(manifest_data["manifest_definitions"].get("changelog_path",""))
							dict_template["manifest_definitions"]["modlet_priority"] = int(manifest_data["manifest_definitions"].get("modlet_priority",0))
							dict_template["manifest_definitions"]["expected_manifest_path"] = String(manifest_data["manifest_definitions"].get("expected_manifest_path",""))
							dict_template["manifest_definitions"]["minimum_game_version"] = PoolIntArray(manifest_data["manifest_definitions"].get("minimum_game_version",PoolIntArray([0,0,0])))
							dict_template["manifest_definitions"]["maximum_game_version"] = PoolIntArray(manifest_data["manifest_definitions"].get("maximum_game_version",PoolIntArray([0,0,0])))
						
						if "links" in manifestKeys:
							var links:Dictionary = manifest_data["links"]
							var ovLinks:Dictionary = Dictionary()
							for link in links.keys():
								var ld = links[link]
								if ld is Dictionary:
									if "URL" in ld and ld.URL is String:
										ld.URL = pointers.DataFormat.__ensure_string_is_url(ld.URL)
										ovLinks[link] = ld
							if ovLinks:
								dict_template["links"] = ovLinks
						if "tags" in manifestKeys:
							var tags:Dictionary = manifest_data["tags"]
							var ovTags:Dictionary = Dictionary()
							for tag in tags.keys():
								var td = tags[tag]
								if td is Dictionary:
									if "type" in td and "value" in td and td.type is String:
										ovTags[tag] = td
							if ovTags:
								dict_template["tags"] = ovTags
						if "languages" in manifestKeys:
							var languages:Dictionary = manifest_data["languages"]
							for language in languages.keys():
								var ld = languages[language]
								if ld is String:
									dict_template["languages"][language] = ld
								elif ld is int or ld is float:
									dict_template["languages"][language] = str(ld) + "%"
						if "library" in manifestKeys:
							dict_template["library"]["is_library"] = manifest_data["library"].get("is_library",false)
							dict_template["library"]["always_display"] = manifest_data["library"].get("always_display",false)
						if "configs" in manifestKeys:
							var configs:Dictionary = manifest_data["configs"]
							var ovConfigs:Dictionary = Dictionary()
							for section in configs.keys():
								var sec_data:Dictionary = configs[section]
								for cfname in sec_data.keys():
									var cfdata:Dictionary = sec_data[cfname]
									var type:String = cfdata.get("type","")
									if cfdata.get("disabled",false):
										pointers.l("Config %s/%s is disabled, skipping" % [section,cfname],log_header)
									elif not (type or type is String):
										var err:String = "Config %s @ %s does not define a type, skipping" % [cfname,section]
										printerr(err)
										pointers.l(err,log_header)
									else:
										if not section in ovConfigs.keys():
											ovConfigs[section] = {cfname:cfdata}
										else:
											ovConfigs[section][cfname] = cfdata
							if ovConfigs:
								pointers.l("Parsed configs for %s, has disabled configs: [%s]" % [file_path,configs.hash() != ovConfigs.hash()],log_header)
								dict_template["configs"] = ovConfigs
				
				var version_metadata : String = dict_template["version"]["version_metadata"]
				var version_string : String = "%d.%d.%d" % [dict_template["version"]["version_major"],dict_template["version"]["version_minor"],dict_template["version"]["version_bugfix"]]
				if version_metadata:
					version_string += "-" + version_metadata
				dict_template["version"]["version_string"] = version_string
				out = dict_template
			else:
				out = manifest_data
			cached_manifests[cachevar] = out
			cachedManifestKeys.append(cachevar)
		return cached_manifests[cachevar].duplicate(true)
	
	static func __get_mod_by_id(id:String, case_sensitive: bool = true) -> Dictionary:
		var path:String = ""
		var pathSplit:PoolStringArray = PoolStringArray()
		for i in modFiles:
			if id == mod_file_to_id_cache[i]:
				if path:
					var split:PoolStringArray = i.split("/",false)
					var splSize:int = split.size()
					var pthSize:int = pathSplit.size()
					if splSize < pthSize:
						path = i
						pathSplit = split
					elif splSize == pthSize and i < path:
						path = i
						pathSplit = split
				else:
					path = i
					pathSplit = i.split("/",false)
		if path:
			return __get_mod_data()[get_mod_path_from_lowercase_path[path]].duplicate(true)
		return Dictionary()
	
	const tag_data_cache = Dictionary()
	
	static func __get_tags() -> Dictionary:
		if !tag_data_cache:
			var mods : Dictionary = __get_mod_data()
			for mod in __get_mod_list_keys():
				if mods[mod]["manifest"]["has_manifest"]:
					var md : Dictionary = mods[mod]["manifest"]["manifest_data"]
					var id : String = md["mod_information"].get("id","")
					if id:
						var tags : Dictionary = md.get("tags",Dictionary())
						for tag in tags.keys():
							if not tag in tag_data_cache:
								tag_data_cache[tag] = Dictionary()
							if tags[tag] is Dictionary:
								var td : Dictionary = tags[tag].duplicate(true)
								if "value" in td and "type" in td and td.type is String:
									tag_data_cache[tag][id] = td["value"]
		return tag_data_cache.duplicate(true)
	
	static func __get_mod_tags(mod_id: String) -> Dictionary:
		var tag_dict : Dictionary = Dictionary()
		var tags : Dictionary = __get_tags()
		for tag in tags.keys():
			var td : Dictionary = tags[tag]
			if mod_id in td:
				if not tag in tag_dict:
					tag_dict[tag] = null
				tag_dict[tag] = td[mod_id]
		return tag_dict
	
	static func __get_mods_from_tag(tag_name: String) -> Array:
		return __get_tags().get(tag_name,Dictionary()).keys()
	
	static func __get_mods_and_tags_from_tag(tag_name: String) -> Dictionary:
		
		# REFACTOR TO USE __parse_tags
		
		var data : Dictionary = __get_tags().get(tag_name,Dictionary())
		var ex_data : Dictionary = Dictionary()
		for mod in data.keys():
			match tag_name:
				"TAG_ADDS_EQUIPMENT","TAG_ADDS_EVENTS","TAG_ADDS_GAMEPLAY_MECHANICS","TAG_ADDS_SHIPS":
					ex_data[mod] = PoolStringArray(data.get(mod,PoolStringArray()))
				"TAG_HANDLE_EXTRA_CREW":
					var k:int = data.get(mod,24)
					if k > 24:
						ex_data[mod] = k
				_:
					var k:bool = data.get(mod,false)
					ex_data[mod] = k
		return ex_data
	
	static func __get_manifest_section(section: String, mod_id: String = "") -> Dictionary:
		var return_data : Dictionary = Dictionary()
		var manifest_data_cache : Dictionary = __get_manifest_cache()
		if mod_id:
			for mod in manifest_data_cache:
				if mod_id in __get_mod_ids():
					var manifest : Dictionary = manifest_data_cache[mod]
					if "mod_information" in manifest:
						if mod_id in manifest["mod_information"]["id"]:
							if section in manifest:
								return_data = manifest[section]
		else:
			for mod in manifest_data_cache:
				var manifest : Dictionary = manifest_data_cache[mod]
				if section in manifest:
					return_data[mod] = manifest[section]
		return return_data
	
	static func __get_manifest_entry(section: String, entry: String, mod_id: String = ""):
		var manifest_data_cache : Dictionary = __get_manifest_cache()
		var return_data = null
		if mod_id:
			for mod in manifest_data_cache.keys():
				if mod_id in __get_mod_ids():
					var manifest : Dictionary = manifest_data_cache[mod]
					if "mod_information" in manifest:
						if mod_id in manifest["mod_information"]["id"]:
							if section in manifest:
								var sec : Dictionary = manifest[section]
								if entry in sec:
									return_data = sec[entry]
		else:
			var dict : Dictionary = Dictionary()
			for mod in manifest_data_cache.keys():
				var manifest : Dictionary = manifest_data_cache[mod]
				if section in manifest:
					var sec : Dictionary = manifest[section]
					var id : String = manifest_data_cache[mod]["mod_information"]["id"]
					if entry in sec:
						dict[id] = sec[entry]
			return_data = dict
		return return_data
	
	const caches_mod_ids : PoolStringArray = PoolStringArray()
	var needs_mod_id_cache:bool = true
	static func __get_mod_ids() -> PoolStringArray:
		if !caches_mod_ids:
			var mod_data : Dictionary = __get_mod_data()
			for mod in __get_mod_list_keys():
				var data : Dictionary = mod_data[mod]["manifest"]["manifest_data"]
				if "mod_information" in data.keys():
					caches_mod_ids.append(data["mod_information"]["id"])
		return caches_mod_ids
	
	static func __check_complementary():
		var tags : Dictionary = __get_manifest_entry("manifest_definitions","complementary_mod_ids")
		var mKeys:PoolStringArray = __get_mod_list_keys()
		var complimentaries : Dictionary = Dictionary()
		for mod in tags.keys():
			var keys = tags[mod]
			if keys:
				var items : PoolStringArray = PoolStringArray()
				for item in keys:
					if item in mKeys:
						items.append(item)
				if items:
					complimentaries[mod] = items
		return complimentaries
	
	static func __check_mod_complementary(mod_id):
		var complimentaries : PoolStringArray = PoolStringArray()
		var mKeys:PoolStringArray = __get_mod_list_keys()
		for mod in __get_manifest_entry("manifest_definitions","complementary_mod_ids",mod_id):
			if mod in mKeys:
				complimentaries.append(mod)
		return complimentaries
	
	static func __check_dependancies():
		var tags : Dictionary = __get_manifest_entry("manifest_definitions","dependancy_mod_ids")
		var complimentaries : Dictionary = Dictionary()
		for mod in tags.keys():
			var keys = tags[mod]
			if keys:
				var items : PoolStringArray = PoolStringArray()
				for item in keys:
					if not __mod_exists(item):
						items.append(item)
				if items:
					complimentaries[mod] = items
		return complimentaries
	
	static func __check_mod_dependancies(mod_id):
		var complimentaries : PoolStringArray = PoolStringArray()
		for mod in __get_manifest_entry("manifest_definitions","dependancy_mod_ids",mod_id):
			if not __mod_exists(mod):
				complimentaries.append(mod)
		return complimentaries
	
	static func __check_conflicts():
		var tags : Dictionary = __get_manifest_entry("manifest_definitions","conflicting_mod_ids")
		var complimentaries : Dictionary = Dictionary()
		for mod in tags.keys():
			var keys = tags[mod]
			if keys:
				var items : PoolStringArray = PoolStringArray()
				for item in keys:
					if __mod_exists(item):
						items.append(item)
				if items:
					complimentaries[mod] = items
		return complimentaries
	
	static func __check_mod_conflicts(mod_id):
		var complimentaries : PoolStringArray = PoolStringArray()
		for mod in __get_manifest_entry("manifest_definitions","conflicting_mod_ids",mod_id):
			if __mod_exists(mod):
				complimentaries.append(mod)
		return complimentaries
	
	static func __parse_tags(tag_data) -> Dictionary:
		var tag_dict : Dictionary = Dictionary()
		for entry in tag_data.keys():
			if not tag_data[entry] is Dictionary:
				return tag_dict
			match tag_data[entry].get("type","null_type").to_lower():
				"boolean","bool":
					tag_dict[entry] = bool(tag_data[entry].get("value"))
				"string","str":
					tag_dict[entry] = str(tag_data[entry].get("value"))
				"integer","int":
					tag_dict[entry] = int(tag_data[entry].get("value"))
				"array","arr":
					tag_dict[entry] = Array(tag_data[entry].get("value"))
				_:
					tag_dict[entry] = tag_data[entry].get("value")
		return tag_dict
	
	
	
	static func __have_mods_updated() -> Dictionary:
		if DO_TEST_MOD_UPDATES:
			var out:Dictionary = Dictionary()
			var all_mods : Dictionary = __get_mod_data()
			for mod in __get_mod_list_keys():
				var data : Dictionary = all_mods[mod]
				if data["manifest"]["has_manifest"] and data["manifest"]["manifest_version"] >= 2.0:
					var manifest : Dictionary = data["manifest"]["manifest_data"]
					var info : Dictionary = manifest["mod_information"]
					var version : Dictionary = manifest["version"]
					out[info["id"]] = {
						"name":info["name"],
						"version":{
							"major":version["version_major"],
							"minor":version["version_minor"],
							"bugfix":version["version_bugfix"]
						},
						"path":data["file_path"],
						"changelog":manifest["manifest_definitions"]["changelog_path"]
					}
			return out
		if not non_static["self"].haveModsChanged:
			return Dictionary()
		return mod_changes_cache.duplicate(true)
	
	const mod_changes_cache = Dictionary()
	
	
	static func __get_mod_versions() -> Dictionary:
		var last : Dictionary = Dictionary()
		var file:File = File.new()
		if file.file_exists(LAST_LAUNCH_MODS_PATH):
			file.open(LAST_LAUNCH_MODS_PATH,File.READ)
			last = JSON.parse(file.get_as_text()).result
			file.close()
		var all_mods : Dictionary = __get_mod_data()
		for mod in __get_mod_list_keys():
			var data : Dictionary = all_mods[mod]
			if data["manifest"]["has_manifest"] and data["manifest"]["manifest_version"] >= 2.0:
				var manifest : Dictionary = data["manifest"]["manifest_data"]
				var info : Dictionary = manifest["mod_information"]
				var version : Dictionary = manifest["version"]
				var id:String = info["id"]
				if (not id in last or (
					(version["version_major"] != last[id]["version"]["major"])
					 or 
					(version["version_minor"] != last[id]["version"]["minor"])
					 or 
					(version["version_bugfix"] != last[id]["version"]["bugfix"])
				)):
					mod_changes_cache[id] = {
						"name":info["name"],
						"version":{
							"major":version["version_major"],
							"minor":version["version_minor"],
							"bugfix":version["version_bugfix"]
						},
						"path":data["file_path"],
						"changelog":manifest["manifest_definitions"]["changelog_path"]
					}
		
		
		var mods : Dictionary = Dictionary()
		for mod in __get_mod_list_keys():
			var data : Dictionary = all_mods[mod]
			if data["manifest"]["has_manifest"] and data["manifest"]["manifest_version"] >= 2.0:
				var manifest : Dictionary = data["manifest"]["manifest_data"]
				var info : Dictionary = manifest["mod_information"]
				var version : Dictionary = manifest["version"]
				mods[info["id"]] = {"name":info["name"],"version":{"major":version["version_major"],"minor":version["version_minor"],"bugfix":version["version_bugfix"]}}
		file.open(LAST_LAUNCH_MODS_PATH,File.WRITE)
		file.store_string(JSON.print(mods))
		file.close()
		return mods
	
	static func __parse_changelogs(file_path):
#		var c:ConfigFile = ConfigFile.new()
#		c.load(file_path)
		var file:File = File.new()
		file.open(file_path,File.READ)
		var text:String = file.get_as_text(true)
		file.close()
		var cv:Dictionary = Dictionary()
		
		var lastVer:String = ""
		for line in text.split("\n"):
			var noedge:String = line.strip_edges()
			if noedge.begins_with(";"):
				continue
			if noedge.begins_with("[") and noedge.ends_with("]"):
				var version:String = noedge.substr(1,noedge.length() - 2)
				if not version in cv:
					lastVer = version
					cv[version] = Dictionary()
				else:
					lastVer = ""
				continue
			if lastVer and noedge:
				var index:String = noedge.split("=")[0]
				var entry:String = noedge.substr(index.length() + 1)
				if entry.begins_with("\""):
					entry = entry.substr(1)
					if entry.ends_with("\""):
						entry = entry.substr(0,entry.length() - 1)
				cv[lastVer][index] = entry
		
		var changelog : Dictionary = Dictionary()
#		var versions : Array = c.get_sections()
		var versions : Array = cv.keys()
#		versions.resize(clamp(versions.size(),0,10))
		var spacing : String = "  "
		var spc:String = non_static["pointers"].ConfigDriver.__get_value("ModMenu2","MODMENU2_CONFIG_GENERAL","changelog_spacing_size","")
		if spc:
			spacing = spc
		for version in versions:
			changelog[version] = Array()
			var keys : Array = cv[version].keys()
			keys.sort_custom(non_static["self"],"changelogKeySorter")
			keys = filterChangelogs(keys)

			for key in keys:
				var entry:String = str(cv[version][key])
				var spacer:String = ""
				for i in (key.split(".").size() - 1):
					spacer += spacing
				changelog[version].append(spacer + entry)
		return changelog
	
	static func changelogKeySorter(al:String,bl:String) -> bool:
		var aList:PoolStringArray = al.split(".")
		var bList:PoolStringArray = bl.split(".")
		var aSize:int = aList.size()
		var bSize:int = bList.size()
		var counter:int = aSize if aSize < bSize else bSize
		for i in counter:
			var a:String = aList[i]
			var b:String = bList[i]
			if a != b:
				return a < b
		return aSize < bSize
	
	static func filterChangelogs(keys:Array) -> Array:
		if keys.size() > 1:
			var counter:int = 0
			var total:int = keys.size() - 1
			while counter < total:
				var aList:PoolStringArray = keys[counter].split(".")
				counter += 1
				var bList:PoolStringArray = keys[counter].split(".")
				var aSize:int = aList.size()
				var bSize:int = bList.size()
				if(aSize == bSize):
					var aItem:int = int(aList[aSize - 1]) + 1
					var bItem:int = int(bList[bSize - 1])
					if(bItem > aItem):
						keys.remove(counter)
						total -= 1
		return keys
	
	static func __get_manifest_cache() -> Dictionary:
		return cached_manifests
	
	var need_modmain_file_cache:bool = true
	const modmain_file_list : PoolStringArray = PoolStringArray()
	static func __get_modmain_files() -> PoolStringArray:
		if !modmain_file_list:
			__get_mod_files()
		return modmain_file_list
	
	const active_modlet_file_list : PoolStringArray = PoolStringArray()
	const all_modlet_file_list : PoolStringArray = PoolStringArray()
	const all_modlet_definitions : Dictionary = Dictionary()
	
	const cached_modlets : Dictionary = Dictionary()
	
	static func __get_all_modlets(only_show_installed : bool = true,recache : bool = false) -> Dictionary:
		var pointers:HevLibPointers._ConfigDriver = non_static["pointers"].ConfigDriver
		if cached_modlets:
			var modletCheck:Dictionary = pointers.__get_value("HevLib","modlets","seen_modlets",Dictionary())
			for modlet in modletCheck.keys():
				if modletCheck[modlet] != cached_modlets[modlet]:
					recache = true
					break
		if recache:
			if not all_modlet_file_list:
				var manifests:PoolStringArray = __get_manifest_files()
				var manifest_checks : Array = Array()
				for i in manifests:
					manifest_checks.append(i.to_lower())
				for r in __get_modmain_files():
					r=r.to_lower()
					var i : String = r.get_file()
					if i.get_extension() == "gd" and i.begins_with("modmain"):
						var mr : String = r.get_base_dir() + "/mod.manifest"
						if mr in manifest_checks:
							manifest_checks.erase(mr)
				var ov : Array = Array()
				for i in manifests:
					if i.to_lower() in manifest_checks:
						ov.append(i)
				ov.sort_custom(non_static["self"],"sort_modlet_files")
				all_modlet_file_list.clear()
				all_modlet_file_list.append_array(PoolStringArray(ov))
			cached_modlets.clear()
			var allowed_modlets:Dictionary = pointers.__get_value("HevLib","modlets","seen_modlets",Dictionary())
			active_modlet_file_list.clear()
			for mod in all_modlet_file_list:
				if not mod in allowed_modlets:
					allowed_modlets[mod] = true
				if allowed_modlets[mod]:
					active_modlet_file_list.append(mod)
			pointers.__store_value("HevLib","modlets","seen_modlets",allowed_modlets)
			cached_modlets.clear()
			cached_modlets.merge(allowed_modlets)
		var out : Dictionary = cached_modlets.duplicate(true)
		if only_show_installed:
			for mod in cached_modlets:
				if not mod in active_modlet_file_list:
					out.erase(mod)
		return out
	
	static func sort_modlet_files(a:String,b:String):
		var aPrio:int = __parse_file_as_manifest(a)["manifest_definitions"]["modlet_priority"]
		var bPrio:int = __parse_file_as_manifest(b)["manifest_definitions"]["modlet_priority"]
		if aPrio != bPrio:
			return aPrio < bPrio
		if a != b:
			return a < b
		return false
	
	static func __get_modlet_files() -> PoolStringArray:
		__get_all_modlets()
		return active_modlet_file_list
	
	const cached_mod_files : PoolStringArray = PoolStringArray()
	static func __get_mod_files():
		if !cached_mod_files:
			var restrict_to_modmains : PoolStringArray = PoolStringArray()
			var pointers:HevLibPointers = non_static["pointers"]
			if pointers.is_editor:
				var file:File = File.new()
				file.open("res://ModLoader.gd",File.READ)
				var tex:String = file.get_as_text(true)
				file.close()
				if "var addedMods = [" in tex:
					var capturing:bool = false
					for a in tex.split("\n"):
						if not capturing and a.begins_with("var addedMods = ["):
							capturing = true
						elif capturing:
							var ab:String = a.strip_edges()
							if ab.begins_with("#"):
								var br:String = ab.split("#")[1].strip_edges()
								if br.begins_with("\""):
									restrict_to_modmains.append(br.split("\"")[1].get_base_dir() + "/")
								elif br.begins_with("\'"):
									restrict_to_modmains.append(br.split("\'")[1].get_base_dir() + "/")
							elif ab.begins_with("]"):
								break
			var sm:Dictionary = pointers.ConfigDriver.__get_value("HevLib","modlets","seen_modlets",Dictionary())
			for a in sm.keys():
				var bd:String = a.get_base_dir() + "/"
				if not sm[a]:
					if bd in restrict_to_modmains:
						breakpoint
					restrict_to_modmains.append(bd)
				elif bd in restrict_to_modmains:
					restrict_to_modmains.remove(restrict_to_modmains.find(bd))
			var arr1 : PoolStringArray = siftFolderStructureForModFiles(restrict_to_modmains)
			if pointers.is_editor:
				var arr2 : PoolStringArray = PoolStringArray()
				var excludeDirs:PoolStringArray = PoolStringArray()
				for i in arr1:
					var r:String = i.get_file().to_lower()
					if r.begins_with("modmain") and r.ends_with(".gd"):
						var can : Script = load(i)
						if not can.can_instance():
							var vdir:String = i.get_base_dir()
							excludeDirs.append(vdir.to_lower())
							pointers.l("Excluding mod directoy %s due to malformatted mod main" % vdir,log_header)
				if excludeDirs:
					for file in arr1:
						var vr:String = file.get_base_dir().to_lower()
						if not vr in excludeDirs:
							arr2.append(file)
					cached_mod_files.append_array(arr2)
				else:
					cached_mod_files.append_array(arr1)
			else:
				cached_mod_files.append_array(arr1)
			for r in cached_mod_files:
				var i : String = r.get_file().to_lower()
				var ext:String = i.get_extension()
				if ext == "manifest" and i.begins_with("mod"):
					cached_manifest_files.append(r)
				elif ext == "gd" and i.begins_with("modmain"):
					modmain_file_list.append(r)
				elif ext in non_static["pointers"].SUPPORTED_IMAGE_EXTENSIONS and i.begins_with("icon"):
					cached_icon_files.append(r)
		return cached_mod_files
	
	static func siftFolderStructureForModFiles(restrictions:PoolStringArray,path:String = "res://") -> PoolStringArray:
		var out:PoolStringArray = PoolStringArray()
		var dir:Directory = Directory.new()
		if dir.open(path) == OK:
			dir.list_dir_begin(true)
			var file:String = dir.get_next()
			while file:
				var pn:String = path + file
				if dir.current_is_dir():
					if (!restrictions or not pn + "/" in restrictions):
						out.append_array(siftFolderStructureForModFiles(restrictions,pn + "/"))
				else:
					var f:String = file.to_lower()
					if ((f.begins_with("modmain") and f.get_extension() == "gd") or (f.begins_with("mod") and f.get_extension() == "manifest") or (f.begins_with("icon") and (f.get_extension() in non_static["pointers"].SUPPORTED_IMAGE_EXTENSIONS))):
						out.append(pn)
				file = dir.get_next()
			dir.list_dir_end()
		return out
	
	static func siftFolderStructureForModFiles_legacy(structure:Dictionary,path:String = "res://",restricted_to_modmains : PoolStringArray = PoolStringArray()) -> PoolStringArray:
		var out : PoolStringArray = PoolStringArray()
		for i in structure.keys():
			if i.ends_with("/") and (!restricted_to_modmains or path + i in restricted_to_modmains):
				out.append_array(siftFolderStructureForModFiles_legacy(structure[i],path + i,restricted_to_modmains))
			else:
				var f : String = i.to_lower()
				if ((f.begins_with("modmain") and f.ends_with(".gd")) or (f.begins_with("mod") and f.ends_with(".manifest")) or (f.begins_with("icon") and (f.get_extension().to_lower() in non_static["pointers"].SUPPORTED_IMAGE_EXTENSIONS))):
					out.append(path + i)
		return out
	
	const cached_manifest_files : PoolStringArray = PoolStringArray()
	static func __get_manifest_files() -> PoolStringArray:
		if !cached_manifest_files:
			__get_mod_files()
		return cached_manifest_files
	
	const cached_icon_files : PoolStringArray = PoolStringArray()
	static func __get_icon_files() -> PoolStringArray:
		if !cached_icon_files:
			__get_mod_files()
		return cached_icon_files
	
	static func __load_modlets() -> void:
		var pointers:HevLibPointers = non_static["pointers"]
		var base:_ManifestV2 = non_static["self"]
		pointers.l("Loading modlet resources with order-safe mode.","pointers.SafeMode")
		pointers.Scripting.make_mineral_scripting()
		pointers.Equipment.__make_upgrades_scene()
		pointers.NodeAccess.__dynamic_crew_expander()
		var load_stash:Array = Array()
		for modlet in __get_modlet_files():
			var mod_data:Dictionary = pointers.ManifestV2.__get_mod_by_id(pointers.ManifestV2.__match_mod_file_path_to_id(modlet))
			var resources : Dictionary = mod_data["drivers"].get("LOAD_RESOURCES.gd",Dictionary()).get("LOAD_RESOURCES",Dictionary())
			if resources:
				load_stash.append({
					"object":base,
					"method":"process_mod_data_for_load",
					"args":[resources,modlet,pointers,float(mod_data["priority"])]
				})
		var cvr:Array = [
			["res://HevLib/scenes/minerals/AstrogatorPanel.gd", -INF, "res://hud/AstrogatorPanel.gd"],
			["res://HevLib/scenes/minerals/OMS.gd", -INF, "res://hud/OMS.gd"],
			["res://HevLib/scenes/minerals/CargoScanner.gd", -INF, "res://hud/CargoScanner.gd"],
			["res://HevLib/scenes/minerals/ProcessedCargoManifest.gd", -INF, "res://hud/trtl/ProcessedCargoManifest.gd"],
			["res://HevLib/scenes/minerals/TheRing.gd", -INF, "res://TheRing.gd"],
			["res://HevLib/scenes/research/Enceladus.gd", -INF, "res://enceladus/Enceladus.gd"],
			["res://HevLib/scenes/research/CurrentGame.gd", -INF, "res://CurrentGame.gd"],
			["res://HevLib/scenes/equipment/SystemShipUpgradeUI.gd", -INF, "res://enceladus/SystemShipUpgradeUI.gd"],
			["res://HevLib/scenes/equipment/SystemBuyUI.gd", -INF, "res://enceladus/SystemBuyUI.gd"],
			["res://HevLib/scenes/equipment/UpgradeGroup.gd", -INF, "res://enceladus/UpgradeGroup.gd"],
			["res://HevLib/scenes/equipment/ThrusterSlot.gd", -INF, "res://ships/modules/ThrusterSlot.gd"],
			["res://HevLib/scenes/equipment/thruster.gd", -INF, "res://sfx/thruster.gd"],
			["res://HevLib/scenes/weaponslot/weapon_slot_handler.gd", -INF, "res://ships/WeaponSlot.gd"],
			["res://HevLib/scenes/equipment/ShipModificationDriver/AddNodes.gd", -INF, "res://ships/ship-ctrl.gd"],
			["res://HevLib/scenes/equipment/ShipModificationDriver/InternalStorageMod.gd", -INF, "res://ships/ship-ctrl.gd"],
			["res://HevLib/scenes/ship_driver/Shipyard.gd", -INF, "res://ships/Shipyard.gd"],
			["res://HevLib/scenes/ship_driver/CurrentGame.gd", -INF, "res://CurrentGame.gd"],
			["user://cache/Minerals/cg.gd", -INF, "res://CurrentGame.gd"],
			["user://cache/Minerals/as.gd", -INF, "res://AsteroidSpawner.gd"],
			["user://cache/Variable_Fetch/derelict_expansion.tscn", -INF, "res://comms/conversation/subtrees/DIALOG_DERELICT_RANDOM.tscn"],
			["user://cache/Variable_Fetch/upgrades.tscn", -INF, "res://enceladus/Upgrades.tscn"],
			["user://cache/Variable_Fetch/ship_limitations.tscn", -INF, "res://enceladus/Upgrades.tscn"],
			["res://HevLib/scenes/ship_driver/TheRing.gd", -INF, "res://TheRing.gd"],
			["res://HevLib/scripts/Namer.gd", -INF, "res://namer/Namer.gd"],
			["res://HevLib/events/TheRing.gd", -INF, "res://TheRing.gd"],
			["res://HevLib/events/Game.gd", -INF, "res://Game.gd"],
			["res://HevLib/events/controls/camera.gd", -INF, "res://ships/camera.gd"],
			["res://HevLib/events/controls/ship-ctrl.gd", -INF, "res://ships/ship-ctrl.gd"],
			["res://HevLib/events/controls/CurrentGame.gd", -INF, "res://CurrentGame.gd"],
			["res://HevLib/events/chaos_map/RingTelescopeView.tscn", -INF, "res://hud/components/RingTelescopeView.tscn"],
			["user://cache/Variable_Fetch/st.gd", INF, "res://Settings.gd"],
			["res://HevLib/events/custom_events/TheRing.gd", -INF, "res://TheRing.gd"],
			["res://HevLib/scenes/notification_driver/Notifications.tscn", -INF, "res://achievement/Notifications.tscn"],
			["res://HevLib/scenes/notification_driver/CurrentGame.gd", -INF, "res://CurrentGame.gd"],
			["res://HevLib/scenes/better_title_screen/SaveSlotButton.gd", -INF, "res://SaveSlotButton.gd"],
			["res://HevLib/scenes/better_title_screen/CurrentlyPlaying.gd", -INF, "res://menu/CurrentlyPlaying.gd"],
			["res://HevLib/ui/ExtensionPopup.gd", -INF, "res://menu/ExtensionPopup.gd"],
			["res://HevLib/ui/mod_menu/titlescreen/TitleMenu.gd", -INF, "res://menu/TitleMenu.gd"],
			["res://HevLib/ui/mod_menu/titlescreen/DLClist.gd", -INF, "res://tools/DLClist.gd"],
			["res://HevLib/scripts/transit_tips/TransitTip.gd", -INF, "res://codex/TransitTip.gd"],
			["res://HevLib/scripts/easters/Screensaver.gd", -INF, "res://Screensaver.gd"],
			["res://HevLib/scripts/easters/TitleMenu.gd", -INF, "res://menu/TitleMenu.gd"],
			["res://HevLib/scenes/minerals/Summary.gd", -INF, "res://enceladus/Summary.gd"],
			["res://HevLib/scenes/rpc/Crew.gd", -INF, "res://enceladus/Crew.gd"],
			["res://HevLib/scenes/rpc/Dealer.gd", -INF, "res://enceladus/Dealer.gd"],
			["res://HevLib/scenes/rpc/DiveTarget.gd", -INF, "res://enceladus/DiveTarget.gd"],
			["res://HevLib/scenes/rpc/Enceladus.gd", -INF, "res://enceladus/Enceladus.gd"],
			["res://HevLib/scripts/Screensaver.gd", 1000, "res://Screensaver.gd"],
			["res://HevLib/scenes/rpc/Game.gd", -INF, "res://Game.gd"],
			["res://HevLib/scenes/rpc/Logs.gd", -INF, "res://enceladus/Logs.gd"],
			["res://HevLib/scenes/rpc/MineralMarket.gd", -INF, "res://enceladus/MineralMarket.gd"],
			["res://HevLib/scenes/rpc/Music.gd", -INF, "res://Music.gd"],
			["res://HevLib/scenes/rpc/PreFlightInspection.gd", -INF, "res://enceladus/PreFlightInspection.gd"],
			["res://HevLib/scenes/rpc/Repairs.gd", -INF, "res://enceladus/Repairs.gd"],
			["res://HevLib/scenes/rpc/Services.gd", -INF, "res://enceladus/Services.gd"],
			["res://HevLib/scenes/rpc/SimulationLayer.gd", -INF, "res://enceladus/Simulator/SimulationLayer.gd"],
			["res://HevLib/scenes/rpc/Summary.gd", -INF, "res://enceladus/Summary.gd"],
			["res://HevLib/scenes/rpc/TitleMenu.gd", -INF, "res://menu/TitleMenu.gd"],
			["res://HevLib/scenes/rpc/Tuning.gd", -INF, "res://enceladus/Tuning.gd"],
			["res://HevLib/scenes/rpc/Upgrades.gd", -INF, "res://enceladus/Upgrades.gd"],
			["res://HevLib/scenes/keymapping/bind_displays/AnalogAxisDisplay.gd", -INF, "res://hud/components/AnalogAxisDisplay.gd"],
			["res://HevLib/scenes/keymapping/bind_displays/GamepadKeybindDisplay.gd", -INF, "res://hud/components/GamepadKeybindDisplay.gd"],
			["res://HevLib/scenes/keymapping/bind_displays/KeybindDisplay.gd", -INF, "res://hud/components/KeybindDisplay.gd"],
			["res://HevLib/scenes/keymapping/bind_displays/MousebindDisplay.gd", -INF, "res://hud/components/MousebindDisplay.gd"],
			["res://HevLib/scripts/Boot.gd", -INF, "res://Boot.gd"],
			["res://HevLib/scenes/minerals/multiminerals/mineral.gd", -INF, "res://asteroids/mineral.gd"],
			["res://HevLib/scenes/minerals/multiminerals/MineralProcessingUnit.gd", -INF, "res://ships/modules/MineralProcessingUnit.gd"],
			["res://HevLib/scenes/minerals/multiminerals/AsteroidSpawner.gd", -INF, "res://AsteroidSpawner.gd"],
			["res://HevLib/scenes/service_driver/Services.gd", -INF, "res://enceladus/Services.gd"],
		]
		for r in pointers.Threading.__request_multiple_threads(load_stash):
			cvr.append_array(r)
		var ovr:Dictionary = Dictionary()
		for f in cvr:
			var extra:String = f[2]
			if not extra in ovr: ovr[extra] = [f]
			else: ovr[extra].append(f)
		var LO:Array = pointers.SafeMode.vanilla_load_order
		var order:Array = Array()
		for i in ovr:
			var paths:Array = ovr[i]
			paths.sort_custom(base,"sortModPathOrder")
			order.append([i,paths,LO.find(i)])
		order.sort_custom(base,"sortModLoadOrder")
		for r in order:
			for i in r[1]:
				var path:String = i[0]
				var ext:String = path.get_extension().to_lower()
				if (ext == "gd" or ext == "gdc"): pointers.DataFormat.__override_script(path,r[0],pointers)
				else: pointers.DataFormat.__replace_resource(path,r[0],pointers)
		pointers.Equipment.__post_load_handling()
		pointers.l("%d modlet resources loaded." % order.size(),"pointers.SafeMode")
	
	static func process_mod_data_for_load(resources:Dictionary,modlet:String,pointers:HevLibPointers,priority:float):
		var out:Array = Array()
		var file:File = File.new()
		var mbd:String = modlet.get_base_dir()
		for resource in resources.keys():
			var subdata:Dictionary = resources[resource]
			var path:String = resource if resource.begins_with("res://" ) else (mbd + ("" if resource.begins_with("/") else "/") + resource)
			if pointers.ConfigDriver.__validate_dictionary(subdata) and pointers.FileAccess.__file_exists(path):
				var ed:String = subdata.get("original_path","")
				if ed:
					if not ed.begins_with("res:/"):
						ed = "res:/" + ("" if ed.begins_with("/") else "/") + ed
				elif path.get_extension().to_lower() == "gd":
					file.open(path,File.READ)
					var data:String = file.get_as_text(true)
					file.close()
					if "extends \"" in data:
						for line in data.split("\n"):
							if line.begins_with("extends \""):
								ed = line.split("\"")[1]
								break
					else: ed = "res:/" + path.split(mbd)[1]
				else: ed = "res:/" + path.split(mbd)[1]
				out.append([path,subdata.get("priority",priority),ed])
		return out
	static func sortModLoadOrder(a:Array,b:Array) -> bool:
		return a[2] < b[2]
	
	static func sortModPathOrder(a:Array,b:Array) -> bool:
		var oa:float = a[1]
		var ob:float = b[1]
		return oa < ob if (oa != ob) else (a[2].to_ascii() < b[2].to_ascii())
	
	const disabledModletCache:Dictionary = Dictionary()
	
	static func __get_disabled_modlets() -> Dictionary:
		if not disabledModletCache:
			var all_modlets:Dictionary = __get_all_modlets(false)
			for modlet in all_modlets.keys():
				if not all_modlets[modlet] and non_static["pointers"].FileAccess.__file_exists(modlet):
					disabledModletCache[modlet] = __parse_file_as_manifest(modlet).get("mod_information",Dictionary()).get("id","%s_MISSING_ID" % modlet)
		return disabledModletCache.duplicate(true)
	
	static func __mod_exists(check_data) -> bool:
		var has:bool = false
		var current_mod_ids:PoolStringArray = __get_mod_ids()
		if not check_data:return false
		if check_data is String:
			if check_data in current_mod_ids:
				has = true
			elif check_data in __get_mod_list_keys():
				has = true
		elif check_data is Array:
			if check_data:
				for i in check_data:
					if __mod_exists(i):
						has = true
						break
		elif check_data is Dictionary:
			var MID:String = check_data.get("mod_id","")
			var MDM:String = check_data.get("mod_main","")
			if MID:
				var moddata:Dictionary = __get_mod_by_id(MID)
				if moddata:
					var t1:bool = true
					var ver_info:Array = moddata["version_data"]["full_version_array"]
					if("maximum_version" in check_data or "max_version" in check_data):
						var minimum = check_data.get("maximum_version",check_data.get("max_version",[0,0,0]))
						var mnm = null
						if minimum is PoolIntArray or minimum is Array:
							if minimum.size() > 2:
								mnm = minimum
						elif minimum is Vector3:
							mnm = minimum
						elif minimum is Dictionary:
							var minarr = Vector3.ZERO
							minarr[0] = int(minimum.get("major",0))
							minarr[1] = int(minimum.get("minor",0))
							minarr[2] = int(minimum.get("bugfix",0))
							mnm = minarr
						if mnm != null:
							for i in 3:
								if t1:
									var a = int(ver_info[i])
									var b = int(mnm[i])
									if a > b:
										t1 = false
									elif a < b:
										break
					if t1 and ("minimum_version" in check_data or "min_version" in check_data):
						var minimum = check_data.get("minimum_version",check_data.get("min_version",[0,0,0]))
						var mnm = null
						if minimum is PoolIntArray or minimum is Array:
							if minimum.size() > 2:
								mnm = minimum
						elif minimum is Vector3:
							mnm = minimum
						elif minimum is Dictionary:
							var minarr = Vector3.ZERO
							minarr[0] = int(minimum.get("major",0))
							minarr[1] = int(minimum.get("minor",0))
							minarr[2] = int(minimum.get("bugfix",0))
							mnm = minarr
						if mnm != null:
							for i in 3:
								if t1:
									var a = int(ver_info[i])
									var b = int(mnm[i])
									if a < b:
										t1 = false
									elif a > b:
										break
					has = t1
			elif MDM and MDM in __get_mod_list_keys():
				has = true
		return has
	
	static func __match_mod_file_path_to_id(file_path:String) -> String:
		if !mod_file_to_id_cache:
			__get_mod_data()
		return mod_file_to_id_cache.get(file_path.to_lower(),"")

class _Math:
	const non_static = Dictionary()
	func _init(p):
		non_static["pointers"] = p
	
	const log_header = "pointers.Math"
	
	static func __rotate_point(point : Vector2, angle : float, degrees : bool = true) -> Vector2:
		if degrees:angle = deg2rad(angle)
		return Vector2((point.x*cos(-angle))-(point.y*sin(-angle)),(point.y*cos(-angle))+(point.x*sin(-angle)))
	
	static func __factorial(n:int) -> int:
		var holdvalue:int = 0
		var boolis:bool = true
		var s:int = sign(n)
		n = abs(n)
		if n < 2:return holdvalue * s
		while n > 0:
			if boolis:
				boolis = false
				holdvalue = n
			else:
				holdvalue *= n
			n -= 1
		return holdvalue * s
	
	static func __get_unique_pairs(max_value: int) -> Array:
		var pairs : Array = Array()
		for i in (max_value + 1):
			for j in range(i + 1, max_value):
				pairs.append(PoolIntArray([i, j]))
		return pairs
	
	static func __mirror_vector(point:Vector2, reflection_angle:float = 0.0, use_degrees:bool = false, angle_offset:Vector2 = Vector2.ZERO, scale:Vector2 = Vector2.ONE) -> Vector2:
		if use_degrees:
			reflection_angle = deg2rad(reflection_angle)
		point *= scale
		reflection_angle = -reflection_angle - (PI/2.0)
		var a:float = -sin(reflection_angle)
		var b:float = cos(reflection_angle)
		var t:float = (-2.0 * ((a * point.x) + (b * point.y) + (-((a * angle_offset.x) + (b * angle_offset.y))))) / ((a * a) + (b * b))
		return Vector2(point.x + (a * t), point.y + (b * t)) / scale
	
	static func __mirror_vector_array(points:PoolVector2Array, reflection_angle:float = 0.0, use_degrees:bool = false, angle_offset:Vector2 = Vector2.ZERO, scale:Vector2 = Vector2.ONE) -> PoolVector2Array:
		for i in points.size():
			points[i] = __mirror_vector(points[i],reflection_angle,use_degrees,angle_offset,scale)
		return points
	
	static func __rand_string(length:int = 16) -> String:
		if length < 1:
			return ""
		length *= 2
		var buffer:PoolByteArray=PoolByteArray()
		buffer.resize(length + 12)
		var out:String = ""
		for i in length:
			out += char(buffer[i + 6])
		return out
	
	static func __convert_arr_to_vec2arr(array: Array) -> PoolVector2Array:
		var converted:PoolVector2Array = PoolVector2Array()
		var size:int = int(floor(array.size() / 2.0))
		converted.resize(size)
		for r in size:
			var index:int = r * 2
			converted[r] = Vector2(float(array[index]),float(array[index + 1]))
		return converted
	
	
	
	static func __imax(a:int,b:int) -> int:
		return a if a > b else b
	
	static func __imin(a:int,b:int) -> int:
		return a if a < b else b
	
	static func __iclamp(value:int,minimum:int,maximum:int) -> int:
		return __imax(__imin(value,maximum),minimum)
	
	static func __idivide(num:int,denom:int) -> int:
		if denom == 0:
			non_static["pointers"].l(DIV_ZERO_ERR,log_header)
			printerr(DIV_ZERO_ERR)
			return 0
		if __are_float_operands_integer_equivalent(num,denom):
			return int(float(num)/denom)
		elif denom == 1:
			return num
		elif denom == -1:
			if num == INT64_MIN:
				non_static["pointers"].l(INT_OVERFLOW_ERR,log_header)
				printerr(INT_OVERFLOW_ERR)
				return INT64_MAX
			return -num
		var r:int = num if num < 0 else -num
		var d:int = denom if denom < 0 else -denom
		var shift:int = 0
		var half:int = (INT64_MIN >> 1) - 1
		while d > half and (d << 1) > (r-1):
			d <<= 1
			shift += 1
		var nq:int = 0
		while shift > -1:
			if d > (r-1):
				r -= d
				nq -= 1 << shift
			d >>= 1
			shift -= 1
		if (num < 0) == (denom < 0):
			return -nq
		return nq
	
	static func __is_float_integer_equivalent(num:float) -> bool:
		return abs(num) < FLOAT_TO_INT_PRECISION_LIMIT
	
	static func __are_float_operands_integer_equivalent(a:int,b:int) -> bool:
		return (abs(a) < FLOAT_TO_INT_PRECISION_LIMIT) and (abs(b) < FLOAT_TO_INT_PRECISION_LIMIT)
	
	static func __make_semicircle(radius:float,start:float,end:float,step:float,degrees:bool = true,anticlockwise:bool = true,include_center:bool = true) -> PoolVector2Array:
		var out:PoolVector2Array = PoolVector2Array()
		step = deg2rad(abs(step)) if degrees else abs(step)
		if step <= 0:
			return out
		if include_center:
			out.append(Vector2.ZERO)
		start = fposmod(deg2rad(start) if degrees else start,TAU)
		end = fposmod(deg2rad(end) if degrees else end,TAU)
		if anticlockwise:
			if end > start:
				end -= TAU
			var cd:float = start
			while cd > end:
				out.append(__rotate_point(Vector2.UP * radius,cd,false))
				cd -= step
			out.append(__rotate_point(Vector2.UP * radius,end + 0.0001,false))
		else:
			if start > end:
				start -= TAU
			var cd:float = start
			while cd < end:
				out.append(__rotate_point(Vector2.UP * radius,cd,false))
				cd += step
			out.append(__rotate_point(Vector2.UP * radius,end - 0.0001,false))
		return out
	

class _NetIO:
	# https://github.com/Abdera7mane/Godot-SimpleHTTPClient
	
	const non_static = Dictionary()
	
	func _init(f):
		non_static["pointers"] = f
		non_static["self"] = self
	
	static func __parse_url(url: String) -> Dictionary:
		var use_ssl:bool = url.begins_with("https://")
		url = url.trim_prefix("http://").trim_prefix("https://")
		var path_delimiter:int = url.find("/")
		if path_delimiter == -1:
			path_delimiter = url.length()
		var path:String = url.substr(path_delimiter)
		if!path:
			path = "/"
		
		var port_delimiter:int = url.find(":")
		var has_port:bool = port_delimiter != -1 and port_delimiter < path_delimiter
		var host_length:int = 0
		
		if url[0] == "[": # IPv6
			if url.find("]") == -1:
				host_length = 0 if not has_port else port_delimiter
		else: # IPv4
			host_length = path_delimiter if not has_port else port_delimiter
		
		var host:String = url.substr(0, host_length)
		var port:int = (url.substr(port_delimiter,(
				(path_delimiter - port_delimiter) if (path_delimiter > 0) else (url.length() - port_delimiter)
			)).to_int()) if has_port else -1
		
		return {
			"host":host,
			"port":port,
			"path":path,
			"use_ssl":use_ssl
		}
	
	
	
	
	
	
	
	
	
	
	
	

class _NodeAccess:
	const non_static = Dictionary()
	func _init(f):
		non_static["pointers"] = f
		non_static["self"] = self
	
	const log_header = "pointers.NodeAccess"
	
	static func __get_all_children(node:Node, strip_supplied_node_from_array = false, return_only_paths = false, use_relative_paths = false):
		var children : PoolStringArray = getAllChildren(node)
		if strip_supplied_node_from_array:
			children = strip_node(node, children)
		if return_only_paths:
			children = returnPaths(children, use_relative_paths, node)
		return children
	
	static func getAllChildren(in_node:Node,arr : Array = Array()):
		arr.push_back(in_node)
		for child in in_node.get_children():
			getAllChildren(child,arr)
	
	static func strip_node(in_node, arr):
		var paths : PoolStringArray = PoolStringArray()
		for m in arr:
			if m.get_path().split(in_node.get_path())[1]:
				paths.append(m)
		return paths
	
	static func returnPaths(arr, relative, in_node):
		var parentPath : String = in_node.get_path()
		var paths : PoolStringArray = PoolStringArray()
		for m in arr:
			paths.append(m.get_path())
		if relative:
			for i in paths.size():
				paths[i] = paths[i].split(parentPath)[1].lstrip("/")
		return paths
	
	static func __claim_child_ownership(node: Node):
		for child in node.get_children():
			setOwnership(child, node)
	
	static func setOwnership(current_node: Node,set_owner_node: Node):
		current_node.set_owner(set_owner_node)
		for child in current_node.get_children():
			if not __is_instanced_from_scene(child.get_parent()):
				setOwnership(child, set_owner_node)
	
	static func __is_instanced_from_scene(p_node):
		return not p_node.filename.empty()
	
	static func __dynamic_crew_expander() -> void:
		var pointers:HevLibPointers = non_static["pointers"]
		var ncrew:Dictionary = pointers.ManifestV2.__get_manifest_entry("tags","TAG_HANDLE_EXTRA_CREW")
		var max_crew:int = 24
		for mod in ncrew.keys():
			var data:int = ncrew[mod]
			if data > max_crew:
				max_crew = data
		var compacted_string : String = "[gd_scene load_steps=3 format=2]\n\n[ext_resource path=\"res://comms/conversation/subtrees/DIALOG_DERELICT_RANDOM.tscn\" type=\"PackedScene\" id=1]\n[ext_resource path=\"res://comms/ConversationPlayer.gd\" type=\"Script\" id=2]\n\n[node name=\"DIALOG_DERELICT_RANDOM_1\" instance=ExtResource( 1 )]\n\n"
		for i in (max_crew - 12):
			i += 12
			compacted_string += "[node name=\"DIALOG_DERELICT_SWITCH_CREW|%d\" type=\"Node\" parent=\".\" index=\"%d\"]\nscript = ExtResource( 2 )\nmyLine = false\nfaceless = true\nimportChildren = NodePath(\"../DIALOG_DERELICT_GO_AND_BRING_IT\")\nagenda = \"CREW/%d\"\nagendaNotSame = true\n\n" % [i,i + 4,i]
		
		var file:File = File.new()
		file.open("user://cache/Variable_Fetch/derelict_expansion.tscn",File.WRITE)
		file.store_string(compacted_string)
		file.close()
	
	static func __remove_scripts(node):
		node.set_script(null)
		for obj in node.get_children():
			__remove_scripts(obj)
	
	static func __exit(restart : bool = false, exit_message : String = "", exit_header : String = "", delay : float = 0.0,exit_url : String = "",use_os_error_message : bool = false):
		var pointers:HevLibPointers = non_static["pointers"]
		if restart:pointers.l(("restarting with message: %s" % exit_message) if exit_message else "exiting with restart",(exit_header) if (exit_header) else log_header)
		else:pointers.l(("exiting with message: %s" % exit_message) if exit_message else "exiting",(exit_header) if (exit_header) else log_header)
		if delay > 0.0 and pointers.is_inside_tree():
			pointers.get_tree().create_timer(delay).connect("timeout",non_static["self"],"__exit",[restart,exit_message,exit_header,0.0,exit_url,use_os_error_message])
			return
		if use_os_error_message and exit_message:
			OS.alert(exit_message,exit_header)
		Debug.batchWrite()
		pointers.storeLogCache()
		if restart:
			OS.execute(OS.get_executable_path(), OS.get_cmdline_args(), false)
		elif exit_url and pointers.DataFormat.__is_valid_url(exit_url):
			OS.shell_open(exit_url)
		if pointers.is_inside_tree():
			yield(pointers,"process_tick")
		OS.kill(OS.get_process_id())
	
	static func __save_node_to_scene(node:Node,file_path:String):
		var ext:String = file_path.get_extension()
		if not ext == "tscn" or ext == "scn":
			return
		var packed:PackedScene = PackedScene.new()
		__claim_child_ownership(node)
		if packed.pack(node) == OK:
			ResourceSaver.save(file_path,packed)

class _RingInfo:
	
	func _init(p):
		pass
	
	static func __get_pixel_at(pos: Vector2) -> Color:
		var image:Image = RING_IMAGE_STORE.map.get_data()
		var size:Vector2 = image.get_size()
		var sx:float = size.x
		var x:int = int(clamp(floor(pos.x / 10000.0), 0, sx - 1))
		var sy:int = int(size.y)
		var y:int = ((int(floor(pos.y / 10000.0)) %sy) + sy) %sy
		var x1:int = int(clamp(x + 1, 0, sx - 1))
		var y1:int = (y + 1) % sy
		
		if x <= 0:
			return Color(0, 0, 0, 0)
		
		image.lock()
		var p00:Color = image.get_pixel(x, y)
		var p10:Color = image.get_pixel(x1, y)
		var p11:Color = image.get_pixel(x1, y1)
		var p01:Color = image.get_pixel(x, y1)
		image.unlock()
		
		var cx:float = (pos.x - floor(pos.x / 10000.0) * 10000.0) / 10000.0
		var cy:float = (pos.y - floor(pos.y / 10000.0) * 10000.0) / 10000.0
		
		var pu:Color = (p00 * (1 - cx) + p10 * (cx))
		var pd:Color = (p01 * (1 - cx) + p11 * (cx))
		
		return (pu * (1 - cy) + pd * (cy))
	
	static func __get_vein_pixel_at(pos: Vector2) -> Color:
		var veinImage:Image = RING_IMAGE_STORE.veins.get_data()
		var veinSize:Vector2 = veinImage.get_size()
		var x:int = posmod(pos.x, veinSize.x)
		var y:int = posmod(pos.y, veinSize.y)
		var x1:int = posmod(pos.x + 1, veinSize.x)
		var y1:int = posmod(pos.y + 1, veinSize.y)
		
		veinImage.lock()
		var p00:Color = veinImage.get_pixel(x, y)
		var p10:Color = veinImage.get_pixel(x1, y)
		var p11:Color = veinImage.get_pixel(x1, y1)
		var p01:Color = veinImage.get_pixel(x, y1)
		veinImage.unlock()
		
		var cx:float = fposmod(pos.x, 1)
		
		return lerp(lerp(p00, p10, cx), lerp(p01, p11, cx), fposmod(pos.y, 1))
	
	static func __get_vein_at(pos: Vector2,only_vanilla:bool = false) -> String:
		var values:PoolRealArray = PoolRealArray()
		if only_vanilla:
			var p1:Color = __get_vein_pixel_at(pos / 1861.0)
			var p2:Color = __get_vein_pixel_at(pos / - 2531.0)
			values = PoolRealArray([p1.r, p1.g, p1.b, p1.a, p2.r, p2.b, p2.g, p2.a])
		else:
			values = get_pixel_values(pos)
		var rnd:float = 0.0
		for n in CurrentGame.traceMinerals.size():
			values[n] = pow(values[n] / pow(CurrentGame.mineralPrices.get(CurrentGame.traceMinerals[n], 1.0), 0.2), 4)
			rnd += values[n]
		rnd *= randf()
		var nr:int = 0
		for n in values:
			rnd -= n
			if rnd < 0.0:
				return CurrentGame.traceMinerals[nr]
			nr += 1
		return CurrentGame.traceMinerals[0]
	
	static func get_chaos_at(pos) -> float:
		return __get_pixel_at(pos).r
	
	const pix_values:PoolIntArray = PoolIntArray()
	
	
	
	static func get_pixel_values(pos:Vector2) -> PoolRealArray:
		if!pix_values:
			var mineral_size:int = int(CurrentGame.traceMinerals.size() / 4.0) - 1
			pix_values.resize(mineral_size + 2)
			pix_values[0] = 1861.0
			pix_values[1] = - 2531.0
			if mineral_size:
				var random:bool = ModLoader._savedObjects[0].ConfigDriver.__get_value("HevLib","HEVLIB_CONFIG_SECTION_DRIVERS","randomize_minerals",false)
				var nsi:int = RING_ORE_DISTRIB_SEEDS_NOT_RANDOM.size()
				for i in mineral_size:
					if random:
						pix_values[i + 2] = ((randi() % 2250) + 750) * sign(randf() - 0.5)
					else:
						pix_values[i + 2] = RING_ORE_DISTRIB_SEEDS_NOT_RANDOM[i%nsi]
		var pxSize:int = pix_values.size()
		var out:PoolRealArray = PoolRealArray()
		out.resize(pxSize * 4)
		for i in pxSize:
			var pixel:Color = __get_vein_pixel_at(pos / pix_values[i])
			var offset:int = i * 4
			out[offset] = pixel.r
			out[offset + 1] = pixel.g
			out[offset + 2] = pixel.b
			out[offset + 3] = pixel.a
		return out
	
	static func get_raw_density_at(pos) -> float:
		return __get_pixel_at(pos).b

class _RPC:
	func _init(p):
		rpc_data["pointers"] = p
		rpc_data["self"] = self
		rpc_data["start_timer"] = OS.get_unix_time()
		rpc_data["update_timer"] = Timer.new()
	
	const log_header = "pointers.RPC"
	
	# RPC CALLABLE FUNCTIONS
	
	static func set_icon(ship:String,force_this_icon:bool = false):
		var icon:String = ""
		if force_this_icon:
			icon = ship
		else:
			if ship in RPC_VALID_SHIP_ICONS:
				icon = ship
			else:
				match ship.to_lower():
					"icon":
						icon = "icon"
					"empty":
						icon = "empty"
					"ep","enceladus","enceladus_prime":
						icon = "enceladus_prime"
					_:
						icon = "unknown"
		if icon != rpc_data["current_icon"]:
			rpc_data["pointers"].l("Changing large icon from %s to %s" % [rpc_data["current_icon"],icon],log_header)
			if!icon:
				icon = "empty"
			rpc_data["current_icon"] = icon
	
	static func set_icon_text(text:String):
		if text != rpc_data["current_icon_text"]:
			rpc_data["pointers"].l("Changing large icon text from %s to %s" % [rpc_data["current_icon_text"],text],log_header)
			rpc_data["current_icon_text"] = text
	
	static func set_small_icon_text(text:String):
		if text != rpc_data["current_small_icon_text"]:
			rpc_data["pointers"].l("Changing small icon text from %s to %s" % [rpc_data["current_small_icon_text"],text],log_header)
			rpc_data["current_small_icon_text"] = text
	
	static func set_small_icon(how:String,force_this_icon:bool = false):
		var icon:String = "None"
		if force_this_icon:
			icon = how
		else:
			if how:
				icon = "icon"
		if icon != rpc_data["current_small_icon"]:
			rpc_data["pointers"].l("Changing small icon from %s to %s" % [rpc_data["current_small_icon"],icon],log_header)
			rpc_data["current_small_icon"] = icon
	
	static func set_start_timer(time:int = OS.get_unix_time()):
		if time != rpc_data["start_timer"]:
			rpc_data["pointers"].l("Changing start time from %d to %d" % [rpc_data["start_timer"],time],log_header)
			rpc_data["start_timer"] = time
	
	static func set_end_timer(time:int = 0):
		if time != rpc_data["end_timer"]:
			rpc_data["pointers"].l("Changing end time from %d to %d" % [rpc_data["end_timer"],time],log_header)
			rpc_data["end_timer"] = time
	
	static func set_state(text:String):
		if text != rpc_data["current_state"]:
			rpc_data["pointers"].l("Changing state from %s to %s" % [rpc_data["current_state"],text],log_header)
			rpc_data["current_state"] = text
	
	static func set_details(text:String):
		if text != rpc_data["current_details"]:
			rpc_data["pointers"].l("Changing details from %s to %s" % [rpc_data["current_details"],text],log_header)
			rpc_data["current_details"] = text
	
	# RPC INTERNALS
	
	signal update_activity()
	signal rpc_timer_complete()
	
	const rpc_data = {
		"current_icon":"empty",
		"current_icon_text":"",
		"current_small_icon":"icon",
		"current_small_icon_text":"",
		"start_timer":0,
		"end_timer":0,
		"current_state":"",
		"current_details":"HEVLIB_DISCORDRPC_TITLE_SCREEN",
		"secondary_state_index":0,
		"secondary_states":Array(),
		"absolute_state":"",
		"loaded":false,
		"update_wait_time":4.5,
		"reconnect_wait_time":3.0,
		"err_update_wait_time":60.0,
		"err_reconnect_wait_time":60.0,
		"update_delay":4.5,
		"reconnect_delay":3.0,
		"update_timer":null,
		"discord":null,
		"activity":null,
		"currentStack":0,
		"err_count":0,
	}
	
	static func ready():
		var discord_script:String = "res://HevLib Discord RPC/lib/discord.gd"
		var pointers:HevLibPointers = rpc_data["pointers"]
		if File.new().file_exists(discord_script) and pointers.ConfigDriver.__get_value("HevLib","HEVLIB_CONFIG_SECTION_POINTERS","discord_rpc_enabled",true):
			var discord = load(discord_script).new()
			rpc_data["activity"] = discord.Activity.new()
			rpc_data["loaded"] = true
			rpc_data["discord"] = discord
			pointers.add_child(rpc_data["discord"])
			var base:_RPC = rpc_data["self"]
			base.connect("update_activity",base,"update_activity")
			var update_timer:Timer = rpc_data["update_timer"]
			update_timer.wait_time = rpc_data["reconnect_delay"]
			update_timer.one_shot = true
			update_timer.name = "UPDATE_TIMER"
			update_timer.connect("timeout",base,"update_timer_finished")
			pointers.add_child(update_timer)
			update_timer_finished()
	
	const stack:PoolStringArray = PoolStringArray(["","","",""])
	
	static func loader_changed(area:String,level:int = 0,how_specific:String = ""):
		if not rpc_data["loaded"]:
			return
		var currentStack:int = rpc_data["currentStack"]
		if area != stack[0]:
			rpc_data["start_timer"] = OS.get_unix_time()
			stack[0] = area
			rpc_data["secondary_states"] = rpc_data["pointers"].Equipment.rpc_second_state_store[area]
			rpc_data["secondary_state_index"] = 0
		currentStack = level
		if how_specific:
			stack[currentStack] = how_specific
		var current_icon:String = ""
		var current_details:String = ""
		var current_state:String = ""
		match stack[0]:
			"enceladus_prime":
				current_icon = "enceladus_prime"
				current_details = "HEVLIB_DISCORDRPC_AT_ENCELADUS"
				current_state = "HEVLIB_DISCORDRPC_AT_ENCELADUS"
				var sn:String = CurrentGame.getPlayerShip().getShipName()
				match stack[currentStack]:
					"simulator":
						current_details = TranslationServer.translate("HEVLIB_DISCORDRPC_IN_MVFS") % sn
					"dive_summary":
						current_details = "HEVLIB_DISCORDRPC_IN_DIVE_SUMMARY"
					"dive_target":
						current_details = "HEVLIB_DISCORDRPC_IN_DIVE_TARGET"
					"mineral_market":
						current_details = "HEVLIB_DISCORDRPC_IN_MINERAL_MARKET"
					"repairs":
						current_details = TranslationServer.translate("HEVLIB_DISCORDRPC_IN_REPAIRS") % sn
					"inspection":
						current_details = TranslationServer.translate("HEVLIB_DISCORDRPC_IN_INSPECTIONS") % sn
					"equipment":
						current_details = TranslationServer.translate("HEVLIB_DISCORDRPC_IN_EQUIPMENT") % sn
					"tuning":
						current_details = TranslationServer.translate("HEVLIB_DISCORDRPC_IN_TUNING") % sn
					"ship_logs":
						current_details = "HEVLIB_DISCORDRPC_IN_SHIP_LOGS"
					"crew":
						current_details = "HEVLIB_DISCORDRPC_IN_CREW"
					"fleet":
						current_details = "HEVLIB_DISCORDRPC_IN_FLEET"
					"dealer":
						current_details = "HEVLIB_DISCORDRPC_IN_DEALER"
					"services":
						current_details = "HEVLIB_DISCORDRPC_IN_SERVICES"
					"research":
						current_details = "HEVLIB_DISCORDRPC_IN_RESEARCH"
					
			"title_screen":
				current_icon = "empty"
				current_details = "HEVLIB_DISCORDRPC_TITLE_SCREEN"
				current_state = "HEVLIB_DISCORDRPC_TITLE_SCREEN"
				
			"ring":
				current_details = "HEVLIB_DISCORDRPC_IN_RING"
				current_state = "HEVLIB_DISCORDRPC_IN_RING"
				
				var playership = CurrentGame.getPlayerShip()
				
				match how_specific:
					"western","western2":
						current_details = "HEVLIB_DISCORDRPC_HIGH_DENSITY"
					"mystery","mystery2":
						current_details = "HEVLIB_DISCORDRPC_ODDITIES"
					"spooky":
						current_details = "HEVLIB_DISCORDRPC_SPOOKY"
					"dare":
						current_details = "HEVLIB_DISCORDRPC_DARE"
					"battle":
						current_details = "HEVLIB_DISCORDRPC_BATTLE"
					"boss":
						current_details = "HEVLIB_DISCORDRPC_BOSS"
					"peril":
						current_details = "HEVLIB_DISCORDRPC_PERIL"
					"l:G4A":
						pass
					"l:locust":
						current_details = "HEVLIB_DISCORDRPC_LOCUSTS"
					
				var shipIcon:String = "empty"
				var thisShip:String = ""
				if "baseShipName" in playership and playership.baseShipName in RPC_VALID_SHIPS:
					thisShip = playership.baseShipName
				if "shipName" in playership and playership.shipName in RPC_VALID_SHIPS:
					thisShip = playership.shipName
				if thisShip in RPC_VALID_SHIPS:
					shipIcon = RPC_VALID_SHIP_LOOKUP[thisShip]
				current_icon = shipIcon
		rpc_data["current_details"] = current_details
		rpc_data["current_icon"] = current_icon
		rpc_data["current_state"] = current_state
		rpc_data["currentStack"] = currentStack
	
	static func update_timer_finished():
		rpc_data["self"].emit_signal("rpc_timer_complete")
		update_rpc()
		rpc_data["update_timer"].start(rpc_data["update_delay"]/Engine.get_time_scale())
	
	static func update_rpc():
		if rpc_data["loaded"]:# and changed:
			calculate_current_state()
			rpc_data["self"].emit_signal("update_activity")
	
	static func get_state_data(state:Dictionary) -> String:
		var playership = CurrentGame.getPlayerShip()
		if not Tool.claim(playership):
			return rpc_data["current_state"]
		Tool.release(playership)
		var out:String = TranslationServer.translate(state.get("text","RPC text missing :("))
		var toFormat:Dictionary = Dictionary()
		var sensors:Array = state.get("sensors",Array())
		if sensors and stack[0] == "ring":
			for sensor in sensors:
				if sensor is String:
					toFormat["sensor:" + sensor] = playership.sensorGet(sensor)
				elif sensor is Dictionary:
					var raw_sensor:String = sensor.get("sensor","")
					var sensor_name:String = sensor.get("sensor_identifier_override",raw_sensor)
					var fallbackFormat:String = sensor.get("fallback","unknown")
					var sensorOut = playership.sensorGet(raw_sensor)
					if "funcref" in sensor:
						sensorOut = sensor.get("funcref").call_funcv([sensorOut] + sensor.get("extra_operands",Array()))
					if sensorOut != null:
						toFormat["sensor:" + sensor_name] = sensorOut
					elif fallbackFormat:
						toFormat["sensor:" + sensor_name] = TranslationServer.translate(fallbackFormat)
		for sensor in state.get("function_outputs",Array()):
			if sensor is Dictionary:
				var sensor_name:String = sensor.get("name","")
				var fallbackFormat:String = sensor.get("fallback","unknown")
				var sensorOut
				if "funcref" in sensor:
					sensorOut = sensor.get("funcref").call_funcv(sensor.get("extra_operands",Array()))
				if sensorOut:
					toFormat["output:" + sensor_name] = sensorOut
				elif fallbackFormat:
					toFormat["output:" + sensor_name] = TranslationServer.translate(fallbackFormat)
		if toFormat:
			out = out.format(toFormat)
		return out
	
	static func calculate_current_state():
		var secondary_states:Array = rpc_data["secondary_states"]
		var secondary_state_index: int = rpc_data["secondary_state_index"]
		if secondary_states:
			secondary_state_index += 1
			if secondary_state_index > secondary_states.size():
				secondary_state_index = 0
			if secondary_state_index == 0 and rpc_data["current_state"] == rpc_data["current_details"]:
				secondary_state_index = 1
			if secondary_state_index > 0:
				var thisState = secondary_states[secondary_state_index - 1]
				rpc_data["absolute_state"] = get_state_data(thisState)
			else:
				rpc_data["absolute_state"] = rpc_data["current_state"]
		else:
			secondary_state_index = 0
			rpc_data["absolute_state"] = rpc_data["current_state"]
		rpc_data["secondary_states"] = secondary_states
		rpc_data["secondary_state_index"] = secondary_state_index
	
	static func update_activity() -> void:
		var st:String = rpc_data["absolute_state"]
		var dt:String = rpc_data["current_details"]
		if st == dt:
			st = ""
		var activity = rpc_data["activity"]
		var discord = rpc_data["discord"]
		activity.set_type(discord.ActivityType.Playing)
		activity.set_state(TranslationServer.translate(st))
		activity.set_details(TranslationServer.translate(dt))
		
		var assets = activity.get_assets()
		assets.set_large_image(rpc_data["current_icon"])
		assets.set_large_text(rpc_data["current_icon_text"])
		assets.set_small_image(rpc_data["current_small_icon"])
		assets.set_small_text(rpc_data["current_small_icon_text"])
		var timestamps = activity.get_timestamps()
		var start_timer:int = rpc_data["start_timer"]
		var end_timer:int = rpc_data["end_timer"]
		if start_timer > 0:
			timestamps.set_start(start_timer)
		if end_timer > 0:
			timestamps.set_end(end_timer)
		var err_count:int = rpc_data["err_count"]
		var result = yield(discord.activity_manager.update_activity(activity), "result").result
		if result != discord.Result.Ok:
			err_count += 1
			if err_count > 3:
				rpc_data["update_delay"] = rpc_data["err_update_wait_time"]
				rpc_data["reconnect_delay"] = rpc_data["err_reconnect_wait_time"]
			rpc_data["pointers"].l("ERROR: RPC returned error code %d" % result,log_header)
		else:
			if err_count:
				rpc_data["update_delay"] = rpc_data["update_wait_time"]
				rpc_data["reconnect_delay"] = rpc_data["reconnect_wait_time"]
			err_count = 0

class _SafeMode:
	const PCKNAMES:PoolStringArray = PoolStringArray()
	var safeCheck:bool = false
	var safeCheckTriggered:bool = false
	const offendingFiles:Dictionary = Dictionary()
	var offendingFileCount:int = 0
	const dependancy_dictionary:Dictionary = Dictionary()
	const dependancy_dict_keys:Array = Array()
	const dependancy_lookup:Dictionary = Dictionary()
	const dependancy_lookup_keys:Array = Array()
	const vanilla_load_order:Array = Array()
	
	const order_tree:Dictionary = Dictionary()
	
	const non_static = Dictionary()
	
	var regex:RegEx = RegEx.new()
	var pointers:HevLibPointers
	func _init(p):
		non_static["pointers"] = p
		pointers = p
		regex.compile(Marshalls.base64_to_variant(PoolByteArray([120,156,117,145,203,110,131,64,12,69,63,169,204,32,26,88,116,81,72,129,48,98,132,64,154,152,89,98,160,8,134,130,68,82,30,95,95,160,85,165,22,197,11,123,113,239,241,67,182,95,215,176,53,123,205,93,68,181,158,157,77,243,146,132,63,149,103,160,166,59,192,48,149,73,211,69,203,88,93,200,173,0,207,200,139,37,176,88,242,254,20,57,111,245,149,24,152,41,114,10,117,237,63,167,29,57,113,224,248,199,129,211,191,185,190,40,157,213,123,38,25,248,97,7,73,179,249,158,193,49,74,108,69,37,125,133,204,29,251,210,29,239,160,219,93,1,188,79,117,94,162,31,124,166,84,44,72,198,78,122,98,200,61,23,25,76,139,188,78,237,206,122,149,129,84,213,72,172,17,91,171,150,192,23,112,170,102,213,181,84,252,246,155,51,202,21,234,28,153,23,171,204,143,43,112,148,137,84,12,82,61,214,183,254,210,15,170,124,157,253,199,79,227,57,133,124,223,119,191,95,220,16,231,240,196,4,49,3,167,217,190,240,242,5,240,143,132,212]).decompress(396,1).get_string_from_utf8()))
	
	
	
	const log_header = "pointers.SafeMode"
	var file:File = File.new()
	func ready():
		var data = null
		if file.file_exists(SAFEMODE_DATA_PATH):
			file.open(SAFEMODE_DATA_PATH,File.READ)
			data = pointers.Zip.__read_hlz(file.get_buffer(file.get_len()))
			file.close()
		
		if not data is Array or pointers.ManifestV2.haveModsChanged:
			pointers.l("Game has updated or cache is missing, rebuilding file info cache.",log_header)
			pointers.FolderAccess.__recursive_delete(SAFEMODE_PATH)
			Directory.new().make_dir(SAFEMODE_PATH)
			var timerStart:int = Time.get_ticks_usec()
			PCKNAMES.append_array(pointers.FolderAccess.__get_vanilla_script_and_scenes())
			for f in PCKNAMES:
				get_dependancies_for_vanilla_file(f)
			order_tree.merge(flatten_tree(get_dependancy_tree()))
			vanilla_load_order.append_array(dependancy_dict_keys)
			var vsize:int = vanilla_load_order.size()
			var idx:int = 0
			while idx < vsize:
				if idx > 0:
					var item:String = vanilla_load_order[idx]
					for i in idx:
						var deps:Array = order_tree[vanilla_load_order[i]]
						if item in deps:
							vanilla_load_order.remove(idx)
							vanilla_load_order.insert(i,item)
							idx = i
							break
				idx += 1
			var data_to_store:PoolByteArray = pointers.Zip.__write_hlz([
				JSON.print(PCKNAMES),
				JSON.print(vanilla_load_order),
				JSON.print(dependancy_lookup),
				JSON.print(dependancy_dictionary)
			])
			file.open(SAFEMODE_DATA_PATH,File.WRITE)
			file.store_buffer(data_to_store)
			file.close()
			var timerEnd:int = Time.get_ticks_usec()-timerStart
			pointers.l("Cache rebuilt in %d.%03d ms" % [int(floor(timerEnd / 1000.0)),timerEnd % 1000],log_header)
		else:
			PCKNAMES.append_array(JSON.parse(data[0]).result)
			vanilla_load_order.append_array(JSON.parse(data[1]).result)
			dependancy_lookup.merge(JSON.parse(data[2]).result)
			dependancy_dictionary.merge(JSON.parse(data[3]).result)
			dependancy_lookup_keys.append_array(dependancy_lookup.keys())
			dependancy_dict_keys.append_array(dependancy_dictionary.keys())
		
		if not pointers.is_editor:
			var safeCheck:bool = pointers.ConfigDriver.__get_value("HevLib","HEVLIB_CONFIG_SECTION_POINTERS","safe_mod_loading",true)
			pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_ENABLED" if safeCheck else "HEVLIB_SAFEMODE_SM_DISABLED"),log_header)
			safeCheck = safeCheck
		else:pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_DISABLED_EDITOR"),log_header)
	
	var sc_mutex:Mutex = Mutex.new()
	
	func __check_file(file_path:String,zip_path:String,crash:bool = true):
		if safeCheck:
			sc_mutex.lock()
			var zf:String = zip_path.get_file()
			pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_CHECKINGFILE") % [zf,file_path],log_header)
			if file_path in PCKNAMES:
				pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_OVERWRITE_VANILLA_ERR_1") % [file_path,zf],log_header)
				pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_OVERWRITE_VANILLA_ERR_2"),log_header)
				pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_OVERWRITE_VANILLA_ERR_3"),log_header)
				pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_OVERWRITE_VANILLA_ERR_4"),log_header)
				if zf in offendingFiles:
					offendingFiles[zf].append(file_path)
				else:
					offendingFiles[zf] = PoolStringArray([file_path])
				offendingFileCount += 1
				if crash:
					safeCheckTriggered = true
			elif not safeCheckTriggered and file_path.get_extension() == "gd" and not pointers.DriverManagement.__is_driver_file(file_path) and file_path.split("/",false)[1] != pointers.resource_path.split("/",false)[1]:
				var file:File = File.new()
				file.open(file_path,File.READ)
				var st:String = file.get_as_text(true)
				file.close()
				if regex.search(st):
					pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_SUPERING_ERR_AI_LIKELY") % [file_path,zf],log_header)
					pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_SUPERING_ERR_2"),log_header)
					pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_SUPERING_ERR_3"),log_header)
					pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_SUPERING_ERR_4"),log_header)
					pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_SUPERING_ERR_5"),log_header)
					if zf in offendingFiles:
						offendingFiles[zf].append(file_path)
					else:
						offendingFiles[zf] = PoolStringArray([file_path])
					offendingFileCount += 1
					if crash:
						safeCheckTriggered = true
			sc_mutex.unlock()
	
	func __handle_exit_for_file_checks():
		pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_TOTALLING") % [offendingFileCount,offendingFiles.size()],log_header)
		if offendingFiles:
			for zip_path in offendingFiles:
				var zip_files:PoolStringArray = offendingFiles[zip_path]
				pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_TOTALLING_FOR_MOD") % [zip_files.size(),zip_path],log_header)
				for i in zip_files:pointers.l(" -> [%s]" % i,log_header)
			pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_TRIPPED_ERR_1"),log_header)
			pointers.l(TranslationServer.translate("HEVLIB_SAFEMODE_SM_TRIPPED_ERR_2"),log_header)
			if safeCheck and safeCheckTriggered:
				pointers.NodeAccess.__exit(false,TranslationServer.translate("HEVLIB_SAFEMODE_SM_TRIPPED_POPUP_MSG") % [offendingFiles.size(),offendingFileCount],log_header,0.0,"",true)
	
	static func flatten_tree(tree:Dictionary) -> Dictionary:
		var out:Dictionary = Dictionary()
		for i in tree.keys():
			out[i] = get_all_branches(tree[i],PoolStringArray())
		return out
	
	static func get_all_branches(dict:Dictionary,out:PoolStringArray) -> PoolStringArray:
		for i in dict.keys():
			if not i in out:
				out.append(i)
			out = get_all_branches(dict[i],out)
		return out
	
	const processed_deps = PoolStringArray()
	
	static func get_dependancy_tree() -> Dictionary:
		var out:Dictionary = Dictionary()
		for i in dependancy_dict_keys:
			out[i] = Dictionary()
		for i in out.keys():
			if i in dependancy_dict_keys:
				for r in dependancy_dictionary[i]:
					if not r in processed_deps and r in out:
						out[i][r] = out[r]
						processed_deps.append(r)
				processed_deps.append(i)
		return out
	
	
	
	static func get_dependancies_for_vanilla_file(file_path:String):
		if (not file_path in PCKNAMES) or (file_path in dependancy_dict_keys):
			return
		var fext:String = file_path.get_extension().to_lower()
		var dependencies:PoolStringArray = non_static["pointers"].FileAccess.__get_dependancies_for_file(file_path,(fext == "gd" or fext == "gdc"))
		if dependencies:
			dependancy_dict_keys.append(file_path)
			dependancy_dictionary[file_path] = dependencies
			for dp in dependencies:
				if not dp in dependancy_lookup:
					dependancy_lookup[dp] = Array()
					dependancy_lookup_keys.append(dp)
				dependancy_lookup[dp].append(file_path)
			for m in dependencies:
				if (m.get_extension().to_lower() in SAFEMODE_BINARY_CHECK):
					get_dependancies_for_vanilla_file(m)
	
	static func __lookup_vanilla_file_dependancies(dependancy) -> PoolStringArray:
		return LDA(dependancy,PoolStringArray())
	
	static func LDA(dependancy,order:PoolStringArray) -> PoolStringArray:
		if dependancy in dependancy_lookup_keys:
			for d in dependancy_lookup[dependancy]:
				if not d in order:
					order.append(d)
					LDA(d,order)
		return order
	
	static func __lookup_file_dependancies(dependancy:String) -> PoolStringArray:
		var deps:PoolStringArray = ResourceLoader.get_dependencies(dependancy)
		var out:PoolStringArray = deps
		for d in deps:
			for i in LDA(d,PoolStringArray()):
				if not i in out:
					out.append(i)
		return out

class _Scripting:
	const non_static = Dictionary()
	
	func _init(p,h):
		non_static["pointers"] = p
		non_static["self"] = self
		non_static["http"] = h
	
	const log_header = "pointers.Scripting"
	
	static func log_essential_info_for_bugreports():
		var p:HevLibPointers = non_static["pointers"]
		var out:String = "Booting from %s on %s[%s] as %s"%[OS.get_model_name(),OS.get_name(),OS.get_process_id(),OS.get_unique_id()]
		out += "\nCPU Information: %s [%s cores]"%[OS.get_processor_name(),OS.get_processor_count()]
		out += "\nBattery state (if any): %s/%s/%s"%[OS.get_power_percent_left(),OS.get_power_state(),OS.get_power_seconds_left()]
		var screens = OS.get_screen_count()
		out += "\nScreens: %s @ %s dpi" % [screens,OS.get_screen_dpi()]
		for i in screens:out += "\n\t%s: %s / %s / %s hz"%[i,str(OS.get_screen_size(i)),OS.get_screen_position(i),OS.get_screen_refresh_rate(i)]
		var audioDrivers = OS.get_audio_driver_count()
		out += "\n[%s] audio drivers:" % audioDrivers
		for i in audioDrivers:out += "\n\t%s" % OS.get_audio_driver_name(i)
		out += "\nKeyboard variant: %s @ %s/%s" % [OS.get_latin_keyboard_variant(),OS.get_locale(),OS.get_locale_language()]
		out += "\nExecutable path: %s" % OS.get_executable_path()
		out += "\nUser directory: %s" % OS.get_user_data_dir()
		if Engine.has_singleton("Steam"):out += "\nSteam initialized with [%s]"%Engine.get_singleton("Steam").current_steam_id
		out += "\nCMD args: [%s]" % OS.get_cmdline_args().join(" \\ ");var pnth = -1
		var file:File = File.new()
		if file.file_exists("res://HevLib/pointers.gd"):
			file.open("res://HevLib/pointers.gd",File.READ);pnth=hash(file.get_as_text(true));p.ConfigDriver.non_static[""]._();file.close()
		out += "\nPointers hash: %d" % pnth
		out += "\nZip reference store: %s" % JSON.print(p.ManifestV2.zip_ref_store)
		p.l("Device Information: [\n%s\n]" % out,log_header)
	
	
	
	static func make_mineral_scripting() -> void:
		var pointers:HevLibPointers = non_static["pointers"]
		for f in pointers.FolderAccess.__fetch_folder_files("user://cache/Minerals/",true,true):pointers.FolderAccess.__recursive_delete(f)
		var mineral_data:Array = Array()
		for mineral_dict in pointers.DriverManagement.__get_specific_driver_type("ADD_MINERALS.gd"):
			for mineral in mineral_dict.keys():
				var md:Dictionary = mineral_dict[mineral]
				if md.get("name",""):mineral_data.append({"object":non_static["self"],"method":"process_mineral_dict","args":[md,pointers]})
		
		# Initialize info for mineral names, colours, and value
		var trace_text:String = ""
		var price_text:String = ""
		var color_text:String = ""
		var content:String = "extends \"res://AsteroidSpawner.gd\"\nfunc _init():\n\tpass"
		
		for mineral in pointers.Threading.__request_multiple_threads(mineral_data):
			color_text += mineral[0]
			var pt:String = mineral[1]
			if pt:price_text += pt
			var ct:String = mineral[2]
			if ct:content += ct
			var tt:String = mineral[3]
			if tt:trace_text += tt
		
		var file:File = File.new()
		# Builds the current game extension script
		file.open("user://cache/Minerals/cg.gd",File.WRITE)
		file.store_string("extends \"res://CurrentGame.gd\"\nfunc _init():\n\tpass%s%s%s\nfunc isDemo():\n\treturn false" % [price_text,color_text,trace_text])
		file.close()
		
		# Builds the AsteroidSpawner.gd script to add new ore scenes
		file.open("user://cache/Minerals/as.gd",File.WRITE)
		file.store_string(content)
		file.close()
		
		# Builds the blank Settings extension
		file.open("user://cache/Variable_Fetch/st.gd",File.WRITE)
		file.store_string("""extends "res://Settings.gd"
var hl_edallowall:bool=false
func _ready():hl_edallowall=(OS.has_feature("editor")&&ModLoader._savedObjects[0].ConfigDriver.__get_value("HevLib","HEVLIB_CONFIG_SECTION_DRIVERS","unlock_dlc",false))
func hasDlc(dlc)->bool:return true if (OS.has_feature("editor")&&hl_edallowall) else .hasDlc(dlc)
""" if (pointers.is_editor) else "extends \"res://Settings.gd\"\n\n")
		file.close()
	
	
	
	static func process_mineral_dict(mineral:Dictionary,pointers:HevLibPointers) -> PoolStringArray:
		var mname:String = mineral.get("name","")
		var col:Color = mineral.get("color",Color.white)
		var out:PoolStringArray = PoolStringArray([MINERALDRIVER_COLOUR_STRUCTURE % [mname,mname,col.r,col.g,col.b],"","",""])
		var price:float = mineral.get("price",0.0)
		if price > 0.0:
			# Only adds minerals to the ring if they have a value.
			# Useful if you only want to reference a mineral by name
			# and a colour without it showing in the market, i.e. getScan()
			out[1] = MINERALDRIVER_PRICE_STRUCTURE % [mname,mname,price]
			var handle:String = mineral.get("handle","none")
			if handle == "scenes":
				# Handle for providing a list of premade scene filepaths to use for the ores
				out[2] = MINERALDRIVER_CONTENT_STRUCTURE % [mname,mname,
					MINERALDRIVER_SCENES_STRUCTURE % [mineral["ore_1"],
						mineral["ore_2"],mineral["ore_3"],
						mineral["ore_4"],mineral["ore_5"],
						mineral["ore_6"],mineral["ore_7"]]
				]
				out[3] = MINERALDRIVER_TRACE_STRUCTURE % [mname,mname]
				pointers.l("adding mineral %s using handler [scene]" % mname,log_header)
			elif handle == "recolor":
				var base:String = "fe"
				match mineral.get("base","fe").to_lower():
					"fe","iron":base = "fe"
					"v","vanadium":base = "v"
					"be","beryllium":base = "be"
					"pd","palladium":base = "pd"
					"pt","platinum":base = "pt"
					"w","tungsten","wolfram":base = "w"
				var color:Color = mineral.get("color",Color.white)
				var mass:float = mineral.get("mass",0.0)
				var filler_mineral:String = mineral.get("filler","H2O")
				var min_scale:float = mineral.get("min_scale",0.75)
				var max_scale:float = mineral.get("max_scale",0.75)
				var ferrous:bool = mineral.get("ferrous",false)
				var purityInfo:Dictionary = mineral.get("purity",Dictionary())
				var purityKeys:PoolIntArray = PoolIntArray(purityInfo.keys())
				var folder:String = MINERALDRIVER_DIRECTORY_STRUCTURE % [mname,int(color.r*255),int(color.g*255),int(color.b*255)]
				var specific_data:Dictionary = mineral.get("specific_ore_data",Dictionary())
				var specificKeys:PoolIntArray = PoolIntArray(specific_data.keys())
				Directory.new().make_dir_recursive(folder)
				var file:File = File.new()
				var mh:String = "[\n"
				for i in 7:
					i += 1
					var fn:String = folder + "h%s.tscn" % i
					if i in specificKeys:
						var idx:Dictionary = specific_data[i]
						var cl:Color = idx.get("color",color)
						var data:String = MINERALDRIVER_HEADER_STRUCTURE % [
							base,i,mname,cl.r,cl.g,cl.b,
							idx.get("mass",mass),
							idx.get("filler",filler_mineral),
							idx.get("min_scale",min_scale),
							idx.get("max_scale",max_scale),
							"true" if idx.get("ferrous",ferrous) else "false"]
						file.open(fn,File.WRITE)
						file.store_string((data + "\npurity = %f" % purityInfo[i]) if (i in purityKeys) else data)
						file.close()
					else:
						var data:String = MINERALDRIVER_HEADER_STRUCTURE % [
							base,i,mname,color.r,color.g,color.b,
							mass,filler_mineral,min_scale,max_scale,
							"true" if ferrous else "false"]
						file.open(fn,File.WRITE)
						file.store_string((data + "\npurity = %f" % purityInfo[i]) if (i in purityKeys) else data)
						file.close()
					mh += "load(\"%s\"),\n" % fn
				out[2] = MINERALDRIVER_CONTENT_STRUCTURE % [mname,mname,mh + "]"]
				out[3] = MINERALDRIVER_TRACE_STRUCTURE % [mname,mname]
				pointers.l("adding mineral %s using handler [recolor]" % mname,log_header)
			else:pointers.l("mineral %s registered with price and colour but not adding to ring" % mineral,log_header)
		else:pointers.l("adding only color references for mineral %s, value set to zero or below" % mineral,log_header)
		return out

class _Threading:
	# https://www.reddit.com/r/godot/comments/elp4ap/how_to_use_multithreading/
	
	var pointers:HevLibPointers
	
	var thread_queue:Array = Array()
	var thread_return:Dictionary = Dictionary()
	var semaphore_store:Dictionary = Dictionary()
	
	var available_threads:Array = Array()
	var max_threads:int = OS.get_processor_count() - 2
	var max_queue:int = 127
	
	# If 2 or fewer logical cores, swap over to use single threading
	var require_single_threading:bool = max_threads < 1 or DEBUG_SINGLE_THREAD_ONLY
	
	var use_single_thread:bool = require_single_threading
	
	var thread_refs:Array = Array()
	var mutex:Mutex = Mutex.new()
	
	const log_header = "pointers.Threading"
	
	func _init(p):
		pointers = p
		if not require_single_threading:
			var cfg:Dictionary = pointers.ConfigDriver.__config_parse("user://cfg/Mod_Configurations.cfg").get("HevLib/HEVLIB_CONFIG_SECTION_POINTERS",Dictionary())
			use_single_thread = cfg.get("single_thread_only",false)
			max_queue = cfg.get("max_thread_queue",128) - 1
			pointers.ConfigDriver.__subscribe_to_setting_change("update_thread_mode",self,"HevLib","HEVLIB_CONFIG_SECTION_POINTERS","single_thread_only")
			pointers.ConfigDriver.__subscribe_to_setting_change("update_max_queue",self,"HevLib","HEVLIB_CONFIG_SECTION_POINTERS","max_thread_queue")
			for i in max_threads:
				thread_refs.append(ThreadStruct.new(self,i))
	func update_thread_mode(how:bool):
		use_single_thread = how
	func update_max_queue(how:int):
		max_queue = int(clamp(how,64,1024)) - 1
	
	# This took me probably close to 2 weeks to fine tune, 1.5 days alone was chasing
	# a bug caused by me testing with the single most thread-unsafe code I had
	# Hope this actually ends up being useful...
	func __request_multiple_threads(operations:Array,log_info:bool = false) -> Array:
		if!operations:
			return Array()
		if use_single_thread:
			if log_info:pointers.l("Requesting mutltiple thread operations, but using main thread",log_header)
			var out:Array = Array()
			for next_op in operations:
				var current_object:Object = next_op.get("object",null)
				var args:Array = next_op.get("args",Array())
				var current_method_call:String = next_op.get("method","")
				if current_object != null and is_instance_valid(current_object) and not current_object.is_queued_for_deletion() and current_object.has_method(current_method_call):
					var op = current_object.callv(current_method_call,args)
					if op is GDScriptFunctionState:
						op = call_single_thread(op)
					out.append(op)
				else:
					printerr("Attempting to call thread with invalid object or function name")
					out.append(null)
			return out
		var request_id:int = (operations.hash() + Time.get_ticks_usec()) & 0x7FFFFFFF
		if log_info:pointers.l("Requesting multiple thread operations under request [%d] @ %d" % [request_id,OS.get_ticks_msec()],log_header)
		var semaphore:Semaphore = Semaphore.new()
		var added_op:int = 0
		mutex.lock()
		var ops:Array = Array()
		for i in operations:
			if i and i is Dictionary:
				i["request_id"] = request_id
				i["not_async"] = true
				ops.append(i)
				added_op += 1
		if added_op < 1:
			mutex.unlock()
			return Array()
		semaphore_store[request_id] = [added_op,semaphore]
		thread_return[request_id] = Array()
		for thread in available_threads:
			if ops:
				if not thread.get_running():
					thread.pop_post(ops.pop_front())
					thread.semaphore.post()
			else: break
		if ops:
			thread_queue.append_array(ops)
		mutex.unlock()
		semaphore.wait()
		mutex.lock()
		var out:Array = thread_return[request_id]
		thread_return.erase(request_id)
		mutex.unlock()
		return out
	
	func __request_single_thread(operation:Dictionary,log_info:bool = false) -> Array:
		if use_single_thread:
			if log_info:pointers.l("Requesting single thread operation, but using main thread",log_header)
			var current_object:Object = operation.get("object",null)
			var args:Array = operation.get("args",Array())
			var current_method_call:String = operation.get("method","")
			if current_object != null and is_instance_valid(current_object) and not current_object.is_queued_for_deletion() and current_object.has_method(current_method_call):
				var op = current_object.callv(current_method_call,args)
				if op is GDScriptFunctionState:
					op = call_single_thread(op)
				return [op]
			printerr("Attempting to call thread with invalid object or function name")
			return [null]
		var request_id:int = (operation.hash() + Time.get_ticks_usec()) & 0x7FFFFFFF
		if log_info:pointers.l("Requesting single thread operation under request [%d]" % request_id,log_header)
		var semaphore:Semaphore = Semaphore.new()
		var added_op:int = 0
		mutex.lock()
		if operation:
			operation["request_id"] = request_id
			operation["not_async"] = true
		else:
			mutex.unlock()
			return Array()
		semaphore_store[request_id] = [1,semaphore]
		thread_return[request_id] = Array()
		var needs_queue:bool = true
		for thread in available_threads:
			if not thread.get_running():
				thread.pop_post(operation)
				thread.semaphore.post()
				needs_queue = false
				break
		if needs_queue:
			thread_queue.append(operation)
		mutex.unlock()
		semaphore.wait()
		mutex.lock()
		var out:Array = thread_return[request_id]
		thread_return.erase(request_id)
		mutex.unlock()
		return out
	
	func __run_multiple_async_operations(operations:Array,log_info:bool = false) -> int:
		if!operations:
			return ERR_UNCONFIGURED
		if use_single_thread:
			if log_info:pointers.l("Requesting mutltiple thread operations, but using main thread",log_header)
			var out:int = OK
			for next_op in operations:
				var current_object:Object = next_op.get("object",null)
				var args:Array = next_op.get("args",Array())
				var current_method_call:String = next_op.get("method","")
				if current_object != null and is_instance_valid(current_object) and not current_object.is_queued_for_deletion() and current_object.has_method(current_method_call):
					current_object.callv(current_method_call,args)
				else:
					printerr("Attempting to call thread with invalid object or function name")
					out = ERR_UNCONFIGURED
			return out
		if thread_queue.size() > max_queue:
			return ERR_UNCONFIGURED
		var request_id:int = (operations.hash() + Time.get_ticks_usec()) & 0x7FFFFFFF
		if log_info:pointers.l("Requesting multiple async thread operations under request [%d]" % request_id,log_header)
		var semaphore:Semaphore = Semaphore.new()
		var added_op:int = 0
		mutex.lock()
		var ops:Array = Array()
		for i in operations:
			if i and i is Dictionary:
				i["request_id"] = request_id
				i["not_async"] = false
				ops.append(i)
				added_op += 1
		if added_op < 1:
			mutex.unlock()
			return ERR_UNCONFIGURED
		semaphore_store[request_id] = [added_op,semaphore]
		thread_return[request_id] = Array()
		for thread in available_threads:
			if ops:
				if not thread.get_running():
					thread.pop_post(ops.pop_front())
					thread.semaphore.post()
			else: break
		if ops:
			thread_queue.append_array(ops)
		mutex.unlock()
		return OK
	
	func __run_single_async_operation(operation:Dictionary,log_info:bool = false) -> int:
		if use_single_thread:
			if log_info:pointers.l("Requesting single thread operation, but using main thread",log_header)
			var current_object:Object = operation.get("object",null)
			var args:Array = operation.get("args",Array())
			var current_method_call:String = operation.get("method","")
			if current_object != null and is_instance_valid(current_object) and not current_object.is_queued_for_deletion() and current_object.has_method(current_method_call):
				current_object.callv(current_method_call,args)
				return OK
			else:
				printerr("Attempting to call thread with invalid object or function name")
				return ERR_UNCONFIGURED
		var request_id:int = (operation.hash() + Time.get_ticks_usec()) & 0x7FFFFFFF
		if log_info:pointers.l("Requesting single async thread operation under request [%d]" % request_id,log_header)
		var semaphore:Semaphore = Semaphore.new()
		var added_op:int = 0
		mutex.lock()
		if operation:
			operation["request_id"] = request_id
			operation["not_async"] = false
		else:
			mutex.unlock()
			return ERR_UNCONFIGURED
		semaphore_store[request_id] = [1,semaphore]
		thread_return[request_id] = Array()
		if thread_queue.size() > max_queue:
			return ERR_UNCONFIGURED
		var needs_queue:bool = true
		for thread in available_threads:
			if not thread.get_running():
				thread.pop_post(operation)
				thread.semaphore.post()
				needs_queue = false
				break
		if needs_queue:
			thread_queue.append(operation)
		mutex.unlock()
		return OK
	
	func _notification(what):
		if what == NOTIFICATION_PREDELETE:
			thread_queue.clear()
			available_threads.clear()
			thread_return.clear()
			semaphore_store.clear()
			thread_refs.clear()
	
	func claim_thread_for_process(thread,thread_id:int):
		mutex.lock()
		while thread in available_threads:
			available_threads.erase(thread)
		mutex.unlock()
	
	func set_thread_to_idle(thread,thread_id:int):
		mutex.lock()
		if not thread in available_threads:
			available_threads.append(thread)
		mutex.unlock()
	
	func call_single_thread(data:GDScriptFunctionState):
		current_data_for_single_thread = data
		single_thread_thread = Thread.new()
		single_thread_thread.start(self,"single_thread_yield_safe")
		return single_thread_thread.wait_to_finish()
	
	var single_thread_thread:Thread = null
	var current_data_for_single_thread:GDScriptFunctionState = null
	func single_thread_yield_safe(a):
		var op = current_data_for_single_thread
		if op is GDScriptFunctionState:
			op = yield(current_data_for_single_thread,"completed")
		return op
	
	class ThreadStruct:
		extends Reference
		
		var semaphore:Semaphore = Semaphore.new()
		var mutex:Mutex = Mutex.new()
		var thread:Thread = Thread.new()
		
		var container:_Threading
		var pointers:HevLibPointers
		
		var thread_id:int = -1
		
		func _init(cv:_Threading,idx:int):
			thread_id = idx
			container = cv
			thread.start(self,"running_thread")
		
		var running:bool = false
		var quit:bool = false
		var next_op = null
		
		func running_thread(a):
			while true:
				mutex.lock()
				if not next_op is Dictionary:
					running = false
					mutex.unlock()
					container.set_thread_to_idle(self,thread_id)
					semaphore.wait()
				else:
					mutex.unlock()
				
				mutex.lock()
				if quit:
					mutex.unlock()
					return
				container.claim_thread_for_process(self,thread_id)
				var not_async:bool = next_op["not_async"]
				var current_thread_id:int = next_op["request_id"]
				var current_object:Object = next_op.get("object",null)
				var args:Array = next_op.get("args",Array())
				var current_method_call:String = next_op.get("method","")
				next_op = null
				mutex.unlock()
				var out = null
				if current_object != null and is_instance_valid(current_object) and not current_object.is_queued_for_deletion() and current_object.has_method(current_method_call):
					out = current_object.callv(current_method_call,args)
					if out is GDScriptFunctionState:
						out = yield(out,"completed")
				container.mutex.lock()
				if not_async:
					container.thread_return[current_thread_id].append(out)
					var cr:Array = container.semaphore_store[current_thread_id]
					cr[0] -= 1
					if cr[0] < 1:
						cr[1].post()
				var next = container.thread_queue.pop_front()
				container.mutex.unlock()
				pop_post(next)
		
		func _notification(what):
			if what == NOTIFICATION_PREDELETE:
				mutex.lock()
				quit = true
				semaphore.post()
				mutex.unlock()
				thread.wait_to_finish()
		
		func pop_post(data):
			next_op = null
			if data is Dictionary:
				mutex.lock()
				running = true
				next_op = data.duplicate(true)
				mutex.unlock()
		
		func set_running(how:bool):
			mutex.lock()
			running = how
			mutex.unlock()
		func get_running() -> bool:
			mutex.lock()
			var how:bool = running
			mutex.unlock()
			return how
		

var copyrights:String = hl_copyright
class _TimeAccess:
	func _init(p):
		pass
	
	static func __compare_dates(date:String, compare_to_this_date:String):
		var difference : String = "newer"
		var splitOne:PoolStringArray = date.split("T")
		var splitTwo:PoolStringArray = compare_to_this_date.split("T")
		var dateOne:PoolStringArray = splitOne[0].split("-")
		var dateTwo:PoolStringArray = splitTwo[0].split("-")
		var timeOne:PoolStringArray = splitOne[1].split(":")
		var timeTwo:PoolStringArray = splitTwo[1].split(":")
		var concatOne : Array = [dateOne[0],dateOne[1],dateOne[2],timeOne[0],timeOne[1],timeOne[2]]
		var concatTwo : Array = [dateTwo[0],dateTwo[1],dateTwo[2],timeTwo[0],timeTwo[1],timeTwo[2]]
		var index:int = 0
		while index < 6:
			var compare1 = concatOne[index]
			var compare2 = concatTwo[index]
			if compare1 > compare2:
				return "newer"
			elif compare1 < compare2:
				return "older"
			index += 1
		return "equal"
	
	static func __get_time_in_seconds(datetime_dict : Dictionary):
		var time : int = 0
		time += (datetime_dict.get("second",0))
		time += (datetime_dict.get("minute",0) * 60)
		time += (datetime_dict.get("hour",0) * 60 * 60)
		time += (datetime_dict.get("day",0) * 60 * 60 * 24)
		time += (datetime_dict.get("month",0) * 60 * 60 * 24 * 30)
		time += (datetime_dict.get("year",0) * 60 * 60 * 24 * 30 * 12)
		return time
	
	static func __get_dos_datetime(datetime:Dictionary = Time.get_datetime_dict_from_system()) -> Dictionary:
		var dos_time:int = (datetime.hour << 11) | (datetime.minute << 5) | int(datetime.second / 2.0)
		var dos_date:int = (int(max(datetime.year - 1980, 0)) << 9) | (datetime.month << 5) | datetime.day
		return {"time":dos_time, "date":dos_date}

class _Tokenizer:
	func _init(p):
		pass
	
	var tokenizer_script:Script = load("res://HevLib/scripts/tokenizer/tokenizer.gd")
	
	func __compile_source_to_bytecode(source:String) -> PoolByteArray:
		var tk:Reference = tokenizer_script.new()
		if tk.__source_to_tokens(source):
			return tk.__get_compiled_bytecode_from_tokens()
		return PoolByteArray()
	
	func __bytecode_to_source(compiled_data:PoolByteArray) -> String:
		var tk:Reference = tokenizer_script.new()
		if tk.__compiled_bytecode_to_tokens(compiled_data):
			return tk.__tokens_to_source()
		return ""
	
	func __normalize_source(source:String) -> String:
		var tk:Reference = tokenizer_script.new()
		if tk.__source_to_tokens(source):
			return tk.__tokens_to_source()
		return ""
	
	
	
	
	
	func __get_tokenizer():
		return tokenizer_script.new()
	
	
	
	
	enum{
		TK_EMPTY,TK_IDENTIFIER,TK_CONSTANT,TK_SELF,TK_BUILT_IN_TYPE,TK_BUILT_IN_FUNC,TK_OP_IN,TK_OP_EQUAL,
		TK_OP_NOT_EQUAL,TK_OP_LESS,TK_OP_LESS_EQUAL,TK_OP_GREATER,TK_OP_GREATER_EQUAL,TK_OP_AND,TK_OP_OR,
		TK_OP_NOT,TK_OP_ADD,TK_OP_SUB,TK_OP_MUL,TK_OP_DIV,TK_OP_MOD,TK_OP_SHIFT_LEFT,TK_OP_SHIFT_RIGHT,TK_OP_ASSIGN,
		TK_OP_ASSIGN_ADD,TK_OP_ASSIGN_SUB,TK_OP_ASSIGN_MUL,TK_OP_ASSIGN_DIV,TK_OP_ASSIGN_MOD,TK_OP_ASSIGN_SHIFT_LEFT,
		TK_OP_ASSIGN_SHIFT_RIGHT,TK_OP_ASSIGN_BIT_AND,TK_OP_ASSIGN_BIT_OR,TK_OP_ASSIGN_BIT_XOR,TK_OP_BIT_AND,
		TK_OP_BIT_OR,TK_OP_BIT_XOR,TK_OP_BIT_INVERT,TK_CF_IF,TK_CF_ELIF,TK_CF_ELSE,TK_CF_FOR,TK_CF_WHILE,TK_CF_BREAK,
		TK_CF_CONTINUE,TK_CF_PASS,TK_CF_RETURN,TK_CF_MATCH,TK_PR_FUNCTION,TK_PR_CLASS,TK_PR_CLASS_NAME,TK_PR_EXTENDS,
		TK_PR_IS,TK_PR_ONREADY,TK_PR_TOOL,TK_PR_STATIC,TK_PR_EXPORT,TK_PR_SETGET,TK_PR_CONST,TK_PR_VAR,TK_PR_AS,
		TK_PR_VOID,TK_PR_ENUM,TK_PR_PRELOAD,TK_PR_ASSERT,TK_PR_YIELD,TK_PR_SIGNAL,TK_PR_BREAKPOINT,TK_PR_REMOTE,
		TK_PR_SYNC,TK_PR_MASTER,TK_PR_SLAVE,TK_PR_PUPPET,TK_PR_REMOTESYNC,TK_PR_MASTERSYNC,TK_PR_PUPPETSYNC,
		TK_BRACKET_OPEN,TK_BRACKET_CLOSE,TK_CURLY_BRACKET_OPEN,TK_CURLY_BRACKET_CLOSE,TK_PARENTHESIS_OPEN,
		TK_PARENTHESIS_CLOSE,TK_COMMA,TK_SEMICOLON,TK_PERIOD,TK_QUESTION_MARK,TK_COLON,TK_DOLLAR,TK_FORWARD_ARROW,
		TK_NEWLINE,TK_CONST_PI,TK_CONST_TAU,TK_WILDCARD,TK_CONST_INF,TK_CONST_NAN,TK_ERROR,TK_EOF,TK_CURSOR,TK_MAX
	}
	
	
	

class _Translations:
	const non_static = Dictionary()
	func _init(c):
		non_static["pointers"] = c
		non_static["self"] = self
	
	const log_header = "pointers.Translations"
	
	static func __updateTL(path:String, delim:String = ",", fullLogging:bool = true):
		var pointers:HevLibPointers = non_static["pointers"]
		var file:File = File.new()
		var fileName : String = path.get_file()
		pointers.l("Adding translations from [%s] in [%s]" % [fileName, path.split(fileName)[0]],log_header)
		file.open(path, File.READ)
		var translations : Array = Array()
		var translationCount:int = 0
		var csvLine : PoolStringArray = file.get_line().split(delim)
		if fullLogging:
			pointers.l("Adding translations as: %s" % csvLine,log_header)
		for i in (csvLine.size() - 1):
			var translationObject:Translation = Translation.new()
			translationObject.locale = csvLine[i + 1]
			translations.append(translationObject)
		while not file.eof_reached():
			var line:String = file.get_line()
			if line.begins_with("#"):
				continue
			csvLine = line.split(delim)
			var size:int = csvLine.size()
			if size > 1:
				if size > 2:
					var i:int = 0
					while i < size:
						if csvLine[i].ends_with("\\") and i < size:
							csvLine[i] = csvLine[i].trim_suffix("\\") + delim + csvLine[i + 1]
							csvLine.remove(i + 1)
							size -= 1
						i += 1
				var translationID : String = csvLine[0]
				for i in (size - 1):
					translations[i].add_message(translationID, csvLine[i].c_unescape())
				if fullLogging:
					pointers.l("Added translation: %s" % csvLine,log_header)
				translationCount += 1
		file.close()
		for translationObject in translations:
			TranslationServer.add_translation(translationObject)
		pointers.l("%s Translations Updated from @ [%s]" % [translationCount, fileName],log_header)
	
	static func __updateTL_from_dictionary(path:Dictionary, fullLogging:bool = true):
		var pointers:HevLibPointers = non_static["pointers"]
		pointers.l("Adding translations from dictionary: %d" % path.hash(),log_header)
		var translations : Array = Array()
		var translationCount:int = 0
		if "file" in path:
			var file_paths : String = path["file"]
			for file in file_paths:
				var delim = file_paths[file]
				if delim is String:
					var dict : Dictionary = __translation_file_to_dictionary(file,delim)
					__updateTL_from_dictionary(dict,fullLogging)
				elif delim is Dictionary:
					var string : String = delim.get("string","")
					if string:
						var mod : String = delim.get("mod","")
						var section : String = delim.get("section","")
						var setting : String = delim.get("setting","")
						var invert:bool = delim.get("invert",false)
						var val = pointers.ConfigDriver.__get_value(mod,section,setting,null)
						var do:bool = true
						if val is bool:
							do = val
						if invert:
							do = !do
						if do:
							__updateTL_from_dictionary(__translation_file_to_dictionary(file,string),fullLogging)
			
			path.erase("file")
		for lang in path.keys():
			var translationObject:Translation = Translation.new()
			translationObject.locale = lang
			var translation_dict:Dictionary = path[lang]
			for key in translation_dict.keys():
				var data = translation_dict[key]
				if data is String:
					translationObject.add_message(key,data.c_unescape())
					if fullLogging:
						pointers.l("Added translation: %s" % key,log_header)
				elif data is Dictionary:
					var string:String = data.get("string","")
					if string:
						var mod:String = data.get("mod","")
						var section:String = data.get("section","")
						var setting:String = data.get("setting","")
						var invert:bool = data.get("invert",false)
						var val = pointers.ConfigDriver.__get_value(mod,section,setting,null)
						var do = true
						if val is bool:
							do = val
						if invert:
							do = !do
						if do:
							translationObject.add_message(key,string.c_unescape())
						if fullLogging:
							pointers.l("Added translation: %s" % key,log_header)
			translationCount += 1
			
			translations.append(translationObject)
		for translationObject in translations:
			TranslationServer.add_translation(translationObject)
		if fullLogging:
			pointers.l("%s Translations Updated" % translationCount,log_header)
	
	static func __translation_file_to_dictionary(path : String, delimiter : String = "|", fullLogging : bool = true) -> Dictionary:
		if not Directory.new().file_exists(path):
			return Dictionary()
		var dictionary:Dictionary = Dictionary()
		var file:File = File.new()
		file.open(path,File.READ)
		var lines:PoolStringArray = file.get_as_text(true).split("\n")
		file.close()
		
		var lang_data:String = lines[0]
		var language_lines:PoolStringArray = lang_data.split(delimiter)
		if not language_lines[0] == "locale":
			return Dictionary()
		if language_lines.size() < 2:
			return Dictionary()
		var languages:Array = Array()
		var lsize:int = language_lines.size()
		var lindex:int = 1
		while lindex < lsize:
			languages.append(language_lines[lindex])
			lindex += 1
		
		for lang in languages:
			dictionary[lang] = Dictionary()
		var translation_count:int = 0
		var size:int = lines.size()
		var index:int = 1
		while index < size:
			var line:String = lines[index]
			if!line:
				index += 1
				continue
			if line.begins_with("#"):
				continue
			var line_split:PoolStringArray = line.split(delimiter)
			var split_size:int = line_split.size()
			var lang_size:int = languages.size()
			if split_size > 2:
				var i:int = 0
				while i < split_size:
					if line_split[i].ends_with("\\") and i < split_size:
						line_split[i] = line_split[i].rstrip("\\") + delimiter + line_split[i + 1]
						line_split.remove(i + 1)
						split_size -= 1
					i += 1
			if split_size == 1:
				index += 1
				continue
			if split_size - 1 < lang_size:
				index += 1
				continue
			var translation_string:String = line_split[0]
			var tlindex:int = 0
			while tlindex < lang_size:
				var lang:String = languages[tlindex]
				dictionary[lang][translation_string] = line_split[tlindex + 1]
				tlindex += 1
			index += 1
			translation_count += 1
		if fullLogging:
			non_static["pointers"].l("%s translations converted from translation file %s" % [translation_count,path],log_header)
		return dictionary
	
	static func __inject_translations():
		var base:_Translations = non_static["self"]
		var pointers:HevLibPointers = non_static["pointers"]
		var fullLogging:bool = pointers.ConfigDriver.__get_value("HevLib","HEVLIB_CONFIG_SECTION_POINTERS","full_logging",false)
		var markPlaceholders:bool = pointers.ConfigDriver.__get_value("HevLib","HEVLIB_CONFIG_SECTION_DEBUG","mark_placeholder_translations",false)
		TranslationServer.clear()
		var processes:Array = Array()
		for mod in pointers.DriverManagement.__get_specific_driver_type("REPLACE_TRANSLATIONS.gd"):
			var tl:Dictionary = mod.get("TRANSLATIONS",Dictionary())
			if tl:
				processes.append({"object":base,"method":"process_drivers_for_translations","args":[tl,markPlaceholders,pointers,TranslationServer]})
		# April Fool's alcohol!
		var date:Dictionary = Time.get_date_dict_from_system()
		if date.month == 4 and date.day == 1:
			var alocol:Translation = Translation.new()
			alocol.add_message("H2O","C2H6O")
			TranslationServer.add_translation(alocol)
		var ml_check_data:Dictionary = Dictionary()
		var trl:Array = pointers.Threading.__request_multiple_threads(processes)
		for item in trl:
			for lang in item.keys():
				if not lang in ml_check_data:
					ml_check_data[lang] = item[lang]
				else:
					var data:Dictionary = item[lang]
					for check in data.keys():
						ml_check_data[lang][check] += data[check]
		var file:File = File.new()
		file.open("user://cache/translation_check_data.json",File.WRITE)
		file.store_string(JSON.print(ml_check_data,"\t"))
		file.close()
		var add_v_tl:Array = Array()
		for i in ProjectSettings.get_setting("locale/translations"):
			add_v_tl.append({"object":base,"method":"reload_vanilla_translation","args":[i]})
		pointers.Threading.__request_multiple_threads(add_v_tl)
	
	static func reload_vanilla_translation(tl_file:String):
		TranslationServer.add_translation(ResourceLoader.load(tl_file,"Translation",true))
	
	static func process_drivers_for_translations(translations:Dictionary,markPlaceholders:bool,pointers:HevLibPointers,TranslationServer:Object):
		var check_data:Dictionary = Dictionary()
		var master_locale:String = ""
		if "master_locale" in translations:
			master_locale = translations["master_locale"]
			translations.erase("master_locale")
		if "file" in translations:
			var tlFiles = translations["file"]
			for tl in tlFiles:
				var d = tlFiles[tl]
				var delim:String = "|"
				var operate:bool = true
				if d is String:
					delim = d
				elif d is Dictionary:
					delim = d.get("string",delim)
					if not pointers.ConfigDriver.__validate_dictionary(d):
						operate = false
				if operate:
					var dict:Dictionary = __translation_file_to_dictionary(tl,delim)
					for lang in dict:
						if not lang in translations:
							translations[lang] = Dictionary()
						translations[lang].merge(dict[lang],true)
			translations.erase("file")
		for language in translations:
			var tl:Translation = Translation.new()
			tl.locale = language
			var check_ml:bool = false
			var lang:Dictionary = translations[language]
			var mlt = null
			if master_locale and language != master_locale:
				if not language in check_data:
					check_data[language] = {"needs_updating":Array(),"needs_updating_size":0,"not_in_master":Array(),"not_in_master_size":0,"missing_translations":Array(),"missing_translations_size":0,"placeholders":Array(),"placeholders_size":0}
				check_ml = true
				mlt = translations[master_locale]
				if lang.size() < mlt.size():
					for tv in mlt:
						if not tv in lang:
							check_data[language]["missing_translations"].append(tv)
							check_data[language]["missing_translations_size"] += 1
			for t in lang.keys():
				var v = lang[t]
				if v is String:
					tl.add_message(t,v.c_unescape())
				elif v is Dictionary:
					if check_ml:
						if mlt and t in mlt:
							var c = mlt[t]
							if "version_hash" in v and c is Dictionary and "string" in c:
								if hash(c.string) != v.version_hash:
									check_data[language]["needs_updating"].append(t)
									check_data[language]["needs_updating_size"] += 1
						else:
							check_data[language]["not_in_master"].append(t)
							check_data[language]["not_in_master_size"] += 1
					if "placeholder" in v and v.placeholder:
						if not language in check_data:
							check_data[language] = {"placeholders":Array(),"placeholders_size":0}
						check_data[language]["placeholders"].append(t)
						check_data[language]["placeholders_size"] += 1
						if markPlaceholders:
							v["string"] = "[PLACEHOLDER] " + v["string"]
					tl.add_message(t,v.string.c_unescape())
			TranslationServer.add_translation(tl)
		return check_data


class _WebTranslate:
	const non_static = Dictionary()
	func _init(f):
		non_static["pointers"] = f
	
	const log_header = "pointers.WebTranslate"
	
	func __webtranslate(URL: String, fallback: Array = Array(), file_check: String = ""):
		var pointers:HevLibPointers = non_static["pointers"]
		pointers.l("Fetching translations from %s" % URL,log_header)
		var HevLib = load("res://HevLib/webtranslate/FetchGithubData.tscn").instance()
		var pms = Debug.get_node("/root")
		var tstamp = Time.get_datetime_string_from_system()
		var date = str(tstamp.split("T")[0])
		var time = str(tstamp.split("T")[1])
		var tSpl = time.split(":")
		var timeConcat = tSpl[0] + "-" + tSpl[1] + "-" + tSpl[2]
		var timestamp = "~" + date + "~" + timeConcat
		var nodes = pms.get_children()
		var names = Array()
		for node in nodes:
			var name = node.name
			if name.begins_with("FetchGithubData"):
				names.append(name)
		var nSize = names.size()
		pointers.l("attaching node @ FetchGithubData%s~%s" % [timestamp,str(nSize)],log_header)
		HevLib.name = "FetchGithubData" + timestamp + "~" + str(nSize)
		HevLib.URLFullStopReformat = URL
		HevLib.fallbackFiles = fallback
		
		HevLib.file_check = file_check
		pms.call_deferred("add_child",HevLib)
	
	func __webtranslate_reset(URL: String) -> bool:
		var dataSplit = str(URL).split("github.com/")[1].split("/")
		var user = dataSplit[0]
		var repo = dataSplit[1]
		var folderToDelete = "user://cache/WebTranslate/" + user + "~_~" + repo
		var pointers:HevLibPointers = non_static["pointers"]
		pointers.l("deleting cache folder @ %s" % folderToDelete,log_header)
		return pointers.FolderAccess.__recursive_delete(folderToDelete)
	
	func __webtranslate_reset_by_file_check(file_check: String) -> bool:
		var did = false
		var folder_to_delete = ""
		var pointers:HevLibPointers._FolderAccess = non_static["pointers"].FolderAccess
		for file in pointers.__fetch_folder_files("user://cache/WebTranslate/", true, true):
			if not file.ends_with("/"):
				continue
			var cFiles = pointers.__fetch_folder_files(file, false, true)
			for f in cFiles:
				if not f.ends_with(".file_check_cache"):
					continue
				var fo = File.new()
				fo.open(f,File.READ)
				var txt = fo.get_as_text()
				fo.close()
				if txt == file_check:
					folder_to_delete = file
				else:
					continue
		if folder_to_delete:
			did = pointers.__recursive_delete(folder_to_delete)
		return did
	
	func __webtranslate_timed(URL: String, MINUTES_DELAY: int, fallback: Array = Array(), file_check: String = ""):
		var pointers:HevLibPointers = non_static["pointers"]
		pointers.l("function 'webtranslate_timed' initiated, starting constant translation of [%s] with a delay of [%s] minutes" % [URL,MINUTES_DELAY],log_header)
		var handleNode = load("res://HevLib/webtranslate/WebtranslateTimerHandler.tscn").instance()
		handleNode.name = URL + Time.get_time_string_from_system()
		handleNode.URL = URL
		handleNode.MINUTES = MINUTES_DELAY
		handleNode.fallback = fallback
		handleNode.file_check = file_check
		pointers.add_child(handleNode)

class _Zip:
	const non_static = Dictionary()
	func _init(p):
		non_static["pointers"] = p
	
	const log_header = "pointers.Zip"
	
	
	
	# Port of the `load` method from hhyyrylainen's GodotPckTool
	# https://github.com/hhyyrylainen/GodotPckTool
	static func __load_pck(file_path:String,only_filenames:bool = false):
		var file:File = File.new()
		var dir:Directory = Directory.new()
		var pointers:HevLibPointers = non_static["pointers"]
		pointers.l("Loading PCK @ %s, fetching only filenames? [%s]" % [file_path,only_filenames],log_header)
		var Contents:Dictionary = Dictionary()
		var Files:PoolStringArray = PoolStringArray()
		file.open(file_path,File.READ)
		file.seek(0)
		if file.get_32() != 0x43504447: # GDPC
			printerr("ERROR: invalid magic number")
			if only_filenames:return Files
			return Contents
		if file.get_32() > 1:
			printerr("ERROR: PCK files written in godot 4.0 or later are unsupported")
			if only_filenames:return Files
			return Contents
		file.seek(file.get_position() + 76)
		for i in file.get_32():
			var path:String = file.get_buffer(file.get_32()).get_string_from_utf8()
			if only_filenames:
				Files.append(path)
				file.seek(file.get_position() + 32)
			else:
				var offset:int = file.get_64()
				var size:int = file.get_64()
				var md5:PoolByteArray = file.get_buffer(16)
				var oldPos:int = file.get_position()
				file.seek(offset)
				var read:PoolByteArray = file.get_buffer(size)
				if read.size() != size:
					printerr("reading file entry content failed (specified offset or data length is too large, pck may be corrupt or malformed)")
				Contents[path] = {
					"path":path,
					"offset":offset,
					"size":size,
					"md5":md5,
					"data":read
				}
				file.seek(oldPos)
		pointers.l(("Finished fetching PCK data, found %d files" % Files.size()) if only_filenames else ("Finished fetching PCK data, fetched %d files" % Contents.size()),log_header)
		if only_filenames:return Files
		return Contents
	
	static func __write_pck(file_path:String,files:Dictionary) -> int:
		var packer:PCKPacker = PCKPacker.new()
		var file:File = File.new()
		packer.pck_start(file_path)
		for file_name in files.keys():
			if file_name.begins_with("res://"):
				var pkfilename:String = "user://cache/Variable_Fetch/writepck_%d" % Time.get_ticks_usec()
				file.open(pkfilename,File.WRITE)
				file.store_buffer(non_static["pointers"].FileAccess.__file_output_to_buffer(files[file_name]))
				file.close()
				packer.add_file(file_name,pkfilename)
		return packer.flush()
	
	static func __get_zip_content(path:String) -> PoolStringArray:
		var miniz:MINIZ = __get_miniz_object()
		if miniz.open_read(path) == OK:
			var fileList:PoolStringArray = miniz.list_files()
			miniz.close()
			return fileList
		return PoolStringArray()
	
	static func __fetch_file_from_zip(path:String, desired_file_names:PoolStringArray, output_directory:String) -> PoolStringArray:
		for i in desired_file_names.size():
			desired_file_names[i] = desired_file_names[i].to_lower()
		var miniz:MINIZ = __get_miniz_object()
		var listOfNames:Dictionary = Dictionary()
		miniz.open_read(path)
		for d in miniz.list_files():
			var df:String = d.to_lower().get_file()
			if df in desired_file_names:
				listOfNames[df] = miniz.read_file(d)
		miniz.close()
		var file:File = File.new()
		var dir:Directory = Directory.new()
		var out:PoolStringArray = PoolStringArray()
		for i in listOfNames.keys():
			var ovr:String = output_directory.plus_file(i)
			dir.make_dir_recursive(ovr.get_base_dir())
			file.open(ovr,File.WRITE)
			file.store_buffer(listOfNames[i])
			file.close()
			out.append(ovr)
		return out
	
	static func __get_miniz_object() -> MINIZ:
		return MINIZ.new()
	
	static func __get_miniz_library():
		return load("res://HevLib/scripts/miniz/miniz.gdns").new()
	
	static func __extract_zip_to_dir(zip_path:String,dir_path:String):
		var miniz:MINIZ = __get_miniz_object()
		if miniz.open_read(zip_path) == OK:
			miniz.extract_all(dir_path)
	
	static func __write_hlz(data,salt:PoolByteArray = PoolByteArray()) -> PoolByteArray:
		if salt and salt.size() != 67:
			printerr("ZIP: HLZ SALT IS WRONG")
			return PoolByteArray()
		var aes:AESContext = AESContext.new()
		var uid:String = OS.get_unique_id()
		var key:PoolByteArray = uid.sha256_buffer()
		if aes.start(AESContext.MODE_CBC_ENCRYPT,key.subarray(0,15),key.subarray(16,31)):
			printerr("ZIP: CANNOT START HLZ WRITE")
			return PoolByteArray()
		var stream:StreamPeerBuffer = StreamPeerBuffer.new()
		var pointers:HevLibPointers = non_static["pointers"]
		stream.put_data(salt if salt else ("HLS" + (uid + "%d.%d.%d" % Array(pointers.DataFormat.__get_vanilla_version()) + pointers.version_string).sha256_text()).to_ascii())
		var toBytes:PoolByteArray = var2bytes(data,true)
		stream.put_32(toBytes.size())
		var forCmp:PoolByteArray = toBytes.compress(1)
		var tbs:int = forCmp.size() % 16
		stream.put_32(tbs)
		if tbs:
			var rem:int = 16 - tbs
			var a:PoolByteArray = PoolByteArray()
			a.resize(rem)
			for i in rem:
				a[i] = 0
			forCmp.append_array(a)
		var ob:PoolByteArray = aes.update(forCmp)
		stream.put_32(ob.size())
		stream.put_data(ob.compress(1))
		aes.finish()
		return stream.data_array
	
	static func __read_hlz(data:PoolByteArray,salt:PoolByteArray = PoolByteArray()):
		if not data:
			printerr("ZIP: HLZ IS EMPTY")
			return null
		var stream:StreamPeerBuffer = StreamPeerBuffer.new()
		stream.put_data(data)
		var ssz:int = stream.get_size()
		stream.seek(0)
		var uid:String = OS.get_unique_id()
		var pointers:HevLibPointers = non_static["pointers"]
		if PoolByteArray(stream.get_data(67)[1]) != (salt if salt else ("HLS" + (uid + "%d.%d.%d" % Array(pointers.DataFormat.__get_vanilla_version()) + pointers.version_string).sha256_text()).to_ascii()):
			printerr("ZIP: SALT IS CORRUPTED")
			return null
		var sz:int = stream.get_32()
		var tbs:int = stream.get_32()
		var tot:int = stream.get_32()
		var bytes:PoolByteArray = stream.get_data(ssz - 8)[1].decompress(tot,1)
		var aes:AESContext = AESContext.new()
		var key:PoolByteArray = uid.sha256_buffer()
		if aes.start(AESContext.MODE_CBC_DECRYPT,key.subarray(0,15),key.subarray(16,31)):
			printerr("ZIP: CANNOT START HLZ READ")
			return null
		var out:PoolByteArray = aes.update(bytes)
		out.resize(out.size() - tbs)
		aes.finish()
		var btr:PoolByteArray = out.decompress(sz,1)
		if btr:
			return bytes2var(btr)
		printerr("ZIP: CANNOT READ HLZ")
		return null
	















func _notification(what):
	match what:
		NOTIFICATION_CRASH:
			l(JSON.print(ManifestV2.__get_mod_data(),"\t"),"pointers")
			l("About to crash, printed mod info","pointers")
			storeLogCache()
		NOTIFICATION_EXIT_TREE:
			l("Exiting game regularly","pointers")
			storeLogCache()






