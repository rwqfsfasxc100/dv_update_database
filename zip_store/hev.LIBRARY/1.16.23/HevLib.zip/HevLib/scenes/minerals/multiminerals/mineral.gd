# [license]
# 3-Clause BSD NON-AI License
# 
# Copyright 2026 __hev (Benjamin Buckhurst)
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

extends "res://asteroids/mineral.gd"

var multiminerals:bool = false

var HevLib_pointers:HevLibPointers

func _enter_tree():
	HevLib_pointers = ModLoader._savedObjects[0]
	hl_multiminerals_UV()

func hl_multiminerals_UV():
	if HevLib_pointers:
		multiminerals = HevLib_pointers.ConfigDriver.__get_value("HevLib","HEVLIB_CONFIG_SECTION_DRIVERS","multiple_minerals_per_chunk")

#Update the roid's mass incase something went fucky
func hl_multiminerals_update_mass():
	hl_multiminerals_calc_comp()
	mass = comp_val


#Sum of all components of the roid
var comp_val = 0.0
func hl_multiminerals_calc_comp():
#	print(composition)
	comp_val = 0.0
	#For every material in the roid
	for type in composition:
		#If that material actually exists 
		if composition[type] >= 0.001:
			#Add it to our sum
			comp_val += composition[type]
		#If the material does not exist
		else:
			#Remove the stray atoms
			composition.erase(type)
	if "fe" in composition:
		set_collision_layer_bit(5,true)
	#Set mineral content to zero so we can abuse the MPU code later
#	mineralContent = 0.0


#Func to let scanners detect all minerals
func getScan():
	if not multiminerals:
		return .getScan()
	#Get our scan value
	var scan : float = rand_range(0, comp_val)
	#For every material in the roid
	var cm = composition.duplicate(true)
	if "H2O" in cm:
		cm.erase("H2O")
	for type in cm:
		#If the scan value is less then the material value
		if scan < cm[type]:
			#Detect that meterial
			return type
		#Otherwise, reduce the scan value and try the next material
		scan -= cm[type]

	#If nothing was detected for some reason, default to the filler
	return filler
