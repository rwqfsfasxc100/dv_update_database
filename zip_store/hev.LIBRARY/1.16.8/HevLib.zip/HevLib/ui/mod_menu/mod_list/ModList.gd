# [license]
# 3-Clause BSD NON-AI License
# 
# Copyright 2026 __hev (Benjamin Buckhurst)
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

extends HBoxContainer

var pointers:HevLibPointers = ModLoader._savedObjects[0]
export var mod_box = preload("res://HevLib/ui/mod_menu/mod_list/mod_box/ModBox.tscn")

export (NodePath) var info_icon = NodePath("")
export (NodePath) var info_name = NodePath("")
export (NodePath) var info_version = NodePath("")
export (NodePath) var info_priority = NodePath("")
export (NodePath) var info_mod_id = NodePath("")
export (NodePath) var info_author = NodePath("")
export (NodePath) var info_settings_button = NodePath("")
export (NodePath) var info_settings_icon = NodePath("")
export (NodePath) var info_desc = NodePath("")
export (NodePath) var info_desc_text = NodePath("")
export (NodePath) var info_desc_author = NodePath("")
export (NodePath) var info_desc_credits = NodePath("")
export (NodePath) var info_desc_languages = NodePath("")
export (NodePath) var info_links_button = NodePath("")
export (NodePath) var info_bugreports_button = NodePath("")
export (NodePath) var info_changelog_button = NodePath("")

export (NodePath) var count_label_path = NodePath("")
onready var count_label = get_node(count_label_path)
export (NodePath) var filter_btn_path = NodePath("")
onready var filter_btn = get_node(filter_btn_path)

export (NodePath) var links_menu_path = NodePath("")
onready var links_menu = get_node(links_menu_path)
export (NodePath) var settings_menu_path = NodePath("")
onready var settings_menu = get_node(settings_menu_path)
export (NodePath) var changelogs_menu_path = NodePath("")
onready var changelogs_menu = get_node(changelogs_menu_path)

onready var listContainer = $ScrollContainer/VBoxContainer

export (NodePath) var conflict_button_path = NodePath("")
export (NodePath) var dependancies_button_path = NodePath("")
export (NodePath) var updates_button_path = NodePath("")

onready var conflict_button = get_node(conflict_button_path)
onready var dependancies_button = get_node(dependancies_button_path)
onready var updates_button = get_node(updates_button_path)

export (NodePath) var toggle_modlet_box = NodePath("")
export (NodePath) var toggle_modlet_button = NodePath("")

var yet_to_connect = true

export (NodePath) var author_header = NodePath("")
export (NodePath) var author_splitter = NodePath("")
export (NodePath) var credits_header = NodePath("")
export (NodePath) var credits_splitter = NodePath("")
export (NodePath) var languages_header = NodePath("")
export (NodePath) var languages_splitter = NodePath("")


func about_to_show():
#	if yet_to_connect:
#		yet_to_connect = false
#		var restart_dialog = subroot.restart_menu
#		restart_dialog.get_node("PanelContainer/VBoxContainer/HBoxContainer/Restart/Button").connect("pressed",self,"_restart")
#		restart_dialog.get_node("PanelContainer/VBoxContainer/HBoxContainer/Exit/Button").connect("pressed",self,"_exit")
#		restart_dialog.get_node("PanelContainer/VBoxContainer/HBoxContainer/Cancel/Button").connect("pressed",self,"restart_cancel")
	var nodes = listContainer.get_children()
	if nodes.size() >= 2:
		nodes[0]._pressed()
	filter_btn.current_text = ""
	filter_btn.keys_pressed = ""

export var subroot_path = NodePath("")
onready var subroot = get_node(subroot_path)

func _restart():
	Settings.restartGame()

func _exit():
	pointers.NodeAccess.__exit()

func restart_cancel():
	subroot.restart_menu.hide()


var http = HTTPRequest.new()
var ptnull = false
func _ready():
	add_child(http)
	http.connect("request_completed",self,"update_return")
	
	tween = Tween.new()
	add_child(tween)
	
	var information_nodes = {
		"mod_list":self,
		"info_icon":get_node(info_icon),
		"info_name":get_node(info_name),
		"info_version":get_node(info_version),
		"info_priority":get_node(info_priority),
		"info_author":get_node(info_author),
		"info_mod_id":get_node(info_mod_id),
		"info_settings_button":get_node(info_settings_button),
		"info_settings_icon":get_node(info_settings_icon),
		"info_desc":get_node(info_desc),
		"info_desc_text":get_node(info_desc_text),
		"info_desc_author":get_node(info_desc_author),
		"info_desc_credits":get_node(info_desc_credits),
		"info_desc_languages":get_node(info_desc_languages),
		"info_links_button":get_node(info_links_button),
		"info_bugreports_button":get_node(info_bugreports_button),
		"info_changelog_button":get_node(info_changelog_button),
		"count_label_path":get_node(count_label_path),
		"filter_btn_path":get_node(filter_btn_path),
		"links_menu_path":get_node(links_menu_path),
		"settings_menu":get_node(settings_menu_path),
		"changelog_menu":get_node(changelogs_menu_path),
		"conflict_button":get_node(conflict_button_path),
		"dependancies_button":get_node(dependancies_button_path),
		"updates_button":get_node(updates_button_path),
		"toggle_modlet_box":get_node(toggle_modlet_box),
		"toggle_modlet_button":get_node(toggle_modlet_button),
		"author_header":get_node(author_header),
		"credits_header":get_node(credits_header),
		"languages_header":get_node(languages_header),
		"author_splitter":get_node(author_splitter),
		"credits_splitter":get_node(credits_splitter),
		"languages_splitter":get_node(languages_splitter),
	}
	var data = pointers.ManifestV2.__get_mod_data()
	var groups = {}
	var mod_data = {}
	var vdata = load("res://HevLib/ui/mod_menu/vanilla/data_dict.gd").get_script_constant_map()
	var vd = vdata.VANILLA
	
	var ver = pointers.DataFormat.__get_vanilla_version()
	var verstr = str(ver[0]) + "." + str(ver[1]) + "." + str(ver[2])
	
	vd["manifest"]["manifest_data"]["version"]["version_major"] = ver[0]
	vd["manifest"]["manifest_data"]["version"]["version_minor"] = ver[1]
	vd["manifest"]["manifest_data"]["version"]["version_bugfix"] = ver[2]
	vd["manifest"]["manifest_data"]["version"]["version_string"] = verstr
	
	vd["version_data"]["version_major"] = ver[0]
	vd["version_data"]["version_minor"] = ver[1]
	vd["version_data"]["version_bugfix"] = ver[2]
	vd["version_data"]["full_version_array"] = ver
	vd["version_data"]["full_version_string"] = verstr
	vd["version_data"]["legacy_mod_version"] = verstr
	
	vd["master_locale"] = TranslationServer.get_locale()
	
	mod_data.merge({"VANILLA":vd})
	
	var manifests = []
	var manifestGroups = {}
	var mainManifestMods = {}
	
	for modlet in pointers.ManifestV2.__get_disabled_modlets():
		var dict = pointers.ManifestV2.__make_mod_entry(pointers.ManifestV2.__concat_mod_info(modlet))
		data[modlet] = dict
	
	for mod in data.keys():
		var fname = mod.split("/")[2]
		var info = data[mod]
		var zipinfo = pointers.ManifestV2.__match_mod_path_to_zip(mod)
		info.merge({"zip":zipinfo})
		if not fname in groups:
			groups.merge({fname:{}})
		if info["manifest"]["has_manifest"]:
			var id = info["manifest"]["manifest_data"]["mod_information"]["id"]
			if not id in manifests:
				manifests.append(id)
		groups[fname].merge({mod:info})
	for modClass in groups:
		var groupID = ""
		var group = groups[modClass]
		var mainManifestMod = ""
		for modpath in group:
			var mod = group[modpath]
			if mod["manifest"]["has_manifest"]:
				var id = mod["manifest"]["manifest_data"]["mod_information"]["id"]
				if groupID:
					if id.split(".").size() <= groupID.split(".").size():
						groupID = id
						mainManifestMod = modpath
				else:
					groupID = id
					mainManifestMod = modpath
		var idSplit = groupID.split(".")
		var baseID = groupID
		
		if groupID:
			if idSplit.size() > 1:
				baseID = idSplit[0] + "." + idSplit[1]
			if not baseID in manifestGroups:
				manifestGroups[baseID] = {}
			manifestGroups[baseID].merge(group.duplicate(true))
			mainManifestMods[groupID] = mainManifestMod
		else:
			for i in group:
				manifestGroups[i] = {i:group[i].duplicate(true)}
				mainManifestMods[i] = i
	for mod in manifestGroups:
		if manifestGroups[mod].size() >= 2:
			var main = mainManifestMods[mod]
			var mainmod = data[main].duplicate()
			mainmod.merge({"children":{}})
			for item in manifestGroups[mod]:
				if item != main:
					mainmod["children"].merge({item:manifestGroups[mod][item]})
			mod_data[main] = mainmod
		else:
			var modgroup = manifestGroups[mod].keys()[0]
			mod_data[modgroup] = data[modgroup]
	
	for mod in mod_data:
		var info = mod_data[mod]
		var button = mod_box.instance()
		
		button.MOD_INFO = info
		button.name = info["name"]
		button.ModContainer = get_parent()
		button.information_nodes = information_nodes
		button.modulate = Color(1,1,1,0)
		listContainer.add_child(button)
	var node = get_node("ScrollContainer/VBoxContainer")
	var index = 1
	var sorting  = true
	var sorted_nodes = node.get_children()
	sorted_nodes.sort_custom(self,"sort")
	for n in sorted_nodes:
		node.move_child(n,sorted_nodes.size())
	var BS = HBoxContainer.new()
	BS.set_script(load("res://HevLib/ui/mod_menu/mod_list/BottomSeparator.gd"))
	BS.connect("visibility_changed",BS,"_visibility_changed")
	BS.name = "HEVLIB_NODE_SEPARATOR_IGNORE_PLS"
	node.add_child(BS)

func sort(a: Node, b: Node): 
	return a.MOD_INFO.name.naturalnocasecmp_to(b.MOD_INFO.name) < 0
	
export var desc_scroll_box = NodePath("")
onready var dp = get_node(desc_scroll_box)

func _draw():
	pass

var aligned_zero_focus = false

func make_info_default_state():
	get_node(info_version).text = ""
	get_node(info_priority).text = ""
	get_node(info_mod_id).text = ""
	get_node(info_author).clear()
	get_node(info_desc_text).clear()
	get_node(info_desc_author).clear()
	get_node(info_desc_credits).clear()
	get_node(info_desc_languages).clear()
	get_node(info_icon).texture = null
	get_node(info_settings_button).visible = false
	get_node(info_links_button).visible = false
	get_node(info_bugreports_button).visible = false
	get_node(info_changelog_button).visible = false
	get_node(toggle_modlet_box).visible = false
	get_node(toggle_modlet_button).change_modlet_to(null,"")


func _process(_delta):
	
	var dp_d_size = dp.get_parent().rect_size
	dp.rect_min_size = dp_d_size
	dp.rect_size = dp_d_size
	if count_label.count <= 1:
		if not aligned_zero_focus:
			get_node(info_desc).grab_focus()
			make_info_default_state()
			aligned_zero_focus = true
	else:
		if aligned_zero_focus:
			var node = get_visible_mods()
			if node.size() >= 1:
				var ar = node[0]
				var iconTexture = null
				if ar["mod_icon"]["has_icon_file"]:
					var icon_filepath = ar["mod_icon"]["icon_path"]
					if icon_filepath.ends_with(".stex"):
						var tex = StreamTexture.new()
						tex.load_path = icon_filepath
						iconTexture = tex
					elif icon_filepath.ends_with(".png"):
						iconTexture = pointers.FileAccess.__load_png(icon_filepath)
				else:
					var tex = StreamTexture.new()
					tex.load_path = "res://HevLib/ui/themes/icons/missing_icon.png.stex"
					iconTexture = tex
				get_node(info_name).text = ar["name"]
				get_node(info_version).text = ar["version_data"]["full_version_string"]
				get_node(info_priority).text = str(ar["priority"])
				get_node(info_mod_id).text = ar["manifest"]["manifest_data"]["mod_information"]["id"]
				get_node(info_author).parse_bbcode(TranslationServer.translate(ar["manifest"]["manifest_data"]["mod_information"]["author"]))
				get_node(info_desc_text).parse_bbcode(TranslationServer.translate(ar["manifest"]["manifest_data"]["mod_information"]["description"]))
				get_node(info_desc_author).parse_bbcode(TranslationServer.translate(ar["manifest"]["manifest_data"]["mod_information"]["author"]))
				var credits = ""
				for c in ar["manifest"]["manifest_data"]["mod_information"]["credits"]:
					c = TranslationServer.translate(c)
					if credits:
						credits = credits + "\n" + c
					else:
						credits = c
				get_node(info_desc_credits).parse_bbcode(credits)
				var languages = ""
				get_node(info_desc_languages).parse_bbcode(languages)
				get_node(info_icon).texture = iconTexture
				get_node(info_settings_button).visible = true
				get_node(info_links_button).visible = true
				get_node(info_bugreports_button).visible = true
				get_node(info_changelog_button).visible = true
			
			aligned_zero_focus = false

var update_store = "user://cache/.Mod_Menu_2_Cache/updates/needs_updates.json"
var dependancies_store = "user://cache/.Mod_Menu_2_Cache/dependancies/dependancies.json"
var conflicts_store = "user://cache/.Mod_Menu_2_Cache/conflicts/conflicts.json"
var complementary_store = "user://cache/.Mod_Menu_2_Cache/complementary/complementary.json"

var currently_selected_mod_id = ""

var file = File.new()

func get_visible_mods():
	var array = []
	var skip_name = "HEVLIB_NODE_SEPARATOR_IGNORE_PLS"
	var node = get_node("ScrollContainer/VBoxContainer")
	var children = node.get_children()
	for child in children:
		if child.name == skip_name:
			continue
		
		var visibility = child.visible
		if visibility:
			array.append(child.MOD_INFO)
		
	return array

export var conflict_menu_path = NodePath("")
export var dependancy_menu_path = NodePath("")
export var update_menu_path = NodePath("")
onready var conflict_menu = get_node(conflict_menu_path)
onready var dependancy_menu = get_node(dependancy_menu_path)
onready var update_menu = get_node(update_menu_path)

func _open_conflicts():
	var conflicts = pointers.ManifestV2.__check_mod_conflicts(currently_selected_mod_id)
	var cfmods = ""
	for mod in conflicts:
		if mod.begins_with("res://"):
			var data = pointers.ManifestV2.__get_mod_data()[mod]
			cfmods += "\n ->" + data.get("name",mod.split("/",false)[1]) + " (" + mod + ")"
		else:
			var data = pointers.ManifestV2.__get_mod_by_id(mod)
			cfmods += "\n ->" + data.get("name",mod.split("/",false)[1]) + " (" + data.get("manifest",{}).get("manifest_data",{}).get("mod_information",{}).get("id",mod) + ")"
	conflict_menu.dialog_text = TranslationServer.translate("HEVLIB_CONFLICT_INFO_BODY") % cfmods
	conflict_menu.popup()
	var size = Settings.getViewportSize()
	var offset = (size - conflict_menu.rect_size) / 2
	conflict_menu.rect_position = offset
	conflict_menu.rect_size = Vector2(700,450)

func _open_dependancies():
	var conflicts = pointers.ManifestV2.__check_mod_dependancies(currently_selected_mod_id)
	var cfmods = ""
	for mod in conflicts:
		if mod.begins_with("res://"):
			var data = pointers.ManifestV2.__get_mod_data()[mod]
			cfmods += "\n ->" + data.get("name",mod.split("/",false)[1]) + " (" + mod + ")"
		else:
			var data = pointers.ManifestV2.__get_mod_by_id(mod)
			cfmods += "\n -> " + data.get("name",mod.split("/",false)[1]) + " (" + data.get("manifest",{}).get("manifest_data",{}).get("mod_information",{}).get("id",mod) + ")"
	dependancy_menu.dialog_text = TranslationServer.translate("HEVLIB_DEPENDANCY_INFO_BODY") % cfmods
	dependancy_menu.popup()
	var size = Settings.getViewportSize()
	var offset = (size - dependancy_menu.rect_size) / 2
	dependancy_menu.rect_position = offset
	dependancy_menu.rect_size = Vector2(700,450)

func _open_updates():
	file.open(update_store,File.READ)
	var udata = JSON.parse(file.get_as_text()).result
	file.close()
	var tex = TranslationServer.translate("HEVLIB_UPDATE_INFO_BODY") % [str(udata[currently_selected_mod_id]["version"][0]) + "." + str(udata[currently_selected_mod_id]["version"][1]) + "." + str(udata[currently_selected_mod_id]["version"][2]),str(udata[currently_selected_mod_id]["new_version"][0]) + "." + str(udata[currently_selected_mod_id]["new_version"][1]) + "." + str(udata[currently_selected_mod_id]["new_version"][2])]
	update_menu.dialog_text = tex
	update_menu.popup()
	var size = Settings.getViewportSize()
	var offset = (size - update_menu.rect_size) / 2
	update_menu.rect_position = offset
	update_menu.rect_size = Vector2(700,450)
	

var zip_folder = "user://cache/.Mod_Menu_2_Cache/updates/zip_cache/"
func updates_started():
	file.open(update_store,File.READ)
	var data = JSON.parse(file.get_as_text()).result
	file.close()
	var github = data[currently_selected_mod_id].get("github","")
	if github:
		http.download_file = zip_folder + data[currently_selected_mod_id]["file_name"]
		http.request(github)
		updating_percent = true
#		if github.ends_with("/"):
#			github.rstrip("/")
#		if not github.ends_with("/releases"):
#			github = github + "/releases"
#		pointers.Github.__get_github_release(github,zip_folder,self,true,"zip")
	
	get_node("../../../../../../WAIT").popup_centered()

func update_return(result, response_code,headers,body):
	var fp = http.download_file
	http.download_file = ""
	updating_percent = false
	_downloaded_zip(fp)

var updating_percent = false
var percent:float = 0
var bytes_downloaded: int = 0
var total_bytes: int = 0

func _downloaded_zip(filepath):
	get_node("../../../../../../WAIT").hide()
	file.open(update_store,File.READ)
	var data = JSON.parse(file.get_as_text()).result
	file.close()
	
	if currently_selected_mod_id in data:
		data.erase(currently_selected_mod_id)
	file.open(update_store,File.WRITE)
	file.store_string(JSON.print(data))
	file.close()
	subroot.restart_menu.popup_centered()
	if filepath:
		pointers.FileAccess.__precache_mod_file(filepath)
	updates_button.visible = false
var tween
func _visibility_changed():
	if is_visible_in_tree():
		yield(CurrentGame.get_tree(),"idle_frame")
		var count = 0.03125
		for child in listContainer.get_children():
			if "MOD_INFO" in child:
				tween.interpolate_property(child,"modulate",Color(1,1,1,0),Color(1,1,1,1),0.25,Tween.TRANS_LINEAR,Tween.EASE_IN,count)
				tween.start()
				count += 0.03125

func hide_mods():
	for child in listContainer.get_children():
		if "MOD_INFO" in child:
			child.modulate = Color(1,1,1,0)
	
