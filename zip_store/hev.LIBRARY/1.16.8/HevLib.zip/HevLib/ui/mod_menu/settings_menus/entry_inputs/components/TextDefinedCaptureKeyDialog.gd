# [license]
# 3-Clause BSD NON-AI License
# 
# Copyright 2026 __hev (Benjamin Buckhurst)
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

extends Popup

var pointers:HevLibPointers = ModLoader._savedObjects[0]

onready var keybox = $PanelContainer / MarginContainer / VBoxContainer / CK / Keys

onready var deleteButton = preload("res://menu/DeleteKeybind.tscn")
onready var addPlayer = $PanelContainer / MarginContainer / VBoxContainer / CenterContainer / Add / AnimationPlayer
onready var addButton = $PanelContainer / MarginContainer / VBoxContainer / CenterContainer / Add
var revert

export var button_path = NodePath("")
onready var hbttn = get_node(button_path)

onready var mod = hbttn.get_parent().get_parent().CONFIG_MOD
onready var section = hbttn.get_parent().get_parent().CONFIG_SECTION
onready var action = hbttn.get_parent().get_parent().CONFIG_ENTRY

func _exit_tree():
	deleteButton = null
	
func _ready():
	set_process_input(false)
	get_tree().get_root().connect("size_changed", self, "_on_resize")

func _on_resize():
	if visible:
		var viewportSize = get_parent().rect_size
		var size = rect_size
		rect_position = (viewportSize - size) / 2


func _on_ActionDefining_pressed():
	popup_centered()
	remakeActionButtons()
	
func _remove_key(key):
	if typeof(key) == TYPE_STRING:
		key = [key]
	var n = pointers.ConfigDriver.__get_value(mod,section,action)
	n.erase(key)
	pointers.ConfigDriver.__store_value(mod,section,action,n)
	remakeActionButtons()

func remakeActionButtons():
	for k in keybox.get_children():
		k.queue_free()
		
	var actions = pointers.ConfigDriver.__get_value(mod,section,action)
	
	
	for act in actions:
		if typeof(act) == TYPE_STRING:
			act = [act]
		for n in act:
			var label = Label.new()
			label.text = n
			label.align = label.ALIGN_CENTER
			keybox.add_child(label)
			var rem = deleteButton.instance()
			keybox.add_child(rem)
			rem.connect("pressed", self, "_remove_key", [n])
			addButton.focus_neighbour_top = rem.get_path()
		
	
		
	
	addButton.visible = actions.size() < 5
	$PanelContainer / MarginContainer / VBoxContainer / CenterContainer2 / HBoxContainer / Ok.grab_focus()
		

var store = []
func _on_CaptureKeyDialog_about_to_show():
	lastFocus = get_focus_owner()
	remakeActionButtons()
	store = pointers.ConfigDriver.__get_value(mod,section,action)
var capturing = false

var lastFocus = null
func refocus():
	if lastFocus and lastFocus.has_method("grab_focus"):
		lastFocus.grab_focus()
	else:
		Debug.l("I have no focus to fall back to!")

func _input(event):
	if capturing and event is InputEventJoypadButton and event.button_index == 1:
		pass
	elif event.is_action_pressed("ui_cancel"):
		if capturing:
			stopCapturing()
		else:
			hide()
			refocus()
		get_tree().set_input_as_handled()
		return

	if capturing:
		if (event is InputEventKey or event is InputEventMouseButton) and event.is_pressed():
			get_tree().set_input_as_handled()
			var key = eventToString(event)
			if event is InputEventKey and event.scancode == KEY_ESCAPE:
				stopCapturing()
			else:
				stopCapturing()
				var ent = pointers.ConfigDriver.__get_value(mod,section,action)
				if not ent.has(key):
					ent.append(key)
					pointers.ConfigDriver.__store_value(mod,section,action,ent)
					remakeActionButtons()
		elif (event is InputEventJoypadButton or event is InputEventJoypadMotion) and event.is_pressed():
			get_tree().set_input_as_handled()
			var key = joyEventToString(event)
			if event is InputEventJoypadButton and event.button_index == JOY_BUTTON_11:
				stopCapturing()
			else:
				stopCapturing()
				var ent = pointers.ConfigDriver.__get_value(mod,section,action)
				if not ent.has(key):
					ent.append(key)
					pointers.ConfigDriver.__store_value(mod,section,action,ent)
					remakeActionButtons()
			

func joyEventToString(event):
	if event is InputEventJoypadButton:
		return "JoyButton %s" % event.button_index
	if event is InputEventJoypadMotion:
		return "JoyAxis %s" % [is_pos_or_neg(event) + str(event.axis)]
	

func eventToString(event: InputEvent) -> String:
	if event is InputEventKey:
		return OS.get_scancode_string(event.scancode)
	if event is InputEventMouseButton:
		return "Mouse %d" % event.button_index
	return ""

func is_pos_or_neg(event):
	var val = event.axis_value
	if val >= 0:
		return ""
	else:
		return "-"

func _on_Add_pressed():
	if capturing:
		stopCapturing()
	else:
		
		addPlayer.play("pulsing")
		capturing = true

func stopCapturing():
	addPlayer.stop()
	capturing = false
	addButton.setColor()

func applySettings():
	var always_binds = hbttn.always_binds
	always_binds.append_array(pointers.ConfigDriver.__get_value(mod,section,action))
	var vbinds = Settings.cfg.get("input",{})
	if action in vbinds:
		always_binds.append_array(vbinds[action])
	var action_list = InputMap.get_action_list(action)
	for action_name in action_list:
		InputMap.action_erase_event(action, action_name)
	var opts = {}
	pointers.Keymapping.__load_input_data(action,always_binds,opts)

func _on_Cancel_pressed():
	stopCapturing()
	pointers.ConfigDriver.__store_value(mod,section,action,store)
	applySettings()
	hide()
	refocus()
func _on_Ok_pressed():
	
	stopCapturing()
	get_tree().call_group("hevlib_settings_tab","recheck_availability")
	applySettings()
	hide()
	refocus()

func _on_CaptureKeyDialog_focus_entered():
	remakeActionButtons()


func _on_CaptureKeyDialog_visibility_changed():
	mod = hbttn.mod
	section = hbttn.section
	action = hbttn.action
	
	set_process_input(is_visible_in_tree())
