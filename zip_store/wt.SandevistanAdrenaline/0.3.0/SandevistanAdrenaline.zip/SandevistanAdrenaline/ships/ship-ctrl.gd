extends "res://ships/ship-ctrl.gd"

var comp_fuel: float = 1.0
var comp_heat: float = 1.0
var comp_energy: float = 1.0

func _ready():
	var pointers = CurrentGame.get_tree().get_root().get_node_or_null("HevLib~Pointers")
	if pointers:
		var v_comp_fuel = pointers.ConfigDriver.__get_value("SandevistanAdrenaline", "SANDEVISTAN_CONFIG_OPTIONS", "comp_fuel")
		if v_comp_fuel != null: comp_fuel = v_comp_fuel
		var v_comp_heat = pointers.ConfigDriver.__get_value("SandevistanAdrenaline", "SANDEVISTAN_CONFIG_OPTIONS", "comp_heat")
		if v_comp_heat != null: comp_heat = v_comp_heat
		var v_comp_energy = pointers.ConfigDriver.__get_value("SandevistanAdrenaline", "SANDEVISTAN_CONFIG_OPTIONS", "comp_energy")
		if v_comp_energy != null: comp_energy = v_comp_energy
		
		pointers.ConfigDriver.__subscribe_to_setting_change("_on_comp_fuel_changed", self, "SandevistanAdrenaline", "SANDEVISTAN_CONFIG_OPTIONS", "comp_fuel")
		pointers.ConfigDriver.__subscribe_to_setting_change("_on_comp_heat_changed", self, "SandevistanAdrenaline", "SANDEVISTAN_CONFIG_OPTIONS", "comp_heat")
		pointers.ConfigDriver.__subscribe_to_setting_change("_on_comp_energy_changed", self, "SandevistanAdrenaline", "SANDEVISTAN_CONFIG_OPTIONS", "comp_energy")

func _on_comp_fuel_changed(val):
	if val != null: comp_fuel = val
func _on_comp_heat_changed(val):
	if val != null: comp_heat = val
func _on_comp_energy_changed(val):
	if val != null: comp_energy = val

func drawReactiveMass(kg, really = true):
	if playerControlled and kg > 0 and Engine.time_scale > 0.0 and Engine.time_scale < 1.0:
		var f = lerp(1.0, Engine.time_scale, comp_fuel)
		return .drawReactiveMass(kg * f, really) / f
	return .drawReactiveMass(kg, really)

func drawThermal(energy, forItem = null):
	if playerControlled and energy > 0 and Engine.time_scale > 0.0 and Engine.time_scale < 1.0:
		var f = lerp(1.0, Engine.time_scale, comp_heat)
		return .drawThermal(energy * f, forItem) / f
	return .drawThermal(energy, forItem)

func drawEnergy(energy):
	if playerControlled and energy > 0 and Engine.time_scale > 0.0 and Engine.time_scale < 1.0:
		var f = lerp(1.0, Engine.time_scale, comp_energy)
		return .drawEnergy(energy * f) / f
	return .drawEnergy(energy)

