extends Node

const LOAD_RESOURCES = {
	"sfx/thruster.gd": {"load_type": "script"},
	"ships/ship-ctrl.gd": {"load_type": "script"}
}
