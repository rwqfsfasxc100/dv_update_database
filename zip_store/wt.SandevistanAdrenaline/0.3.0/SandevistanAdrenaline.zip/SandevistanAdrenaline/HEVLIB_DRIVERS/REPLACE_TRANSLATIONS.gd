# This translation file is generated automatically
# Do not modify anything directly, as this can break things for those working on them
# Please use Translation Tracker to modify these yourself, and contact the mod author to implement them
# https://github.com/rwqfsfasxc100/TranslationTracker/releases/latest

# [license]
# 3-Clause BSD NON-AI License
# 
# Copyright 2026 WT (Oleksandr Hladyr)
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, the training of, or improvment of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form in an AI-training dataset is considered a breach of this License.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# 
# [/license]


const TRANSLATIONS = {
	"master_locale": "en",
	"en": {
		"MOD_SANDEVISTAN_DESC": {
			"string": "Boosts ship thrusters during adrenal slowdown, allowing normalish movement while time is slowed.",
			"version_hash": 3216221701
		},
		"MOD_SANDEVISTAN_BRIEF": {
			"string": "Boost movement during adrenal slowdown.",
			"version_hash": 2886205634
		},
		"SANDEVISTAN_CONFIG_OPTIONS": {
			"string": "Sandevistan Settings",
			"version_hash": 2657424566
		},
		"SANDEVISTAN_CONFIG_STRENGTH_NAME": {
			"string": "Thrust Compensation",
			"version_hash": 3125683199
		},
		"SANDEVISTAN_CONFIG_STRENGTH_DESC": {
			"string": "Multiplies thruster output to compensate for time dilation. At 1.0, the increased acceleration makes the ship's movement feel like it's operating in real-time.",
			"version_hash": 2610853987
		},
		"SANDEVISTAN_CONFIG_COMP_GIMBAL_NAME": {
			"string": "Gimbal Compensation",
			"version_hash": 2450675329
		},
		"SANDEVISTAN_CONFIG_COMP_GIMBAL_DESC": {
			"string": "Multiplies gimbal rotation speed to compensate for time dilation. At 1.0, thruster aiming feels like it's operating in real-time.",
			"version_hash": 2325560323
		},
		"SANDEVISTAN_CONFIG_COMP_FUEL_NAME": {
			"string": "Propellant Compensation",
			"version_hash": 2961029974
		},
		"SANDEVISTAN_CONFIG_COMP_FUEL_DESC": {
			"string": "Balances ship-wide propellant consumption during slowdown. At 1.0, your total propellant usage per real-time second matches normal gameplay.",
			"version_hash": 1515796228
		},
		"SANDEVISTAN_CONFIG_COMP_ENERGY_NAME": {
			"string": "Energy Compensation",
			"version_hash": 3644785247
		},
		"SANDEVISTAN_CONFIG_COMP_ENERGY_DESC": {
			"string": "Balances ship-wide electrical power draw during slowdown. At 1.0, your total energy consumption per real-time second matches normal gameplay.",
			"version_hash": 880920074
		},
		"SANDEVISTAN_CONFIG_COMP_HEAT_NAME": {
			"string": "Thermal Compensation",
			"version_hash": 2038553474
		},
		"SANDEVISTAN_CONFIG_COMP_HEAT_DESC": {
			"string": "Balances ship-wide thermal draw during slowdown. At 1.0, your total heat generation per real-time second matches normal gameplay.",
			"version_hash": 1463880183
		},
		"SANDEVISTAN_CONFIG_COMP_PULSE_NAME": {
			"string": "Thruster Pulse Compensation",
			"version_hash": 4199383327
		},
		"SANDEVISTAN_CONFIG_COMP_PULSE_DESC": {
			"string": "Boosts thruster pulse rate during slowdown. At 1.0, thrusters pulse at normal frequency in real-time.",
			"version_hash": 3576271499
		}
	}
}
