extends "res://sfx/thruster.gd"

var strength: float = 1.0
var comp_gimbal: float = 1.0
var comp_pulse: float = 1.0

var _base_gps = 0.0
var _base_pps = 0.0
var _base_stats_stored = false

func _ready():
	var pointers = CurrentGame.get_tree().get_root().get_node_or_null("HevLib~Pointers")
	if pointers:
		var v_strength = pointers.ConfigDriver.__get_value("SandevistanAdrenaline", "SANDEVISTAN_CONFIG_OPTIONS", "strength")
		if v_strength != null: strength = v_strength
		var v_comp_gimbal = pointers.ConfigDriver.__get_value("SandevistanAdrenaline", "SANDEVISTAN_CONFIG_OPTIONS", "comp_gimbal")
		if v_comp_gimbal != null: comp_gimbal = v_comp_gimbal
		var v_comp_pulse = pointers.ConfigDriver.__get_value("SandevistanAdrenaline", "SANDEVISTAN_CONFIG_OPTIONS", "comp_pulse")
		if v_comp_pulse != null: comp_pulse = v_comp_pulse
		
		pointers.ConfigDriver.__subscribe_to_setting_change("_on_strength_changed", self, "SandevistanAdrenaline", "SANDEVISTAN_CONFIG_OPTIONS", "strength")
		pointers.ConfigDriver.__subscribe_to_setting_change("_on_comp_gimbal_changed", self, "SandevistanAdrenaline", "SANDEVISTAN_CONFIG_OPTIONS", "comp_gimbal")
		pointers.ConfigDriver.__subscribe_to_setting_change("_on_comp_pulse_changed", self, "SandevistanAdrenaline", "SANDEVISTAN_CONFIG_OPTIONS", "comp_pulse")

func _on_strength_changed(val):
	if val != null: strength = val
func _on_comp_gimbal_changed(val):
	if val != null: comp_gimbal = val
func _on_comp_pulse_changed(val):
	if val != null: comp_pulse = val

func updateStats():
	if playerControlled and (not _base_stats_stored or Engine.time_scale >= 1.0):
		_base_gps = gimbalPerSecond
		_base_pps = pulsePerSecond
		_base_stats_stored = true

func getThrust(force = false):
	var t = .getThrust(force)
	if not force and Engine.time_scale < 1.0 and playerControlled:
		return t * lerp(1.0, 1.0 / Engine.time_scale, strength)
	return t

func _physics_process(delta):
	if not _base_stats_stored and playerControlled:
		updateStats()

	if Engine.time_scale < 1.0 and playerControlled and _base_stats_stored:
		gimbalPerSecond = _base_gps * lerp(1.0, 1.0 / Engine.time_scale, comp_gimbal)
		pulsePerSecond = _base_pps * lerp(1.0, 1.0 / Engine.time_scale, comp_pulse)
	elif _base_stats_stored:
		gimbalPerSecond = _base_gps
		pulsePerSecond = _base_pps

