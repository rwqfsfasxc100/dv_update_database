extends Node

var pointers = null
var mod_id = "SandevistanAdrenaline"
var section = "SANDEVISTAN_CONFIG_OPTIONS"

# Config state
var strength = 1.0
var comp_gimbal = 1.0
var comp_fuel = 1.0
var comp_energy = 1.0
var comp_heat = 1.0
var comp_pulse = 1.0

func _ready():
	add_to_group("SandevistanConfig")
	#Debug.l("SANDEVISTAN: Config node path: " + str(get_path()))
	_wait_for_pointers()

func _wait_for_pointers():
	var attempts = 0
	var max_attempts = 120 # Wait up to 2 seconds at 60fps
	
	while pointers == null and attempts < max_attempts:
		pointers = get_tree().get_root().get_node_or_null("HevLib~Pointers")
		if pointers == null:
			attempts += 1
			yield (get_tree(), "idle_frame")
			
	if pointers == null:
		Debug.l("SANDEVISTAN ERROR: HevLib Pointers not found! Configuration will not load.")
		return
		
	_initialize_config()

func _initialize_config():
	#var full_config = pointers.ConfigDriver.__get_config(mod_id)
	#Debug.l("SANDEVISTAN CONFIG DUMP: %s" % full_config)
	pointers.ConfigDriver.__subscribe_to_setting_change("_on_strength_changed", self , mod_id, section, "strength")
	pointers.ConfigDriver.__subscribe_to_setting_change("_on_comp_gimbal_changed", self , mod_id, section, "comp_gimbal")
	pointers.ConfigDriver.__subscribe_to_setting_change("_on_comp_fuel_changed", self , mod_id, section, "comp_fuel")
	pointers.ConfigDriver.__subscribe_to_setting_change("_on_comp_energy_changed", self , mod_id, section, "comp_energy")
	pointers.ConfigDriver.__subscribe_to_setting_change("_on_comp_heat_changed", self , mod_id, section, "comp_heat")
	pointers.ConfigDriver.__subscribe_to_setting_change("_on_comp_pulse_changed", self , mod_id, section, "comp_pulse")
	
	strength = pointers.ConfigDriver.__get_value(mod_id, section, "strength")
	comp_gimbal = pointers.ConfigDriver.__get_value(mod_id, section, "comp_gimbal")
	comp_fuel = pointers.ConfigDriver.__get_value(mod_id, section, "comp_fuel")
	comp_energy = pointers.ConfigDriver.__get_value(mod_id, section, "comp_energy")
	comp_heat = pointers.ConfigDriver.__get_value(mod_id, section, "comp_heat")
	comp_pulse = pointers.ConfigDriver.__get_value(mod_id, section, "comp_pulse")
	
	#Debug.l("SANDEVISTAN: Config loaded successfully.")

func _on_strength_changed(how):
	strength = how
	#Debug.l("SANDEVISTAN: strength changed to %s" % how)
func _on_comp_gimbal_changed(how):
	comp_gimbal = how
	#Debug.l("SANDEVISTAN: comp_gimbal changed to %s" % how)
func _on_comp_fuel_changed(how):
	comp_fuel = how
	#Debug.l("SANDEVISTAN: comp_fuel changed to %s" % how)
func _on_comp_energy_changed(how):
	comp_energy = how
	#Debug.l("SANDEVISTAN: comp_energy changed to %s" % how)
func _on_comp_heat_changed(how):
	comp_heat = how
	#Debug.l("SANDEVISTAN: comp_heat changed to %s" % how)
func _on_comp_pulse_changed(how):
	comp_pulse = how
	#Debug.l("SANDEVISTAN: comp_pulse changed to %s" % how)
