extends "res://ships/ship-ctrl.gd"

var modConfig

func _ready():
	var configs = get_tree().get_nodes_in_group("SandevistanConfig")
	if configs.size() > 0:
		modConfig = configs[0]
		# Debug.l("[Sandevistan]: Ship-ctrl Ready. Config Found.")

func drawReactiveMass(kg, really = true):
	if playerControlled and kg > 0 and modConfig and Engine.time_scale > 0.0 and Engine.time_scale < 1.0:
		var f = lerp(1.0, Engine.time_scale, modConfig.comp_fuel)
		return.drawReactiveMass(kg * f, really) / f
	return.drawReactiveMass(kg, really)

func drawThermal(energy, forItem = null):
	if playerControlled and energy > 0 and modConfig and Engine.time_scale > 0.0 and Engine.time_scale < 1.0:
		var f = lerp(1.0, Engine.time_scale, modConfig.comp_heat)
		return.drawThermal(energy * f, forItem) / f
	return.drawThermal(energy, forItem)

func drawEnergy(energy):
	if playerControlled and energy > 0 and modConfig and Engine.time_scale > 0.0 and Engine.time_scale < 1.0:
		var f = lerp(1.0, Engine.time_scale, modConfig.comp_energy)
		return.drawEnergy(energy * f) / f
	return.drawEnergy(energy)
