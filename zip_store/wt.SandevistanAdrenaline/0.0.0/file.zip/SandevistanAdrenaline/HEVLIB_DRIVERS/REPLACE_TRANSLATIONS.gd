extends Node

# This translation file is generated automatically
# Do not modify anything directly, as this can break things for those working on them
# Please use Translation Tracker to modify these yourself, and contact the mod author to implement them
# https://github.com/rwqfsfasxc100/TranslationTracker/releases/latest

const TRANSLATIONS = {
	"master_locale": "en",
	"en": {
		"MOD_SANDEVISTAN_DESC": {
			"string": "Boosts ship thrusters during adrenal slowdown, allowing normalish movement while time is slowed.",
			"version_hash": 3216221701
		},
		"MOD_SANDEVISTAN_BRIEF": {
			"string": "Boost movement during adrenal slowdown.",
			"version_hash": 2886205634
		},
		"SANDEVISTAN_CONFIG_OPTIONS": {
			"string": "Sandevistan Settings",
			"version_hash": 2657424566
		},
		"SANDEVISTAN_CONFIG_STRENGTH_NAME": {
			"string": "Thrust Compensation",
			"version_hash": 3125683199
		},
		"SANDEVISTAN_CONFIG_STRENGTH_DESC": {
			"string": "Multiplies thruster output to compensate for time dilation. At 1.0, the increased acceleration makes the ship's movement feel like it's operating in real-time.",
			"version_hash": 2610853987
		},
		"SANDEVISTAN_CONFIG_COMP_GIMBAL_NAME": {
			"string": "Gimbal Compensation",
			"version_hash": 2450675329
		},
		"SANDEVISTAN_CONFIG_COMP_GIMBAL_DESC": {
			"string": "Multiplies gimbal rotation speed to compensate for time dilation. At 1.0, thruster aiming feels like it's operating in real-time.",
			"version_hash": 2325560323
		},
		"SANDEVISTAN_CONFIG_COMP_FUEL_NAME": {
			"string": "Propellant Compensation",
			"version_hash": 2961029974
		},
		"SANDEVISTAN_CONFIG_COMP_FUEL_DESC": {
			"string": "Balances ship-wide propellant consumption during slowdown. At 1.0, your total propellant usage per real-time second matches normal gameplay.",
			"version_hash": 1515796228
		},
		"SANDEVISTAN_CONFIG_COMP_ENERGY_NAME": {
			"string": "Energy Compensation",
			"version_hash": 3644785247
		},
		"SANDEVISTAN_CONFIG_COMP_ENERGY_DESC": {
			"string": "Balances ship-wide electrical power draw during slowdown. At 1.0, your total energy consumption per real-time second matches normal gameplay.",
			"version_hash": 880920074
		},
		"SANDEVISTAN_CONFIG_COMP_HEAT_NAME": {
			"string": "Thermal Compensation",
			"version_hash": 2038553474
		},
		"SANDEVISTAN_CONFIG_COMP_HEAT_DESC": {
			"string": "Balances ship-wide thermal draw during slowdown. At 1.0, your total heat generation per real-time second matches normal gameplay.",
			"version_hash": 1463880183
		},
		"SANDEVISTAN_CONFIG_COMP_PULSE_NAME": {
			"string": "Thruster Pulse Compensation",
			"version_hash": 4199383327
		},
		"SANDEVISTAN_CONFIG_COMP_PULSE_DESC": {
			"string": "Boosts thruster pulse rate during slowdown. At 1.0, thrusters pulse at normal frequency in real-time.",
			"version_hash": 3576271499
		}
	}
}