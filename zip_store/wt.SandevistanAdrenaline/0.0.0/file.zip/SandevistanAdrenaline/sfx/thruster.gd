extends "res://sfx/thruster.gd"

var modConfig
var _base_gps = 0.0
var _base_pps = 0.0
var _base_stats_stored = false

func _ready():
	var configs = get_tree().get_nodes_in_group("SandevistanConfig")
	if configs.size() > 0:
		modConfig = configs[0]
		#Debug.l("[Sandevistan]: Thruster Ready. Config Found. PlayerControlled: " + str(playerControlled))
	#else:
		#Debug.l("[Sandevistan]: Thruster Ready. Config NOT FOUND! PlayerControlled: " + str(playerControlled))

func updateStats():
	if playerControlled and (not _base_stats_stored or Engine.time_scale >= 1.0):
		_base_gps = gimbalPerSecond
		_base_pps = pulsePerSecond
		_base_stats_stored = true

func getThrust(force = false):
	var t =.getThrust(force)
	if not force and Engine.time_scale < 1.0 and modConfig and playerControlled:
		return t * lerp(1.0, 1.0 / Engine.time_scale, modConfig.strength)

	return t

func _physics_process(delta):
	if not _base_stats_stored and playerControlled:
		updateStats()

	if modConfig and Engine.time_scale < 1.0 and playerControlled and _base_stats_stored:
		gimbalPerSecond = _base_gps * lerp(1.0, 1.0 / Engine.time_scale, modConfig.comp_gimbal)
		pulsePerSecond = _base_pps * lerp(1.0, 1.0 / Engine.time_scale, modConfig.comp_pulse)
	elif _base_stats_stored:
		gimbalPerSecond = _base_gps
		pulsePerSecond = _base_pps
