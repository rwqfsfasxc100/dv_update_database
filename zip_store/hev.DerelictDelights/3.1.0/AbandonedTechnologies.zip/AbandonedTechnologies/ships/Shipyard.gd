# [license]
# 3-Clause BSD NON-AI License
# 
# Copyright 2026 __hev (Benjamin Buckhurst)
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, the training of, or improvment of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form in an AI-training dataset is considered a breach of this License.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

extends "res://ships/Shipyard.gd"

func _ready():
	usedShipConfigs.merge(thisTookWayTooLongToGetWorkingWhyIsJSONSoStingyAndCouldntThisHaveJustBeenDoneInATCSNToMakeTheEngineDoTheWorkInstead, true)

var thisTookWayTooLongToGetWorkingWhyIsJSONSoStingyAndCouldntThisHaveJustBeenDoneInATCSNToMakeTheEngineDoTheWorkInstead = {
	"COTHON":[
		{
		"weaponSlot":{
			"right":{
				"type":"SYSTEM_MWG"
				}, 
			"left":{
				"type":"SYSTEM_MWG"
				}
			}, 
		"reactor":{
			"power":8.0
			}, 
		"ammo":{
			"capacity":0.0, 
			"initial":0.0, 
			}, 
		"drones":{
			"capacity":0.0, 
			"initial":0.0
			}, 
		"fuel":{
			"capacity":80000.0, 
			"initial":80000.0, 
			}, 
		"capacitor":{
			"capacity":1000.0, 
			}, 
		"turbine":{
			"power":200.0, 
			},
		"cargo":{
			"equipment":"SYSTEM_CARGO_STANDARD"
			}, 
		"autopilot":{
			"type":"SYSTEM_AUTOPILOT_MK3"
			}, 
		"propulsion":{
			"main":"SYSTEM_MAIN_ENGINE_PNTR", 
			"rcs":"SYSTEM_THRUSTER_NDSTR"
			}
		}, 
		{
		"weaponSlot":{
			"right":{
				"type":"SYSTEM_CL600P"
				}, 
			"left":{
				"type":"SYSTEM_CL600P"
				},
			"rightBack":{
				"type":"SYSTEM_EXSTORAGE-R"
				},
			"leftBack":{
				"type":"SYSTEM_EXSTORAGE-L"
				}
			}, 
		"reactor":{
			"power":30.0
			}, 
		"ammo":{
			"capacity":0.0, 
			"initial":0.0, 
			}, 
		"drones":{
			"capacity":0.0, 
			"initial":0.0
			}, 
		"fuel":{
			"capacity":80000.0, 
			"initial":80000.0, 
			}, 
		"capacitor":{
			"capacity":1500.0, 
			}, 
		"turbine":{
			"power":500.0, 
			}, 
		"aux":{
			"power":"SYSTEM_AUX_SMES_MK2"
			},
		"cargo":{
			"equipment":"SYSTEM_CARGO_STANDARD"
			}, 
		"autopilot":{
			"type":"SYSTEM_AUTOPILOT_MK3"
			}, 
		"propulsion":{
			"main":"SYSTEM_MAIN_ENGINE_BWMT535", 
			"rcs":"SYSTEM_THRUSTER_MA150HO"
			}
		}, 
		{
		"weaponSlot":{
			"right":{
				"type":"SYSTEM_DND_HAUL"
				}, 
			"left":{
				"type":"SYSTEM_PDMWG-L"
				}
			}, 
		"reactor":{
			"power":20.0
			}, 
		"ammo":{
			"capacity":0.0, 
			"initial":0.0, 
			}, 
		"drones":{
			"capacity":5000.0, 
			"initial":5000.0
			}, 
		"fuel":{
			"capacity":50000.0, 
			"initial":50000.0, 
			}, 
		"capacitor":{
			"capacity":1000.0, 
			}, 
		"turbine":{
			"power":200.0, 
			},
		"shielding":{
			"emp":0, 
			}, 
		"cargo":{
			"equipment":"SYSTEM_CARGO_MPUFSO"
			}, 
		"autopilot":{
			"type":"SYSTEM_AUTOPILOT_MK3"
			}, 
		"propulsion":{
			"main":"SYSTEM_MAIN_ENGINE_BWMT535", 
			"rcs":"SYSTEM_THRUSTER_MA150HO"
			}
		},
		{
		"ammo":{
			"capacity":0,
			"initial":0
		},
		"autopilot":{
			"type":"SYSTEM_AUTOPILOT_MK3"
		},
		"aux":{
			"power":"SYSTEM_NONE"
		},
		"capacitor":{
			"capacity":1000
		},
		"cargo":{
			"equipment":"SYSTEM_CARGO_STANDARD"
		},
		"drone":{
			"scanner":"SYSTEM_RD_GRAVIMETRIC"
		},
		"drones":{
			"capacity":20000,
			"initial":20000
		},
		"fuel":{
			"capacity":50000,
			"initial":50000
		},
		"hud":{
			"type":"SYSTEM_HUD_HAL"
		},
		"lidar":{
			"type":"SYSTEM_LIDAR_DOPPLER"
		},
		"propulsion":{
			"main":"SYSTEM_MAIN_ENGINE_BWMT535",
			"rcs":"SYSTEM_THRUSTER_NDVTT"
		},
		"reactor":{
			"power":12
		},
		"turbine":{
			"power":200
		},
		"weaponSlot":{
			"left":{
				"type":"SYSTEM_HUNK-L"
			},
			"leftBack":{
				"type":"SYSTEM_HUNK-L"
			},
			"right":{
				"type":"SYSTEM_ACL200P"
			},
			"rightBack":{
				"type":"SYSTEM_DND_HAUL"
			}
		}
	}
	],
	"AT225":[
		{
		"ammo": {
			"capacity": 0,
			"initial": 0
		},
		"autopilot": {
			"type": "SYSTEM_AUTOPILOT_RTYPE"
		},
		"aux": {
			"power": "SYSTEM_NONE"
		},
		"capacitor": {
			"capacity": 1500
		},
		"cargo": {
			"equipment": "SYSTEM_CARGO_MPUFSO"
		},
		"drones": {
			"capacity": 50000.0,
			"initial": 50000.0
		},
		"fuel": {
			"capacity": 500000,
			"initial": 500000
		},
		"hud":{
			"type": "SYSTEM_HUD_AT225"
		},
		"drone": {
			"scanner": "SYSTEM_RD_GRAVIMETRIC"
		},
		"lidar": {
			"type": "SYSTEM_LIDAR_DOPPLER"
		},
		"propulsion": {
			"main": "SYSTEM_MAIN_ENGINE_K44",
			"rcs": "SYSTEM_THRUSTER_NDSTR"
		},
		"reactor": {
			"power": 30
		},
		"turbine": {
			"power": 500
		},
		"weaponSlot": {
			"leftBay1":{
				"type": "SYSTEM_DND_HAUL"
			},
			"leftBay2": {
				"type": "SYSTEM_EXMONO-L"
			},
			"leftBay3": {
				"type": "SYSTEM_EXMONO-L"
			},
			"middleLeft": {
				"type": "SYSTEM_PDMWG"
			},
			"middleRight": {
				"type": "SYSTEM_PDMWG"
			},
			"rightBay1": {
				"type": "SYSTEM_DND_HAUL"
			},
			"rightBay2": {
				"type": "SYSTEM_EXMONO-R"
			},
			"rightBay3": {
				"type": "SYSTEM_EXMONO-R"
			}
		}
	},
	{
		"ammo": {
			"capacity": 0,
			"initial": 0
		},
		"autopilot": {
			"type": "SYSTEM_AUTOPILOT_RTYPE"
		},
		"aux": {
			"power": "SYSTEM_NONE"
		},
		"capacitor": {
			"capacity": 1500
		},
		"cargo": {
			"equipment": "SYSTEM_CARGO_MPUFSO"
		},
		"drones": {
			"capacity": 50000.0,
			"initial": 50000.0
		},
		"fuel": {
			"capacity": 500000,
			"initial": 500000
		},
		"hud":{
			"type": "SYSTEM_HUD_AT225"
		},
		"drone": {
			"scanner": "SYSTEM_RD_SPECTROMETER"
		},
		"lidar": {
			"type": "SYSTEM_LIDAR_DOPPLER"
		},
		"propulsion": {
			"main": "SYSTEM_MAIN_ENGINE_K44",
			"rcs": "SYSTEM_THRUSTER_NDSTR"
		},
		"reactor": {
			"power": 30
		},
		"turbine": {
			"power": 500
		},
		"weaponSlot": {
			"leftBay1":{
				"type": "SYSTEM_DND_HAUL"
			},
			"leftBay2": {
				"type": "SYSTEM_EXSTORAGE-L"
			},
			"leftBay3": {
				"type": "SYSTEM_EXSTORAGE-L"
			},
			"middleLeft": {
				"type": "SYSTEM_PDMWG"
			},
			"middleRight": {
				"type": "SYSTEM_PDMWG"
			},
			"rightBay1": {
				"type": "SYSTEM_DND_HAUL"
			},
			"rightBay2": {
				"type": "SYSTEM_EXSTORAGE-R"
			},
			"rightBay3": {
				"type": "SYSTEM_EXSTORAGE-R"
			}
		}
	}
	],
	"OCP209": [
	{
		"ammo":{
			"capacity":0,
			"initial":0
		},
		"autopilot":{
			"type":"SYSTEM_AUTOPILOT_MK3"
		},
		"aux":{
			"power":"SYSTEM_AUX_SMES"
		},
		"capacitor":{
			"capacity":1000
		},
		"cargo":{
			"equipment":"SYSTEM_CARGO_MPUSML"
		},
		"drone":{
			"scanner":"SYSTEM_RD_SPECTROMETER"
		},
		"drones":{
			"capacity":10000,
			"initial":10000
		},
		"fuel":{
			"capacity":200000,
			"initial":200000
		},
		"hud":{
			"type":"SYSTEM_HUD_OCP209"
		},
		"lidar":{
			"type":"SYSTEM_LIDAR_DOPPLER_HIRES"
		},
		"propulsion":{
			"main":"SYSTEM_MAIN_ENGINE_DFMPD2205",
			"rcs":"SYSTEM_THRUSTER_K69V"
		},
		"reactor":{
			"power":30
		},
		"turbine":{
			"power":200
		},
		"weaponSlot":{
			"mainLeft":{
				"type":"SYSTEM_SALVAGE_ARM"
			},
			"mainRight":{
				"type":"SYSTEM_SALVAGE_ARM"
			},
			"middleLeft":{
				"type":"SYSTEM_DND_HAUL"
			},
			"middleRight":{
				"type":"SYSTEM_ACL200P"
			}
		}
	},
	{
		"ammo":{
			"capacity":0,
			"initial":0
		},
		"autopilot":{
			"type":"SYSTEM_AUTOPILOT_MK3"
		},
		"aux":{
			"power":"SYSTEM_AUX_SMES"
		},
		"capacitor":{
			"capacity":1000
		},
		"cargo":{
			"equipment":"SYSTEM_CARGO_MPUSML"
		},
		"drone":{
			"scanner":"SYSTEM_RD_SPECTROMETER"
		},
		"drones":{
			"capacity":10000,
			"initial":10000
		},
		"fuel":{
			"capacity":200000,
			"initial":200000
		},
		"hud":{
			"type":"SYSTEM_HUD_OCP209"
		},
		"lidar":{
			"type":"SYSTEM_LIDAR_DOPPLER_HIRES"
		},
		"propulsion":{
			"main":"SYSTEM_MAIN_ENGINE_DFMPD2205",
			"rcs":"SYSTEM_THRUSTER_K44"
		},
		"reactor":{
			"power":40
		},
		"turbine":{
			"power":200
		},
		"weaponSlot":{
			"mainLeft":{
				"type":"SYSTEM_SALVAGE_ARM"
			},
			"mainRight":{
				"type":"SYSTEM_SALVAGE_ARM"
			},
			"middleLeft":{
				"type":"SYSTEM_DND_HAUL"
			},
			"middleRight":{
				"type":"SYSTEM_ACL200P"
			}
		}
	}
	],
	"PROSPECTOR-BALD":[
	{
		"ammo":{
			"capacity":5000,
			"initial":5000
		},
		"autopilot":{
			"type":"SYSTEM_AUTOPILOT_RTYPE"
		},
		"aux":{
			"power":"SYSTEM_AUX_MPD_MK2"
		},
		"capacitor":{
			"capacity":1500
		},
		"cargo":{
			"equipment":"SYSTEM_CARGO_MPU_FAB"
		},
		"drone":{
			"scanner":"SYSTEM_RD_STANDARD"
		},
		"drones":{
			"capacity":10000,
			"initial":10000
		},
		"fuel":{
			"capacity":50000,
			"initial":50000
		},
		"hud":{
			"type":"SYSTEM_HUD_OCP209"
		},
		"lidar":{
			"type":"SYSTEM_LIDAR_DOPPLER_HIRES"
		},
		"propulsion":{
			"main":"SYSTEM_MAIN_ENGINE_NPMP",
			"rcs":"SYSTEM_THRUSTER_K69V"
		},
		"reactor":{
			"power":50
		},
		"turbine":{
			"power":500
		},
		"weaponSlot":{
			"leftDrone":{
				"type":"SYSTEM_DND_FIX"
			},
			"rightDrone":{
				"type":"SYSTEM_DND_FIX"
			},
			"middleLeft":{
				"type":"SYSTEM_RAILTOR"
			},
			"middleRight":{
				"type":"SYSTEM_MWG"
			}
		}
	},
	{
		"ammo":{
			"capacity":0,
			"initial":0
		},
		"autopilot":{
			"type":"SYSTEM_AUTOPILOT_RTYPE"
		},
		"aux":{
			"power":"SYSTEM_AUX_MPD_MK3"
		},
		"capacitor":{
			"capacity":1500
		},
		"cargo":{
			"equipment":"SYSTEM_CARGO_MPU_FAB"
		},
		"drone":{
			"scanner":"SYSTEM_RD_STANDARD"
		},
		"drones":{
			"capacity":10000,
			"initial":10000
		},
		"fuel":{
			"capacity":200000,
			"initial":200000
		},
		"hud":{
			"type":"SYSTEM_HUD_OCP209"
		},
		"lidar":{
			"type":"SYSTEM_LIDAR_DOPPLER_HIRES"
		},
		"propulsion":{
			"main":"SYSTEM_MAIN_ENGINE_EIZAP",
			"rcs":"SYSTEM_THRUSTER_K69V"
		},
		"reactor":{
			"power":50
		},
		"turbine":{
			"power":500
		},
		"weaponSlot":{
			"leftDrone":{
				"type":"SYSTEM_DND_FIX"
			},
			"rightDrone":{
				"type":"SYSTEM_DND_FIX"
			},
			"middleLeft":{
				"type":"SYSTEM_DND_FIX"
			},
			"middleRight":{
				"type":"SYSTEM_DND_FIX"
			}
		}
	}
	]
}

# var additionalShipType = {
#	"PROSPECTOR-VP":"TRTL"
#	}
#	configAlias.merge(additionalShipType)
