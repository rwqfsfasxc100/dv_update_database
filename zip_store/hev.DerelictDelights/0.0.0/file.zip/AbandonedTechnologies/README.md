# Abandoned Technologies
Fill the rings with life and find the secrets of old and new tech.

> [!WARNING]
> HevLib is required for this mod to function.
> A download can be found from it's [releases page](https://github.com/rwqfsfasxc100/HevLib/releases/latest)

[![ko-fi](https://ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/M4M01L6LMF)

This mod currently adds:
* NPC miners now can utilize all TNTRL variants (except the K44), Cothon variants, Eagle variants, AT-K225 variants (except modified variant), OCP-209, and the Kitsune.
* New ship configs for the dealership, NPC, and derelict ships.
* Added a new container variant: the THI Interlunar Container, rogue form can be found randomly in the rings and be sold by pirates too.
* Experimental Interplanetary containers can be found randomly in the rings, which may contain some loot for capturing them.
* Several variants of the NT Companions, with the mike replaced with other tools, to swapping out the grinders, and even adding in an MPU 
* More dialogue options for random crew interactions.
* The Ganymedeans have started to take use of the Eagle Prospectors they've been stockpiling, and using them with the more powerful equipment they have taken from piracy.
* The Ganymedeans now have a chance to sell a ship other than the default 3 (K37, Eagle Prospector, Cothon-212). As a result to the increase in ship opportunities, the weight to be offered an ore container has been increased sevenfold, and the weights for the vanilla 3 ship offers have been increased fourfold each, resulting in a 50.6/49.4 container-to-ship offer ratio.
* You can more rarely find monocargo containers filled with ore, being a much higher risk-reward with higher highs and lower lows. Pirates also occasionally sell these.
* Vilcy utilize their contracts with Obonto Habitats to put their point defence turrets on Titans, and use them in extreme cases of caution.
* You can now ask a container to supply a new one nearby, at a cost of course.
* Empty, inert containers can be found in the rings.
* You can find a new Habitat, SRA-08, under construction in the rings.
* Added a new crew agenda: the Historian
* Questline with the historian unlocks the interplanetary line of cargo container
* Fully configurable from a config with mod menu

## NOTES
1. If you have any suggestions for this mod, please feel free to comment on the mod's [Discord thread](https://discord.com/channels/426287934870781952/1316256288329699419). If you want to suggest a new ship loadout configuration, check out [this Google form here](https://forms.gle/yzvbGmaWeHWH9ChK8), and it should give you a quick dropdown selection for each equipment on a ship to save time and not clog up the Discord channel.
2. The K225 and K225-BB's THICCs act similarly to Rogue THICCs. Even the cargo containers have opted to include the NT Companions' work ethic.

## Derelict Spawn Chances
Check [this wiki page](https://delta-v.kodera.pl/index.php/Profit_Strategy_-_Derelicts#Finding_Derelicts_in_the_Wild) for further understanding on how derelicts spawn, as some of these values may seem misleading as to what they do.
* Bald Eagle:
  *   Spawn Chance: 15%
  *   Minimum Chance: 1%
  *   Money Ceiling: 2 million E$

## Planned Additions
* Expanding Historian questline and other interactions
* Expanding Vilcy & G4A encounters
* Adding new storylines
