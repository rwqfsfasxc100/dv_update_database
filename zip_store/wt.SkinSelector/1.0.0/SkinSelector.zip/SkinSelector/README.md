# Skin Selector

Apply custom paint jobs to individual ships in your fleet.

> [!WARNING]
> This mod requires HevLib to function.
> Download it from the [HevLib releases page](https://github.com/rwqfsfasxc100/HevLib/releases/latest).

## Features

- **Per-Ship Skins**: Assign different paint jobs to each ship, even for ships of the same model.
- **Dedicated Folders**: Store PNG skins in `user://skins/<model>/`.

## How to Add Skins

1. Open the Tuning menu at Enceladus Prime.
2. Select the **Paint** row.
3. Click the **Folder** button to open the skin folder for your ship model.
4. Copy your custom `.png` skin files into this folder.
5. Click the **Refresh** button in the Tuning menu to update the list.
6. Select your skin from the dropdown list.
