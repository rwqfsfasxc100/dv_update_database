# This translation file is generated automatically
# Do not modify anything directly, as this will cause the file to break for translators
# Please use Translation Tracker to modify these yourself, and contact the mod author to implement them
# https://github.com/rwqfsfasxc100/TranslationTracker/releases/latest

# [license]
# 3-Clause BSD NON-AI License
# 
# Copyright 2026 WT (Oleksandr Hladyr)
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, the training of, or improvment of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form in an AI-training dataset is considered a breach of this License.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# 
# [/license]

const TRANSLATIONS = {
	"master_locale": "en",
	"en": {
		"SKIN_SELECTOR_TITLE": {
			"string": "Paint Job",
			"version_hash": 2037503132
		},
		"SKIN_SELECTOR_HULL_PAINT": {
			"string": "Paint",
			"version_hash": 232629889
		},
		"SKIN_SELECTOR_DEFAULT": {
			"string": "<Default>",
			"version_hash": 1418266308
		},
		"SKIN_SELECTOR_LEGACY": {
			"string": "<Legacy>",
			"version_hash": 2827157812
		},
		"SKIN_SELECTOR_OPEN_FOLDER": {
			"string": "Folder",
			"version_hash": 3007164545
		},
		"SKIN_SELECTOR_REFRESH": {
			"string": "Refresh",
			"version_hash": 2666929716
		},
		"SKIN_SELECTOR_DESC": {
			"string": "Apply custom paint jobs to individual ships in your fleet.\n\n[center][u]Features:[/u][/center]\n\n * [b]Per-Ship Skins[/b] - Assign different paint jobs to each ship, even for ships of the same model.\n * [b]Dedicated Folders[/b] - Store PNG skins in [code]user://skins/<model>/[/code].\n\n[center][u]How to Add Skins:[/u][/center]\n\n 1. Open the Tuning menu at Enceladus Prime.\n 2. Select the [b]Paint[/b] row.\n 3. Click the [b]Folder[/b] button to open the skin folder for your ship model.\n 4. Copy your custom [code].png[/code] skin files into this folder.\n 5. Click the [b]Refresh[/b] button in the Tuning menu to update the list.\n 6. Select your skin from the dropdown list.",
			"version_hash": 1624898190
		},
		"SKIN_SELECTOR_BRIEF": {
			"string": "Custom paint job selector for individual ships.",
			"version_hash": 1119311357
		}
	},
	"uk_UA": {
		"SKIN_SELECTOR_TITLE": {
			"string": "ЛІВРЕЯ",
			"version_hash": 2037503132
		},
		"SKIN_SELECTOR_HULL_PAINT": {
			"string": "Фарбування корпусу",
			"version_hash": 232629889
		},
		"SKIN_SELECTOR_DEFAULT": {
			"string": "<За замовчуванням>",
			"version_hash": 1418266308
		},
		"SKIN_SELECTOR_LEGACY": {
			"string": "<Класичний>",
			"version_hash": 2827157812
		},
		"SKIN_SELECTOR_OPEN_FOLDER": {
			"string": "Папка",
			"version_hash": 3007164545
		},
		"SKIN_SELECTOR_REFRESH": {
			"string": "Оновити",
			"version_hash": 2666929716
		},
		"SKIN_SELECTOR_DESC": {
			"string": "Застосування користувацьких скінів для окремих кораблів у вашому флоті.\n\n[center][u]Особливості:[/u][/center]\n\n * [b]Скіни для кожного корабля[/b] - Призначайте різні лівреї кожному кораблю, навіть для однакових моделей.\n * [b]Окремі папки[/b] - Зберігайте PNG-скіни у [code]user://skins/<model>/[/code].\n\n[center][u]Як додати скін:[/u][/center]\n\n 1. Відкрийте меню Тюнінгу на станції Енцелад Прайм.\n 2. Оберіть рядок [b]Фарбування корпусу[/b].\n 3. Натисніть кнопку [b]Папка[/b], щоб відкрити папку скінів для моделі вашого корабля.\n 4. Скопіюйте ваші файли скінів [code].png[/code] у цю папку.\n 5. Натисніть кнопку [b]Оновити[/b] у меню тюнінгу, щоб оновити список.\n 6. Оберіть ваш скін зі списку.",
			"version_hash": 1624898190
		},
		"SKIN_SELECTOR_BRIEF": {
			"string": "Вибір скінів для окремих кораблів.",
			"version_hash": 1119311357
		}
	}
}