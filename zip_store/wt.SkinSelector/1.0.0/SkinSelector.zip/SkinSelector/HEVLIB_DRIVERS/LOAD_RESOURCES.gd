const LOAD_RESOURCES = {
	"ships/Hull.gd": {
		"load_type": "script"
	},
	"enceladus/Tuning.gd": {
		"load_type": "script"
	}
}
