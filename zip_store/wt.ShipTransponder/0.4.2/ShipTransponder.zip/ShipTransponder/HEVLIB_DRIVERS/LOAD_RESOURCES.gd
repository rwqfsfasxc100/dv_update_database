const LOAD_RESOURCES = {
	"hud/ShipList.gd": {"load_type": "script", "onready": false},
}
