# [license]
# 3-Clause BSD NON-AI License
# 
# Copyright 2026 __hev (Benjamin Buckhurst)
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

extends Popup

var current_save_slot = "user://savegame.dv"

onready var text_template = TranslationServer.translate("VP_SAVE_INFO_TEMPLATE")

func show_menu(slot,button):
	current_save_slot = slot
	get_data()
	handle_save()
	popup_centered()

func cancel():
	hide()
	refocus()

var lastFocus = null
func refocus():
	if lastFocus and lastFocus.has_method("grab_focus"):
		lastFocus.grab_focus()
	else:
		Debug.l("I have no focus to fall back to!")
var items_node_path = "VB/MarginContainer/ScrollContainer/MarginContainer/Items"
var equipment_names = []
var ship_names = []

func _about_to_show():
	
	lastFocus = get_focus_owner()


func _confirmed():
	cancel()

func get_data():
	var equipment = load("res://enceladus/Upgrades.tscn").instance()
	
	var cv = equipment.get_node(items_node_path).get_children()
	for slot in cv:
		var children = slot.get_node("VBoxContainer").get_children()
		if children.size() <= 1:
			continue
		for i in children:
			var ename = ""
			if "system" in i:
				if "nameOverride" in i and i.nameOverride != "":
					ename = i.nameOverride
				else:
					ename = i.system
			if ename != "" and not ename in equipment_names:
				equipment_names.append(ename)
	Tool.remove(equipment)
	
	
	for ship in Shipyard.ships:
		var s = Shipyard.ships[ship].instance()
		var sname = s.shipName
		if not sname in ship_names:
			ship_names.append(sname)
		Tool.remove(s)

func handle_save():
	
	
	var offset_time = Time.get_unix_time_from_datetime_dict({"year":0})
	var data = getSave(current_save_slot)
	var datetime = data.get("time",0)
	var date = Time.get_datetime_string_from_unix_time(datetime,true)
	var gamestart = CurrentGame.getGameStartTime()
	var diff = datetime - gamestart + offset_time
	var time = str(Time.get_datetime_string_from_unix_time(diff,true)).lstrip(str(0))
	var time_concat = "%s hours %s minutes %s seconds"
	var date_concat = "%s years %s months %s days"
	var elapsed_split = time.split(" ")
	var elapsed_date_split = elapsed_split[0].split("-")
	var elapsed_time_split = elapsed_split[1].split(":")
	for f in range(elapsed_date_split.size()):
		var val = int(elapsed_date_split[f])
		if val:
			elapsed_date_split[f] = str(val)
		else:
			elapsed_date_split[f] = str(0)
		pass
	for f in range(elapsed_time_split.size()):
		var val = int(elapsed_time_split[f])
		if val:
			elapsed_time_split[f] = str(val)
		else:
			elapsed_time_split[f] = str(0)
		pass
	var crew = data.get("crew",{}).size()
	var owned_ships = data.get("garage",{}).size() + 1
	var money = data.get("money",0.0)
	var insurance = data.get("insurance",0.0)
	var sseed = data.get("seed",0)
	var playtime = data.get("playtime",{})
	var playtime_display = ""
	var playtime_dict = {}
	var playtime_array = []
	for item in playtime:
		var i = playtime[item]
		var pt = get_minutes(i)
		playtime_dict.merge({item:pt})
		playtime_array.append(item)
	playtime_array.sort()
	var ships = []
	var equipment = []
	var misc = []
	for p in playtime_array:
		var d = playtime_dict[p]
		if p in equipment_names:
			equipment.append("    " + TranslationServer.translate(p) + ": " + d + "\n")
		elif p in ship_names:
			ships.append("    " + TranslationServer.translate(p) + ": " + d + "\n")
		else:
			misc.append("    " + TranslationServer.translate(p) + ": " + d + "\n")
	var ships_display = ""
	var equipment_display = ""
	var misc_display = ""
	for i in ships:
		ships_display = ships_display + i
	
	for i in equipment:
		equipment_display = equipment_display + i
	
	for i in misc:
		misc_display = misc_display + i
	
	var display = text_template % [str(date),date_concat % [elapsed_date_split[0],elapsed_date_split[1],elapsed_date_split[2]] + " " + time_concat % [elapsed_time_split[0],elapsed_time_split[1],elapsed_time_split[2]],str(CurrentGame.formatThousands(int(money))),str(CurrentGame.formatThousands(int(insurance))),str(crew),str(owned_ships),str(sseed),ships_display,equipment_display,misc_display]
	
	
	$PanelContainer/VBoxContainer/ScrollContainer/Label.text = display
	pass
func get_minutes(time):
	var minute_indicator = TranslationServer.translate("VP_MINUTES_INDICATOR")
	var hour_indicator = TranslationServer.translate("VP_HOURS_INDICATOR")
	var hour_temp = Time.get_unix_time_from_datetime_dict({"hour":1})
	var timeconcat = round(time/60.0)
	var minutes = int(timeconcat) % 60
	var hours = floor(timeconcat / 60)
	
	
	
	
	
	return hour_indicator % hours + " " + minute_indicator % minutes
func getSave(file):
	var f = File.new()
	if f.file_exists(file):
		f.open_encrypted_with_pass(file, File.READ, "FTWOMG")
		var sg = f.get_line()
		var savedState = parse_json(sg)
		f.close()
		return savedState
