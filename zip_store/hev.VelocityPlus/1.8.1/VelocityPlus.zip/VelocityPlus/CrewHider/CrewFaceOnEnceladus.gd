# [license]
# 3-Clause BSD NON-AI License
# 
# Copyright 2026 __hev (Benjamin Buckhurst)
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

extends "res://enceladus/CrewFaceOnEnceladus.gd"

var vac_tex
var vc:StreamTexture = StreamTexture.new()

func _enter_tree():
	vc.load_path = "res://VelocityPlus/CrewHider/vaccover.stex"
	yield(CurrentGame.get_tree(),"idle_frame")
	vac_tex = get_node_or_null("C/O/Face/Sprite").material.get_shader_param("mask")
	
	var pointersVP:HevLibPointers = ModLoader._savedObjects[0]
	pointersVP.ConfigDriver.__subscribe_to_setting_change("vp_hide_crew",self,"VelocityPlus","VP_CREW","hide_on_enceladus")
	pointersVP.ConfigDriver.__subscribe_to_setting_change("vp_hide_vac",self,"VelocityPlus","VP_CREW","hide_crew_suit")
	vp_hide_crew(pointersVP.ConfigDriver.__get_value("VelocityPlus","VP_CREW","hide_on_enceladus",false))
	vp_hide_vac(pointersVP.ConfigDriver.__get_value("VelocityPlus","VP_CREW","hide_crew_suit",false))

func vp_hide_crew(how:bool):
	visible = how

func vp_hide_vac(how:bool):
	if how:
		get_node_or_null("C/O").position = Vector2(120,100)
		get_node_or_null("C/O/Face/Sprite").z_index = 2
		get_node_or_null("C/O/Face/Sprite").material.set_shader_param("mask",vc)
		get_node_or_null("C/O/Vac").visible = false
		get_node_or_null("C/O/Screen2").texture_scale = 50
		get_node_or_null("C/O/Screen2").energy = 2.19
		get_node_or_null("C/O/Screen2").color = Color( "bebebe" )
		get_node_or_null("C/O/Screen3").energy = 0.0
		get_node_or_null("C/O/Screen3").visible = false
	else:
		get_node_or_null("C/O").position = Vector2(120,0)
		get_node_or_null("C/O/Face/Sprite").z_index = 1
		get_node_or_null("C/O/Face/Sprite").material.set_shader_param("mask",vac_tex)
		get_node_or_null("C/O/Vac").visible = true
		get_node_or_null("C/O/Screen2").texture_scale = 4.34
		get_node_or_null("C/O/Screen2").energy = 4.05
		get_node_or_null("C/O/Screen2").color = Color( "e1a023" )
		get_node_or_null("C/O/Screen3").energy = 5.9
		get_node_or_null("C/O/Screen3").visible = true
