# [license]
# 3-Clause BSD NON-AI License
# 
# Copyright 2026 __hev (Benjamin Buckhurst)
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

extends Node
var ship
var thrusterObject

var pointers:HevLibPointers._ConfigDriver

func _init(p,s,o):
	ship = s
	thrusterObject = o
	pointers = p
	pointers.__subscribe_to_setting_change("a1",self,"VelocityPlus","VP_SHIPS","adjust_thrust_to_temperature")
	pointers.__subscribe_to_setting_change("a2",self,"VelocityPlus","VP_SHIPS","adjust_thrust_nullify_thermal")
	a1(pointers.__get_value("VelocityPlus","VP_SHIPS","adjust_thrust_to_temperature",false))
	a2(pointers.__get_value("VelocityPlus","VP_SHIPS","adjust_thrust_nullify_thermal",false))

func a1(how:bool):
	adjust_thrust_to_temperature = how
func a2(how:bool):
	adjust_thrust_nullify_thermal = how

var adjust_thrust_to_temperature:bool = false
var adjust_thrust_nullify_thermal:bool = false

var deltaTime:float = 0.0
func _physics_process(delta:float):
	if adjust_thrust_to_temperature and adjust_thrust_nullify_thermal:
		deltaTime = delta


func drawThermal(how,what):
	if adjust_thrust_to_temperature and adjust_thrust_nullify_thermal:
		return ship.drawThermal(how * (thrusterObject.avgTarget / float(thrusterObject.temp)),what)
	return ship.drawThermal(how,what)

func sensorGet(sensor):
	return ship.sensorGet(sensor)

var ageWithSeed = 0 setget _setAgeWithSeed , _getAgeWithSeed
var dummy = false setget _setDummy , _getDummy
var damageLimit = 0.35 setget _setDamageLimit , _getDamageLimit
var inside = 0 setget _setInside , _getInside
var setup = false setget _setSetup , _getSetup
var frozen = null setget _setFrozen , _getFrozen
var shock = 0.0 setget _setShock , _getShock
var physicsExclude = [] setget _setPhysicsExclude , _getPhysicsExclude
var escapeCutscene = false setget _setEscapeCutscene , _getEscapeCutscene
var faction = "civilian" setget _setFaction, _getFaction
var linear_velocity = Vector2.ZERO setget _setLV, _getLV
var reactors = [] setget _setReactors , _getReactors
var rotation = 0.0 setget _setRotation , _getRotation

func _setRotation(how):
	rotation = how
	ship.rotation = how
func _getRotation():
	if ship: rotation = ship.rotation
	else: rotation = 0.0
	return rotation

func _setReactors(how):
	reactors = how
	ship.reactors = how
func _getReactors():
	if ship: reactors = ship.reactors
	else: reactors = []
	return reactors

func _setLV(how):
	linear_velocity = how
	ship.linear_velocity = how
func _getLV():
	if ship: linear_velocity = ship.linear_velocity
	else: linear_velocity = Vector2.ZERO
	return linear_velocity

func _setFaction(how):
	faction = how
	ship.faction = how
func _getFaction():
	if ship: faction = ship.faction
	else: faction = "civilian"
	return faction

func _setEscapeCutscene(how):
	escapeCutscene = how
	ship.escapeCutscene = how
func _getEscapeCutscene():
	if ship: escapeCutscene = ship.escapeCutscene
	else: escapeCutscene = false
	return escapeCutscene

func _setPhysicsExclude(how):
	physicsExclude = how
	ship.physicsExclude = how
func _getPhysicsExclude():
	if ship: physicsExclude = ship.physicsExclude
	else: physicsExclude = []
	return physicsExclude

func _setShock(how):
	shock = how
	ship.shock = how
func _getShock():
	if ship: shock = ship.shock
	else: shock = 0.0
	return shock

func _getAgeWithSeed():
	if ship: ageWithSeed = ship.ageWithSeed
	else: ageWithSeed = 0
	return ageWithSeed
func _setAgeWithSeed(how:int):
	ageWithSeed = how
	ship.ageWithSeed = how

func _setDummy(how:bool):
	dummy = how
	ship.dummy = how
func _getDummy():
	if ship: dummy = ship.dummy
	else: dummy = false
	return dummy

func _setDamageLimit(how:float):
	damageLimit = how
	ship.damageLimit = how
func _getDamageLimit():
	if ship: damageLimit = ship.damageLimit
	else: damageLimit = 0.35
	return damageLimit

func _setSetup(how:bool):
	setup = how
	ship.setup = how
func _getSetup():
	if ship: setup = ship.setup
	else: setup = false
	return setup

func _setFrozen(how):
	frozen = how
	ship.frozen = how
func _getFrozen():
	if ship: frozen = ship.frozen
	else: frozen = null
	return frozen

func _setInside(how:int):
	inside = how
	ship.inside = how
func _getInside():
	if ship: inside = ship.inside
	else: inside = 0
	return inside


func getTunedValue(where,which,how):
	return ship.getTunedValue(where,which,how)

func getSystemDamage(where,which):
	return ship.getSystemDamage(where, which)

func getCrewAdjustedJuryRigFactorForSystem(where,which):
	return ship.getCrewAdjustedJuryRigFactorForSystem(where,which)

func changeSystemDamage(where,which,how,by):
	return ship.changeSystemDamage(where,which,how,by)

func has_method(what):
	return ship.has_method(what)

func get_parent():
	return ship.get_parent()

func connect(how: String,to: Object,out: String,params : Array = [], binds : int = 0) -> int:
	return ship.connect(how,to,out,params,binds)

func isPlayerControlled() -> bool:
	return ship.isPlayerControlled()

func getAgeYears():
	return ship.getAgeYears()

func takeProcessedCargo(which,what,how) : 
	return ship.takeProcessedCargo(which,what,how)

func get_world_2d():
	return ship.get_world_2d()

func drawEnergy(much):
	return ship.drawEnergy(much)

func drawReactiveMass(how):
	return ship.drawReactiveMass(how)

func isRealShip():
	return ship.isRealShip()

func apply_impulse(how,much):
	return ship.apply_impulse(how,much)
