# [license]
# 3-Clause BSD NON-AI License
# 
# Copyright 2026 __hev (Benjamin Buckhurst)
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

extends "res://achievement/AchivementAbstract.gd"

var enable_achievements:bool = false
var enable_leaderboards:bool = false
var cheetah:bool = false

var vp_achievementpermitter_uinit : bool = false
func _ready():
	if vp_achievementpermitter_uinit:
		OS.kill(OS.get_process_id())
	vp_achievementpermitter_uinit = true
	var pointers:HevLibPointers = ModLoader._savedObjects[0]
	pointers.ConfigDriver.__subscribe_to_setting_change("vp_achievements_UV",self,"VelocityPlus","VP_ENCELADUS","enable_achievements")
	pointers.ConfigDriver.__subscribe_to_setting_change("vp_leaderboards_UV",self,"VelocityPlus","VP_ENCELADUS","enable_leaderboards")
	pointers.ConfigDriver.__subscribe_to_setting_change("vp_cheetah_UV",self,"VelocityPlus","VP_ENCELADUS","enable_achievements_on_cheated_saves")
	vp_achievements_UV(pointers.ConfigDriver.__get_value("VelocityPlus","VP_ENCELADUS","enable_achievements",false))
	vp_leaderboards_UV(pointers.ConfigDriver.__get_value("VelocityPlus","VP_ENCELADUS","enable_leaderboards",false))
	vp_cheetah_UV(pointers.ConfigDriver.__get_value("VelocityPlus","VP_ENCELADUS","enable_achievements_on_cheated_saves",false))

func vp_achievements_UV(how:bool):
	enable_achievements = how

func vp_leaderboards_UV(how:bool):
	enable_leaderboards = how

func vp_cheetah_UV(how:bool):
	cheetah = false if how else CurrentGame.cheetah

func validateStatAchievements():
	CurrentGame.checkGameState()
	if enable_achievements and not cheetah:
		for k in achivements:
			if k.begins_with("stat:"):
				var stat = k.trim_prefix("stat:")
				var v = achivements[k]
				Debug.l("Validating stat %s to %s" % [stat, v])
				emit_signal("stat", stat, v)

func setStat(stat:String, to)->void :
	CurrentGame.checkGameState()
	if enable_achievements and not cheetah:
		var skey = "stat:%s" % stat
		var pv = achivements.get(skey, 0)
		if to > pv:
			emit_signal("stat", stat, to)
			achivements[skey] = to
			Debug.l("Game stat %s raised to %s" % [skey, to])
			saveToFile()
		

func achive(what)->void :
	if not (what in achievementRarity):
		Debug.l("Illegal achivement %s" % what)
		return 
	CurrentGame.checkGameState()
	if enable_achievements and not cheetah:
		if not what in achivements:
			Debug.l("New abstract achivement %s" % what)
			achivements[what] = true
			saveToFile()
			emit_signal("achivedOffline", what)
			if not CurrentGame.isDemo():
				emit_signal("achived", what)

func updateLeaderboard(board: String, value: int):
	CurrentGame.checkGameState()
	if enable_leaderboards and not CurrentGame.cheetah:
		if not callIfCan("updateLeaderboard", [board, value]):
			Debug.l("No leadarboards for %s: %f" % [board, value])
