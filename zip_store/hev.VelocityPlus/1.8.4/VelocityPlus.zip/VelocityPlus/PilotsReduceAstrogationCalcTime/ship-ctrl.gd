# [license]
# SPDX-License-Identifier: LicenseRef-Proprietary
# Copyright © 2026 __hev (Benjamin Buckhurst). All Rights Reserved.
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that all following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

extends "res://ships/ship-ctrl.gd"

func _enter_tree():
	var pointersVP_pilots_reduce_astro_calc_time:HevLibPointers._ConfigDriver = ModLoader._savedObjects[0].ConfigDriver
	pointersVP_pilots_reduce_astro_calc_time.__subscribe_to_setting_change("vp_do_reduce_calc_UV",self,"VelocityPlus","VP_CREW","pilots_reduce_astro_calculations")
	pointersVP_pilots_reduce_astro_calc_time.__subscribe_to_setting_change("vp_min_time_UV",self,"VelocityPlus","VP_CREW","minimum_astrogation_time")
	pointersVP_pilots_reduce_astro_calc_time.__subscribe_to_setting_change("vp_max_time_UV",self,"VelocityPlus","VP_CREW","maximum_astrogation_time")
	pointersVP_pilots_reduce_astro_calc_time.__subscribe_to_setting_change("vp_skill_bias_UV",self,"VelocityPlus","VP_CREW","pilot_skill_bias")
	vp_do_reduce_calc = pointersVP_pilots_reduce_astro_calc_time.__get_value("VelocityPlus","VP_CREW","pilots_reduce_astro_calculations",true)
	vp_min_time = pointersVP_pilots_reduce_astro_calc_time.__get_value("VelocityPlus","VP_CREW","minimum_astrogation_time",3.0)
	vp_max_time = pointersVP_pilots_reduce_astro_calc_time.__get_value("VelocityPlus","VP_CREW","maximum_astrogation_time",10.0)
	vp_skill_bias = pointersVP_pilots_reduce_astro_calc_time.__get_value("VelocityPlus","VP_CREW","pilot_skill_bias",0.3)

var vp_pilotsreduceadrenalinehandler_uinit : bool = false
func _ready():
	if vp_pilotsreduceadrenalinehandler_uinit:
		ModLoader._savedObjects[0].log_double_load_error(get_script().resource_path)
	vp_pilotsreduceadrenalinehandler_uinit = true
	vp_modify_crew_skill()
	CurrentGame.connect("xpChanged",self,"vp_modify_crew_skill")

var vp_do_reduce_calc:bool = true
var vp_min_time:float = 3.0
var vp_max_time:float = 10.0
var vp_skill_bias:float = 0.3

func vp_do_reduce_calc_UV(how:bool):
	vp_do_reduce_calc = how
	vp_modify_crew_skill()

func vp_min_time_UV(how:float):
	vp_min_time = how
	vp_modify_crew_skill()

func vp_max_time_UV(how:float):
	vp_max_time = how
	vp_modify_crew_skill()

func vp_skill_bias_UV(how:float):
	vp_skill_bias = how
	vp_modify_crew_skill()

func vp_modify_crew_skill():
	if vp_do_reduce_calc:
		var education:float = 0.0
		var experience:float = 0.0
		for crew in CurrentGame.getCurrentlyActiveCrewNames():
			var dta:Dictionary = CurrentGame.state.crew[crew]
			if dta["occupation"] == "CREW_OCCUPATION_PILOT":
				var ex:float = dta["experience"]
				var tal:float = dta["talent"]
				if ex > experience:
					experience = ex
				if tal > education:
					education = tal
		
		trajectoryTime = clamp(lerp(vp_min_time,vp_max_time,(vp_max_time - (lerp(education,experience,vp_skill_bias) * vp_max_time))/vp_max_time),vp_min_time,vp_max_time)
