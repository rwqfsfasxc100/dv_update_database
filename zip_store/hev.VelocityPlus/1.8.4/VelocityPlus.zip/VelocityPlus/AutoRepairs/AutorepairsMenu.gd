# [license]
# SPDX-License-Identifier: LicenseRef-Proprietary
# Copyright © 2026 __hev (Benjamin Buckhurst). All Rights Reserved.
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that all following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

extends Popup

export (NodePath) var enable_p = NodePath("PanelContainer/VBoxContainer/ScrollContainer/VBoxContainer/EnableAutorepair/CheckButton")
onready var enable = get_node_or_null(enable_p)
export (NodePath) var mode_button_p = NodePath("PanelContainer/VBoxContainer/ScrollContainer/VBoxContainer/MethodPrio/OptionButton")
onready var mode_button = get_node_or_null(mode_button_p)

export (NodePath) var minmoney_p = NodePath("PanelContainer/VBoxContainer/ScrollContainer/VBoxContainer/MinMoney/HSlider")
onready var minmoney = get_node_or_null(minmoney_p)

export (NodePath) var mininsurance_p = NodePath("PanelContainer/VBoxContainer/ScrollContainer/VBoxContainer/MinInsurance/HSlider")
onready var mininsurance = get_node_or_null(mininsurance_p)

export (NodePath) var maxrepair_p = NodePath("PanelContainer/VBoxContainer/ScrollContainer/VBoxContainer/MaxRepair/HSlider")
onready var maxrepair = get_node_or_null(maxrepair_p)

export (NodePath) var maxreplace_p = NodePath("PanelContainer/VBoxContainer/ScrollContainer/VBoxContainer/MaxReplace/HSlider")
onready var maxreplace = get_node_or_null(maxreplace_p)

export (NodePath) var target_p = NodePath("PanelContainer/VBoxContainer/ScrollContainer/VBoxContainer/Target/HSlider")
onready var target = get_node_or_null(target_p)

var pointersVP:HevLibPointers

func vp_autorepairsmenu_VP():
	if pointersVP:
		config = pointersVP.ConfigDriver.__get_config("VelocityPlus")

func _enter_tree():
	pointersVP = ModLoader._savedObjects[0]
	pointersVP.ConfigDriver.__establish_connection("vp_autorepairsmenu_VP",self)
	vp_autorepairsmenu_VP()

var config:Dictionary = {}
func _ready():
	mode_button.add_item("VP_AUTOREPAIR_PRIORITY_COSTEFFECTIVE",0)
	mode_button.add_item("VP_AUTOREPAIR_PRIORITY_ONLYREPAIR",1)
	mode_button.add_item("VP_AUTOREPAIR_PRIORITY_ONLYREPLACE",2)
	mode_button.add_item("VP_AUTOREPAIR_PRIORITY_MAXPROFIT",3)

enum{
	VP_AUTOREPAIR_PRIORITY_COSTEFFECTIVE,
	VP_AUTOREPAIR_PRIORITY_ONLYREPAIR,
	VP_AUTOREPAIR_PRIORITY_ONLYREPLACE,
	VP_AUTOREPAIR_PRIORITY_MAXPROFIT,
}

func _visibility_changed():
	if is_visible_in_tree():
		enable.pressed = config["VP_AUTOREPAIRS"]["automatic_repairs"]
		
		mode_button.selected = config["VP_AUTOREPAIRS"]["repair_method_priority"]
		yield(get_tree(),"idle_frame")
		set_slider_val(config["VP_AUTOREPAIRS"]["minimum_money"],minmoney,"PanelContainer/VBoxContainer/ScrollContainer/VBoxContainer/MinMoney/Val",true)
		set_slider_val(config["VP_AUTOREPAIRS"]["minimum_insurance"],mininsurance,"PanelContainer/VBoxContainer/ScrollContainer/VBoxContainer/MinInsurance/Val",true)
		set_slider_val(config["VP_AUTOREPAIRS"]["maximum_repair"],maxrepair,"PanelContainer/VBoxContainer/ScrollContainer/VBoxContainer/MaxRepair/Val",true)
		set_slider_val(config["VP_AUTOREPAIRS"]["maximum_replace"],maxreplace,"PanelContainer/VBoxContainer/ScrollContainer/VBoxContainer/MaxReplace/Val",true)
		set_slider_val(config["VP_AUTOREPAIRS"]["target_percent"],target,"PanelContainer/VBoxContainer/ScrollContainer/VBoxContainer/Target/Val",true)

var code_changed:Array = []

func set_slider_val(val,s,v,code = false):
	if code:
		code_changed.append(s)
	s.value = val
	get_node(v).text = str(val)
	yield(get_tree(),"idle_frame")
	if code:
		code_changed.erase(s)

func save_slider_val(val,s,opt,v):
	if not s in code_changed:
		pointersVP.ConfigDriver.__store_value("VelocityPlus","VP_AUTOREPAIRS",opt,val)
		get_node(v).text = str(val)

var lastFocus = null
func refocus():
	if lastFocus and lastFocus.has_method("grab_focus"):
		lastFocus.grab_focus()
	else:
		Debug.l("I have no focus to fall back to!")

func _about_to_show():
	lastFocus = get_focus_owner()
	

func _input(event):
	if visible:
		if Input.is_action_just_pressed("ui_cancel") or Input.is_action_just_pressed("pause"):
			cancel()
			get_tree().set_input_as_handled()

func show_menu():
	popup_centered()

func cancel():
	hide()
	refocus()


func enabled_toggle(button_pressed):
	pointersVP.ConfigDriver.__store_value("VelocityPlus","VP_AUTOREPAIRS","automatic_repairs",button_pressed)


func method_select(index):
	pointersVP.ConfigDriver.__store_value("VelocityPlus","VP_AUTOREPAIRS","repair_method_priority",index)


func minmoney_changed(value):
	save_slider_val(value,minmoney,"minimum_money","PanelContainer/VBoxContainer/ScrollContainer/VBoxContainer/MinMoney/Val")


func mininsurance_changed(value):
	save_slider_val(value,mininsurance,"minimum_insurance","PanelContainer/VBoxContainer/ScrollContainer/VBoxContainer/MinInsurance/Val")


func maxrepair_changed(value):
	save_slider_val(value,maxrepair,"maximum_repair","PanelContainer/VBoxContainer/ScrollContainer/VBoxContainer/MaxRepair/Val")


func maxreplace_changed(value):
	save_slider_val(value,maxreplace,"maximum_replace","PanelContainer/VBoxContainer/ScrollContainer/VBoxContainer/MaxReplace/Val")


func target_changed(value):
	save_slider_val(value,target,"target_percent","PanelContainer/VBoxContainer/ScrollContainer/VBoxContainer/Target/Val")
