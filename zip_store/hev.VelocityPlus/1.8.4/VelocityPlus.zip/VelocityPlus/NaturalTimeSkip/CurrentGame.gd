# [license]
# SPDX-License-Identifier: LicenseRef-Proprietary
# Copyright © 2026 __hev (Benjamin Buckhurst). All Rights Reserved.
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that all following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

extends "res://CurrentGame.gd"

var file:File = File.new()
var vp_naturaltimeskiphandler_uinit : bool = false
func _ready():
	if vp_naturaltimeskiphandler_uinit:
		ModLoader._savedObjects[0].log_double_load_error(get_script().resource_path)
	vp_naturaltimeskiphandler_uinit = true
	var pointersVP_natural_time_skip:HevLibPointers._ConfigDriver = ModLoader._savedObjects[0].ConfigDriver
	pointersVP_natural_time_skip.__subscribe_to_setting_change("vp_natural_time_skip_UV",self,"VelocityPlus","VP_ENCELADUS","natural_time_skip")
	natural_time_skip = pointersVP_natural_time_skip.__get_value("VelocityPlus","VP_ENCELADUS","natural_time_skip",true)

func vp_natural_time_skip_UV(how:bool):
	natural_time_skip = how

var natural_time_skip:bool = true

func loadFromFile():
	var age:int = OS.get_unix_time() - file.get_modified_time(saveFile)
	.loadFromFile()
	if natural_time_skip:
		yieldTimeSkip(age)
	
func yieldTimeSkip(age):
	yield(Tool.makeTimer(3, self), "timeout")
	Debug.l("Natural Time Skip: save is %s old, advancing by %s seconds" % [timeToString(age),age])
	advanceTimeBySeconds(age)
	for c in getCrew():
		while shouldPayWages(c) and canAffordSalary(c):
			paySalary(c)
