# [license]
# 3-Clause BSD NON-AI License
# 
# Copyright 2026 __hev (Benjamin Buckhurst)
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
# in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products
# derived from this software without specific prior written permission.
# 
# 4. The source code and the binary form, and any modifications made to them may not be used for the purpose of input data, reference code snippets and/or files, OR used in the training of, or improvement of machine learning algorithms,
# including but not limited to artificial intelligence, natural language processing, or data mining. This condition applies to any derivatives,
# modifications, or updates based on the Software code. Any usage of the source code or the binary form may not be present in any form as data fed, inputted, or provided to an AI, or present in any AI-training dataset is considered a breach of this License.
# 
# 5. Any projects deriving work from this project MUST include a copy of this license and all other license and/or copyright agreements posed within other source material,
# all of which must be followed to its entirety. Failure to follow these licenses prohibit all modification and redistribution of the material until all licensing has been reinstated.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# [/license]

extends "res://enceladus/Tuning.gd"

var pointersVP:HevLibPointers


func vp_tuning_UV():
	if pointersVP:
		toggle_systems_at_enceladus = pointersVP.ConfigDriver.__get_value("VelocityPlus","VP_SHIPS","toggle_systems_at_enceladus")

var toggle_systems_at_enceladus = false
var omsToggleCfg = "omstoggles.%s.%s"
onready var systemLabel = load("res://VelocityPlus/ToggleSystemsAtEnceladus/EnabledSystem.tscn")
onready var systemTitle = load("res://VelocityPlus/ToggleSystemsAtEnceladus/EnabledItems.tscn")

func fillTuneableSystems():
	.fillTuneableSystems()
	if toggle_systems_at_enceladus:
		var node = get_node(itemsNodePath)
		if Tool.claim(ship):
			if not ship.setup:
				yield(ship,"setup")
			var systems = ship.getSystems()
			if not "omstoggles" in ship.shipConfig:
				ship.shipConfig.merge({"omstoggles":{}})
			var oms = ship.shipConfig["omstoggles"]
			node.add_child(systemTitle.instance())
			for system in systems:
				var sys = systems[system]
				var vname = sys.name
				if sys.togleable:
					var pos = null
					if "position" in sys.ref:
						pos = ship.get_path_to(sys.ref)
					var current = ship.getConfig(omsToggleCfg % [system,vname],true)
					ship.setConfig(omsToggleCfg % [system,vname],current)
					var label = systemLabel.instance()
					label.tuningItem = vname
					label.tune = current
					label.connect("value_changed",self,"handleOMSToggle",[system,vname,pos])
					node.add_child(label)
			Tool.release(ship)
	yield(get_tree(),"idle_frame")
	set_draw(false,false)

func handleOMSToggle(how,opt,system,pos):
	descriptionLabel.text = ""
	var ps = CurrentGame.getPlayerShip()
	var current = ps.getConfig(omsToggleCfg % [opt,system],true)
	ps.setConfig(omsToggleCfg % [opt,system],how)
	testProtocol = "hide"
	ship.forceHud = false
	ship.preheat = false
	ship.autopilot = false
	ship.autopilotComfort = false
	ship.autopilotComfortEnabled = false
	ship.autopilot = false
	camera.zoom = Vector2(1, 1)
	shipParams.visible = false
	charts.visible = false
	lidar.visible = false
	if Tool.claim(ship):
		ship.shipConfig = CurrentGame.getPlayerShipConfig().config
		ship.setConfig(omsToggleCfg % [opt,system],how)
		Tool.release(ship)
	if current != how:
		Tool.deferCallInPhysics(self, "addShip")
	set_draw(true,true,pos)

onready var tex_rect = $VB/WindowMargin/Window/VP/TextureRect

func _enter_tree():
	pointersVP = ModLoader._savedObjects[0]
	pointersVP.ConfigDriver.__establish_connection("vp_tuning_UV",self)
	vp_tuning_UV()

var vp_toggleequipmentsysposdisplay_uinit : bool = false
func _ready():
	if vp_toggleequipmentsysposdisplay_uinit:
		OS.kill(OS.get_process_id())
	vp_toggleequipmentsysposdisplay_uinit = true
	tex_rect.set_script(load("res://VelocityPlus/ToggleSystemsAtEnceladus/tex_rect_draw.gd"))

func tuningChanged(system, type, to, protocol):
	.tuningChanged(system, type, to, protocol)
	set_draw(false,false)

func set_draw(how,object_position,obj = null):
	if tex_rect.do_draw != how or ((tex_rect.obj_pos == true or object_position == true) and obj != tex_rect.obj):
		tex_rect.obj_pos = object_position
		tex_rect.obj = obj
		tex_rect.ship = getShip()
		tex_rect.do_draw = how
		tex_rect.update()

